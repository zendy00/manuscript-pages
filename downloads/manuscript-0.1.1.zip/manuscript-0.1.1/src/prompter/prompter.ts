/**
 * Prompter popup window logic.
 *
 * - URL: src/prompter/prompter.html?tabId=N (background가 채워줌)
 * - chrome.storage.local의 prompterState를 읽고 onChanged로 실시간 반영
 * - 버튼 클릭 → chrome.tabs.sendMessage(tabId, { type: 'prompter.cmd', cmd })
 *   로 content script에 명령 전송
 */

import { STORAGE_KEYS } from '../lib/constants';
import {
  initI18n,
  onLanguageChanged,
  t,
} from '../lib/i18n';
import {
  getTtsEnabled,
  onTtsEnabledChanged,
  setTtsEnabled,
} from '../lib/tts';

interface PrompterStepInfo {
  name: string;
  description: string;
  autoAdvanceMs?: number | null;
  waitForNavigation?: boolean;
  thumbnailDataUrl?: string | null;
}

interface PrompterState {
  scenarioId: string;
  scenarioName?: string;
  currentIndex: number;
  total: number;
  paused: boolean;
  current: PrompterStepInfo | null;
  next: PrompterStepInfo | null;
  steps?: Array<{ name: string }>;
}

type Cmd = 'prev' | 'next' | 'pause' | 'jump';

document.addEventListener('DOMContentLoaded', () => {
  void init();
});

async function init(): Promise<void> {
  await initI18n();
  applyI18n();
  onLanguageChanged(() => {
    applyI18n();
    void renderFromStorage();
  });
  bindCommands();
  await renderFromStorage();
  await initTts();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const ch = changes[STORAGE_KEYS.prompterState];
    if (!ch) return;
    const next = ch.newValue as PrompterState | undefined;
    if (next) render(next);
  });
}

function applyI18n(): void {
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n]')) {
    const key = el.getAttribute('data-i18n');
    if (key) el.textContent = t(key);
  }
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n-aria]')) {
    const key = el.getAttribute('data-i18n-aria');
    if (key) el.setAttribute('aria-label', t(key));
  }
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n-title]')) {
    const key = el.getAttribute('data-i18n-title');
    if (key) el.setAttribute('title', t(key));
  }
}

async function initTts(): Promise<void> {
  await renderTtsToggle();
  onTtsEnabledChanged(() => {
    void renderTtsToggle();
  });
}

const SPEAKER_ON = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`;
const SPEAKER_OFF = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`;

async function renderTtsToggle(): Promise<void> {
  const enabled = await getTtsEnabled();
  const btn = document.querySelector<HTMLButtonElement>('[data-region="tts-toggle"]');
  if (!btn) return;
  btn.setAttribute('aria-pressed', String(enabled));
  btn.classList.toggle('active', enabled);
  const icon = btn.querySelector<HTMLElement>('[data-region="tts-icon"]');
  if (icon) icon.innerHTML = enabled ? SPEAKER_ON : SPEAKER_OFF;
}


async function renderFromStorage(): Promise<void> {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.prompterState);
    const state = raw[STORAGE_KEYS.prompterState] as PrompterState | undefined;
    if (state) render(state);
  } catch (err) {
    console.warn('[manuscript] prompter load failed', err);
  }
}

// Progress fill is recreated only when the step changes or the user
// resumes from pause; otherwise the running animation would snap back
// to zero on every storage push (counter refresh, step name edit, etc).
let lastStepIndex = -1;
let lastPaused = false;

function render(state: PrompterState): void {
  // Window title 에 시나리오 이름을 끼워 발표 도중 어느 manuscript 인지
  // 한눈에 보이게 한다.
  const baseTitle = t('prompter.title');
  document.title = state.scenarioName ? `${state.scenarioName} · ${baseTitle}` : baseTitle;

  const counter = document.querySelector('[data-region="counter"]');
  if (counter) counter.textContent = `${state.currentIndex + 1} / ${state.total}`;

  renderStepColumn('now', state.current, state.currentIndex + 1);
  renderStepColumn(
    'next',
    state.next,
    state.next ? state.currentIndex + 2 : null,
  );
  renderProgress(state);
  renderStepList(state);

  const pauseIcon = document.querySelector('[data-region="pause-icon"]');
  if (pauseIcon) pauseIcon.textContent = state.paused ? '▶' : 'II';

  const status = document.querySelector<HTMLElement>('[data-region="status"]');
  if (status) {
    status.textContent = state.paused ? t('prompter.paused') : t('prompter.playing');
    status.classList.toggle('paused', state.paused);
  }

  const prev = document.querySelector<HTMLButtonElement>('[data-cmd="prev"]');
  if (prev) prev.toggleAttribute('disabled', state.currentIndex <= 0);
  const next = document.querySelector<HTMLButtonElement>('[data-cmd="next"]');
  if (next) next.toggleAttribute('disabled', state.currentIndex >= state.total - 1);
}

function escapeHtml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function renderStepList(state: PrompterState): void {
  const list = document.querySelector<HTMLElement>('[data-region="step-list"]');
  if (!list) return;
  const steps = state.steps ?? [];
  list.innerHTML = steps
    .map((s, i) => {
      const label = s.name && s.name.length > 0 ? s.name : 'Step Name';
      const active = i === state.currentIndex ? ' class="active"' : '';
      return `<li${active} role="option" data-index="${i}" aria-selected="${i === state.currentIndex}" title="${escapeHtml(label)}"><span class="step-list-no">${i + 1}</span><span class="step-list-name">${escapeHtml(label)}</span></li>`;
    })
    .join('');
}

function renderProgress(state: PrompterState): void {
  const wrap = document.querySelector<HTMLElement>('[data-region="progress"]');
  if (!wrap) return;

  const info = state.current;
  const ms = info?.autoAdvanceMs ?? null;
  const visible = !!info && info.waitForNavigation !== true && ms !== null && ms > 0;

  if (!visible) {
    wrap.hidden = true;
    wrap.innerHTML = '';
    lastStepIndex = -1;
    lastPaused = false;
    return;
  }

  wrap.hidden = false;

  const stepChanged = state.currentIndex !== lastStepIndex;
  const resumedFromPause = lastPaused && !state.paused;
  const shouldRestart = stepChanged || resumedFromPause;
  lastStepIndex = state.currentIndex;
  lastPaused = state.paused;

  let fill = wrap.querySelector<HTMLElement>('.progress-fill');
  if (!fill || shouldRestart) {
    fill?.remove();
    fill = document.createElement('div');
    fill.className = 'progress-fill';
    fill.style.animationDuration = `${ms}ms`;
    wrap.appendChild(fill);
  }

  fill.classList.toggle('paused', state.paused);
}

function renderStepColumn(
  side: 'now' | 'next',
  info: PrompterStepInfo | null,
  stepNo: number | null,
): void {
  const stepNoEl = document.querySelector<HTMLElement>(`[data-region="${side}-no"]`);
  if (stepNoEl) stepNoEl.textContent = stepNo === null ? '' : t('prompter.step-no', { n: stepNo });

  const name = document.querySelector<HTMLElement>(`[data-region="${side}-name"]`);
  if (name) name.textContent = info?.name ?? '';

  const text = document.querySelector<HTMLElement>(`[data-region="${side}-text"]`);
  if (text) {
    text.textContent = info?.description ?? (side === 'now' ? t('prompter.waiting') : '');
  }

  const thumb = document.querySelector<HTMLImageElement>(`[data-region="${side}-thumb"]`);
  if (thumb) {
    if (info?.thumbnailDataUrl) {
      thumb.src = info.thumbnailDataUrl;
      thumb.hidden = false;
    } else {
      thumb.removeAttribute('src');
      thumb.hidden = true;
    }
  }

  const timer = document.querySelector<HTMLElement>(`[data-region="${side}-timer"]`);
  if (timer) {
    const ms = info?.autoAdvanceMs ?? null;
    if (info && !info.waitForNavigation && ms !== null && ms > 0) {
      const sec = Math.round(ms / 100) / 10;
      timer.textContent = `⏱ ${sec}s`;
      timer.hidden = false;
    } else {
      timer.hidden = true;
    }
  }

  const action = document.querySelector<HTMLElement>(`[data-region="${side}-action"]`);
  if (action) action.hidden = !info?.waitForNavigation;
}

function bindCommands(): void {
  document.querySelectorAll<HTMLButtonElement>('[data-cmd]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cmd = btn.getAttribute('data-cmd') as Cmd | null;
      if (!cmd) return;
      void sendCommand(cmd);
    });
  });

  // Step list — clicking an item jumps replay (or panel step) to that index.
  // Mirrors play-controller's step-jump popup behavior.
  const list = document.querySelector<HTMLElement>('[data-region="step-list"]');
  list?.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const li = target.closest<HTMLLIElement>('li[data-index]');
    if (!li) return;
    const i = Number(li.getAttribute('data-index'));
    if (Number.isFinite(i)) void sendCommand('jump', i);
  });

  // TTS toggle
  const ttsBtn = document.querySelector<HTMLButtonElement>('[data-region="tts-toggle"]');
  ttsBtn?.addEventListener('click', () => {
    void (async () => {
      const next = !(await getTtsEnabled());
      await setTtsEnabled(next);
    })();
  });

  // Keyboard shortcuts — match the play controller's bindings so the
  // prompter window can be driven without the mouse.
  //   ←  prev,  →  next,  Space  pause/play
  document.addEventListener('keydown', (event) => {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
      return;
    }
    switch (event.key) {
      case 'ArrowRight':
        event.preventDefault();
        void sendCommand('next');
        break;
      case 'ArrowLeft':
        event.preventDefault();
        void sendCommand('prev');
        break;
      case ' ':
      case 'Spacebar':
        event.preventDefault();
        void sendCommand('pause');
        break;
    }
  });
}

async function sendCommand(cmd: Cmd, index?: number): Promise<void> {
  try {
    // Background가 저장된 client tabId로 relay. popup이 직접 tabs.sendMessage
    // 하려면 host_permission 등 권한 이슈가 있어 background를 거친다.
    await chrome.runtime.sendMessage({ type: 'prompter.cmd', cmd, index });
  } catch (err) {
    console.warn('[manuscript] prompter command failed', err);
  }
}
