import{O as H,S as K,E as ya}from"./chunk-aRRa0OE6.js";import{s as go,g as xa,S as wa,a as Zn,b as bo,c as ka,d as Sa,e as Ea,m as Aa}from"./chunk-DPGwt5bL.js";import{t as b,i as Ma}from"./chunk-DAwYOt8I.js";import{g as vo,i as $a,a as La,b as yo,c as Ta,s as Ca,d as Ia,w as Pa,l as Da,e as Na,f as Ra}from"./chunk-Cr8au9ne.js";const Rn="manuscript:mode-changed";let Ce="idle";function ht(){return Ce}function P(t){if(t===Ce)return;const e=Ce;Ce=t,document.dispatchEvent(new CustomEvent(Rn,{detail:{prev:e,next:t}}))}function mt(t){const e=n=>t(n.detail);return document.addEventListener(Rn,e),()=>document.removeEventListener(Rn,e)}function xo(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),i=n*(1-e),a=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,u=0;switch(r){case 0:c=n,l=s,u=i;break;case 1:c=a,l=n,u=i;break;case 2:c=i,l=n,u=s;break;case 3:c=i,l=a,u=n;break;case 4:c=s,l=i,u=n;break;case 5:c=n,l=i,u=a;break}return[Math.round(c*255),Math.round(l*255),Math.round(u*255)]}function wo(t,e,n){const r=t/255,o=e/255,i=n/255,a=Math.max(r,o,i),s=Math.min(r,o,i),c=a-s;let l=0;return c!==0&&(a===r?l=(o-i)/c%6:a===o?l=(i-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:a===0?0:c/a,v:a}}function ko(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function So(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(i=>i+i).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(i=>!Number.isFinite(i))?{h:0,s:1,v:1}:wo(n,r,o)}function wn(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function kr(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function Oa(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const Fa=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function Ot(){return Fa.replace(/:root\s*\{/g,":host {")}const le="studio",Ha=140,za=140;function _a(){return`
    ${Ot()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${Ha}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${za}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function Ba(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function qa(){return[_a(),Ba()].join(`
`)}const On="manuscript:scenario-changed",ja=500,Wa=5e3,m={scenario:null,currentStepIndex:0,saveTimer:null};function I(){return m.scenario}function q(){return m.currentStepIndex}function Mt(){return m.scenario?m.scenario.steps[m.currentStepIndex]??null:null}function ue(t){return document.addEventListener(On,t),()=>document.removeEventListener(On,t)}function j(){document.dispatchEvent(new CustomEvent(On)),Ua()}function st(){m.scenario&&(m.scenario.updatedAt=new Date().toISOString())}function Eo(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Qn(){return{id:Eo("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:Wa,waitForNavigation:!1}}function Ua(){if(!m.scenario)return;m.saveTimer!==null&&window.clearTimeout(m.saveTimer);const t=m.scenario;m.saveTimer=window.setTimeout(()=>{m.saveTimer=null,go(t).catch(e=>{console.error("[manuscript] save failed",e)})},ja)}function an(){m.saveTimer!==null&&(window.clearTimeout(m.saveTimer),m.saveTimer=null,m.scenario&&go(m.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const Xa=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],Ya=8,Ga=5;function Va(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const a=Fn(e.getAttribute("content"));a&&t.add(a)}const n=getComputedStyle(document.documentElement);for(const a of Xa){const s=Fn(n.getPropertyValue(a));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:a,prop:s}of r)Sr(t,a,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let a=0;a<o.length&&a<Ga;a++)Sr(t,o[a]??null,"background-color");const i=Array.from(t).filter(Ka).slice(0,Ya);return{text:i,background:i}}function Sr(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Fn(r);o&&t.add(o)}function Fn(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],i=e[3];return`#${r}${r}${o}${o}${i}${i}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=kn(n[1]),i=kn(n[2]),a=kn(n[3]);return`#${Sn(o)}${Sn(i)}${Sn(a)}`}return null}function kn(t){return Math.max(0,Math.min(255,Number(t)|0))}function Sn(t){return t.toString(16).padStart(2,"0")}function Ka(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const i=Math.max(n,r,o),a=Math.min(n,r,o);return!(i-a<12)}const Za="'Asta Sans', sans-serif",Qa=6,Ja=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function ts(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const i=o.trim();if(!i)continue;const a=es(i);if(!a)continue;const s=a.toLowerCase();if(!Ja.has(s)&&!e.has(s)&&(e.add(s),n.push(ns(i)),n.length>=Qa))break}return n}function es(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function ns(t){return/asta\s*sans/i.test(t)?t:`${t}, ${Za}`}function Er(){an();const t=rs(),e=os();m.scenario={schemaVersion:wa,id:Eo("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[Qn()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},m.currentStepIndex=0,j()}function rs(){try{const t=Va();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function os(){try{return ts()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function Ar(t){an();const e=await xa(t);return e?(m.scenario=e,m.currentStepIndex=0,j(),!0):!1}function is(t){an(),m.scenario=t,m.currentStepIndex=0,j()}function as(t){if(!m.scenario)return;const e=t.trim();!e||e===m.scenario.name||(m.scenario.name=e,m.scenario.updatedAt=new Date().toISOString(),j())}function ss(){an(),m.scenario=null,m.currentStepIndex=0,j()}function Mr(t={}){if(!m.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>m.scenario.steps.length?m.scenario.steps.length:t.insertIndex;return m.scenario.steps.splice(e,0,Qn()),st(),m.currentStepIndex=e,j(),m.currentStepIndex}function Ut(t,e){if(!m.scenario)return;const n=m.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(st(),j())}function cs(t){const e=Mt();!e||!m.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,st(),j())}function ls(t){m.scenario&&(t<0||t>=m.scenario.steps.length||(m.scenario.steps.splice(t,1),m.scenario.steps.length===0?(m.scenario.steps.push(Qn()),m.currentStepIndex=0):m.currentStepIndex>=m.scenario.steps.length?m.currentStepIndex=m.scenario.steps.length-1:t<m.currentStepIndex&&(m.currentStepIndex-=1),st(),j()))}function Ft(t){m.scenario&&(t<0||t>=m.scenario.steps.length||t!==m.currentStepIndex&&(m.currentStepIndex=t,j()))}function us(t,e){if(!m.scenario||t===e||t<0||t>=m.scenario.steps.length||e<0||e>=m.scenario.steps.length)return;const[n]=m.scenario.steps.splice(t,1);n&&(m.scenario.steps.splice(e,0,n),m.currentStepIndex===t?m.currentStepIndex=e:t<m.currentStepIndex&&e>=m.currentStepIndex?m.currentStepIndex-=1:t>m.currentStepIndex&&e<=m.currentStepIndex&&(m.currentStepIndex+=1),st(),j())}function ds(t){const e=Mt();!e||!m.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),st(),j())}function de(t){const e=Mt();!e||!m.scenario||(e.annotations.push(t),st(),j())}function Ao(t){const e=Mt();!e||!m.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),st(),j())}function T(t,e){const n=Mt();!n||!m.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),st(),j())}function Mo(){var t;return((t=Mt())==null?void 0:t.annotations)??[]}function L(t){return Mo().find(e=>e.id===t)}function ps(t,e){if(!m.scenario)return;const n=e.trim();if(!n)return;const r=m.scenario.customColors??{},o=r[t]??[];o.includes(n)||(m.scenario.customColors={...r,[t]:[...o,n]},st(),j())}function fs(t,e){if(!m.scenario||!m.scenario.customColors)return;const n=m.scenario.customColors[t];!n||!n.includes(e)||(m.scenario.customColors={...m.scenario.customColors,[t]:n.filter(r=>r!==e)},st(),j())}function hs(){return`
    <style>${qa()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${ms()}
      ${gs()}
      ${bs()}
      ${vs()}
    </div>
  `}function ms(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function gs(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function bs(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function vs(){var i,a;const t=I(),e=((i=t==null?void 0:t.customColors)==null?void 0:i.text)??[],n=((a=t==null?void 0:t.customColors)==null?void 0:a.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${ye(s)}" style="background: ${ye(s)}" aria-label="Use ${ye(s)}" title="${ye(s)}"></button>`).join("")}</div>
    </div>
  `}function ye(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function ys(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let i=n.left;i+r.width>window.innerWidth-8&&(i=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,i)}px`}let X=null,O=null,kt=0,Pt=1,Dt=1,St=null;function xs(t){Nt(),St=t.onConfirm;const e=So(t.initialColor);kt=e.h,Pt=e.s,Dt=e.v,X=document.createElement("div"),X.setAttribute("data-manuscript","ui"),X.setAttribute("data-palette",le),X.style.cssText=["position: fixed",`z-index: ${H+7}`,"pointer-events: auto"].join("; "),O=X.attachShadow({mode:"open"}),O.innerHTML=hs(),ks(),document.body.appendChild(X),ys(X,t.anchor),pe(),document.addEventListener("mousedown",Lo,!0),document.addEventListener("keydown",To,!0)}function Nt(){X&&(document.removeEventListener("mousedown",Lo,!0),document.removeEventListener("keydown",To,!0),X.remove(),X=null,O=null,St=null)}function ws(){return X!==null}function pe(){if(!O)return;const t=O.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${kt}deg, 100%, 50%)`);const e=O.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Pt*100}%`,e.style.top=`${(1-Dt)*100}%`);const n=O.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${kt/360*100}%`);const[r,o,i]=xo(kt,Pt,Dt),a=ko(r,o,i),s=O.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${i})`);const c=O.querySelector('[data-region="hex"]');c&&(c.textContent=a),O.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===X&&O.activeElement===l)return;const u=l.dataset.channel;u==="r"?l.value=String(r):u==="g"?l.value=String(o):u==="b"&&(l.value=String(i))})}function $o(){const[t,e,n]=xo(kt,Pt,Dt);return ko(t,e,n)}function ks(){if(!O)return;const t=O.querySelector('[data-region="sv"]');t&&kr(t,n=>Ss(t,n));const e=O.querySelector('[data-region="hue"]');e&&kr(e,n=>Es(e,n)),O.addEventListener("input",n=>{var c,l,u;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=wn((c=O.querySelector('[data-channel="r"]'))==null?void 0:c.value),i=wn((l=O.querySelector('[data-channel="g"]'))==null?void 0:l.value),a=wn((u=O.querySelector('[data-channel="b"]'))==null?void 0:u.value),s=wo(o,i,a);kt=s.h,Pt=s.s,Dt=s.v,pe()}),O.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),i=o==null?void 0:o.getAttribute("data-action");if(i==="confirm")St==null||St($o()),Nt();else if(i==="eyedrop")Oa($r);else if(i==="recent"){const a=o==null?void 0:o.getAttribute("data-color");a&&$r(a)}})}function $r(t){const e=So(t);kt=e.h,Pt=e.s,Dt=e.v,pe()}function Ss(t,e){const n=t.getBoundingClientRect();Pt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Dt=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),pe()}function Es(t,e){const n=t.getBoundingClientRect();kt=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,pe()}function Lo(t){if(!X)return;const e=t.target;e instanceof HTMLElement&&X.contains(e)||Nt()}function To(t){t.key==="Escape"?(t.preventDefault(),Nt()):t.key==="Enter"&&(t.preventDefault(),St==null||St($o()),Nt())}const xe=8,_t=6,Co=32,Lr=16,we=4,Io=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function Tr(t,e,n,r){let{x:o,y:i,width:a,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,a-=n):(t==="ne"||t==="e"||t==="se")&&(a+=n),t==="nw"||t==="n"||t==="ne"?(i+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),a<_t&&(o=e.x+e.width-_t,a=_t),s<_t&&(i=e.y+e.height-_t,s=_t),{x:o,y:i,width:a,height:s}}function Po(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of t)i.x<e&&(e=i.x),i.y<n&&(n=i.y),i.x>r&&(r=i.x),i.y>o&&(o=i.y);return{x:e,y:n,width:r-e,height:o-n}}function As(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const M={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},N="http://www.w3.org/2000/svg";function Ms(){document.removeEventListener("mousemove",Jn,!0),document.removeEventListener("mouseup",tr,!0),document.removeEventListener("keydown",No,!0)}function $s(){document.addEventListener("keydown",No,!0)}function Ls(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=L(M.activeId);!n||n.kind!=="shape"||(M.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds}},sn())}function Ts(t){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const e=L(M.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;M.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},sn()}function Do(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=L(M.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,i=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;M.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:i},sn()}function Cs(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=L(M.activeId);if(!n||n.kind!=="freedraw")return;const r=Po(n.points);!r||r.width===0||r.height===0||(M.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...r},startPoints:n.points.map(o=>({...o}))},sn())}function sn(){document.addEventListener("mousemove",Jn,!0),document.addEventListener("mouseup",tr,!0)}function Jn(t){const{activeId:e,dragState:n}=M;if(!e||!n)return;t.preventDefault();const r=L(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,i=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const a=Tr(n.handle,n.startBounds,o,i);T(e,{bounds:a})}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const a=n.startBounds,s=Tr(n.handle,a,o,i),c=a.width===0?1:s.width/a.width,l=a.height===0?1:s.height/a.height,u=n.startPoints.map(f=>({x:s.x+(f.x-a.x)*c,y:s.y+(f.y-a.y)*l}));T(e,{points:u})}else if(n.kind==="rotate"){const a=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(a-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?T(e,{rotate:s}):r.kind==="freedraw"?T(e,{rotate:s}):r.kind==="text"&&T(e,{rotate:s})}}function tr(){document.removeEventListener("mousemove",Jn,!0),document.removeEventListener("mouseup",tr,!0),M.dragState=null}function No(t){var o;const{activeId:e}=M;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Ao(e);return}if(t.key.startsWith("Arrow")){const i=L(e);if(!i||i.kind!=="shape")return;const a=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-a:t.key==="ArrowRight"?a:0,c=t.key==="ArrowUp"?-a:t.key==="ArrowDown"?a:0;(s!==0||c!==0)&&(t.preventDefault(),T(e,{bounds:{...i.bounds,x:i.bounds.x+s,y:i.bounds.y+c}}))}}}function Ro(t,e,n,r,o){const i=document.createElementNS(N,"rect");return i.setAttribute("x",String(t-xe/2)),i.setAttribute("y",String(e-xe/2)),i.setAttribute("width",String(xe)),i.setAttribute("height",String(xe)),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),i.style.cursor=r,i.style.pointerEvents="auto",i.setAttribute("pointer-events","all"),i.addEventListener("mousedown",a=>o(a,n)),i}function Oo(t,e,n){const r=document.createElementNS(N,"g"),o=e-18,i=e-Co,a=12,s=document.createElementNS(N,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(N,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(i+1)),c.setAttribute("r",String(a)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(N,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(i)),l.setAttribute("r",String(a)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const u=t-8,f=i-8,d=document.createElementNS(N,"path");d.setAttribute("d",`M ${u+4} ${f+11} A 5 5 0 1 1 ${u+11} ${f+4}`),d.setAttribute("fill","none"),d.setAttribute("stroke","oklch(0.48 0.085 245)"),d.setAttribute("stroke-width","1.5"),d.setAttribute("stroke-linecap","round"),d.setAttribute("stroke-linejoin","round"),d.style.pointerEvents="none",r.appendChild(d);const p=document.createElementNS(N,"path");return p.setAttribute("d",`M ${u+11} ${f+1.5} L ${u+14} ${f+4} L ${u+11} ${f+6.5} Z`),p.setAttribute("fill","oklch(0.48 0.085 245)"),p.setAttribute("stroke","oklch(0.48 0.085 245)"),p.setAttribute("stroke-width","1.5"),p.setAttribute("stroke-linejoin","round"),p.style.pointerEvents="none",r.appendChild(p),l.addEventListener("mousedown",h=>n(h)),r}function er(t,e){const n=document.createElementNS(N,"g"),r=t.x-Lr,o=t.y-Lr;return n.appendChild(Is(r,o,e)),n}function Is(t,e,n){const r=document.createElementNS(N,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(N,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const i=document.createElementNS(N,"circle");i.setAttribute("cx",String(t)),i.setAttribute("cy",String(e)),i.setAttribute("r","12"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.92 0.008 240)"),i.setAttribute("stroke-width","1"),r.appendChild(i);const a=t-6,s=e-6,c=document.createElementNS(N,"path");return c.setAttribute("d",[`M ${a+1.5} ${s+3.5} L ${a+10.5} ${s+3.5}`,`M ${a+4.5} ${s+3.5} L ${a+4.5} ${s+2} L ${a+7.5} ${s+2} L ${a+7.5} ${s+3.5}`,`M ${a+3} ${s+3.5} L ${a+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${a+4.3} ${s+11} L ${a+7.7} ${s+11} A 0.8 0.8 0 0 0 ${a+8.5} ${s+10.5} L ${a+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function nr(t){const e=document.createElementNS(N,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function cn(){const{host:t,activeId:e,activeMode:n}=M;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=L(e);if(!r){Hn();return}if(n==="freedraw"&&r.kind==="freedraw"){Rs(t,r);return}if(n==="text"&&r.kind==="text"){Ns(t,r);return}if(r.kind!=="shape"){Hn();return}Ps(t,r)}function Ps(t,e){const n=e.bounds,r=e.rotate??0,o=n.x+n.width/2,i=n.y+n.height/2,a=document.createElementNS(N,"g");r&&a.setAttribute("transform",`rotate(${r} ${o} ${i})`),a.appendChild(nr(n));for(const s of Io){const{x:c,y:l}=s.offset(n);a.appendChild(Ro(c,l,s.name,s.cursor,Ls))}a.appendChild(Ds(n)),t.appendChild(a),t.appendChild(er(n,rr))}function Ds(t){const e=t.x+t.width/2,n=t.y-Co,r=document.createElementNS(N,"g"),o=document.createElementNS(N,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const i=document.createElementNS(N,"g");i.style.cursor="grab",i.style.pointerEvents="auto",i.setAttribute("pointer-events","all");const a=document.createElementNS(N,"circle");a.setAttribute("cx",String(e)),a.setAttribute("cy",String(n)),a.setAttribute("r","9"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),i.appendChild(a);const s=document.createElementNS(N,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",i.appendChild(s),i.addEventListener("mousedown",c=>Ts(c)),r.appendChild(i),r}function Ns(t,e){const n=As(e.id);if(!n)return;const r=Fo(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(nr(r)),t.appendChild(Oo(o,r.y,a=>Do(a,()=>({x:o,y:i})))),t.appendChild(er(r,rr))}function Rs(t,e){const n=Po(e.points);if(!n)return;const r=Fo(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(nr(r));for(const a of Io){if(a.name!=="nw"&&a.name!=="ne"&&a.name!=="sw"&&a.name!=="se")continue;const{x:s,y:c}=a.offset(r);t.appendChild(Ro(s,c,a.name,a.cursor,Cs))}t.appendChild(Oo(o,r.y,a=>Do(a,()=>({x:o,y:i})))),t.appendChild(er(r,rr))}function Fo(t){return{x:t.x-we,y:t.y-we,width:t.width+we*2,height:t.height+we*2}}function rr(){const t=M.activeId;t&&Ao(t)}function Os(t){const e=L(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const i=document.querySelectorAll(o);if(i.length===0)return;const a=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;i.forEach(s=>{s.style.animation=""}),i[0].getBoundingClientRect(),i.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${a}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function Fs(t){const e=L(t);!e||e.kind!=="shape"||(M.activeId=t,M.activeMode="shape",or(),cn())}function Hs(t){const e=L(t);!e||e.kind!=="freedraw"||(M.activeId=t,M.activeMode="freedraw",or(),cn())}function zs(t){const e=L(t);!e||e.kind!=="text"||(M.activeId=t,M.activeMode="text",or(),cn())}function Hn(){var t;M.host&&(Ms(),(t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,M.host.remove(),M.host=null,M.activeId=null,M.activeMode="shape",M.dragState=null)}function _s(t){return M.host!==null&&t!==null&&M.host.contains(t)}function or(){if(M.host)return;const t=document.createElementNS(N,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),M.host=t,$s(),M.unsubscribeScenario=ue(cn)}const Bs=400,qs=0;function js(t){return{kind:t,durationMs:Bs,delayMs:qs}}function Ws(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const Cr=10,Us=46,Ho=12,zo=36,_o=0,Bo=20,Xs=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],Ys=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],Gs=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}],Vs=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],A={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function gt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function qo(t){const e=A.activeId;if(!e)return;const n=L(e);n&&(n.kind==="text"?T(e,{style:{...n.style,color:t}}):n.kind==="shape"?T(e,{stroke:t}):n.kind==="freedraw"&&T(e,{stroke:t}))}function jo(t){const e=A.activeId;if(!e)return;const n=L(e);n&&(n.kind==="text"?T(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&T(e,{fill:t}))}function Wo(t){const e=A.activeId;if(!e)return;const n=L(e);!n||n.kind!=="text"||T(e,{style:{...n.style,borderColor:t}})}function Ks(t){const e=A.activeId;if(!e)return;const n=L(e);!n||n.kind!=="text"||T(e,{style:{...n.style,fontFamily:t}})}function Zs(t){const e=A.activeId;if(!e)return;const n=L(e);!n||n.kind!=="text"||T(e,{style:{...n.style,fontSize:t}})}function Qs(){const t=A.activeId;if(!t)return;const e=L(t);!e||e.kind!=="text"||T(t,{style:{...e.style,bold:!e.style.bold}})}function Js(){const t=A.activeId;if(!t)return;const e=L(t);!e||e.kind!=="text"||T(t,{style:{...e.style,italic:e.style.italic!==!0}})}function tc(t){const e=A.activeId;e&&T(e,{entryAnimation:t==="none"?void 0:js(t)})}function ec(t){const e=A.activeId;if(!e)return;const n=L(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?T(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?T(e,{fillOpacity:r}):n.kind==="freedraw"&&T(e,{strokeOpacity:r})}function nc(t){const e=A.activeId;if(!e)return;const n=L(e);n&&(n.kind==="shape"?T(e,{strokeWidth:t}):n.kind==="freedraw"&&T(e,{strokeWidth:t}))}function rc(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=a=>{r&&En(e,a.clientX)},i=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",i,!0)};n.addEventListener("mousedown",a=>{r=!0,En(e,a.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0),a.preventDefault()}),e.addEventListener("mousedown",a=>{const s=a.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(En(e,a.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0))})}function En(t,e){const n=t.getBoundingClientRect();ec(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function zn(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function oc(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function An(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function Mn(t,e,n){var l,u,f;const r=A.swatchMode==="muted"?Xs:Ys,o=[];if(n&&(t==="bg"||t==="border")){const d=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${d}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let d=0;d<r.length;d++){const p=r[d];if(!p)continue;const h=d===1,g=An(e,p.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${p.resolved}" style="background:${p.resolved}" aria-pressed="${g}" title="${t} ${p.resolved}"></button>
    `)}const i=I(),a=(t==="text"||t==="border"?(l=i==null?void 0:i.siteColors)==null?void 0:l.text:(u=i==null?void 0:i.siteColors)==null?void 0:u.background)??[];for(const d of a){const p=An(e,d);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${gt(d)}" style="background:${gt(d)}" aria-pressed="${p}" title="Site color ${gt(d)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((f=i==null?void 0:i.customColors)==null?void 0:f[s])??[];for(const d of c){const p=An(e,d);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${gt(d)}" style="background:${gt(d)}" aria-pressed="${p}" title="Custom ${gt(d)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${gt(d)}" title="Remove" aria-label="Remove color ${gt(d)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function ir(){const{shadow:t,activeId:e,activeKind:n}=A;if(!t||!e||!n)return;const r=L(e);if(!r||r.kind==="arrow")return;const o=r,i=t.querySelector('[data-region="caption"]');i&&(i.textContent=dc(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(a=>{const s=a.getAttribute("data-mode");a.setAttribute("aria-pressed",String(s===A.swatchMode))}),ic(t,n),ac(t,n,o),sc(t,n,o),cc(t,n,o),lc(t,o),uc(t,o)}function ic(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const i=t.querySelector('[data-region="width-row"]'),a=e==="shape"||e==="freedraw";i&&(i.hidden=!a);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const u=t.querySelector('[data-region="bg-label"]');u&&(u.textContent=e==="text"?"Bg":"Fill")}function ac(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const i=t.querySelector('[data-region="bold"]');i&&i.setAttribute("aria-pressed",String(n.style.bold));const a=t.querySelector('[data-region="italic"]');a&&a.setAttribute("aria-pressed",String(n.style.italic===!0))}function sc(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),i=n.strokeWidth;r&&(r.value=String(i)),o&&(o.textContent=String(i))}function cc(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),i=t.querySelector('[data-region="border-swatches"]'),a=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=zn(n,"text"),l=zn(n,"bg");if(r&&(r.innerHTML=Mn("text",c,!1)),o&&!(a!=null&&a.hidden)&&(o.innerHTML=Mn("bg",l,e==="text")),i&&!(s!=null&&s.hidden)&&n.kind==="text"){const u=n.style.borderColor??"#000000";i.innerHTML=Mn("border",u,!0)}}function lc(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=Ws(e))}function uc(t,e){const n=Math.round(oc(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),i=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),i&&(i.textContent=`${n}%`)}function dc(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function pc(t){const{shadow:e,host:n}=A;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>fc(o)),e.addEventListener("change",o=>hc(o)),e.addEventListener("input",o=>mc(o)),rc(),document.addEventListener("mousedown",o=>bc(o,t),!0),document.addEventListener("keydown",o=>vc(o,t),!0)}function fc(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(A.swatchMode=c,ir());return}if(e.closest('[data-region="bold"]'))return Qs();if(e.closest('[data-region="italic"]'))return Js();if(e.closest('[data-region="effect-play"]')){A.activeId&&Os(A.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return qo(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return jo(o.getAttribute("data-value")??"");const i=e.closest('[data-swatch="border"]');if(i)return Wo(i.getAttribute("data-value")??"");const a=e.closest('[data-action="more-colors"]');if(a instanceof HTMLElement)return gc(a);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&fs(c==="text"||c==="border"?"text":"background",l)}}function hc(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Ks(e.value):e.dataset.region==="effect"&&tc(e.value))}function mc(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(Ho,Math.min(zo,Number(e.value)||16));Zs(n)}else if(e.dataset.region==="width"){const n=Math.max(_o,Math.min(Bo,Number(e.value)||0));nc(n)}}}function gc(t){const{activeId:e,activeKind:n}=A;if(!e||!n)return;const r=L(e);if(!r||r.kind==="arrow")return;const o=r,i=t.getAttribute("data-slot");if(!i)return;const a=zn(o,i)||"#ffffff";xs({anchor:t,initialColor:a,onConfirm:s=>{ps(i==="text"||i==="border"?"text":"background",s),i==="text"?qo(s):i==="border"?Wo(s):jo(s)}})}function bc(t,e){const{host:n,activeAnchorSelector:r}=A,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||_s(o)||ws()||r&&o instanceof Element&&o.closest(r)||(e(),Nt())}function vc(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function Uo(t){const{host:e}=A;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-Cr-Us;o<8&&(o=r.bottom+Cr);const i=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${i}px`}function yc(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function xc(t,e){t==="text"?zs(e):t==="shape"?Fs(e):Hs(e)}function wc(){return`
    ${Ot()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function kc(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function Sc(){return[wc(),kc()].join(`
`)}function Ec(){return`
    <style>${Sc()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${Ac()}
      ${Mc()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${$c()}
      <div class="divider"></div>
      ${Lc()}
      ${Tc()}
      ${Cc()}
      ${Ic()}
    </div>
  `}function Ac(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function Mc(){return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Gs.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${Ho}" max="${zo}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function $c(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function Lc(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${_o}" max="${Bo}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function Tc(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Vs.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function Cc(){return`
    <div class="alpha-row">
      <span class="label">Alpha</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function Ic(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function ar(t,e,n){L(t)&&(A.activeId=t,A.activeKind=n,A.activeAnchorSelector=yc(n,t),A.host||Oc(),ir(),Uo(e),xc(n,t))}function sr(){var t;A.host&&((t=A.unsubscribeScenario)==null||t.call(A),A.unsubscribeScenario=null,Nt(),Hn(),A.host.remove(),A.host=null,A.shadow=null,A.activeId=null,A.activeKind=null,A.activeAnchorSelector=null)}function Pc(){return A.activeId}function Dc(t,e){ar(t,e,"text")}function Xo(){sr()}function Nc(t,e){ar(t,e,"shape")}function Rc(t,e){ar(t,e,"freedraw")}function Oc(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",le),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${H+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=Ec(),A.host=t,A.shadow=e,document.body.appendChild(t),pc(sr),A.unsubscribeScenario=ue(Fc)}function Fc(){const{activeId:t,host:e,activeAnchorSelector:n}=A;if(!t||!e)return;if(!L(t)){sr();return}if(ir(),n){const o=document.querySelector(n);o&&Uo(o)}}const pt=20;let Re=null,Ir=!1;function Hc(){Ir||(Ir=!0,document.addEventListener("keydown",Bc,!0)),zc()}async function zc(){try{const e=(await chrome.storage.local.get(K.annotationClipboard))[K.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(Re=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function _c(t){try{await chrome.storage.local.set({[K.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function Bc(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||ht()!=="replay"&&(qc()||(e==="c"?jc(t):Wc(t)))}function qc(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function jc(t){const e=Pc();if(!e)return;const n=L(e);n&&(Re=n,_c(n),t.preventDefault())}function Wc(t){if(!Re||!Mt())return;const e=Uc(Re);de(e),t.preventDefault()}function Uc(t){switch(t.kind){case"text":return Xc(t);case"shape":return Yc(t);case"freedraw":return Gc(t);case"arrow":return Vc(t)}}function Xc(t){return{...t,id:ln("text"),position:{x:t.position.x+pt,y:t.position.y+pt},style:{...t.style}}}function Yc(t){return{...t,id:ln("shape"),bounds:{...t.bounds,x:t.bounds.x+pt,y:t.bounds.y+pt}}}function Gc(t){return{...t,id:ln("freedraw"),points:t.points.map(e=>({x:e.x+pt,y:e.y+pt}))}}function Vc(t){return{...t,id:ln("arrow"),from:{x:t.from.x+pt,y:t.from.y+pt},to:{x:t.to.x+pt,y:t.to.y+pt}}}function ln(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function $n(t,e,n){if(t&&t.length){const[r,o]=e,i=Math.PI/180*n,a=Math.cos(i),s=Math.sin(i);for(const c of t){const[l,u]=c;c[0]=(l-r)*a-(u-o)*s+r,c[1]=(l-r)*s+(u-o)*a+o}}}function Kc(t,e){return t[0]===e[0]&&t[1]===e[1]}function Zc(t,e,n,r=1){const o=n,i=Math.max(e,.1),a=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of a)$n(l,s,o);const c=(function(l,u,f){const d=[];for(const y of l){const E=[...y];Kc(E[0],E[E.length-1])||E.push([E[0][0],E[0][1]]),E.length>2&&d.push(E)}const p=[];u=Math.max(u,.1);const h=[];for(const y of d)for(let E=0;E<y.length-1;E++){const z=y[E],R=y[E+1];if(z[1]!==R[1]){const C=Math.min(z[1],R[1]);h.push({ymin:C,ymax:Math.max(z[1],R[1]),x:C===z[1]?z[0]:R[0],islope:(R[0]-z[0])/(R[1]-z[1])})}}if(h.sort(((y,E)=>y.ymin<E.ymin?-1:y.ymin>E.ymin?1:y.x<E.x?-1:y.x>E.x?1:y.ymax===E.ymax?0:(y.ymax-E.ymax)/Math.abs(y.ymax-E.ymax))),!h.length)return p;let g=[],v=h[0].ymin,x=0;for(;g.length||h.length;){if(h.length){let y=-1;for(let E=0;E<h.length&&!(h[E].ymin>v);E++)y=E;h.splice(0,y+1).forEach((E=>{g.push({s:v,edge:E})}))}if(g=g.filter((y=>!(y.edge.ymax<=v))),g.sort(((y,E)=>y.edge.x===E.edge.x?0:(y.edge.x-E.edge.x)/Math.abs(y.edge.x-E.edge.x))),(f!==1||x%u==0)&&g.length>1)for(let y=0;y<g.length;y+=2){const E=y+1;if(E>=g.length)break;const z=g[y].edge,R=g[E].edge;p.push([[Math.round(z.x),v],[Math.round(R.x),v]])}v+=f,g.forEach((y=>{y.edge.x=y.edge.x+f*y.edge.islope})),x++}return p})(a,i,r);if(o){for(const l of a)$n(l,s,-o);(function(l,u,f){const d=[];l.forEach((p=>d.push(...p))),$n(d,u,f)})(c,s,-o)}return c}function fe(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let i=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(i=o),Zc(t,o,r,i||1)}class cr{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=fe(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function un(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Qc extends cr{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=fe(e,Object.assign({},n,{hachureGap:r})),i=Math.PI/180*n.hachureAngle,a=[],s=.5*r*Math.cos(i),c=.5*r*Math.sin(i);for(const[l,u]of o)un([l,u])&&a.push([[l[0]-s,l[1]+c],[...u]],[[l[0]+s,l[1]-c],[...u]]);return{type:"fillSketch",ops:this.renderLines(a,n)}}}class Jc extends cr{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),i=this._fillPolygons(e,o);return r.ops=r.ops.concat(i.ops),r}}class tl{constructor(e){this.helper=e}fillPolygons(e,n){const r=fe(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let i=n.fillWeight;i<0&&(i=n.strokeWidth/2);const a=o/4;for(const s of e){const c=un(s),l=c/o,u=Math.ceil(l)-1,f=c-u*o,d=(s[0][0]+s[1][0])/2-o/4,p=Math.min(s[0][1],s[1][1]);for(let h=0;h<u;h++){const g=p+f+h*o,v=d-a+2*Math.random()*a,x=g-a+2*Math.random()*a,y=this.helper.ellipse(v,x,i,i,n);r.push(...y.ops)}}return{type:"fillSketch",ops:r}}}class el{constructor(e){this.helper=e}fillPolygons(e,n){const r=fe(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,i=[];return e.forEach((a=>{const s=un(a),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let u=a[0],f=a[1];u[0]>f[0]&&(u=a[1],f=a[0]);const d=Math.atan((f[1]-u[1])/(f[0]-u[0]));for(let p=0;p<c;p++){const h=p*(r+o),g=h+r,v=[u[0]+h*Math.cos(d)+l*Math.cos(d),u[1]+h*Math.sin(d)+l*Math.sin(d)],x=[u[0]+g*Math.cos(d)+l*Math.cos(d),u[1]+g*Math.sin(d)+l*Math.sin(d)];i.push(...this.helper.doubleLineOps(v[0],v[1],x[0],x[1],n))}})),i}}class nl{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,i=fe(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(i,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((i=>{const a=un(i),s=Math.round(a/(2*n));let c=i[0],l=i[1];c[0]>l[0]&&(c=i[1],l=i[0]);const u=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let f=0;f<s;f++){const d=2*f*n,p=2*(f+1)*n,h=Math.sqrt(2*Math.pow(n,2)),g=[c[0]+d*Math.cos(u),c[1]+d*Math.sin(u)],v=[c[0]+p*Math.cos(u),c[1]+p*Math.sin(u)],x=[g[0]+h*Math.cos(u+Math.PI/4),g[1]+h*Math.sin(u+Math.PI/4)];o.push(...this.helper.doubleLineOps(g[0],g[1],x[0],x[1],r),...this.helper.doubleLineOps(x[0],x[1],v[0],v[1],r))}})),o}}const U={};class rl{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const ol=0,Ln=1,Pr=2,ke={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Tn(t,e){return t.type===e}function lr(t){const e=[],n=(function(a){const s=new Array;for(;a!=="";)if(a.match(/^([ \t\r\n,]+)/))a=a.substr(RegExp.$1.length);else if(a.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:ol,text:RegExp.$1},a=a.substr(RegExp.$1.length);else{if(!a.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:Ln,text:`${parseFloat(RegExp.$1)}`},a=a.substr(RegExp.$1.length)}return s[s.length]={type:Pr,text:""},s})(t);let r="BOD",o=0,i=n[o];for(;!Tn(i,Pr);){let a=0;const s=[];if(r==="BOD"){if(i.text!=="M"&&i.text!=="m")return lr("M0,0"+t);o++,a=ke[i.text],r=i.text}else Tn(i,Ln)?a=ke[r]:(o++,a=ke[i.text],r=i.text);if(!(o+a<n.length))throw new Error("Path data ended short");for(let c=o;c<o+a;c++){const l=n[c];if(!Tn(l,Ln))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof ke[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=a,i=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function Yo(t){let e=0,n=0,r=0,o=0;const i=[];for(const{key:a,data:s}of t)switch(a){case"M":i.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],i.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":i.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],i.push({key:"L",data:[e,n]});break;case"C":i.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":i.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":i.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],i.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":i.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],i.push({key:"H",data:[e]});break;case"V":i.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],i.push({key:"V",data:[n]});break;case"S":i.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":i.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],i.push({key:"T",data:[e,n]});break;case"Z":case"z":i.push({key:"Z",data:[]}),e=r,n=o}return i}function Go(t){const e=[];let n="",r=0,o=0,i=0,a=0,s=0,c=0;for(const{key:l,data:u}of t){switch(l){case"M":e.push({key:"M",data:[...u]}),[r,o]=u,[i,a]=u;break;case"C":e.push({key:"C",data:[...u]}),r=u[4],o=u[5],s=u[2],c=u[3];break;case"L":e.push({key:"L",data:[...u]}),[r,o]=u;break;case"H":r=u[0],e.push({key:"L",data:[r,o]});break;case"V":o=u[0],e.push({key:"L",data:[r,o]});break;case"S":{let f=0,d=0;n==="C"||n==="S"?(f=r+(r-s),d=o+(o-c)):(f=r,d=o),e.push({key:"C",data:[f,d,...u]}),s=u[0],c=u[1],r=u[2],o=u[3];break}case"T":{const[f,d]=u;let p=0,h=0;n==="Q"||n==="T"?(p=r+(r-s),h=o+(o-c)):(p=r,h=o);const g=r+2*(p-r)/3,v=o+2*(h-o)/3,x=f+2*(p-f)/3,y=d+2*(h-d)/3;e.push({key:"C",data:[g,v,x,y,f,d]}),s=p,c=h,r=f,o=d;break}case"Q":{const[f,d,p,h]=u,g=r+2*(f-r)/3,v=o+2*(d-o)/3,x=p+2*(f-p)/3,y=h+2*(d-h)/3;e.push({key:"C",data:[g,v,x,y,p,h]}),s=f,c=d,r=p,o=h;break}case"A":{const f=Math.abs(u[0]),d=Math.abs(u[1]),p=u[2],h=u[3],g=u[4],v=u[5],x=u[6];f===0||d===0?(e.push({key:"C",data:[r,o,v,x,v,x]}),r=v,o=x):(r!==v||o!==x)&&(Vo(r,o,v,x,f,d,p,h,g).forEach((function(y){e.push({key:"C",data:y})})),r=v,o=x);break}case"Z":e.push({key:"Z",data:[]}),r=i,o=a}n=l}return e}function ne(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function Vo(t,e,n,r,o,i,a,s,c,l){const u=(f=a,Math.PI*f/180);var f;let d=[],p=0,h=0,g=0,v=0;if(l)[p,h,g,v]=l;else{[t,e]=ne(t,e,-u),[n,r]=ne(n,r,-u);const Q=(t-n)/2,_=(e-r)/2;let lt=Q*Q/(o*o)+_*_/(i*i);lt>1&&(lt=Math.sqrt(lt),o*=lt,i*=lt);const Ht=o*o,zt=i*i,ba=Ht*zt-Ht*_*_-zt*Q*Q,va=Ht*_*_+zt*Q*Q,wr=(s===c?-1:1)*Math.sqrt(Math.abs(ba/va));g=wr*o*_/i+(t+n)/2,v=wr*-i*Q/o+(e+r)/2,p=Math.asin(parseFloat(((e-v)/i).toFixed(9))),h=Math.asin(parseFloat(((r-v)/i).toFixed(9))),t<g&&(p=Math.PI-p),n<g&&(h=Math.PI-h),p<0&&(p=2*Math.PI+p),h<0&&(h=2*Math.PI+h),c&&p>h&&(p-=2*Math.PI),!c&&h>p&&(h-=2*Math.PI)}let x=h-p;if(Math.abs(x)>120*Math.PI/180){const Q=h,_=n,lt=r;h=c&&h>p?p+120*Math.PI/180*1:p+120*Math.PI/180*-1,d=Vo(n=g+o*Math.cos(h),r=v+i*Math.sin(h),_,lt,o,i,a,0,c,[h,Q,g,v])}x=h-p;const y=Math.cos(p),E=Math.sin(p),z=Math.cos(h),R=Math.sin(h),C=Math.tan(x/4),Z=4/3*o*C,ct=4/3*i*C,ve=[t,e],nt=[t+Z*E,e-ct*y],$t=[n+Z*R,r-ct*z],xr=[n,r];if(nt[0]=2*ve[0]-nt[0],nt[1]=2*ve[1]-nt[1],l)return[nt,$t,xr].concat(d);{d=[nt,$t,xr].concat(d);const Q=[];for(let _=0;_<d.length;_+=3){const lt=ne(d[_][0],d[_][1],u),Ht=ne(d[_+1][0],d[_+1][1],u),zt=ne(d[_+2][0],d[_+2][1],u);Q.push([lt[0],lt[1],Ht[0],Ht[1],zt[0],zt[1]])}return Q}}const il={randOffset:function(t,e){return w(t,e)},randOffsetWithRange:function(t,e,n){return Oe(t,e,n)},ellipse:function(t,e,n,r,o){const i=Zo(n,r,o);return _n(t,e,o,i).opset},doubleLineOps:function(t,e,n,r,o){return At(t,e,n,r,o,!0)}};function Ko(t,e,n,r,o){return{type:"path",ops:At(t,e,n,r,o)}}function Ie(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let i=0;i<r-1;i++)o.push(...At(t[i][0],t[i][1],t[i+1][0],t[i+1][1],n));return e&&o.push(...At(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?Ko(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function al(t,e,n,r,o){return(function(i,a){return Ie(i,!0,a)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function Dr(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=Se(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:Se(n[0],1.5*(1+.22*e.roughness),Or(e));for(let i=1;i<n.length;i++){const a=n[i];if(a.length){const s=Se(a,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:Se(a,1.5*(1+.22*e.roughness),Or(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function Zo(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),i=2*Math.PI/o;let a=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return a+=w(a*c,n),s+=w(s*c,n),{increment:i,rx:a,ry:s}}function _n(t,e,n,r){const[o,i]=Fr(r.increment,t,e,r.rx,r.ry,1,r.increment*Oe(.1,Oe(.4,1,n),n),n);let a=Fe(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=Fr(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=Fe(s,null,n);a=a.concat(c)}return{estimatedPoints:i,opset:{type:"path",ops:a}}}function Nr(t,e,n,r,o,i,a,s,c){const l=t,u=e;let f=Math.abs(n/2),d=Math.abs(r/2);f+=w(.01*f,c),d+=w(.01*d,c);let p=o,h=i;for(;p<0;)p+=2*Math.PI,h+=2*Math.PI;h-p>2*Math.PI&&(p=0,h=2*Math.PI);const g=2*Math.PI/c.curveStepCount,v=Math.min(g/2,(h-p)/2),x=Hr(v,l,u,f,d,p,h,1,c);if(!c.disableMultiStroke){const y=Hr(v,l,u,f,d,p,h,1.5,c);x.push(...y)}return a&&(s?x.push(...At(l,u,l+f*Math.cos(p),u+d*Math.sin(p),c),...At(l,u,l+f*Math.cos(h),u+d*Math.sin(h),c)):x.push({op:"lineTo",data:[l,u]},{op:"lineTo",data:[l+f*Math.cos(p),u+d*Math.sin(p)]})),{type:"path",ops:x}}function Rr(t,e){const n=Go(Yo(lr(t))),r=[];let o=[0,0],i=[0,0];for(const{key:a,data:s}of n)switch(a){case"M":i=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...At(i[0],i[1],s[0],s[1],e)),i=[s[0],s[1]];break;case"C":{const[c,l,u,f,d,p]=s;r.push(...sl(c,l,u,f,d,p,i,e)),i=[d,p];break}case"Z":r.push(...At(i[0],i[1],o[0],o[1],e)),i=[o[0],o[1]]}return{type:"path",ops:r}}function Cn(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,i=r.length;if(i>2){n.push({op:"move",data:[r[0][0]+w(o,e),r[0][1]+w(o,e)]});for(let a=1;a<i;a++)n.push({op:"lineTo",data:[r[a][0]+w(o,e),r[a][1]+w(o,e)]})}}return{type:"fillPath",ops:n}}function Bt(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!U[o])switch(o){case"zigzag":U[o]||(U[o]=new Qc(r));break;case"cross-hatch":U[o]||(U[o]=new Jc(r));break;case"dots":U[o]||(U[o]=new tl(r));break;case"dashed":U[o]||(U[o]=new el(r));break;case"zigzag-line":U[o]||(U[o]=new nl(r));break;default:o="hachure",U[o]||(U[o]=new cr(r))}return U[o]})(e,il).fillPolygons(t,e)}function Or(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function Qo(t){return t.randomizer||(t.randomizer=new rl(t.seed||0)),t.randomizer.next()}function Oe(t,e,n,r=1){return n.roughness*r*(Qo(n)*(e-t)+t)}function w(t,e,n=1){return Oe(-t,t,e,n)}function At(t,e,n,r,o,i=!1){const a=i?o.disableMultiStrokeFill:o.disableMultiStroke,s=Bn(t,e,n,r,o,!0,!1);if(a)return s;const c=Bn(t,e,n,r,o,!0,!0);return s.concat(c)}function Bn(t,e,n,r,o,i,a){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let u=o.maxRandomnessOffset||0;u*u*100>s&&(u=c/10);const f=u/2,d=.2+.2*Qo(o);let p=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;p=w(p,o,l),h=w(h,o,l);const g=[],v=()=>w(f,o,l),x=()=>w(u,o,l),y=o.preserveVertices;return a?g.push({op:"move",data:[t+(y?0:v()),e+(y?0:v())]}):g.push({op:"move",data:[t+(y?0:w(u,o,l)),e+(y?0:w(u,o,l))]}),a?g.push({op:"bcurveTo",data:[p+t+(n-t)*d+v(),h+e+(r-e)*d+v(),p+t+2*(n-t)*d+v(),h+e+2*(r-e)*d+v(),n+(y?0:v()),r+(y?0:v())]}):g.push({op:"bcurveTo",data:[p+t+(n-t)*d+x(),h+e+(r-e)*d+x(),p+t+2*(n-t)*d+x(),h+e+2*(r-e)*d+x(),n+(y?0:x()),r+(y?0:x())]}),g}function Se(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]),r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]),o===t.length-1&&r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]);return Fe(r,null,n)}function Fe(t,e,n){const r=t.length,o=[];if(r>3){const i=[],a=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*t[s+1][0]-a*t[s-1][0])/6,c[1]+(a*t[s+1][1]-a*t[s-1][1])/6],i[2]=[t[s+1][0]+(a*t[s][0]-a*t[s+2][0])/6,t[s+1][1]+(a*t[s][1]-a*t[s+2][1])/6],i[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[i[1][0],i[1][1],i[2][0],i[2][1],i[3][0],i[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...Bn(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function Fr(t,e,n,r,o,i,a,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let u=0;u<=2*Math.PI;u+=t){const f=[e+r*Math.cos(u),n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const u=w(.5,s)-Math.PI/2;l.push([w(i,s)+e+.9*r*Math.cos(u-t),w(i,s)+n+.9*o*Math.sin(u-t)]);const f=2*Math.PI+u-.01;for(let d=u;d<f;d+=t){const p=[w(i,s)+e+r*Math.cos(d),w(i,s)+n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([w(i,s)+e+r*Math.cos(u+2*Math.PI+.5*a),w(i,s)+n+o*Math.sin(u+2*Math.PI+.5*a)]),l.push([w(i,s)+e+.98*r*Math.cos(u+a),w(i,s)+n+.98*o*Math.sin(u+a)]),l.push([w(i,s)+e+.9*r*Math.cos(u+.5*a),w(i,s)+n+.9*o*Math.sin(u+.5*a)])}return[l,c]}function Hr(t,e,n,r,o,i,a,s,c){const l=i+w(.1,c),u=[];u.push([w(s,c)+e+.9*r*Math.cos(l-t),w(s,c)+n+.9*o*Math.sin(l-t)]);for(let f=l;f<=a;f+=t)u.push([w(s,c)+e+r*Math.cos(f),w(s,c)+n+o*Math.sin(f)]);return u.push([e+r*Math.cos(a),n+o*Math.sin(a)]),u.push([e+r*Math.cos(a),n+o*Math.sin(a)]),Fe(u,null,c)}function sl(t,e,n,r,o,i,a,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let u=[0,0];const f=s.disableMultiStroke?1:2,d=s.preserveVertices;for(let p=0;p<f;p++)p===0?c.push({op:"move",data:[a[0],a[1]]}):c.push({op:"move",data:[a[0]+(d?0:w(l[0],s)),a[1]+(d?0:w(l[0],s))]}),u=d?[o,i]:[o+w(l[p],s),i+w(l[p],s)],c.push({op:"bcurveTo",data:[t+w(l[p],s),e+w(l[p],s),n+w(l[p],s),r+w(l[p],s),u[0],u[1]]});return c}function re(t){return[...t]}function zr(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(re(t[0]),re(t[1]),re(t[2]),re(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const i=[],a=1-e;r.push(re(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*o[s+1][0]-a*o[s-1][0])/6,c[1]+(a*o[s+1][1]-a*o[s-1][1])/6],i[2]=[o[s+1][0]+(a*o[s][0]-a*o[s+2][0])/6,o[s+1][1]+(a*o[s][1]-a*o[s+2][1])/6],i[3]=[o[s+1][0],o[s+1][1]],r.push(i[1],i[2],i[3])}}return r}function Pe(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function cl(t,e,n){const r=Pe(e,n);if(r===0)return Pe(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),Pe(t,Tt(e,n,o))}function Tt(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function qn(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],u=s[c+1],f=s[c+2],d=s[c+3];let p=3*u[0]-2*l[0]-d[0];p*=p;let h=3*u[1]-2*l[1]-d[1];h*=h;let g=3*f[0]-2*d[0]-l[0];g*=g;let v=3*f[1]-2*d[1]-l[1];return v*=v,p<g&&(p=g),h<v&&(h=v),p+h})(t,e)<n){const s=t[e+0];o.length?(i=o[o.length-1],a=s,Math.sqrt(Pe(i,a))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],u=t[e+2],f=t[e+3],d=Tt(c,l,.5),p=Tt(l,u,.5),h=Tt(u,f,.5),g=Tt(d,p,.5),v=Tt(p,h,.5),x=Tt(g,v,.5);qn([c,d,g,x],0,n,o),qn([x,v,h,f],0,n,o)}var i,a;return o}function ll(t,e){return He(t,0,t.length,e)}function He(t,e,n,r,o){const i=o||[],a=t[e],s=t[n-1];let c=0,l=1;for(let u=e+1;u<n-1;++u){const f=cl(t[u],a,s);f>c&&(c=f,l=u)}return Math.sqrt(c)>r?(He(t,e,l+1,r,i),He(t,l,n,r,i)):(i.length||i.push(a),i.push(s)),i}function In(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let i=0;i<o;i++)qn(t,3*i,e,r);return n&&n>0?He(r,0,r.length,n):r}const Y="none";class ze{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,i){const a=this._o(i);return this._d("line",[Ko(e,n,r,o,a)],a)}rectangle(e,n,r,o,i){const a=this._o(i),s=[],c=al(e,n,r,o,a);if(a.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];a.fillStyle==="solid"?s.push(Cn([l],a)):s.push(Bt([l],a))}return a.stroke!==Y&&s.push(c),this._d("rectangle",s,a)}ellipse(e,n,r,o,i){const a=this._o(i),s=[],c=Zo(r,o,a),l=_n(e,n,a,c);if(a.fill)if(a.fillStyle==="solid"){const u=_n(e,n,a,c).opset;u.type="fillPath",s.push(u)}else s.push(Bt([l.estimatedPoints],a));return a.stroke!==Y&&s.push(l.opset),this._d("ellipse",s,a)}circle(e,n,r,o){const i=this.ellipse(e,n,r,r,o);return i.shape="circle",i}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[Ie(e,!1,r)],r)}arc(e,n,r,o,i,a,s=!1,c){const l=this._o(c),u=[],f=Nr(e,n,r,o,i,a,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const d=Object.assign({},l);d.disableMultiStroke=!0;const p=Nr(e,n,r,o,i,a,!0,!1,d);p.type="fillPath",u.push(p)}else u.push((function(d,p,h,g,v,x,y){const E=d,z=p;let R=Math.abs(h/2),C=Math.abs(g/2);R+=w(.01*R,y),C+=w(.01*C,y);let Z=v,ct=x;for(;Z<0;)Z+=2*Math.PI,ct+=2*Math.PI;ct-Z>2*Math.PI&&(Z=0,ct=2*Math.PI);const ve=(ct-Z)/y.curveStepCount,nt=[];for(let $t=Z;$t<=ct;$t+=ve)nt.push([E+R*Math.cos($t),z+C*Math.sin($t)]);return nt.push([E+R*Math.cos(ct),z+C*Math.sin(ct)]),nt.push([E,z]),Bt([nt],y)})(e,n,r,o,i,a,l));return l.stroke!==Y&&u.push(f),this._d("arc",u,l)}curve(e,n){const r=this._o(n),o=[],i=Dr(e,r);if(r.fill&&r.fill!==Y)if(r.fillStyle==="solid"){const a=Dr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(a.ops)})}else{const a=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?a.push(...l):l.length===3?a.push(...In(zr([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):a.push(...In(zr(l),10,(1+r.roughness)/2))}a.length&&o.push(Bt([a],r))}return r.stroke!==Y&&o.push(i),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],i=Ie(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(Cn([e],r)):o.push(Bt([e],r))),r.stroke!==Y&&o.push(i),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const i=r.fill&&r.fill!=="transparent"&&r.fill!==Y,a=r.stroke!==Y,s=!!(r.simplification&&r.simplification<1),c=(function(u,f,d){const p=Go(Yo(lr(u))),h=[];let g=[],v=[0,0],x=[];const y=()=>{x.length>=4&&g.push(...In(x,f)),x=[]},E=()=>{y(),g.length&&(h.push(g),g=[])};for(const{key:R,data:C}of p)switch(R){case"M":E(),v=[C[0],C[1]],g.push(v);break;case"L":y(),g.push([C[0],C[1]]);break;case"C":if(!x.length){const Z=g.length?g[g.length-1]:v;x.push([Z[0],Z[1]])}x.push([C[0],C[1]]),x.push([C[2],C[3]]),x.push([C[4],C[5]]);break;case"Z":y(),g.push([v[0],v[1]])}if(E(),!d)return h;const z=[];for(const R of h){const C=ll(R,d);C.length&&z.push(C)}return z})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=Rr(e,r);if(i)if(r.fillStyle==="solid")if(c.length===1){const u=Rr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(u.ops)})}else o.push(Cn(c,r));else o.push(Bt(c,r));return a&&(s?c.forEach((u=>{o.push(Ie(u,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const i=typeof n=="number"&&n>=0?o.data.map((a=>+a.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${i[0]} ${i[1]} `;break;case"bcurveTo":r+=`C${i[0]} ${i[1]}, ${i[2]} ${i[3]}, ${i[4]} ${i[5]} `;break;case"lineTo":r+=`L${i[0]} ${i[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const i of n){let a=null;switch(i.type){case"path":a={d:this.opsToPath(i),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:Y};break;case"fillPath":a={d:this.opsToPath(i),stroke:Y,strokeWidth:0,fill:r.fill||Y};break;case"fillSketch":a=this.fillSketch(i,r)}a&&o.push(a)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||Y,strokeWidth:r,fill:Y}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class ul{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new ze(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,i=e.options.fixedDecimalPlaceDigits;for(const a of n)switch(a.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,a,i),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,a,i,s),o.restore();break}case"fillSketch":this.fillSketch(o,a,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const i of n.ops){const a=typeof r=="number"&&r>=0?i.data.map((s=>+s.toFixed(r))):i.data;switch(i.op){case"move":e.moveTo(a[0],a[1]);break;case"bcurveTo":e.bezierCurveTo(a[0],a[1],a[2],a[3],a[4],a[5]);break;case"lineTo":e.lineTo(a[0],a[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a),a}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a),a}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a),a}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i),i}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const Ee="http://www.w3.org/2000/svg";class dl{constructor(e,n){this.svg=e,this.gen=new ze(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,i=o.createElementNS(Ee,"g"),a=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(Ee,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(Ee,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&i.appendChild(c)}return i}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const i=e.createElementNS(Ee,"path");return i.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),i.setAttribute("stroke",r.fill||""),i.setAttribute("stroke-width",o+""),i.setAttribute("fill","none"),r.fillLineDash&&i.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&i.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),i}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a)}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a)}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a)}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var Jo={canvas:(t,e)=>new ul(t,e),svg:(t,e)=>new dl(t,e),generator:t=>new ze(t),newSeed:()=>ze.newSeed()};const pl="http://www.w3.org/2000/svg",_r=1,ti="#000000",_e=3;let F=null;function fl(){F||(F=document.createElementNS(pl,"svg"),F.setAttribute("data-manuscript","ui"),F.setAttribute("width","100%"),F.setAttribute("height","100%"),F.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(F))}function ur(){F==null||F.remove(),F=null}function ei(t,e,n,r){if(!F)return;for(;F.firstChild;)F.removeChild(F.firstChild);const o=Jo.svg(F);Br(p=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:_r,...p}));const i=Math.atan2(r-e,n-t),a=14+_e*2,s=Math.PI/7,c=n-a*Math.cos(i-s),l=r-a*Math.sin(i-s),u=n-a*Math.cos(i+s),f=r-a*Math.sin(i+s),d=`M ${c} ${l} L ${n} ${r} L ${u} ${f}`;Br(p=>o.path(d,{roughness:1.5,bowing:1,seed:_r+1,...p}))}function Br(t){F&&(F.appendChild(t({stroke:"#ffffff",strokeWidth:_e+4})),F.appendChild(t({stroke:ti,strokeWidth:_e})))}const hl=8;let Be=!1,qr=null,Zt=!1,Xt=0,Yt=0;function ml(){qr||(qr=mt(({prev:t,next:e})=>{e==="arrow"?gl():t==="arrow"&&bl()}))}function gl(){Be||(Be=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",ni,!0),document.addEventListener("mousemove",ri,!0),document.addEventListener("mouseup",oi,!0),document.addEventListener("keydown",ii,!0))}function bl(){Be&&(Be=!1,Zt=!1,document.body.style.cursor="",document.removeEventListener("mousedown",ni,!0),document.removeEventListener("mousemove",ri,!0),document.removeEventListener("mouseup",oi,!0),document.removeEventListener("keydown",ii,!0),ur())}function ni(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Zt=!0,Xt=t.clientX,Yt=t.clientY,fl(),ei(Xt,Yt,Xt,Yt))}function ri(t){Zt&&(t.preventDefault(),ei(Xt,Yt,t.clientX,t.clientY))}function oi(t){if(!Zt)return;Zt=!1,ur();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Xt,n-Yt)<hl){P("idle");return}t.preventDefault(),t.stopPropagation();const o={kind:"arrow",id:vl(),style:"excalidraw",from:{x:Xt,y:Yt},to:{x:e,y:n},color:ti,strokeWidth:_e};de(o),P("idle")}function ii(t){t.key==="Escape"&&(t.preventDefault(),Zt=!1,ur(),P("idle"))}function vl(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const jr="http://www.w3.org/2000/svg",ai="#1a1a1a",si=3,yl=2,xl=2;let qe=!1,Wr=null,Qt=!1,at=[],et=null,ut=null;function wl(){Wr||(Wr=mt(({prev:t,next:e})=>{e==="freedraw"?kl():t==="freedraw"&&Sl()}))}function kl(){qe||(qe=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",ci,!0),document.addEventListener("mousemove",li,!0),document.addEventListener("mouseup",ui,!0),document.addEventListener("keydown",di,!0))}function Sl(){qe&&(qe=!1,Qt=!1,at=[],document.body.style.cursor="",document.removeEventListener("mousedown",ci,!0),document.removeEventListener("mousemove",li,!0),document.removeEventListener("mouseup",ui,!0),document.removeEventListener("keydown",di,!0),dr())}function ci(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Qt=!0,at=[{x:t.clientX,y:t.clientY}],El(),pi())}function li(t){if(!Qt)return;t.preventDefault();const e=at[at.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<xl||(at.push({x:t.clientX,y:t.clientY}),pi())}function ui(t){if(!Qt)return;if(Qt=!1,dr(),at.length<yl){at=[],P("idle");return}t.preventDefault(),t.stopPropagation();const e={kind:"freedraw",id:Al(),points:at.slice(),stroke:ai,strokeWidth:si};de(e),at=[],P("idle")}function di(t){t.key==="Escape"&&(t.preventDefault(),Qt=!1,at=[],dr(),P("idle"))}function El(){et||(et=document.createElementNS(jr,"svg"),et.setAttribute("data-manuscript","ui"),et.setAttribute("width","100%"),et.setAttribute("height","100%"),et.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),ut=document.createElementNS(jr,"polyline"),ut.setAttribute("fill","none"),ut.setAttribute("stroke",ai),ut.setAttribute("stroke-width",String(si)),ut.setAttribute("stroke-linecap","round"),ut.setAttribute("stroke-linejoin","round"),et.appendChild(ut),document.body.appendChild(et))}function dr(){et==null||et.remove(),et=null,ut=null}function pi(){ut&&ut.setAttribute("points",at.map(t=>`${t.x},${t.y}`).join(" "))}function Al(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function fi(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const i=r.tagName.toLowerCase(),a=r.parentElement,s=r.tagName;if(a){const c=Array.from(a.children).filter(l=>{var u;return l.tagName===s&&!((u=l.matches)!=null&&u.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${i}:nth-of-type(${l})`)}else n.unshift(i)}else n.unshift(i);r=a,o++}return n.join(" > ")}function pr(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function Ml(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const $l=["data-testid","data-test","id","aria-label"];function Ll(t){for(const e of $l){const n=t.getAttribute(e);if(n&&n.length>0)return{kind:"stable-attr",cssSelector:`[${e}="${Ml(n)}"]`}}return{kind:"stable-attr",cssSelector:fi(t)}}function Tl(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!pr(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function Cl(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?fi(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Il(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!pr(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function Pl(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const i of Array.from(r.children)){if(i===t)continue;const a=(i.textContent??"").trim();if(a.length>0&&a.length<60&&n.push(a),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function Dl(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||pr(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const i=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>i.includes(c))?n:null}function Nl(t){return{layer1:Ll(t),layer2:Cl(t),layer3:Pl(t)}}function Rl(t,e){const n=e.ownerDocument;return n?hi(t,n)===e:!1}function jn(t){const e=mi(t.framePath);return e?hi(t,e):null}function hi(t,e){return Tl(t.layer1,e)??Il(t.layer2,e)??Dl(t.layer3,e)}function mi(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function Ol(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}const he="manuscript:element-selected";let je=!1,J=null,Ur=null;function Fl(){Ur||(Ur=mt(({prev:t,next:e})=>{e==="picker"?Hl():t==="picker"&&zl()}))}function Hl(){je||(je=!0,document.addEventListener("mouseover",gi,!0),document.addEventListener("mouseout",bi,!0),document.addEventListener("click",vi,!0),document.addEventListener("keydown",yi,!0))}function zl(){je&&(je=!1,document.removeEventListener("mouseover",gi,!0),document.removeEventListener("mouseout",bi,!0),document.removeEventListener("click",vi,!0),document.removeEventListener("keydown",yi,!0),xi())}function gi(t){const e=t.target;!(e instanceof HTMLElement)||wi(e)||Bl(e)}function bi(t){xi()}function vi(t){const e=t.target;if(!(e instanceof HTMLElement)||wi(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=Nl(e);if(!Rl(n,e)){_l();return}const r=e.getBoundingClientRect(),o={chain:n,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};document.dispatchEvent(new CustomEvent(he,{detail:o})),P("idle")}let rt=null,Ae=null;function _l(){rt&&rt.remove(),rt=document.createElement("div"),rt.setAttribute("data-manuscript","ui"),rt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${H+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),rt.textContent=b("toast.ambiguous-selector"),document.body.appendChild(rt),Ae!==null&&window.clearTimeout(Ae),Ae=window.setTimeout(()=>{rt==null||rt.remove(),rt=null,Ae=null},3500)}function yi(t){t.key==="Escape"&&(t.preventDefault(),P("idle"))}function Bl(t){J||(J=document.createElement("div"),J.setAttribute("data-manuscript","ui"),J.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${H+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(J));const e=t.getBoundingClientRect();J.style.left=`${e.left}px`,J.style.top=`${e.top}px`,J.style.width=`${e.width}px`,J.style.height=`${e.height}px`,J.style.display="block"}function xi(){J&&(J.style.display="none")}function wi(t){return t.closest('[data-manuscript="ui"]')!==null}const me="http://www.w3.org/2000/svg";function fr(t,e){let n;switch(t){case"rectangle":n=ql(e);break;case"ellipse":n=jl(e);break;case"triangle":n=Me(Xl(e),e);break;case"diamond":n=Me(Yl(e),e);break;case"star":n=Me(Gl(e),e);break;case"callout":n=Ul(Vl(e),e);break;case"line":n=Wl(e);break;case"block-arrow":n=Me(Kl(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function ql(t){const e=document.createElementNS(me,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),dn(e,t),e}function jl(t){const e=document.createElementNS(me,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),dn(e,t),e}function Wl(t){const e=document.createElementNS(me,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function Me(t,e){const n=document.createElementNS(me,"polygon");return n.setAttribute("points",t),dn(n,e),n.setAttribute("stroke-linejoin","round"),n}function Ul(t,e){const n=document.createElementNS(me,"path");return n.setAttribute("d",t),dn(n,e),n.setAttribute("stroke-linejoin","round"),n}function dn(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function Xl(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function Yl(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function Gl(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,i=[];for(let a=0;a<10;a++){const s=Math.PI/5*a-Math.PI/2,c=a%2===0?r:o;i.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return i.join(" ")}function Vl(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,i=t.x+t.width*.5,a=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${i} ${r}`,`L ${a} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function Kl(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const Zl="http://www.w3.org/2000/svg",Ql="#ffffff",Jl="#1a1a1a",tu=2;let W=null,dt=null;function ki(t){return{fill:t==="line"?"transparent":Ql,stroke:Jl,strokeWidth:tu}}function eu(){dt||(dt=document.createElement("div"),dt.setAttribute("data-manuscript","ui"),dt.textContent="Click and drag to draw a shape · Esc to cancel",dt.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${H+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(dt))}function Si(){dt==null||dt.remove(),dt=null}function nu(){W||(W=document.createElementNS(Zl,"svg"),W.setAttribute("data-manuscript","ui"),W.setAttribute("width","100%"),W.setAttribute("height","100%"),W.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(W))}function hr(){W==null||W.remove(),W=null}function Ei(t,e,n,r,o){if(!W)return;for(;W.firstChild;)W.removeChild(W.firstChild);const i=t==="line"?r-e:Math.abs(r-e),a=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=ki(t),u=fr(t,{x:s,y:c,width:i,height:a,...l});u&&W.appendChild(u)}const ru=6;let bt="rectangle",We=!1,Xr=null,Jt=!1,vt=0,yt=0;function ou(t){bt=t}function iu(){Xr||(Xr=mt(({prev:t,next:e})=>{e==="shape"?au():t==="shape"&&su()}))}function au(){We||(We=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Ai,!0),document.addEventListener("mousemove",Mi,!0),document.addEventListener("mouseup",$i,!0),document.addEventListener("keydown",Li,!0),eu())}function su(){We&&(We=!1,Jt=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Ai,!0),document.removeEventListener("mousemove",Mi,!0),document.removeEventListener("mouseup",$i,!0),document.removeEventListener("keydown",Li,!0),hr(),Si())}function Ai(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Jt=!0,vt=t.clientX,yt=t.clientY,Si(),nu(),Ei(bt,vt,yt,vt,yt))}function Mi(t){Jt&&(t.preventDefault(),Ei(bt,vt,yt,t.clientX,t.clientY))}function $i(t){if(!Jt)return;Jt=!1,hr();const e=t.clientX,n=t.clientY,r=bt==="line"?e-vt:Math.abs(e-vt),o=bt==="line"?n-yt:Math.abs(n-yt);if(Math.max(Math.abs(r),Math.abs(o))<ru){P("idle");return}t.preventDefault(),t.stopPropagation();const i=bt==="line"?{x:vt,y:yt,width:r,height:o}:{x:Math.min(vt,e),y:Math.min(yt,n),width:r,height:o},a=ki(bt),s={kind:"shape",id:cu(),shapeKind:bt,bounds:i,...a};de(s),P("idle")}function Li(t){t.key==="Escape"&&(t.preventDefault(),Jt=!1,hr(),P("idle"))}function cu(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const lu={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},uu="Text";let Ue=!1,Yr=null;function du(){Yr||(Yr=mt(({prev:t,next:e})=>{e==="text"?pu():t==="text"&&fu()}))}function pu(){Ue||(Ue=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Ti,!0),document.addEventListener("keydown",Ci,!0))}function fu(){Ue&&(Ue=!1,document.body.style.cursor="",document.removeEventListener("click",Ti,!0),document.removeEventListener("keydown",Ci,!0))}function Ti(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={kind:"text",id:hu(),text:uu,position:{x:t.clientX,y:t.clientY},style:{...lu}};de(n),requestAnimationFrame(()=>{const r=document.querySelector(`[data-annotation-text="${n.id}"]`);r&&r.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),P("idle")}function Ci(t){t.key==="Escape"&&(t.preventDefault(),P("idle"))}function hu(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const mu="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",gu="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",Gr="Asta Sans",bu="fonts/AstaSans-VariableFont_wght.ttf";let Vr=!1;function vu(){Vr||(Vr=!0,Kr(mu),Kr(gu),yu())}function Kr(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function yu(){try{for(const t of document.fonts)if(t.family===Gr)return}catch{}try{const t=chrome.runtime.getURL(bu);new FontFace(Gr,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const ot="manuscript";function pn(...t){}function Pn(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function qt(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function Ii(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===ot&&typeof e.type=="string"}function xu(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const i=o.data;if(Ii(i)){if(pn("child received",i.type,"in",location.href),i.type==="set-mode"){P(i.mode),t=i.mode;return}if(i.type==="top-drag-start"){n=!0;return}if(i.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(he,(o=>{const i=o.detail;qt({source:ot,type:"element-selected",detail:i})})),mt(({prev:o,next:i})=>{o==="picker"&&i==="idle"&&qt({source:ot,type:"exit-picker"})}),qt({source:ot,type:"frame-ready"}),document.addEventListener("mousedown",o=>{qt({source:ot,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&qt({source:ot,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&qt({source:ot,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function wu(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const i=o.getBoundingClientRect();return{x:i.left,y:i.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function ku(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Su(){mt(({next:t})=>{Pn({source:ot,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Pn({source:ot,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Pn({source:ot,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(Ii(e)){if(pn("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){Eu(t.source,e.detail);return}if(e.type==="exit-picker"){P("idle");return}if(e.type==="iframe-mousedown"){Zr("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";Zr(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){Au(t.source);return}}})}function Eu(t,e){const n=ku(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};pn("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(he,{detail:o})),P("idle")}function Zr(t,e,n,r){const o=wu(e),i=n+o.x,a=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:i,clientY:a}))}function Au(t){if(ht()==="picker")try{t==null||t.postMessage({source:ot,type:"set-mode",mode:"picker"},"*"),pn("top → late child: set-mode picker")}catch{}}function Mu(){if(typeof window>"u")return;window===window.top?Su():xu()}const $u="iframe-tool-overlay",Qr=new Set(["text","shape","freedraw"]);let Gt=[],Dn=!1,jt=null;function Lu(){typeof window>"u"||window===window.top&&(mt(({next:t})=>{Qr.has(t)?Jr():Pi()}),Qr.has(ht())&&Jr())}function Jr(){Pi(),to(),window.addEventListener("scroll",Xe,!0),window.addEventListener("resize",Xe),jt=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&to()}),jt.observe(document.body,{childList:!0,subtree:!0})}function Pi(){Gt.forEach(t=>t.remove()),Gt=[],window.removeEventListener("scroll",Xe,!0),window.removeEventListener("resize",Xe),jt==null||jt.disconnect(),jt=null}function to(){Gt.forEach(e=>e.remove()),Gt=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",$u),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${H+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),Gt.push(n),Di(n,e)})}const $e=8;function Di(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-$e}px`,t.style.top=`${n.top-$e}px`,t.style.width=`${n.width+$e*2}px`,t.style.height=`${n.height+$e*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function Xe(){Dn||(Dn=!0,requestAnimationFrame(()=>{Dn=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=Gt[e];r&&Di(r,n),e++})}))}let Et=!1;function fn(){return Et}async function Tu(){try{if(typeof(await chrome.storage.local.get(K.prompterWindowId))[K.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(Et=!0)}catch{}}async function Ni(){if(Et){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}Et=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(Et=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Ri(){if(Et){Et=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function Oi(t){try{await chrome.storage.local.set({[K.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function Cu(){Et=!1}const Lt="http://www.w3.org/2000/svg",eo="manuscript-spotlight-mask";let oe=null,G=null,it=null,V=null,Wn=[];function Fi(t){oe=t,G||Pu(),Ye(),Iu(t)}function te(){oe=null,Hi(),G&&(G.remove(),G=null,it=null,V=null)}function Iu(t){var n;Hi();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=Ye;r.addEventListener("scroll",o,!0),Wn.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",Ye)}function Hi(){for(const t of Wn)t.remove();Wn=[],window.removeEventListener("resize",Ye)}function Pu(){G=document.createElementNS(Lt,"svg"),G.setAttribute("data-manuscript","ui"),G.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H}`].join("; "),G.setAttribute("width","100%"),G.setAttribute("height","100%");const t=document.createElementNS(Lt,"defs"),e=document.createElementNS(Lt,"mask");e.setAttribute("id",eo);const n=document.createElementNS(Lt,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),it=document.createElementNS(Lt,"rect"),it.setAttribute("fill","black"),it.setAttribute("rx","4"),it.setAttribute("ry","4"),e.appendChild(it),t.appendChild(e),G.appendChild(t);const r=document.createElementNS(Lt,"rect");r.setAttribute("width","100%"),r.setAttribute("height","100%"),r.setAttribute("fill","rgba(0, 0, 0, 0.55)"),r.setAttribute("mask",`url(#${eo})`),G.appendChild(r),V=document.createElementNS(Lt,"rect"),V.setAttribute("fill","none"),V.setAttribute("stroke","rgba(255, 61, 139, 0.85)"),V.setAttribute("stroke-width","3"),V.setAttribute("rx","4"),V.setAttribute("ry","4"),G.appendChild(V),document.body.appendChild(G)}function Ye(){if(!oe||!it||!V)return;const t=oe.getBoundingClientRect(),e=Du(oe),n=4,r=t.left+e.x-n,o=t.top+e.y-n,i=t.width+n*2,a=t.height+n*2;it.setAttribute("x",String(r)),it.setAttribute("y",String(o)),it.setAttribute("width",String(i)),it.setAttribute("height",String(a)),V.setAttribute("x",String(r)),V.setAttribute("y",String(o)),V.setAttribute("width",String(i)),V.setAttribute("height",String(a))}function Du(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const k={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function Wt(t,e,n){return Math.max(e,Math.min(n,t))}function zi(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=Fu()),Nu()}function Nu(){const{host:t}=k;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),i=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${Wt(o,0,n)}px`),Number.isFinite(i)&&(t.style.top=`${Wt(i,0,r)}px`)}async function Ru(){try{return(await chrome.storage.local.get(K.replayControlsOrientation))[K.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Ou(t){try{await chrome.storage.local.set({[K.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function Fu(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function Hu(){try{const e=(await chrome.storage.local.get(K.replayControlsPosition))[K.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function no(t){try{await chrome.storage.local.set({[K.replayControlsPosition]:t})}catch{}}function zu(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function _u(){const{host:t,shadow:e}=k;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,i=0,a=0,s=0;const c=d=>{if(!k.host)return;d.preventDefault(),d.stopPropagation(),r=!0,n.classList.add("dragging");const p=k.host.getBoundingClientRect();k.host.style.left=`${p.left}px`,k.host.style.top=`${p.top}px`,k.host.style.bottom="auto",k.host.style.transform="none",o=d.clientX,i=d.clientY,a=p.left,s=p.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",u,!0)},l=d=>{if(!r||!k.host)return;const p=k.host.getBoundingClientRect(),h=d.clientX-o,g=d.clientY-i,v=Wt(a+h,0,window.innerWidth-p.width),x=Wt(s+g,0,window.innerHeight-p.height);k.host.style.left=`${v}px`,k.host.style.top=`${x}px`},u=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0);const d=k.host;if(d){const p=parseFloat(d.style.left||"0"),h=parseFloat(d.style.top||"0");Number.isFinite(p)&&Number.isFinite(h)&&no({left:p,top:h})}},f=()=>{if(k.host&&k.host.style.transform==="none"){const d=k.host.getBoundingClientRect(),p=Wt(d.left,0,window.innerWidth-d.width),h=Wt(d.top,0,window.innerHeight-d.height);k.host.style.left=`${p}px`,k.host.style.top=`${h}px`,no({left:p,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",f),k.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",f),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0)}}function _i(){return`
    ${Ot()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function Bi(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Bu(t){return Bi(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function qu(t,e){const{shadow:n}=k;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,i)=>{const a=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${i===e?" active":""}" role="option" data-action="step-jump" data-index="${i}" aria-selected="${i===e}" title="${Bu(a)}">${i+1}. ${Bi(a)}</li>`}).join(""))}function ju(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function Un(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function qi(t){const{host:e,shadow:n}=k;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||Un()}let De=-1,Ne=!1;function Wu(){De=-1,Ne=!1}function Uu(t,e,n){const{shadow:r}=k;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",De=-1,Ne=!1;return}o.classList.remove("hidden");const s=t!==De||Ne&&!n;De=t,Ne=n;let c=o.querySelector(".progress-fill");(!c||s)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function Xu(){return`
    ${Ot()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid rgb(255 255 255 / 0.6);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: rgb(255 255 255 / 0.08); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: rgb(255 255 255 / 0.15); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: rgb(255 255 255 / 0.2);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: rgb(255 255 255 / 0.18);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: rgb(255 255 255 / 0.55);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: rgb(255 255 255 / 0.75);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: rgb(255 255 255 / 0.08); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function Yu(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function Gu(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function Vu(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?Yu(14):Gu(14))}function hn(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",le);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}function Ku(t){if(k.host)return;const{host:e,shadow:n}=hn();k.host=e,k.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${H+6}`,"pointer-events: auto"].join("; "),n.innerHTML=`<style>${Xu()}</style>${Zu()}`,n.addEventListener("click",r=>Qu(r,t)),document.body.appendChild(e),_u(),document.addEventListener("mousedown",qi,!0),k.orientationApplied=!1,Ru().then(r=>{k.orientationApplied||(k.orientationApplied=!0,zi(r))}),Hu().then(r=>{k.host&&r&&k.host.style.transform!=="none"&&zu(k.host,r)})}function Zu(){return`
    <div class="bar" role="toolbar" aria-label="${b("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${b("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${b("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${b("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${b("replay.prompter-aria")}" title="${b("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${b("replay.tts-aria")}" title="${b("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${b("replay.move-aria")}" title="${b("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${b("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${b("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Qu(t,e){var i;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){ju();return}const r=n.closest('[data-action="step-jump"]');if(r){const a=Number(r.getAttribute("data-index"));Number.isFinite(a)&&(Un(),e.onStepSelect(a));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(i=n.closest("[data-action]"))==null?void 0:i.getAttribute("data-action");switch(o&&Un(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Ju();break}}function Ju(){const{shadow:t}=k;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";k.orientationApplied=!0,zi(n),Ou(n)}function td(){var t,e;(t=k.cleanupDrag)==null||t.call(k),k.cleanupDrag=null,document.removeEventListener("mousedown",qi,!0),(e=k.host)==null||e.remove(),k.host=null,k.shadow=null,k.orientationApplied=!1,Wu()}function ro(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const i=e.querySelector('[data-action="prev"]');i&&i.toggleAttribute("disabled",t.currentIndex<=0);const a=e.querySelector('[data-action="next"]');a&&(a.toggleAttribute("disabled",!1),a.setAttribute("aria-label",t.currentIndex>=t.total-1?b("replay.finish-aria"):b("replay.next-aria"))),Uu(t.currentIndex,t.timerDurationMs??null,t.paused),qu(t.steps??[],t.currentIndex),Vu(t.ttsEnabled===!0)}let xt=null;function ed(t){ge();const{host:e,shadow:n}=hn();xt=e,xt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${H+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${_i()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${b("replay.notfound.title")}</h2>
          <p>${b("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${b("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${b("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const i=o.target;if(!(i instanceof HTMLElement))return;const a=(s=i.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");a==="skip"?t.onSkip():a==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),xt.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(xt)}function ge(){if(!xt)return;const t=xt.__cleanup;t==null||t(),xt.remove(),xt=null}let wt=null;function nd(t){Ge();const{host:e,shadow:n}=hn();wt=e,wt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${H+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${_i()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${b("replay.url-mismatch.title")}</h2>
          <p>${b("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${b("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${b("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${b("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",i=>{var c;const a=i.target;if(!(a instanceof HTMLElement))return;const s=(c=a.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=i=>{i.key==="Escape"?(i.preventDefault(),t.onCancel()):i.key==="Enter"&&(i.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),wt.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(wt)}function Ge(){if(!wt)return;const t=wt.__cleanup;t==null||t(),wt.remove(),wt=null}let Ct=null;function rd(t){be();const e=t.getBoundingClientRect(),n=od(t),r=e.left+n.x,o=e.top+n.y,i=e.bottom+n.y,a=36,s=8,c=o-s-a<8,l=c?Math.min(window.innerHeight-8-a,i+s):Math.max(8,o-s-a),u=Math.max(8,Math.min(r,window.innerWidth-200)),f=c?"up":"down",{host:d,shadow:p}=hn();Ct=d,Ct.style.cssText=["position: fixed",`top: ${l}px`,`left: ${u}px`,`z-index: ${H+6}`,"pointer-events: none"].join("; "),p.innerHTML=`
    <style>
      ${Ot()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${b("prompter.action-step")}</span>
      <span>${b("replay.action-prompt")}</span>
      <span class="tip ${f}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Ct)}function be(){Ct==null||Ct.remove(),Ct=null}function od(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const $={state:null,unsubscribeStep:null};function mr(){return $.state!==null}let Vt=null;function id(t){Vt||(Vt=e=>{if($.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",Vt,!0))}function ad(){Vt&&(document.removeEventListener("keydown",Vt,!0),Vt=null)}function ji(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function sd(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function cd(t,e){var r,o;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||ji(n,location.href))return!1;try{await Zn({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((o=$.state)==null?void 0:o.paused)??!1})}catch(i){console.warn("[manuscript] persist activeReplay before nav failed",i)}return location.href=n,!0}function ld(t){return new Promise(e=>{nd({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{Ge(),e("force")},onCancel:()=>{Ge(),e("cancel")}})})}async function ud(t){try{const e=await bo();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function gr(){const t=I();if(!(!t||!$.state))try{await Zn({scenarioId:t.id,stepIndex:q(),startedAt:Date.now(),paused:$.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function Wi(t,e,n){const r=I();if(!r)return{ok:!1};if(n&&await ud(r.id))return{ok:!0};const o=sd(r);if(!o||ji(o,location.href))return{ok:!0};const i=await ld(o);return i==="cancel"?{ok:!1}:i==="navigate"?(await Zn({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class Ui extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function dd(t,e=ya){const n=jn(t);return n?Promise.resolve(n):new Promise((r,o)=>{let i=!1;const s=(mi(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(i)return;const u=jn(t);u&&(i=!0,c.disconnect(),clearTimeout(l),r(u))}),l=setTimeout(()=>{i||(i=!0,c.disconnect(),o(new Ui(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function ee(){const{state:t}=$;if(!t)return;const e=I();if(!e)return;const n=e.steps[q()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(vo().then(o=>{ro({currentIndex:q(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:o})}),ro({currentIndex:q(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),fn()){const o=q(),i=e.steps[o],a=e.steps[o+1];Oi({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(s=>({name:s.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:a?{name:a.name,description:a.description,autoAdvanceMs:a.autoAdvanceMs??null,waitForNavigation:a.waitForNavigation,thumbnailDataUrl:a.thumbnailDataUrl??null}:null})}}async function pd(){if(fn()){await Ri(),Ve(!1);return}Ve(!0),await Ni(),ee()}function fd(){Ve(!1)}function Ve(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function mn(t){var i;const{state:e}=$;if(!e)return;const n=I();if(!n)return;const r=n.steps[q()];if(ee(),!r)return;if(ge(),be(),$a()&&!e.paused&&La(r.description),!r.selectors){te(),r.waitForNavigation||oo(t);return}const o=new AbortController;e.pendingWait=o;try{const a=await dd(r.selectors);if(o.signal.aborted)return;a.scrollIntoView({block:"center"}),Fi(a),r.waitForNavigation?(rd(a),hd(a,o,t.onNext)):oo(t)}catch(a){if(o.signal.aborted)return;if(a instanceof Ui){te(),ed({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",a)}finally{((i=$.state)==null?void 0:i.pendingWait)===o&&($.state.pendingWait=null)}}function hd(t,e,n){if(!$.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!$.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function oo(t){var a;const{state:e}=$;if(!e||e.paused)return;const n=I();if(!n)return;const r=q(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(a=e.autoAdvanceAbort)==null||a.abort();const i=new AbortController;e.autoAdvanceAbort=i,(async()=>{const s=[],c=Ta();c&&s.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&s.push(new Promise(l=>{const u=window.setTimeout(()=>{$.state&&$.state.autoAdvanceTimer===u&&($.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);$.state&&($.state.autoAdvanceTimer=u),i.signal.addEventListener("abort",()=>{window.clearTimeout(u),l()})})),s.length!==0&&(await Promise.race([Promise.all(s).then(()=>{}),new Promise(l=>{i.signal.aborted?l():i.signal.addEventListener("abort",()=>l(),{once:!0})})]),!i.signal.aborted&&(!$.state||$.state.paused||q()===r&&t.onNext()))})()}function gn(){var e,n;const{state:t}=$;t&&(t.autoAdvanceTimer!==null&&(window.clearTimeout(t.autoAdvanceTimer),t.autoAdvanceTimer=null),(e=t.autoAdvanceAbort)==null||e.abort(),t.autoAdvanceAbort=null,(n=t.pendingWait)==null||n.abort(),t.pendingWait=null,yo())}const bn={onNext:()=>void Ke(),onExit:()=>void Ze()};async function vn(t=0,e={}){if($.state)return;const n=I();if(!n||n.steps.length===0||!(await Wi(n.id,t,!0)).ok)return;$.state={originalStepIndex:q(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null},P("replay"),Ku({onPrev:Xn,onNext:Ke,onTogglePause:Yn,onExit:Ze,onStepSelect:i=>void Xi(i),onTogglePrompter:()=>void pd(),onToggleTts:()=>void md()}),fn()&&Ve(!0),id({onNext:()=>void Ke(),onPrev:()=>void Xn(),onTogglePause:Yn,onExit:()=>void Ze()}),$.unsubscribeStep=ue(ee);const o=Math.min(Math.max(0,t),n.steps.length-1);Ft(o),await gr(),await mn(bn)}async function br(t){if(!$.state)return;const e=I();e&&(t<0||t>=e.steps.length||(gn(),ge(),be(),!await cd(e,t)&&(Ft(t),await gr(),await mn(bn))))}async function Xi(t){t!==q()&&await br(t)}async function Ke(){const{state:t}=$;if(!t)return;const e=I();if(!e)return;const n=q();if(n>=e.steps.length-1){gn(),ge(),be(),t.paused=!0,ee();return}await br(n+1)}async function Xn(){await br(q()-1)}async function md(){const t=!await vo();await Ca(t),t||yo(),ee()}function Yn(){const{state:t}=$;if(!t)return;const e=I();if(e&&t.paused&&q()>=e.steps.length-1){gd();return}t.paused=!t.paused,t.paused?gn():mn(bn),ee()}async function gd(){if(!$.state)return;const t=I();!t||!(await Wi(t.id,0,!1)).ok||$.state&&($.state.paused=!1,Ft(0),await gr(),await mn(bn))}async function Ze(){var n;const{state:t}=$;if(!t)return;gn(),ge(),be(),Ge(),te(),td(),Ri(),ad(),(n=$.unsubscribeStep)==null||n.call($),$.unsubscribeStep=null;const e=t.originalStepIndex;$.state=null,Ft(e),P("idle"),await ka()}const io="data-wp-animations";function bd(){if(document.head.querySelector(`[${io}]`))return;const t=document.createElement("style");t.setAttribute(io,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function se(t,e,n){if(!e||e.kind==="none"||ht()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const i=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",i),t.removeEventListener("animationcancel",i)};t.addEventListener("animationend",i),t.addEventListener("animationcancel",i)}const Qe="http://www.w3.org/2000/svg",Yi="data-annotation-text",ao="data-annotation-arrow",Gi="data-annotation-shape",so="data-annotation-freedraw",D={host:null,svg:null,roughSvg:null,unsubscribe:null};function vd(t){const{svg:e,roughSvg:n}=D;if(!e||!n)return;const r=xd(t.id);Vi(t,o=>n.line(t.from.x,t.from.y,t.to.x,t.to.y,{roughness:1.5,bowing:1,seed:r,...o})),yd(t,r+1)}function yd(t,e){const{roughSvg:n}=D;if(!n)return;const r=Math.atan2(t.to.y-t.from.y,t.to.x-t.from.x),o=14+t.strokeWidth*2,i=Math.PI/7,a=t.to.x-o*Math.cos(r-i),s=t.to.y-o*Math.sin(r-i),c=t.to.x-o*Math.cos(r+i),l=t.to.y-o*Math.sin(r+i),u=`M ${a} ${s} L ${t.to.x} ${t.to.y} L ${c} ${l}`;Vi(t,f=>n.path(u,{roughness:1.5,bowing:1,seed:e,...f}))}function Vi(t,e){const{svg:n}=D;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(ao,t.id),se(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(ao,t.id),se(o,t.entryAnimation,0),n.appendChild(o)}function xd(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}function wd(t){const{svg:e}=D;if(!e)return;const n=kd(t),r=t.points.map(a=>`${a.x},${a.y}`).join(" "),o=document.createElementNS(Qe,"polyline");o.setAttribute("points",r),o.setAttribute("fill","none"),o.setAttribute("stroke",t.stroke),o.setAttribute("stroke-width",String(t.strokeWidth)),o.setAttribute("stroke-linecap","round"),o.setAttribute("stroke-linejoin","round"),o.setAttribute(so,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&o.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),n&&o.setAttribute("transform",n),o.style.pointerEvents="none",se(o,t.entryAnimation,t.rotate??0),e.appendChild(o);const i=document.createElementNS(Qe,"polyline");i.setAttribute(so,t.id),i.setAttribute("points",r),i.setAttribute("fill","none"),i.setAttribute("stroke","transparent"),i.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute("pointer-events","stroke"),n&&i.setAttribute("transform",n),i.style.cursor="pointer",i.addEventListener("mousedown",a=>{a.button===0&&(a.stopPropagation(),a.preventDefault(),Sd(t.id,a,i))}),e.appendChild(i)}function kd(t){const e=t.rotate??0;if(!e||t.points.length===0)return"";let n=1/0,r=1/0,o=-1/0,i=-1/0;for(const c of t.points)c.x<n&&(n=c.x),c.y<r&&(r=c.y),c.x>o&&(o=c.x),c.y>i&&(i=c.y);const a=(n+o)/2,s=(r+i)/2;return`rotate(${e} ${a} ${s})`}function Sd(t,e,n){const r=L(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},i=r.points.map(l=>({...l}));let a=!1;const s=l=>{const u=l.clientX-o.x,f=l.clientY-o.y;!a&&Math.hypot(u,f)<3||(a=!0,l.preventDefault(),T(t,{points:i.map(d=>({x:d.x+u,y:d.y+f}))}))},c=()=>{document.removeEventListener("mousemove",s,!0),document.removeEventListener("mouseup",c,!0);const l=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),u=l[l.length-1]??n;Rc(t,u)};document.addEventListener("mousemove",s,!0),document.addEventListener("mouseup",c,!0)}function Ed(t){const{svg:e}=D;if(!e)return;const n=fr(t.shapeKind,{x:t.bounds.x,y:t.bounds.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});n&&(n.setAttribute(Gi,t.id),n.style.pointerEvents="none",se(n,t.entryAnimation,t.rotate??0),e.appendChild(n),e.appendChild(Ad(t)))}function Ad(t){const e=document.createElementNS(Qe,"rect");if(e.setAttribute(Gi,t.id),e.setAttribute("x",String(t.bounds.x)),e.setAttribute("y",String(t.bounds.y)),e.setAttribute("width",String(Math.max(0,t.bounds.width))),e.setAttribute("height",String(Math.max(0,t.bounds.height))),e.setAttribute("fill","rgba(0, 0, 0, 0.001)"),e.setAttribute("stroke","none"),e.setAttribute("pointer-events","all"),e.style.pointerEvents="all",e.style.cursor="pointer",t.rotate){const n=t.bounds.x+t.bounds.width/2,r=t.bounds.y+t.bounds.height/2;e.setAttribute("transform",`rotate(${t.rotate} ${n} ${r})`)}return e.addEventListener("mousedown",n=>Md(t.id,n,e)),e}function Md(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=L(t);if(!o||o.kind!=="shape")return;const i={...o.bounds};let a=!1;const s=l=>{const u=l.clientX-r.x,f=l.clientY-r.y;!a&&Math.hypot(u,f)<3||(a=!0,l.preventDefault(),T(t,{bounds:{...i,x:i.x+u,y:i.y+f}}))},c=()=>{document.removeEventListener("mousemove",s,!0),document.removeEventListener("mouseup",c,!0);const l=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=l[l.length-1]??n;Nc(t,u)};document.addEventListener("mousemove",s,!0),document.addEventListener("mouseup",c,!0)}function $d(t){const{host:e}=D;if(!e)return;const n=document.createElement("div");n.setAttribute(Yi,t.id),n.setAttribute("data-manuscript","ui"),n.dataset.annotationId=t.id;const r=t.style.italic===!0,o=t.style.backgroundColor??"#ffffff",i=t.style.backgroundOpacity??.96,a=o==="transparent"?"transparent":Ld(o,i),s=t.rotate??0,c=t.style.borderColor??"#000000",l=c==="transparent"?"none":`2px solid ${c}`;n.style.cssText=["position: absolute",`left: ${t.position.x}px`,`top: ${t.position.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${r?"italic":"normal"}`,"padding: 8px 12px",`background: ${a}`,`border: ${l}`,"border-radius: 8px","pointer-events: auto","cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${s}deg)`,"transform-origin: center center"].join("; "),n.textContent=t.text,Td(n,t.id),se(n,t.entryAnimation,t.rotate??0),e.appendChild(n)}function Ld(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,i=0,a=0;return r.length===4?(o=parseInt(r[1]+r[1],16),i=parseInt(r[2]+r[2],16),a=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),i=parseInt(r.slice(3,5),16),a=parseInt(r.slice(5,7),16)),`rgba(${o}, ${i}, ${a}, ${n})`}return t}function Td(t,e){let n=!1,r=0,o=0,i=0,a=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();i=l.left,a=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,u=c.clientY-o;Math.abs(l)+Math.abs(u)>2&&(s=!0),t.style.left=`${i+l}px`,t.style.top=`${a+u}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top);T(e,{position:{x:c,y:l}})}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),Dc(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Cd(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",T(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Cd(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function Id(){if(D.host)return;bd();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+3}`].join("; ");const e=document.createElementNS(Qe,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),D.host=t,D.svg=e,D.roughSvg=Jo.svg(e),document.body.appendChild(t),D.unsubscribe=ue(co),co()}function Pd(){var t;(t=D.unsubscribe)==null||t.call(D),D.unsubscribe=null,D.host&&(D.host.remove(),D.host=null,D.svg=null,D.roughSvg=null)}function co(){const{host:t,svg:e}=D;if(!t||!e)return;for(t.querySelectorAll(`[${Yi}]`).forEach(r=>r.remove());e.firstChild;)e.removeChild(e.firstChild);const n=Mo();for(const r of n)r.kind==="text"?$d(r):r.kind==="arrow"?vd(r):r.kind==="shape"?Ed(r):r.kind==="freedraw"&&wd(r)}const Dd=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],ft=28,Le=4,Nd="http://www.w3.org/2000/svg";let B=null,Rt=null,ie=null;function Rd(t,e){yn(),ie=e,B=document.createElement("div"),B.setAttribute("data-manuscript","ui"),B.style.cssText=["position: fixed",`z-index: ${H+5}`,"pointer-events: auto"].join("; "),Rt=B.attachShadow({mode:"open"}),Rt.innerHTML=Od(),Hd(),document.body.appendChild(B),lo(t),Fd(),requestAnimationFrame(()=>{B&&lo(t)}),document.addEventListener("mousedown",Ki,!0),document.addEventListener("keydown",Zi,!0)}function yn(){B&&(document.removeEventListener("mousedown",Ki,!0),document.removeEventListener("keydown",Zi,!0),B.remove(),B=null,Rt=null,ie=null)}function Od(){return`
    <style>
      :host { all: initial; }
      .menu {
        background: #ffffff;
        border: 2px solid #000000;
        border-radius: 8px;
        padding: 6px;
        font-family: 'Asta Sans', system-ui, sans-serif;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
        display: grid;
        grid-template-columns: repeat(4, ${ft+Le*2}px);
        gap: 2px;
      }
      .menu-btn {
        width: ${ft+Le*2}px;
        height: ${ft+Le*2}px;
        padding: ${Le}px;
        border: 1px solid transparent;
        border-radius: 4px;
        background: #ffffff;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
      }
      .menu-btn:hover {
        border-color: #ff3d8b;
        background: #fef0f5;
      }
      .menu-btn:focus-visible {
        outline: 2px solid #ff3d8b;
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function Fd(){if(!Rt)return;const t=Rt.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of Dd){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(Nd,"svg");o.setAttribute("width",String(ft)),o.setAttribute("height",String(ft)),o.setAttribute("viewBox",`0 0 ${ft} ${ft}`);const i=fr(e,{x:3,y:3,width:ft-6,height:ft-6,fill:e==="line"?"transparent":"#ffffff",stroke:"#1a1a1a",strokeWidth:1.5});i&&o.appendChild(i),r.appendChild(o),t.appendChild(r)}}}function Hd(){Rt&&Rt.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(ie==null||ie(r),yn())})}function lo(t){if(!B)return;const e=t.getBoundingClientRect();B.style.top="0px",B.style.left="0px";const n=B.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),B.style.top=`${Math.max(8,r)}px`,B.style.left=`${Math.max(8,o)}px`}function Ki(t){if(!B)return;const e=t.target;e instanceof Node&&B.contains(e)||yn()}function Zi(t){t.key==="Escape"&&(t.preventDefault(),yn())}const zd=320,Kt=32,_d=.8,Je=200,S={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null};function tn(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function tt(t){return tn(t)}function ce(t,e=!1){const{shadow:n}=S;if(!n)return;const r=n.querySelector('[data-region="toast"]');r&&(r.textContent=t,r.classList.add("visible"),r.classList.toggle("error",e),S.toastTimer!==null&&window.clearTimeout(S.toastTimer),S.toastTimer=window.setTimeout(()=>{r.classList.remove("visible"),S.toastTimer=null},2500))}function en(t,e,n){return Math.max(e,Math.min(n,t))}function Bd(){const t=I();if(t)try{const e=Sa(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Wd(t.name)}-${Ud(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),ce(b("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),ce(b("toast.export-failed"),!0)}}async function qd(){const t=I();if(t){if(t.steps.length===0){ce(b("toast.no-steps"),!0);return}Xo(),await vn(0,{paused:!0})}}function jd(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Ea(r);is(o),ce(b("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),ce(b("toast.import-failed"),!0)}}),t.click()}function Wd(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Ud(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function xn(t){const e=I(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!Xd(n.pickedAtUrl,location.href)?(Qi(n.pickedAtUrl,t),!0):!1}function ae(){const t=I();if(!t)return;const e=q(),n=t.steps[e],r=t.steps[e+1];Oi({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function Xd(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function Qi(t,e){const n=I();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let nn=!1,Ji=0,ta=0,Gn=0,Vn=0;function Yd(){const{shadow:t}=S;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=S;if(!o)return;nn=!0,Ji=n.clientX,ta=n.clientY;const i=o.getBoundingClientRect();Gn=i.left,Vn=i.top,o.style.left=`${Gn}px`,o.style.top=`${Vn}px`,o.style.right="auto",document.addEventListener("mousemove",ea,!0),document.addEventListener("mouseup",na,!0),n.preventDefault()})}function ea(t){const{host:e}=S;if(!nn||!e)return;const n=t.clientX-Ji,r=t.clientY-ta,o=e.offsetWidth,i=e.offsetHeight,a=en(Gn+n,0,window.innerWidth-o),s=en(Vn+r,0,window.innerHeight-i);e.style.left=`${a}px`,e.style.top=`${s}px`}function na(){nn&&(nn=!1,document.removeEventListener("mousemove",ea,!0),document.removeEventListener("mouseup",na,!0))}let rn=!1,ra=0,oa=0;function Gd(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=S;r&&(rn=!0,ra=n.clientY,oa=r.getBoundingClientRect().height,document.addEventListener("mousemove",ia,!0),document.addEventListener("mouseup",aa,!0),n.preventDefault(),n.stopPropagation())})}function ia(t){const{host:e}=S;if(!rn||!e)return;const n=t.clientY-ra,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-Kt,i=en(oa+n,Je,o);e.style.height=`${i}px`,e.style.maxHeight=`${i}px`}function aa(){rn&&(rn=!1,document.removeEventListener("mousemove",ia,!0),document.removeEventListener("mouseup",aa,!0))}function Vd(t){const e=window.innerHeight-Kt*2;return en(t,Je,Math.max(Je,e))}function sa(){const{host:t}=S;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-Kt;if(e.bottom>n){const o=Math.max(Je,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),i=window.innerWidth-r.width;o>i&&(t.style.left=`${Math.max(0,i)}px`)}if(t.style.top){const o=parseFloat(t.style.top),i=window.innerHeight-r.height;o>i&&(t.style.top=`${Math.max(0,i)}px`)}}function vr(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function ca(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function Kd(){const t=vr();t&&(t.hidden?(Zd(),t.hidden=!1):t.hidden=!0)}function la(){const t=vr();t&&(t.hidden=!0)}async function Zd(){const t=ca();if(!t)return;await Pa();const e=Da(),n=await Na(),r=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const i of e){const a=i.name===n?" selected":"";o.push(`<option value="${r(i.name)}"${a}>${r(i.name)} (${r(i.lang)})</option>`)}t.innerHTML=o.join("")}function Qd(){var n;const t=ca();t&&t.addEventListener("change",()=>{const r=t.value;Ia(r.length>0?r:null)});const e=(n=S.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>la())}function Jd(t){var o;const e=vr();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=S.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||la()}function It(t){const e=t===q();Ft(t),e&&ua()}function ua(){const t=Mt();if(!(t!=null&&t.selectors)){te();return}const e=jn(t.selectors);e?(e.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),Fi(e)):te()}function uo(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function yr(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function tp(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function ep(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function np(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function rp(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function op(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function ip(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=I(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));It(l)}const i=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${i}" aria-label="Auto-advance seconds" />
    ${yr(10)}
  `;const a=t.querySelector("input");if(!a)return;a.focus(),a.select();const s=l=>{if(t.classList.remove("editing"),l){po(t,i);return}const u=a.value.trim();let f=5;if(u===""||u==="0")Ut(r.id,{autoAdvanceMs:null});else{const d=Number(u);Number.isFinite(d)&&d>0?(Ut(r.id,{autoAdvanceMs:Math.round(d*1e3)}),f=d):Ut(r.id,{autoAdvanceMs:null})}po(t,f)};a.addEventListener("blur",()=>s(!1)),a.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),a.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),a.addEventListener("mousedown",l=>l.stopPropagation())}function po(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${yr(10)}
  `}function ap(t,e){const{shadow:n,host:r}=S;if(!n||!r)return;Yd(),Gd(),lp(),Qd(),document.addEventListener("mousedown",Jd,!0);const o=i=>i.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",i=>sp(i,t,e))}function sp(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void qd();if(o.closest('[data-action="prompter"]')){n(!0),Ni().then(()=>{ae()});return}if(o.closest('[data-action="export"]'))return Bd();if(o.closest('[data-action="import"]'))return jd();if(o.closest('[data-action="settings-toggle"]'))return Kd();const i=o.closest('[data-action="tool-set"]');if(i instanceof HTMLElement){t.stopPropagation();const s=i.getAttribute("data-tool");if(s==="shape"){Rd(i,c=>{ou(c),P("shape")});return}P(ht()===s?"idle":s);return}if(cp(t,o))return;const a=o.closest("[data-step-card]");if(a&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(a.getAttribute("data-step-card"));if(xn(s))return;It(s)}}function cp(t,e){var c;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const l=Number(n.getAttribute("data-insert-index"));return Mr({insertIndex:l}),!0}if(e.closest('[data-action="step-add"]'))return Mr(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const l=Number(r.getAttribute("data-step-index"));return xn(l)||(It(l),P(ht()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),ls(Number(o.getAttribute("data-step-index"))),!0;const i=e.closest('[data-action="step-link"]');if(i){t.stopPropagation();const l=i.getAttribute("data-url")??"",u=i.closest("[data-step-card]"),f=u?Number(u.getAttribute("data-step-card")):0;return l&&Qi(l,Number.isFinite(f)?f:0),!0}const a=e.closest('[data-action="step-action-toggle"]');if(a instanceof HTMLElement){t.stopPropagation();const l=Number(a.getAttribute("data-step-index")),u=(c=I())==null?void 0:c.steps[l];return u&&(It(l),Ut(u.id,{waitForNavigation:!u.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');return s instanceof HTMLElement?(t.stopPropagation(),s.classList.contains("disabled")||ip(s),!0):!1}function lp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>Kn(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=I();r&&(e.textContent=r.name),Kn(e),e.blur()}}),e.addEventListener("blur",()=>{as(e.textContent??"")}))}function Kn(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const up='[data-manuscript="ui"][data-region="permission-banner"]';function da(){return document.querySelector(up)}function dp(t){const e=da();if(e){fa(e,t);return}pp(t)}function pa(){const t=da();t&&t.remove()}function fa(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function pp(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),e.setAttribute("data-palette",le),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${H+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=fp(),fa(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>pa()),document.body.appendChild(e)}function fp(){return`
    <style>
      ${Ot()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const Te=16,hp=240,mp=/permission|<all_urls>|activeTab/i;async function gp(t){const e=bp({x:t.x-Te,y:t.y-Te,width:t.width+Te*2,height:t.height+Te*2});if(e.width<=0||e.height<=0)return null;const n=await vp();if(!n.ok)return mp.test(n.error)?dp(b("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await wp(n.dataUrl,e,hp)}catch(r){return console.error("[manuscript] crop failed",r),null}}function bp(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function vp(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await xp();try{return{ok:!0,dataUrl:await yp()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function yp(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function xp(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function wp(t,e,n){const r=await kp(t),o=r.naturalWidth/window.innerWidth||1,i=e.x*o,a=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),u=Math.max(1,Math.round(e.width*l)),f=Math.max(1,Math.round(e.height*l)),d=document.createElement("canvas");d.width=u,d.height=f;const p=d.getContext("2d");if(!p)throw new Error("No 2d context");return p.drawImage(r,i,a,s,c,0,0,u,f),d.toDataURL("image/png")}function kp(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function ha(t){const e=t.detail;ds(e.chain);const n=Sp(e.rect,e.chain.framePath);Ep(n)}function Sp(t,e){if(!e||e.length===0)return t;const n=Ol(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function Ep(t){try{const e=await gp(t);cs(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}function Ap(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Mp(){return`
      ${Ot()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function $p(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -1px;
        left: 3px;
        font-family: var(--ff-mono);
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 1px 3px;
        border-radius: 2px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

  `}function Lp(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Tp(){return[Mp(),$p(),Lp(),Ap()].join(`
`)}function Cp(){return`
    <style>${Tp()}</style>
    <div class="panel" role="region" aria-label="${b("panel.aria.region")}">
      ${Ip()}
      ${Pp()}
      <div class="body" data-region="steps"></div>
      ${Dp()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${b("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Ip(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${Aa({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <button type="button" class="close-btn" data-action="close" aria-label="${b("panel.close-aria")}">×</button>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${b("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Pp(){return`
    <div class="tool-bar" role="toolbar" aria-label="${b("panel.tool-label")}">
      <span class="eyebrow">${b("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${b("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${b("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${b("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Dp(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${b("panel.replay-aria")}" title="${b("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${b("panel.prompter-aria")}" title="${b("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${b("panel.import-aria")}" title="${b("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${b("panel.export-aria")}" title="${b("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${b("panel.settings-aria")}" title="${b("panel.settings.title")}" data-region="settings-toggle">
          ${op(16)}
        </button>
      </div>
      ${Np()}
    </div>
  `}function Np(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${b("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${b("panel.settings.close-aria")}" title="${b("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${b("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${b("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function Rp(t){const e=t.pickedAtUrl;return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${tt(e)}"
        aria-label="Open ${tt(e)}"
      >${rp(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${tn(e)}</span>
    </div>
  `:""}function Op(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,i=t.thumbnailDataUrl!==null,a=n&&ht()==="picker",s="step-thumb"+(o?" has-element":"")+(a?" is-picking":""),c=i?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,u=t.waitForNavigation;return r.innerHTML=`
    <button
      type="button"
      class="${s}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${tt(b("step.wand-aria",{n:e+1}))}"
      title="${tt(b("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!i?`<span class="step-thumb-icon">${np(18)}</span>`:""}
      ${!o&&!i?'<span class="step-thumb-plus">+</span>':""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${tt(b("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${tn(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${tt(b("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${tn(t.description)}</div>
    </div>
    ${Rp(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${u}" aria-label="${tt(b("step.action-aria"))}" title="${tt(b("step.action-aria"))}">${ep(10)}</button>
      <div class="step-timer${u?" disabled":""}" data-action="step-timer" data-step-id="${tt(t.id)}" title="${tt(b("step.timer-aria"))}" ${u?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${yr(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${tt(b("step.delete-aria"))}" title="${tt(b("step.delete-aria"))}">${tp(12)}</button>
    </div>
  `,r}function Fp(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function Hp(t,e,n){fo(t,"step-name",n,r=>Ut(e.id,{name:r})),fo(t,"step-desc",n,r=>Ut(e.id,{description:r}),{escapeBlurs:!0}),zp(t,n)}function fo(t,e,n,r,o={}){const i=t.querySelector(`[data-region="${e}"]`);i&&(i.addEventListener("input",()=>Fp(i)),i.addEventListener("focus",()=>{xn(n)||Ft(n)}),i.addEventListener("mousedown",a=>a.stopPropagation()),i.addEventListener("blur",()=>r(i.textContent??"")),i.addEventListener("keydown",a=>{(a.key==="Enter"&&e==="step-name"||a.key==="Escape"&&o.escapeBlurs)&&(a.preventDefault(),i.blur())}))}function zp(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}S.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),S.dragFromIndex=null,(n=S.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{S.dragFromIndex===null||S.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(S.dragFromIndex===null||S.dragFromIndex===e)&&(us(S.dragFromIndex,e),S.dragFromIndex=null)})}function _p(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=I();if(e.innerHTML="",!n)return;const r=q();n.steps.forEach((i,a)=>{if(a>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(a)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${a+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${a}" aria-label="Insert step here">
          ${uo(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=Op(i,a,r===a);e.appendChild(s),Hp(s,i,a)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${uo(10,1.8)}
    </button>
  `,e.appendChild(o)}function ma(t){const{host:e}=S;e&&(e.dataset.promptedHidden=t?"1":"",ht()!=="replay"&&(e.style.display=t?"none":""))}async function on(t){if(S.host){t&&await Ar(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-palette",le);const n=Vd(window.innerHeight*_d);e.style.cssText=["position: fixed",`top: ${Kt}px`,`right: ${Kt}px`,`width: ${zd}px`,`height: ${n}px`,`max-height: calc(100vh - ${Kt*2}px)`,`z-index: ${H+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=Cp(),S.host=e,S.shadow=r,ap(ga,ma),document.body.appendChild(e),t&&await Ar(t)||Er(),Id(),document.addEventListener(he,ha),window.addEventListener("resize",sa),S.unsubscribeMode=mt(Nn),S.unsubscribeScenario=ue(Nn),Nn();const o=I();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(i){console.warn("[manuscript] markActive failed",i)}}function ga(){var e,n;const{host:t}=S;t&&(document.removeEventListener(he,ha),window.removeEventListener("resize",sa),(e=S.unsubscribeMode)==null||e.call(S),S.unsubscribeMode=null,(n=S.unsubscribeScenario)==null||n.call(S),S.unsubscribeScenario=null,P("idle"),te(),Xo(),Pd(),ss(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),S.host=null,S.shadow=null)}function Nn(){const{host:t,shadow:e}=S;if(!e||!t)return;const n=ht(),r=t.dataset.promptedHidden==="1";t.style.display=n==="replay"||r?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(a=>{const s=a.getAttribute("data-tool");a.setAttribute("aria-pressed",String(s===n))});const o=I(),i=e.querySelector('[data-region="title-edit"]');i&&o&&i!==e.activeElement&&(i.textContent!==o.name&&(i.textContent=o.name),Kn(i)),_p(),ua(),fn()&&!mr()&&ae()}function Bp(t,e,n){switch(t.type){case"panel.open":return on(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return ga(),n({ok:!0}),!1;case"scenario.replay":return on(t.scenarioId).then(()=>vn(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return qp(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return Cu(),mr()&&Ze(),fd(),ma(!1),n({ok:!0}),!1}return!1}function qp(t,e){if(mr()){t==="prev"?Xn():t==="next"?Ke():t==="jump"&&typeof e=="number"?Xi(e):t==="pause"&&Yn();return}const n=I();if(!n)return;const r=q();if(t==="prev")r>0&&It(r-1),ae();else if(t==="next")r<n.steps.length-1&&It(r+1),ae();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(xn(e))return;It(e)}ae()}else t==="pause"&&vn(r)}async function jp(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Wp(){try{const t=await bo();if(!t)return;if(Up()){await chrome.storage.local.remove(K.activeReplay);return}P("replay"),await on(t.scenarioId),await vn(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function Up(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function Xp(){try{const t=await jp();if(!t)return;await on(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Ft(t.stepIndex)}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const Yp=window===window.top;vu();Ra();Ma();Fl();du();ml();iu();wl();Hc();Mu();Lu();var ho,mo;Yp&&(Tu().then(()=>{Wp(),Xp()}),chrome.runtime.onMessage.addListener(Bp),(mo=(ho=chrome.permissions)==null?void 0:ho.onAdded)==null||mo.addListener(()=>pa()));
