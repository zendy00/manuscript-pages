/**
 * Prompter inline-edit helpers (v0.5.0).
 *
 * Prompter 는 paused 상태에서만 step name/description 을 contenteditable
 * 로 열고, blur 마다 본 모듈의 빌더로 commit payload 를 만들어 background
 * 로 보낸다. 별도 모듈로 둔 이유 두 가지:
 *
 *   1. payload 모양 (`prompter.edit` 메시지 contract) 을 unit-test 로 묶기 위함.
 *   2. echo-guard — render() 가 곧장 storage.onChanged 로 다시 돌아올 때,
 *      현재 focus 중인 editable 필드만 textContent 덮어쓰기를 건너뛰어
 *      커서 점프를 막는다.
 */

export interface EditInput {
  stepIndex: number;
  /** undefined = 편집되지 않음. 빈 문자열은 "사용자가 비웠다" 는 실 편집 */
  name?: string;
  description?: string;
}

export interface PrompterEditMessage {
  type: 'prompter.edit';
  stepIndex: number;
  name?: string;
  description?: string;
}

/**
 * 편집된 필드가 하나도 없으면 null — caller 는 메시지 전송을 스킵한다.
 * stepIndex 만 와도 변경 없음으로 본다 (실수 commit 방지).
 */
export function buildEditMessage(input: EditInput): PrompterEditMessage | null {
  const nameTouched = input.name !== undefined;
  const descTouched = input.description !== undefined;
  if (!nameTouched && !descTouched) return null;
  const msg: PrompterEditMessage = { type: 'prompter.edit', stepIndex: input.stepIndex };
  if (nameTouched) msg.name = input.name;
  if (descTouched) msg.description = input.description;
  return msg;
}

/**
 * render() 의 echo-guard. 현재 focus 가 같은 editable 노드면 storage
 * push 에서 textContent 를 다시 쓰지 않는다 — IME 조합·커서 위치를 보존.
 */
export interface ToggleActionMessage {
  type: 'prompter.toggleAction';
  stepIndex: number;
}
export interface EditStepDwellMessage {
  type: 'prompter.editStepDwell';
  stepIndex: number;
  ms: number;
}
export interface EditSubDwellMessage {
  type: 'prompter.editSubDwell';
  stepIndex: number;
  subIndex: number;
  ms: number;
}

export function buildToggleActionMessage(stepIndex: number): ToggleActionMessage {
  return { type: 'prompter.toggleAction', stepIndex };
}

export function buildEditStepDwellMessage(
  stepIndex: number,
  ms: number,
): EditStepDwellMessage | null {
  if (!Number.isFinite(ms) || ms <= 0) return null;
  return { type: 'prompter.editStepDwell', stepIndex, ms };
}

export interface ShiftSubDwellMessage {
  type: 'prompter.shiftSubDwell';
  stepIndex: number;
  subId: string;
  direction: -1 | 1;
}

/**
 * v0.5.0 — Selected-sub arrow-key shift. content side routes through
 * `shiftSelectedSubs` which already handles the contiguous-block
 * rebalance against neighbors.
 */
export function buildShiftSubDwellMessage(
  stepIndex: number,
  subId: string,
  direction: -1 | 1,
): ShiftSubDwellMessage | null {
  if (!subId) return null;
  return { type: 'prompter.shiftSubDwell', stepIndex, subId, direction };
}

export function buildEditSubDwellMessage(
  stepIndex: number,
  subIndex: number,
  ms: number,
): EditSubDwellMessage | null {
  if (subIndex < 0 || !Number.isFinite(subIndex)) return null;
  if (!Number.isFinite(ms) || ms <= 0) return null;
  return { type: 'prompter.editSubDwell', stepIndex, subIndex, ms };
}

/**
 * Parse a dwell badge string like "9.5", "9.5s", "⏱ 9.5s" into ms,
 * rounded to the nearest 100ms (matches the scale the existing UI
 * displays). Returns null on garbage / non-positive.
 */
export function parseDwellSeconds(input: string): number | null {
  if (!input) return null;
  if (/-\s*\d/.test(input)) return null;
  const m = input.match(/(\d+(?:\.\d+)?)/);
  if (!m || !m[1]) return null;
  const seconds = parseFloat(m[1]);
  if (!Number.isFinite(seconds) || seconds <= 0) return null;
  return Math.round(seconds * 10) * 100;
}

export function shouldSkipFieldRender(el: Element | null): boolean {
  if (!el) return false;
  if (!(el instanceof HTMLElement)) return false;
  const editable = el.isContentEditable || el.getAttribute('contenteditable') === 'true' || el.getAttribute('contenteditable') === 'plaintext-only';
  if (!editable) return false;
  return document.activeElement === el;
}
