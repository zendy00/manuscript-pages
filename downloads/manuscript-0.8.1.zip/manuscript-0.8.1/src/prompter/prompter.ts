/**
 * Prompter popup window logic.
 *
 * - URL: src/prompter/prompter.html?tabId=N (background가 채워줌)
 * - chrome.storage.local의 prompterState를 읽고 onChanged로 실시간 반영
 * - 버튼 클릭 → chrome.tabs.sendMessage(tabId, { type: 'prompter.cmd', cmd })
 *   로 content script에 명령 전송
 */

import { STORAGE_KEYS } from '../lib/constants';
import { escapeHtml } from '../lib/escape';
import { t } from '../lib/i18n';
import {
  getTtsEnabled,
  onTtsEnabledChanged,
  setTtsEnabled,
} from '../lib/tts';
import {
  buildEditMessage,
  buildEditStepDwellMessage,
  buildShiftSubDwellMessage,
  buildToggleActionMessage,
  parseDwellSeconds,
  shouldSkipFieldRender,
} from './prompter-edit';

interface PrompterSubInfo {
  id: string;
  thumbnailDataUrl: string | null;
  dwellMs: number;
}

interface PrompterStepInfo {
  name: string;
  description: string;
  autoAdvanceMs?: number | null;
  waitForNavigation?: boolean;
  thumbnailDataUrl?: string | null;
  subs?: PrompterSubInfo[];
  primaryDwellMs?: number;
}

interface PrompterState {
  scenarioId: string;
  scenarioName?: string;
  currentIndex: number;
  total: number;
  paused: boolean;
  current: PrompterStepInfo | null;
  next: PrompterStepInfo | null;
  steps?: Array<{ name: string }>;
  /** Auto-advance elapsed at last publish — keeps the progress bar
   *  in sync with the timer across pause/resume (v0.5.0). */
  timerElapsedMs?: number;
}

type Cmd = 'prev' | 'next' | 'pause' | 'jump';

let editableStepIndex = -1;
const dirtyDraft: { name?: string; description?: string } = {};

document.addEventListener('DOMContentLoaded', () => {
  void init();
});

const LIGHT_PALETTE = 'studio';
const DARK_PALETTE = 'studio-dark';

function isDarkPaletteId(id: string): boolean {
  return id.endsWith('-dark');
}

function applyPalette(id: string): void {
  document.body.setAttribute('data-palette', id);
  const btn = document.querySelector<HTMLButtonElement>('[data-region="palette-toggle"]');
  btn?.setAttribute('aria-pressed', isDarkPaletteId(id) ? 'true' : 'false');
}

async function loadPalette(): Promise<string> {
  try {
    const result = await chrome.storage.local.get(STORAGE_KEYS.palette);
    const value = result[STORAGE_KEYS.palette];
    if (typeof value === 'string') return value;
  } catch {
    // chrome.storage unavailable — fall through to default.
  }
  return DARK_PALETTE;
}

async function togglePalette(): Promise<void> {
  const current = document.body.getAttribute('data-palette') ?? DARK_PALETTE;
  const next = isDarkPaletteId(current) ? LIGHT_PALETTE : DARK_PALETTE;
  applyPalette(next);
  try {
    await chrome.storage.local.set({ [STORAGE_KEYS.palette]: next });
  } catch {
    // Non-fatal; UI already reflects the change.
  }
}

async function init(): Promise<void> {
  // chrome.i18n reads the browser UI locale synchronously, no async
  // init needed. Language flips require an extension reload, so we
  // also drop the previous storage-driven re-render dance.
  applyI18n();
  bindCommands();
  bindKeyboardShortcuts();
  bindEditHandlers();
  applyPalette(await loadPalette());
  await renderFromStorage();
  await initTts();
  chrome.storage.onChanged.addListener((changes, area) => {
    if (area !== 'local') return;
    const ch = changes[STORAGE_KEYS.prompterState];
    if (ch) {
      const next = ch.newValue as PrompterState | undefined;
      if (next) render(next);
    }
    const palette = changes[STORAGE_KEYS.palette]?.newValue;
    if (typeof palette === 'string') applyPalette(palette);
    const blocked = changes[STORAGE_KEYS.ttsBlocked];
    if (blocked) {
      ttsBlocked = blocked.newValue === true;
      void renderTtsToggle();
    }
  });
}

function applyI18n(): void {
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n]')) {
    const key = el.getAttribute('data-i18n');
    if (key) el.textContent = t(key);
  }
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n-aria]')) {
    const key = el.getAttribute('data-i18n-aria');
    if (key) el.setAttribute('aria-label', t(key));
  }
  for (const el of document.querySelectorAll<HTMLElement>('[data-i18n-title]')) {
    const key = el.getAttribute('data-i18n-title');
    if (key) el.setAttribute('title', t(key));
  }
}

// Mirror of the content/player autoplay-blocked signal, read straight from
// chrome.storage (the prompter has no replay ports wired, so getPrefs-based
// helpers are no-ops here). The speaker shows the demo can't autoplay sound.
let ttsBlocked = false;

async function initTts(): Promise<void> {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.ttsBlocked);
    ttsBlocked = raw[STORAGE_KEYS.ttsBlocked] === true;
  } catch {
    /* storage unavailable — leave false */
  }
  await renderTtsToggle();
  onTtsEnabledChanged(() => {
    void renderTtsToggle();
  });
}

const SPEAKER_ON = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`;
const SPEAKER_OFF = `<svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`;

async function renderTtsToggle(): Promise<void> {
  const enabled = await getTtsEnabled();
  const btn = document.querySelector<HTMLButtonElement>('[data-region="tts-toggle"]');
  if (!btn) return;
  // Blocked beats enabled: when the demo's narration is held by the browser
  // autoplay policy, show a muted speaker tinted orange (.blocked) + a bouncing
  // hint telling the presenter to click the demo page (clicking the prompter
  // window can't grant the demo page the activation speak() needs).
  btn.setAttribute('aria-pressed', String(enabled));
  btn.classList.toggle('active', enabled && !ttsBlocked);
  btn.classList.toggle('blocked', ttsBlocked);
  const icon = btn.querySelector<HTMLElement>('[data-region="tts-icon"]');
  if (icon) icon.innerHTML = ttsBlocked || !enabled ? SPEAKER_OFF : SPEAKER_ON;
  const hint = btn.querySelector<HTMLElement>('[data-region="tts-hint"]');
  if (hint) hint.hidden = !ttsBlocked;
}


async function renderFromStorage(): Promise<void> {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.prompterState);
    const state = raw[STORAGE_KEYS.prompterState] as PrompterState | undefined;
    if (state) render(state);
  } catch (err) {
    console.warn('[manuscript] prompter load failed', err);
  }
}

// Progress fill is recreated only when the step changes or the user
// resumes from pause; otherwise the running animation would snap back
// to zero on every storage push (counter refresh, step name edit, etc).
let lastStepIndex = -1;
let lastPaused = false;

function render(state: PrompterState): void {
  // Window title 에 시나리오 이름을 끼워 발표 도중 어느 manuscript 인지
  // 한눈에 보이게 한다.
  const baseTitle = t('prompter.title');
  document.title = state.scenarioName ? `${state.scenarioName} · ${baseTitle}` : baseTitle;

  const counter = document.querySelector('[data-region="counter"]');
  if (counter) counter.textContent = `${state.currentIndex + 1} / ${state.total}`;

  // Step 이 바뀌면 다른 step 의 잔재 dirty draft 를 폐기 (편집 중이던 step
  // 을 떠나면 그 편집은 commit 흐름이 따로 처리한다 — 여기선 로컬 상태만 청소).
  if (state.currentIndex !== editableStepIndex) {
    editableStepIndex = state.currentIndex;
    dirtyDraft.name = undefined;
    dirtyDraft.description = undefined;
    selectedSubId = null;
  }

  renderStepColumn('now', state.current, state.currentIndex + 1, state.paused);
  renderStepColumn(
    'next',
    state.next,
    state.next ? state.currentIndex + 2 : null,
    false,
  );
  renderProgress(state);
  renderStepList(state);

  const pauseIcon = document.querySelector('[data-region="pause-icon"]');
  if (pauseIcon) pauseIcon.textContent = state.paused ? '▶' : 'II';

  const status = document.querySelector<HTMLElement>('[data-region="status"]');
  if (status) {
    status.textContent = state.paused ? t('prompter.paused') : t('prompter.playing');
    status.classList.toggle('paused', state.paused);
  }

  const prev = document.querySelector<HTMLButtonElement>('[data-cmd="prev"]');
  if (prev) prev.toggleAttribute('disabled', state.currentIndex <= 0);
  const next = document.querySelector<HTMLButtonElement>('[data-cmd="next"]');
  if (next) next.toggleAttribute('disabled', state.currentIndex >= state.total - 1);
}

function renderStepList(state: PrompterState): void {
  const list = document.querySelector<HTMLElement>('[data-region="step-list"]');
  if (!list) return;
  const steps = state.steps ?? [];
  list.innerHTML = steps
    .map((s, i) => {
      const label = s.name && s.name.length > 0 ? s.name : 'Step Name';
      const active = i === state.currentIndex ? ' class="active"' : '';
      return `<li${active} role="option" data-index="${i}" aria-selected="${i === state.currentIndex}" title="${escapeHtml(label)}"><span class="step-list-no">${i + 1}</span><span class="step-list-name">${escapeHtml(label)}</span></li>`;
    })
    .join('');
}

function renderProgress(state: PrompterState): void {
  const wrap = document.querySelector<HTMLElement>('[data-region="progress"]');
  if (!wrap) return;

  const info = state.current;
  const ms = info?.autoAdvanceMs ?? null;
  const visible = !!info && info.waitForNavigation !== true && ms !== null && ms > 0;

  if (!visible) {
    wrap.hidden = true;
    wrap.innerHTML = '';
    lastStepIndex = -1;
    lastPaused = false;
    return;
  }

  wrap.hidden = false;

  const stepChanged = state.currentIndex !== lastStepIndex;
  const resumedFromPause = lastPaused && !state.paused;
  const shouldRestart = stepChanged || resumedFromPause;
  lastStepIndex = state.currentIndex;
  lastPaused = state.paused;

  let fill = wrap.querySelector<HTMLElement>('.progress-fill');
  if (!fill || shouldRestart) {
    fill?.remove();
    fill = document.createElement('div');
    fill.className = 'progress-fill';
    fill.style.animationDuration = `${ms}ms`;
    // Pause→resume 시 elapsed 만큼 negative animation-delay 로 건너뛰어
    // 바가 0 으로 점프하지 않게 한다. play controller(replay-controls-progress)
    // 와 동일한 패턴이다.
    const elapsedMs = state.timerElapsedMs ?? 0;
    const clampedElapsed = Math.max(0, Math.min(elapsedMs, ms - 1));
    if (clampedElapsed > 0) {
      fill.style.animationDelay = `-${clampedElapsed}ms`;
    }
    wrap.appendChild(fill);
  }

  fill.classList.toggle('paused', state.paused);
}

function setEditable(el: HTMLElement, on: boolean): void {
  if (on) {
    el.setAttribute('contenteditable', 'plaintext-only');
    el.setAttribute('tabindex', '0');
  } else {
    // 편집 중이던 사용자가 paused → playing 으로 가면 commit 메시지가
    // 이미 blur 핸들러에서 나갔다고 보고 그냥 비활성화.
    if (document.activeElement === el && el instanceof HTMLElement) el.blur();
    el.removeAttribute('contenteditable');
    el.removeAttribute('tabindex');
  }
}

function bindEditHandlers(): void {
  const name = document.querySelector<HTMLElement>('[data-region="now-name"]');
  const text = document.querySelector<HTMLElement>('[data-region="now-text"]');
  name?.addEventListener('input', () => {
    dirtyDraft.name = name.textContent ?? '';
  });
  text?.addEventListener('input', () => {
    dirtyDraft.description = text.textContent ?? '';
  });
  name?.addEventListener('blur', () => {
    void commitDraft();
  });
  text?.addEventListener('blur', () => {
    void commitDraft();
  });
  // Enter on name → blur (commit). description 은 multi-line 허용.
  name?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      name.blur();
    }
  });

  // Step header — timer dwell edit + action toggle. paused 일 때만 활성화.
  // 편집 가능한 부분은 숫자 span 만. 아이콘/단위(⏱/s) 는 정적이라 사용자가
  // 지울 수 없다. 단, 클릭 hit-area 는 배지 전체 — 아이콘/단위를 클릭해도
  // 숫자 span 으로 caret 이 들어간다.
  const timer = document.querySelector<HTMLElement>('[data-region="now-timer"]');
  const timerValue = document.querySelector<HTMLElement>('[data-region="now-timer-value"]');
  timer?.addEventListener('mousedown', (e) => {
    if (!timerValue?.isContentEditable) return;
    e.preventDefault(); // 직접 클릭한 caret 위치 대신 전체 선택을 우선.
    timerValue.focus();
  });
  // Edit 진입 시 기존 숫자를 전체 선택 — 곧장 새 숫자를 입력하면 덮어쓴다.
  timerValue?.addEventListener('focus', () => {
    if (!timerValue.isContentEditable) return;
    const range = document.createRange();
    range.selectNodeContents(timerValue);
    const sel = window.getSelection();
    sel?.removeAllRanges();
    sel?.addRange(range);
  });
  timerValue?.addEventListener('blur', () => {
    void commitStepDwell(timerValue);
  });
  timerValue?.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      timerValue.blur();
    }
  });

  const action = document.querySelector<HTMLElement>('[data-region="now-action"]');
  action?.addEventListener('click', () => {
    if (!action.hasAttribute('aria-pressed')) return;
    // editable=false 일 때 button 은 hidden 이라 클릭 자체가 못 옴.
    void commitToggleAction();
  });

  // Sub-list — click selects, ← / → on document shifts the selected sub.
  const list = document.querySelector<HTMLElement>('[data-region="now-sub-list"]');
  list?.addEventListener('click', (e) => {
    const t = e.target;
    if (!(t instanceof Element)) return;
    const row = t.closest<HTMLElement>('.sub-row');
    if (!row) return;
    if (!list.classList.contains('editable')) return;
    const id = row.getAttribute('data-sub-id');
    if (!id) return; // primary row 는 비선택
    selectedSubId = id;
    for (const r of list.querySelectorAll<HTMLElement>('.sub-row')) {
      r.classList.toggle('selected', r === row);
      r.setAttribute('aria-selected', r === row ? 'true' : 'false');
    }
    row.focus();
  });
  // 리스트 밖 클릭 시 선택 해제 — 단축키가 nav 로 돌아오게 한다.
  document.addEventListener('click', (e) => {
    if (!selectedSubId) return;
    const t = e.target;
    if (t instanceof Element && t.closest('.sub-list')) return;
    deselectSub();
  });
}

async function commitStepDwell(el: HTMLElement): Promise<void> {
  if (editableStepIndex < 0) return;
  const ms = parseDwellSeconds(el.textContent ?? '');
  if (ms === null) {
    // Reject; let the next render restore the prior textContent.
    el.textContent = '';
    return;
  }
  const payload = buildEditStepDwellMessage(editableStepIndex, ms);
  if (!payload) return;
  await sendPrompterMessage(payload);
}

async function commitToggleAction(): Promise<void> {
  if (editableStepIndex < 0) return;
  const payload = buildToggleActionMessage(editableStepIndex);
  await sendPrompterMessage(payload);
}

function deselectSub(): void {
  selectedSubId = null;
  const list = document.querySelector<HTMLElement>('[data-region="now-sub-list"]');
  if (!list) return;
  for (const r of list.querySelectorAll<HTMLElement>('.sub-row')) {
    r.classList.remove('selected');
    r.setAttribute('aria-selected', 'false');
  }
}

async function shiftSelectedSub(direction: 1 | -1): Promise<void> {
  if (editableStepIndex < 0 || !selectedSubId) return;
  const payload = buildShiftSubDwellMessage(editableStepIndex, selectedSubId, direction);
  if (!payload) return;
  await sendPrompterMessage(payload);
}

async function sendPrompterMessage(payload: unknown): Promise<void> {
  const p = (async () => {
    try {
      await chrome.runtime.sendMessage(payload);
    } catch (err) {
      console.warn('[manuscript] prompter message failed', err);
    }
  })();
  pendingCommit = p;
  await p;
  if (pendingCommit === p) pendingCommit = null;
}

// Latest in-flight edit relay. sendCommand awaits this before forwarding
// a play (`pause`) cmd so the edit lands at the content tab BEFORE the
// togglePause/dirty-check fires — without it the click-on-play gesture
// races its own blur-commit and the play often wins.
let pendingCommit: Promise<void> | null = null;

async function commitDraft(): Promise<void> {
  if (editableStepIndex < 0) return;
  const payload = buildEditMessage({
    stepIndex: editableStepIndex,
    name: dirtyDraft.name,
    description: dirtyDraft.description,
  });
  // draft 를 비워두면 다음 render 가 storage 의 권위값으로 바로 복원된다.
  dirtyDraft.name = undefined;
  dirtyDraft.description = undefined;
  if (!payload) return;
  await sendPrompterMessage(payload);
}

function renderStepColumn(
  side: 'now' | 'next',
  info: PrompterStepInfo | null,
  stepNo: number | null,
  editable: boolean,
): void {
  const stepNoEl = document.querySelector<HTMLElement>(`[data-region="${side}-no"]`);
  if (stepNoEl) stepNoEl.textContent = stepNo === null ? '' : t('prompter.step-no', { n: stepNo });

  const isNow = side === 'now';
  const name = document.querySelector<HTMLElement>(`[data-region="${side}-name"]`);
  if (name) {
    setEditable(name, editable);
    // Echo-guard: 편집 중인 필드는 storage push 의 textContent 덮어쓰기를
    // 건너뛴다 (IME 조합·caret 보존). dirty draft 가 있으면 그 값을 우선.
    if (!shouldSkipFieldRender(name)) {
      name.textContent = (isNow ? dirtyDraft.name : undefined) ?? info?.name ?? '';
    }
  }

  const text = document.querySelector<HTMLElement>(`[data-region="${side}-text"]`);
  if (text) {
    setEditable(text, editable);
    if (!shouldSkipFieldRender(text)) {
      text.textContent =
        (isNow ? dirtyDraft.description : undefined) ??
        info?.description ??
        (isNow ? t('prompter.waiting') : '');
    }
  }

  const thumb = document.querySelector<HTMLImageElement>(`[data-region="${side}-thumb"]`);
  if (thumb) {
    if (info?.thumbnailDataUrl) {
      thumb.src = info.thumbnailDataUrl;
      thumb.hidden = false;
    } else {
      thumb.removeAttribute('src');
      thumb.hidden = true;
    }
  }

  const timer = document.querySelector<HTMLElement>(`[data-region="${side}-timer"]`);
  if (timer) {
    const ms = info?.autoAdvanceMs ?? null;
    // Timer 는 autoAdvance 가 있을 때 보인다. action+subs 같이 섞인
    // 모드도 autoAdvanceMs > 0 이라 dwell 편집이 의미가 있다. 순수
    // action(no subs, no timer)일 때만 숨김.
    const hasTimer = !!info && ms !== null && ms > 0;
    if (hasTimer) {
      timer.hidden = false;
      const valueEl = timer.querySelector<HTMLElement>(
        side === 'now' ? '[data-region="now-timer-value"]' : '.timer-value',
      );
      if (valueEl) {
        // 편집은 숫자 span 만. 아이콘/단위는 정적.
        setEditable(valueEl, isNow && editable);
        if (!shouldSkipFieldRender(valueEl)) {
          const sec = Math.round((ms as number) / 100) / 10;
          valueEl.textContent = String(sec);
        }
      }
    } else {
      timer.hidden = true;
    }
  }

  const action = document.querySelector<HTMLElement>(`[data-region="${side}-action"]`);
  if (action) {
    if (isNow && editable) {
      // Paused: 토글 버튼이 항상 보이게. 현재 ON/OFF 는 aria-pressed 로.
      action.hidden = false;
      action.setAttribute('aria-pressed', info?.waitForNavigation ? 'true' : 'false');
      action.classList.toggle('on', !!info?.waitForNavigation);
    } else {
      // Playing 또는 next 컬럼: 기존 0.4 동작 (ON 일 때만 표시).
      action.hidden = !info?.waitForNavigation;
      action.setAttribute('aria-pressed', info?.waitForNavigation ? 'true' : 'false');
      action.classList.toggle('on', !!info?.waitForNavigation);
    }
  }

  // Sub list — 'now' 컬럼만, paused 일 때만 보임. subs 가 있으면 항상
  // 표시(편집 가능 여부는 paused 에 의해 결정). next 는 sub-list 안 보여줌.
  if (isNow) {
    renderSubList(info, editable);
  }
}

// Currently-selected sub id (per editable step). ↑/↓ shift this sub's
// dwell. Cleared on step change.
let selectedSubId: string | null = null;

const FLOW_ARROW_SVG =
  '<svg class="sub-flow" width="12" height="14" viewBox="0 0 12 14" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 1 v10 M2.5 8.5 l3.5 3.5 3.5 -3.5"/></svg>';

function renderSubList(info: PrompterStepInfo | null, editable: boolean): void {
  const list = document.querySelector<HTMLElement>('[data-region="now-sub-list"]');
  const thumb = document.querySelector<HTMLImageElement>('[data-region="now-thumb"]');
  if (!list) return;
  const subs = info?.subs ?? [];
  const hasSubs = subs.length > 0;

  // Sub 가 있으면 primary 도 리스트의 첫 row 로 흡수 → 별도 .thumb 는 숨김.
  // Sub 가 없으면 기존 단독 .thumb 유지.
  if (thumb) {
    if (hasSubs) {
      thumb.hidden = true;
    }
    // (sub 없을 때의 hidden 토글은 renderStepColumn 의 기존 thumb 처리에서 담당)
  }

  if (!hasSubs) {
    list.hidden = true;
    list.innerHTML = '';
    selectedSubId = null;
    return;
  }

  // Selection 유효성: 현재 step 에 해당 sub 가 사라졌으면 클리어.
  if (selectedSubId && !subs.some((s) => s.id === selectedSubId)) {
    selectedSubId = null;
  }
  list.hidden = false;
  list.classList.toggle('editable', editable);

  // Node 목록: [primary, ...subs]. Primary 는 비선택, dwell 표시만.
  const primaryDwell = info?.primaryDwellMs ?? 0;
  const primarySec = Math.round(primaryDwell / 100) / 10;
  const primaryThumb = info?.thumbnailDataUrl
    ? `<img class="sub-thumb primary" src="${info.thumbnailDataUrl}" alt="">`
    : '<span class="sub-thumb-empty primary"></span>';
  const rows: string[] = [
    `<div class="sub-row primary">${primaryThumb}<span class="sub-dwell">⏱ ${primarySec}s</span></div>`,
  ];
  for (const s of subs) {
    rows.push(FLOW_ARROW_SVG);
    const sec = Math.round(s.dwellMs / 100) / 10;
    const t = s.thumbnailDataUrl
      ? `<img class="sub-thumb" src="${s.thumbnailDataUrl}" alt="">`
      : '<span class="sub-thumb-empty"></span>';
    const selected = editable && s.id === selectedSubId ? ' selected' : '';
    rows.push(
      `<div class="sub-row${selected}" data-sub-id="${s.id}" role="option" aria-selected="${
        s.id === selectedSubId
      }" tabindex="${editable ? 0 : -1}">${t}<span class="sub-dwell">⏱ ${sec}s</span></div>`,
    );
  }
  list.innerHTML = rows.join('');
}

function bindCommands(): void {
  document.querySelectorAll<HTMLButtonElement>('[data-cmd]').forEach((btn) => {
    btn.addEventListener('click', () => {
      const cmd = btn.getAttribute('data-cmd') as Cmd | null;
      if (!cmd) return;
      void sendCommand(cmd);
    });
  });

  // Step list — clicking an item jumps replay (or panel step) to that index.
  // Mirrors play-controller's step-jump popup behavior.
  const list = document.querySelector<HTMLElement>('[data-region="step-list"]');
  list?.addEventListener('click', (event) => {
    const target = event.target;
    if (!(target instanceof Element)) return;
    const li = target.closest<HTMLLIElement>('li[data-index]');
    if (!li) return;
    const i = Number(li.getAttribute('data-index'));
    if (Number.isFinite(i)) void sendCommand('jump', i);
  });

  // TTS toggle
  const ttsBtn = document.querySelector<HTMLButtonElement>('[data-region="tts-toggle"]');
  ttsBtn?.addEventListener('click', () => {
    void (async () => {
      const next = !(await getTtsEnabled());
      await setTtsEnabled(next);
    })();
  });

  // Palette (dark mode) toggle
  const paletteBtn = document.querySelector<HTMLButtonElement>('[data-region="palette-toggle"]');
  paletteBtn?.addEventListener('click', () => {
    void togglePalette();
  });

  // Record toggle. The recorder window owns the capture and must be opened
  // from the demo tab (so its ?tab is correct), so we relay through the
  // background to the client tab's content script rather than capturing here.
  const recordBtn = document.querySelector<HTMLButtonElement>('[data-region="record-toggle"]');
  recordBtn?.addEventListener('click', () => {
    void handleRecordClick(recordBtn);
  });
}

async function handleRecordClick(_btn: HTMLButtonElement): Promise<void> {
  try {
    await chrome.runtime.sendMessage({ type: 'recording.fromPrompter' });
  } catch (err) {
    console.warn('[manuscript] prompter record request failed', err);
  }
}

// Keyboard shortcuts — match the play controller's bindings so the
// prompter window can be driven without the mouse.
//   ←  prev,  →  next,  Space  pause/play
//   When a sub is selected ← / → instead shift its dwell ±100ms (v0.5.0).
function bindKeyboardShortcuts(): void {
  document.addEventListener('keydown', (event) => {
    if (event.target instanceof HTMLInputElement || event.target instanceof HTMLTextAreaElement) {
      return;
    }
    if (event.target instanceof HTMLElement && event.target.isContentEditable) {
      return;
    }
    switch (event.key) {
      case 'ArrowRight':
        event.preventDefault();
        if (selectedSubId) {
          // sub 선택 중일 땐 우측 화살표 = dwell shift later (block 이 늦게 시작).
          void shiftSelectedSub(1);
        } else {
          void sendCommand('next');
        }
        break;
      case 'ArrowLeft':
        event.preventDefault();
        if (selectedSubId) {
          void shiftSelectedSub(-1);
        } else {
          void sendCommand('prev');
        }
        break;
      case 'Escape':
        if (selectedSubId) {
          event.preventDefault();
          deselectSub();
        }
        break;
      case ' ':
      case 'Spacebar':
        event.preventDefault();
        void sendCommand('pause');
        break;
    }
  });
}

async function sendCommand(cmd: Cmd, index?: number): Promise<void> {
  try {
    // 같은 클릭 제스처에서 blur-commit 과 cmd send 가 동시에 일어날 수
    // 있어 content 도착 순서가 보장 안 된다. 진행 중인 edit relay 가
    // 있으면 그게 끝난 뒤 cmd 를 보내, 새 텍스트가 반드시 dirty 플래그와
    // 함께 적용된 상태에서 togglePause 가 실행되도록 한다.
    if (pendingCommit) await pendingCommit;
    // Background가 저장된 client tabId로 relay. popup이 직접 tabs.sendMessage
    // 하려면 host_permission 등 권한 이슈가 있어 background를 거친다.
    await chrome.runtime.sendMessage({ type: 'prompter.cmd', cmd, index });
  } catch (err) {
    console.warn('[manuscript] prompter command failed', err);
  }
}
