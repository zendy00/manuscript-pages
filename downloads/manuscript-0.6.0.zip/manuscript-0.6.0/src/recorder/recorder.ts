/**
 * Manuscript recorder window — owns the getDisplayMedia stream +
 * MediaRecorder AND is the recording control surface. Separate persistent
 * window so the recording survives the demo tab navigating; window/screen
 * capture carries system audio (TTS). This window is not itself captured.
 * docs/09.SUBSYSTEMS.md (Screen recording).
 *
 * Light/dark via body[data-palette] (tokens.css), synced with the rest of
 * the extension through STORAGE_KEYS.palette like the prompter window.
 *
 * Messaging:
 *   here ─tabs.sendMessage(demoTab, 'recording.armed')───────────────▶ content
 *   here ─tabs.sendMessage(demoTab, 'recording.ended')───────────────▶ content
 *   here ─tabs.sendMessage(demoTab, 'recording.togglePause')─────────▶ content
 *   content ─runtime 'recording.stopRequest'─────────────────────────▶ here
 *   content ─runtime 'recording.paused' / 'recording.resumed'────────▶ here
 *
 * Space / Esc are detected in this window too (it may hold focus while the
 * presenter clicks Pause/Stop here) and forwarded to the demo tab so they
 * behave the same as pressing them on the demo page.
 */

import { STORAGE_KEYS } from '../lib/constants';
import { t } from '../lib/i18n';
import shareStep2Asset from '../content/recording/assets/share-step-2.png?url';

const params = new URLSearchParams(location.search);
const demoTabId = Number(params.get('tab'));

const primaryBtn = document.getElementById('primary') as HTMLButtonElement;
const statusEl = document.getElementById('status') as HTMLElement;
const guideEl = document.getElementById('guide') as HTMLElement;
const liveEl = document.getElementById('live') as HTMLElement;
const scenarioState = document.getElementById('scenario-state') as HTMLElement;
const scenarioStateLabel = document.getElementById('scenario-state-label') as HTMLElement;
const keysInfoGuide = document.querySelector<HTMLElement>('[data-only="guide"]');
const micInput = document.getElementById('opt-mic') as HTMLInputElement;
const shareImg = document.getElementById('share-img') as HTMLImageElement;

// ── i18n + assets ──────────────────────────────────────────────────────
document.querySelectorAll<HTMLElement>('[data-i18n]').forEach((el) => {
  const key = el.getAttribute('data-i18n');
  if (key) el.textContent = t(key);
});
document.querySelectorAll<HTMLElement>('[data-i18n-html]').forEach((el) => {
  const key = el.getAttribute('data-i18n-html');
  if (key) el.innerHTML = t(key);
});
shareImg.src = chrome.runtime.getURL(shareStep2Asset.replace(/^\/+/, ''));
shareImg.alt = t('recorder.share-title');
statusEl.textContent = '';

// ── Palette (light / dark) ─────────────────────────────────────────────
const LIGHT_PALETTE = 'studio';

function applyPalette(id: string): void {
  document.body.setAttribute('data-palette', id);
}
async function loadPalette(): Promise<string> {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.palette);
    const v = raw[STORAGE_KEYS.palette];
    if (typeof v === 'string') return v;
  } catch {
    /* default below */
  }
  return LIGHT_PALETTE;
}
void loadPalette().then(applyPalette);
chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const p = changes[STORAGE_KEYS.palette]?.newValue;
  if (typeof p === 'string') applyPalette(p);
});

// ── Live step view (mirrors the prompter via shared prompterState) ───────
// The demo tab publishes STORAGE_KEYS.prompterState as replay advances; we
// read the same key so the recorder shows the step list + now / next while
// recording, without holding any scenario state of its own.
interface RecStepInfo {
  name: string;
  description: string;
}
interface RecPrompterState {
  currentIndex: number;
  total: number;
  current: RecStepInfo | null;
  next: RecStepInfo | null;
  steps?: Array<{ name: string }>;
}

const liveCounter = document.getElementById('live-counter') as HTMLElement;
const recStepList = document.getElementById('rec-step-list') as HTMLElement;
const nowNo = document.getElementById('now-no') as HTMLElement;
const nowName = document.getElementById('now-name') as HTMLElement;
const nowText = document.getElementById('now-text') as HTMLElement;
const nextNo = document.getElementById('next-no') as HTMLElement;
const nextName = document.getElementById('next-name') as HTMLElement;
const nextText = document.getElementById('next-text') as HTMLElement;

function escapeHtml(s: string): string {
  return s.replace(/[&<>"]/g, (c) =>
    c === '&' ? '&amp;' : c === '<' ? '&lt;' : c === '>' ? '&gt;' : '&quot;',
  );
}

function renderLiveState(state: RecPrompterState): void {
  liveCounter.textContent = `${state.currentIndex + 1} / ${state.total}`;

  const steps = state.steps ?? [];
  recStepList.innerHTML = steps
    .map((s, i) => {
      const label = s.name && s.name.length > 0 ? s.name : t('prompter.waiting');
      const active = i === state.currentIndex ? ' class="active"' : '';
      return `<li${active}><span class="rec-step-no">${i + 1}</span><span class="rec-step-name">${escapeHtml(label)}</span></li>`;
    })
    .join('');
  recStepList.querySelector('li.active')?.scrollIntoView({ block: 'nearest' });

  nowNo.textContent = String(state.currentIndex + 1);
  nowName.textContent = state.current?.name ?? '';
  nowText.textContent = state.current?.description ?? '';

  if (state.next) {
    nextNo.textContent = String(state.currentIndex + 2);
    nextName.textContent = state.next.name ?? '';
    nextText.textContent = state.next.description ?? '';
  } else {
    nextNo.textContent = '';
    nextName.textContent = '';
    nextText.textContent = '';
  }
}

async function renderLiveFromStorage(): Promise<void> {
  try {
    const raw = await chrome.storage.local.get(STORAGE_KEYS.prompterState);
    const s = raw[STORAGE_KEYS.prompterState] as RecPrompterState | undefined;
    if (s) renderLiveState(s);
  } catch {
    /* no state yet */
  }
}

chrome.storage.onChanged.addListener((changes, area) => {
  if (area !== 'local') return;
  const next = changes[STORAGE_KEYS.prompterState]?.newValue as RecPrompterState | undefined;
  if (next) renderLiveState(next);
});

// ── Recording ──────────────────────────────────────────────────────────
const MIME_CANDIDATES = [
  'video/webm;codecs=vp9,opus',
  'video/webm;codecs=vp9',
  'video/webm;codecs=vp8,opus',
  'video/webm;codecs=vp8',
  'video/webm',
];
function pickMime(): string {
  for (const m of MIME_CANDIDATES) {
    if (typeof MediaRecorder !== 'undefined' && MediaRecorder.isTypeSupported(m)) return m;
  }
  return 'video/webm';
}

interface Active {
  recorder: MediaRecorder;
  chunks: Blob[];
  cleanup: () => void;
  finalized: boolean;
}
let active: Active | null = null;

function notifyDemo(type: string, extra: Record<string, unknown> = {}): void {
  if (!Number.isFinite(demoTabId)) return;
  void chrome.tabs.sendMessage(demoTabId, { type, ...extra }).catch(() => undefined);
}

/**
 * Pull this recorder window back to the front. getDisplayMedia brings the
 * shared (demo) window forward, burying us — so when we bail on a bad share
 * the error toast would be hidden. Re-focus + flash so the user sees it.
 */
function focusSelf(): void {
  try {
    chrome.windows.getCurrent((w) => {
      if (w?.id != null) chrome.windows.update(w.id, { focused: true, drawAttention: true });
    });
  } catch {
    window.focus();
  }
}

function showGuidePhase(): void {
  guideEl.hidden = false;
  liveEl.hidden = true;
  if (keysInfoGuide) keysInfoGuide.hidden = false;
  primaryBtn.textContent = t('recorder.start');
  primaryBtn.classList.remove('is-recording');
}
function showLivePhase(): void {
  guideEl.hidden = true;
  liveEl.hidden = false;
  if (keysInfoGuide) keysInfoGuide.hidden = true;
  // The recording badge ("녹화 중") is fixed (filled by the data-i18n pass) —
  // recording runs regardless of the scenario's play/pause, which the
  // scenario chip reflects separately.
  setScenarioPaused(false);
  primaryBtn.textContent = t('recorder.stop');
  primaryBtn.classList.add('is-recording');
  void renderLiveFromStorage();
}

function setScenarioPaused(paused: boolean): void {
  scenarioState.classList.toggle('is-paused', paused);
  scenarioStateLabel.textContent = t(paused ? 'recorder.scenario-paused' : 'recorder.scenario-playing');
}

chrome.runtime.onMessage.addListener((msg) => {
  if (!msg || typeof msg !== 'object') return;
  const type = (msg as { type?: string }).type;
  if (type === 'recording.stopRequest') stopAndSave();
  else if (type === 'recording.paused') setScenarioPaused(true);
  else if (type === 'recording.resumed') setScenarioPaused(false);
});

primaryBtn.addEventListener('click', () => {
  if (active) stopAndSave();
  else void beginShare();
});

// Space / Esc work even when this recorder window holds focus. Only while
// recording (active) so the Start button's own Space/Enter still clicks it
// in the guide phase. Space → toggle the demo's scenario pause (the demo tab
// echoes recording.paused/resumed back to update the indicator); Esc → stop.
window.addEventListener(
  'keydown',
  (event) => {
    if (!active) return;
    if (event.key === ' ' || event.key === 'Spacebar') {
      event.preventDefault();
      notifyDemo('recording.togglePause');
    } else if (event.key === 'Escape') {
      event.preventDefault();
      stopAndSave();
    }
  },
  true,
);

/**
 * Get the demo tab onto the scenario's starting page before we start
 * capturing. We already hold the display stream (getDisplayMedia ran on the
 * Start click), so navigating + going fullscreen now happens BEFORE
 * recorder.start — none of it lands in the video. The demo tab replies
 * { ready:true } when already on the right page, or navigates there and
 * replies { ready:false }; the freshly-loaded content script then emits
 * 'recording.pageReady', which waitForPageReady resolves on.
 */
async function prepareDemo(): Promise<{ navigating: boolean }> {
  if (!Number.isFinite(demoTabId)) return { navigating: false };
  try {
    const res = (await chrome.tabs.sendMessage(demoTabId, { type: 'recording.prepare' })) as
      | { ready?: boolean }
      | undefined;
    return { navigating: res?.ready === false };
  } catch {
    return { navigating: false };
  }
}

/**
 * Wait for one of a set of runtime messages from the demo tab, mapping each
 * message type to a resolved value. Resolves `onTimeout` if none arrives in
 * time (e.g. the tab has no content script) so the flow never hangs.
 */
function awaitDemoSignal<T>(
  map: Record<string, T>,
  timeoutMs: number,
  onTimeout: T,
): Promise<T> {
  return new Promise((resolve) => {
    let settled = false;
    const finish = (value: T): void => {
      if (settled) return;
      settled = true;
      chrome.runtime.onMessage.removeListener(onMsg);
      clearTimeout(timer);
      resolve(value);
    };
    const onMsg = (msg: unknown): void => {
      const type = (msg as { type?: string })?.type;
      const value = type ? map[type] : undefined;
      if (value !== undefined) finish(value);
    };
    chrome.runtime.onMessage.addListener(onMsg);
    const timer = setTimeout(() => finish(onTimeout), timeoutMs);
  });
}

/** Resolve when the (re-navigated) demo tab signals it's ready, or on timeout. */
function waitForPageReady(timeoutMs: number): Promise<unknown> {
  return awaitDemoSignal({ 'recording.pageReady': true }, timeoutMs, true);
}

/**
 * Run the pre-capture countdown on the demo page and wait for it. Resolves
 * true when it completes (start capturing), false when the user cancels it.
 * A no-content-script tab (no response) resolves true after a short timeout
 * (~5s covers a 3·2·1 count plus latency) so recording isn't blocked.
 */
function runCountdownAndWait(): Promise<boolean> {
  notifyDemo('recording.countdown');
  return awaitDemoSignal(
    { 'recording.countdownDone': true, 'recording.countdownCancelled': false },
    5000,
    true,
  );
}

async function beginShare(): Promise<void> {
  const withMicrophone = micInput.checked;
  try {
    primaryBtn.disabled = true;
    const display = await navigator.mediaDevices.getDisplayMedia({
      video: true,
      audio: true,
      systemAudio: 'include',
    } as DisplayMediaStreamOptions);

    // Guard the common mistakes. We can't know the captured window's app
    // (browser privacy), but the surface type + audio tell us whether the
    // TTS narration (system audio) will land. A tab surface ('browser')
    // never carries system audio; a window/screen needs the "share system
    // audio" box ticked. If neither and the user isn't narrating by mic,
    // the video would be silent of narration — bail and let them re-share.
    const vSettings = display.getVideoTracks()[0]?.getSettings() as
      | (MediaTrackSettings & { displaySurface?: string })
      | undefined;
    const surface = vSettings?.displaySurface;
    const systemAudioCaptured = display.getAudioTracks().length > 0 && surface !== 'browser';
    if (!withMicrophone && !systemAudioCaptured) {
      display.getTracks().forEach((tk) => tk.stop());
      primaryBtn.disabled = false;
      statusEl.textContent = t('recorder.warn-no-tts');
      statusEl.classList.add('is-error');
      focusSelf();
      return;
    }

    let micStream: MediaStream | null = null;
    if (withMicrophone) {
      try {
        micStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      } catch (err) {
        console.warn('[manuscript/recorder] mic failed', err);
      }
    }

    let audioContext: AudioContext | null = null;
    let mergedAudio: MediaStreamTrack | null = null;
    const sysAudio = display.getAudioTracks();
    const micAudio = micStream?.getAudioTracks() ?? [];
    if (sysAudio.length || micAudio.length) {
      audioContext = new AudioContext();
      const dest = audioContext.createMediaStreamDestination();
      if (sysAudio.length) audioContext.createMediaStreamSource(new MediaStream(sysAudio)).connect(dest);
      if (micAudio.length) audioContext.createMediaStreamSource(new MediaStream(micAudio)).connect(dest);
      mergedAudio = dest.stream.getAudioTracks()[0] ?? null;
    }

    const videoTrack = display.getVideoTracks()[0];
    const finalTracks: MediaStreamTrack[] = videoTrack ? [videoTrack] : [];
    if (mergedAudio) finalTracks.push(mergedAudio);
    const finalStream = new MediaStream(finalTracks);

    const recorder = new MediaRecorder(finalStream, { mimeType: pickMime() });
    const chunks: Blob[] = [];
    const a: Active = {
      recorder,
      chunks,
      finalized: false,
      cleanup: () => {
        display.getTracks().forEach((tk) => tk.stop());
        micStream?.getTracks().forEach((tk) => tk.stop());
        void audioContext?.close().catch(() => undefined);
      },
    };
    active = a;

    recorder.ondataavailable = (e) => {
      if (e.data && e.data.size) chunks.push(e.data);
    };
    recorder.onstop = () => download(a);
    recorder.onerror = () => download(a);
    display.getVideoTracks()[0]?.addEventListener('ended', () => stopAndSave());

    // Get the demo tab onto the scenario's start page (it navigates there if
    // needed), then fullscreen it — all BEFORE recording starts, so neither
    // the navigation nor the fullscreen transition is captured.
    const prep = await prepareDemo();
    if (prep.navigating) await waitForPageReady(8000);
    notifyDemo('recording.enterFullscreen');

    // Pre-capture countdown on the demo page. Its 3·2·1 doubles as the
    // settle time for the fullscreen transition (no extra delay needed) and
    // is NOT recorded — capture starts only after it completes. Cancelling it
    // (Esc / Space / Cancel) aborts the whole recording.
    const proceed = await runCountdownAndWait();
    if (!proceed) {
      a.cleanup();
      active = null;
      notifyDemo('recording.exitFullscreen');
      showGuidePhase();
      primaryBtn.disabled = false;
      return;
    }

    recorder.start(1000);
    primaryBtn.disabled = false;
    showLivePhase();
    statusEl.textContent = '';
    statusEl.classList.remove('is-error');
    notifyDemo('recording.armed');
  } catch (err) {
    primaryBtn.disabled = false;
    statusEl.textContent = 'Could not start: ' + (err instanceof Error ? err.message : String(err));
    statusEl.classList.add('is-error');
    focusSelf();
  }
}

function stopAndSave(): void {
  if (active && active.recorder.state === 'recording') active.recorder.stop();
  else if (active) download(active);
}

function download(a: Active): void {
  if (a.finalized) return;
  a.finalized = true;
  const blob = new Blob(a.chunks, { type: 'video/webm' });
  const url = URL.createObjectURL(blob);
  void chrome.downloads.download({ url, filename: filename(), saveAs: true });
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
  a.cleanup();
  active = null;
  showGuidePhase();
  statusEl.classList.remove('is-error');
  statusEl.textContent = t('recorder.status-saved');
  notifyDemo('recording.ended');
}

function filename(): string {
  const d = new Date();
  const p = (n: number): string => String(n).padStart(2, '0');
  return `manuscript-recording-${d.getFullYear()}${p(d.getMonth() + 1)}${p(d.getDate())}-${p(d.getHours())}${p(d.getMinutes())}.webm`;
}
