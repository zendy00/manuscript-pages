import"./chunk-B5Qt9EMX.js";import{o as we,p as ve,q as $e,m as G,r as Se,b as Ae,a as Ee,_ as Le,n as K,s as ke}from"./chunk-b9UwEhlW.js";import{S as v}from"./chunk-C8iY6jtx.js";import{t as s}from"./chunk-ClheHCf9.js";const Be="<all_urls>";function Ie(){return{origins:[Be]}}function Ce(){return typeof chrome>"u"?null:chrome.permissions??null}function Y(t){const e=Ce();if(!e){t(!1);return}try{e.request(Ie(),r=>t(r??!1))}catch{t(!1)}}function k(t){const e=document.getElementById("error-message");e&&(e.textContent=t,e.hidden=!1)}function Te(){const t=document.getElementById("error-message");t&&(t.textContent="",t.hidden=!0)}function Pe(t){const e=Date.parse(t);if(!e)return"";const r=Math.floor((Date.now()-e)/1e3);if(r<60)return"just now";const a=Math.floor(r/60);if(a<60)return`${a}m ago`;const n=Math.floor(a/60);if(n<24)return`${n}h ago`;const o=Math.floor(n/24);if(o<7)return`${o}d ago`;const c=new Date(e);return`${c.getFullYear()}-${Q(c.getMonth()+1)}-${Q(c.getDate())}`}function Q(t){return String(t).padStart(2,"0")}function B(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function D(t){return B(t)}function j(){return new URLSearchParams(window.location.search).has("detached")}async function Me(){try{return(await chrome.storage.local.get(v.popupMode))[v.popupMode]==="detached"?"detached":"inline"}catch{return"inline"}}async function oe(t){try{await chrome.storage.local.set({[v.popupMode]:t})}catch(e){console.error("[manuscript] save popup mode failed",e)}}async function Re(){if(j()){await oe("inline"),window.close();return}await ie()}async function je(){if(j()){const[e]=await chrome.tabs.query({active:!0,windowType:"normal"});return e}const[t]=await chrome.tabs.query({active:!0,currentWindow:!0});return t}async function ie(){const t=chrome.runtime.getURL("src/popup/popup.html");try{await oe("detached");const e=await Ue();if(e!==void 0)try{await chrome.windows.update(e,{focused:!0}),window.close();return}catch{await X(void 0)}const r=await chrome.windows.create({url:t+"?detached=1",type:"popup",width:420,height:680});(r==null?void 0:r.id)!==void 0&&await X(r.id),window.close()}catch(e){console.error("[manuscript] open detached failed",e),k("Failed to open a separate window. Check the console.")}}async function Ue(){try{const e=(await chrome.storage.local.get(v.detachedWindowId))[v.detachedWindowId];return typeof e=="number"?e:void 0}catch{return}}async function X(t){try{t===void 0?await chrome.storage.local.remove(v.detachedWindowId):await chrome.storage.local.set({[v.detachedWindowId]:t})}catch(e){console.error("[manuscript] save detached window id failed",e)}}async function q(t,e){Te();try{const r=await je();if(!(r!=null&&r.id)){k(s("popup.error.no-tab"));return}if(!xe(r.url)){k(s("popup.error.bad-url"));return}if(await te(r.id,t)){ee(e);return}try{await _e(r.id)}catch(a){console.error("[manuscript] inject failed",a),k(s("popup.error.inject"));return}if(await te(r.id,t)){ee(e);return}k(s("popup.error.inject"))}catch(r){console.error("[manuscript] handleStart failed",r),k(s("popup.error.unknown"))}}function ee(t){if(j()){t==null||t();return}window.close()}async function te(t,e){try{return await chrome.tabs.sendMessage(t,{type:"panel.open",scenarioId:e}),!0}catch{return!1}}async function _e(t){var a,n;const r=(n=(a=chrome.runtime.getManifest().content_scripts)==null?void 0:a[0])==null?void 0:n.js;if(!r||r.length===0)throw new Error("no content_scripts.js in manifest");await chrome.scripting.executeScript({target:{tabId:t},files:r})}function xe(t){return t?/^https?:/i.test(t):!1}function se(t){const e=t.cancelLabel??s("common.cancel"),r=t.tone==="danger"?"confirm-delete":"confirm-primary";return new Promise(a=>{var p;const n=document.createElement("div");n.className="confirm-overlay",n.setAttribute("role","dialog"),n.setAttribute("aria-modal","true"),n.innerHTML=`
      <div class="confirm-card">
        <p class="confirm-title">${B(t.message)}</p>
        <div class="confirm-actions">
          <button type="button" class="confirm-btn confirm-cancel" data-confirm="cancel">${B(e)}</button>
          <button type="button" class="confirm-btn ${r}" data-confirm="confirm">${B(t.confirmLabel)}</button>
        </div>
      </div>
    `;const o=d=>{document.removeEventListener("keydown",c,!0),n.remove(),a(d)},c=d=>{d.key==="Escape"&&(d.preventDefault(),o(!1))};n.addEventListener("click",d=>{var L;const f=d.target;if(f===n)return o(!1);const $=(L=f.closest("[data-confirm]"))==null?void 0:L.getAttribute("data-confirm");$==="cancel"?o(!1):$==="confirm"&&o(!0)}),document.addEventListener("keydown",c,!0),document.body.appendChild(n),(p=n.querySelector(".confirm-cancel"))==null||p.focus()})}async function R(){try{const[t,e]=await Promise.all([ve(),$e()]);De(t,e==null?void 0:e.id)}catch(t){console.error("[manuscript] list load failed",t)}}function De(t,e){const r=document.getElementById("scenarios");if(!r)return;if(t.length===0){r.hidden=!0,r.innerHTML="";return}r.hidden=!1;const a=t.map(n=>Fe(n,n.id===e)).join("");r.innerHTML=`
    <div class="list-header">
      <h2 class="list-heading">${B(s("popup.list.heading"))}</h2>
      <span class="list-count">${t.length}</span>
    </div>
    <ul class="list" role="list">${a}</ul>
  `}function Fe(t,e){const r=t.steps.length,a=Pe(t.updatedAt),n=e?`<span> · </span><span class="resume-tag">${B(s("popup.list.resume-tag"))}</span>`:"",o=G({height:14,color:"currentColor"}),c=s("popup.list.steps",{n:r});return`
    <li class="list-item${e?" list-item-recent":""}" role="listitem">
      <button class="list-resume" data-resume="${D(t.id)}" type="button">
        <span class="list-thumb" aria-hidden="true">${o}</span>
        <span class="list-text">
          <span class="list-name">${B(t.name)}</span>
          <span class="list-meta"><span>${B(c)} · ${a}</span>${n}</span>
        </span>
      </button>
      <button
        class="list-delete"
        data-delete="${D(t.id)}"
        data-delete-name="${D(t.name)}"
        type="button"
        aria-label="${D(s("popup.list.delete-aria",{name:t.name}))}"
      >×</button>
    </li>
  `}function He(t){return se({message:s("common.delete-confirm",{name:t}),confirmLabel:s("common.delete"),tone:"danger"})}async function qe(t){const e=t.target;if(!(e instanceof HTMLElement))return;const r=e.closest("[data-delete]");if(r){t.stopPropagation();const n=r.getAttribute("data-delete");if(!n)return;const o=r.getAttribute("data-delete-name")??"",c=o.length>0?o:s("common.untitled");if(!await He(c))return;try{await we(n),await R()}catch(p){console.error("[manuscript] delete failed",p)}return}const a=e.closest("[data-resume]");if(a){const n=a.getAttribute("data-resume");if(!n)return;Y(()=>{q(n,R)})}}async function Ne(t,e,r={}){const a=Se(t);if(r.confirmOverwrite){const n=await Ae(a.id);if(n&&!await r.confirmOverwrite(n.name))return{scenarioId:a.id,status:"cancelled"}}return await Ee(a),e&&await e(),{scenarioId:a.id,status:"saved"}}function Oe(t,e={}){t.addEventListener("click",()=>{Ve(r=>{We(r,e.reloadList)})})}async function We(t,e){try{const{scenarioId:r,status:a}=await Ne(t,e,{confirmOverwrite:n=>se({message:s("popup.import.overwrite-confirm",{name:n.length>0?n:s("common.untitled")}),confirmLabel:s("common.overwrite"),tone:"primary"})});if(a==="cancelled")return;await q(r,e)}catch(r){console.error("[manuscript/popup] import failed",r),k(s("popup.import.failed"))}}function Ve(t){const e=document.createElement("input");e.type="file",e.accept="application/json,.json",e.style.display="none",document.body.appendChild(e),e.addEventListener("change",async()=>{var a;const r=(a=e.files)==null?void 0:a[0];if(e.remove(),!!r)try{const n=await r.text();t(n)}catch(n){console.error("[manuscript/popup] file read failed",n),k(s("popup.import.failed"))}}),e.click()}const O="manuscript.popupTab",Je="local";async function Ge(t,e={}){const r=Array.from(t.querySelectorAll("[data-tab]")),a=new Set(r.map(p=>p.getAttribute("data-tab")).filter(p=>!!p)),n=await Ye(),o=n&&a.has(n)?n:e.defaultTab&&a.has(e.defaultTab)?e.defaultTab:Je;re(t,o);const c=p=>{var $;const f=p.currentTarget.getAttribute("data-tab");f&&f!==Ke(t)&&(re(t,f),ze(f),($=e.onTabChange)==null||$.call(e,f))};for(const p of r)p.addEventListener("click",c);return()=>{for(const p of r)p.removeEventListener("click",c)}}function Ke(t){const e=t.querySelector('[data-tab][aria-pressed="true"]');return(e==null?void 0:e.getAttribute("data-tab"))??null}function re(t,e){const r=t.querySelectorAll("[data-tab]");for(const n of r)n.setAttribute("aria-pressed",n.getAttribute("data-tab")===e?"true":"false");const a=t.querySelectorAll("[data-tab-panel]");for(const n of a)n.hidden=n.getAttribute("data-tab-panel")!==e}async function Ye(){try{const e=(await chrome.storage.local.get(O))[O];return typeof e=="string"?e:null}catch{return null}}async function ze(t){try{await chrome.storage.local.set({[O]:t})}catch{}}const Ze={sources:[],catalogs:{}};async function U(){const e=(await chrome.storage.local.get(v.remoteLibrary))[v.remoteLibrary];if(!e||typeof e!="object")return Qe(Ze);const r=e;return{sources:Array.isArray(r.sources)?r.sources:[],catalogs:r.catalogs&&typeof r.catalogs=="object"?r.catalogs:{}}}async function z(t){await chrome.storage.local.set({[v.remoteLibrary]:t})}function Qe(t){return JSON.parse(JSON.stringify(t))}function ne(t){return`${t.owner}/${t.repo}@${t.branch}:${t.path}`}function Xe(){return`src-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`}async function F(){return(await U()).sources}async function ce(t){const e=await U(),r=ne(t),a=e.sources.find(o=>ne(o)===r);if(a)return a;const n={...t,id:Xe(),label:`${t.owner}/${t.repo}`,addedAt:Date.now()};return e.sources.push(n),await z(e),n}async function le(t){const e=await U();e.sources=e.sources.filter(r=>r.id!==t),delete e.catalogs[t],await z(e)}async function de(t){return(await U()).catalogs[t]??null}async function ue(t,e){const r=await U();r.catalogs[t]=e,await z(r)}function pe(t,e){const r=e.filter(d=>d.type==="dir"||d.type==="file"&&d.name.toLowerCase().endsWith(".json")),a=new Map(t.map(d=>[d.name,d])),n=new Map(r.map(d=>[d.name,d])),o=[],c=[];for(const d of r){const f=a.get(d.name);f&&f.sha===d.sha?c.push(f):o.push(d)}const p=[];for(const d of t)n.has(d.name)||p.push(d);return{toFetch:o,toKeep:c,toRemove:p}}const et=Object.freeze(Object.defineProperty({__proto__:null,addRemoteSource:ce,diffCatalog:pe,getCatalog:de,listRemoteSources:F,removeRemoteSource:le,setCatalog:ue},Symbol.toStringTag,{value:"Module"})),me="main",tt="",T=/^[A-Za-z0-9_.\-]+$/;function rt(t){if(typeof t!="string")return null;const e=t.trim();return e.length===0||/(^|[\\/])\.\.([\\/]|$)/.test(e)||/(^|[\\/])\.([\\/]|$)/.test(e)?null:/^https?:\/\//i.test(e)?nt(e):at(e)}function nt(t){let e;try{e=new URL(t)}catch{return null}if(e.host.toLowerCase()!=="github.com")return null;const r=e.pathname.split("/").filter(d=>d.length>0);if(r.length<2)return null;const a=r[0];let n=r[1];if(n.endsWith(".git")&&(n=n.slice(0,-4)),!T.test(a)||!T.test(n))return null;if(r.length===2||r[2]!=="tree")return r.length>2?null:{owner:a,repo:n,branch:me,path:tt};const o=r[3];if(!o||!T.test(o))return null;const c=r.slice(4),p=fe(c);return p===null?null:{owner:a,repo:n,branch:o,path:p}}function at(t){const e=t.split("/").filter(c=>c.length>0);if(e.length<2)return null;const r=e[0];let a=e[1];if(a.endsWith(".git")&&(a=a.slice(0,-4)),!T.test(r)||!T.test(a))return null;const n=e.slice(2),o=fe(n);return o===null?null:{owner:r,repo:a,branch:me,path:o}}function fe(t){if(t.length===0)return"";for(const e of t)if(e===".."||e==="."||!T.test(e))return null;return t.join("/")}const ot="https://api.github.com";async function he(t){const e=`${ot}/repos/${W(t.owner)}/${W(t.repo)}/contents/${it(t.path)}?ref=${encodeURIComponent(t.branch)}`,r=await fetch(e,{headers:{Accept:"application/vnd.github+json"}});if(!r.ok)throw r.status===404?new Error(`Folder not found (404): ${t.path}`):r.status===403?new Error("GitHub API rate limit reached (403). Try again in an hour or sign in via a future private-repo path."):new Error(`GitHub API error: ${r.status} ${r.statusText}`);const a=await r.json();if(!Array.isArray(a))throw new Error("Expected a folder listing — the path points to a file or unknown shape.");return a.map(st)}async function ge(t){const e=await fetch(t);if(!e.ok)throw new Error(`Raw fetch failed: ${e.status} ${e.statusText}`);const r=await e.text();try{return JSON.parse(r)}catch(a){throw new Error(`Invalid JSON at ${t}: ${a.message}`)}}function W(t){return encodeURIComponent(t)}function it(t){return t.split("/").filter(e=>e.length>0).map(W).join("/")}function st(t){const e=t;return{name:typeof e.name=="string"?e.name:"",path:typeof e.path=="string"?e.path:"",sha:typeof e.sha=="string"?e.sha:"",type:typeof e.type=="string"?e.type:"file",downloadUrl:typeof e.download_url=="string"?e.download_url:null}}const ct=8;async function lt(t,e={}){const r=await he(t),{getCatalog:a}=await Le(async()=>{const{getCatalog:g}=await Promise.resolve().then(()=>et);return{getCatalog:g}},void 0),n=await a(t.id),o=(n==null?void 0:n.items)??[],c=pe(o,r),p=e.fetchRaw??ge,d=Math.max(1,e.concurrency??ct);let f=0;const $=c.toFetch.length,L=new Array(c.toFetch.length);let I=0;async function N(){var g;for(;;){const C=I++;if(C>=c.toFetch.length)return;const i=c.toFetch[C];L[C]=await dt(i,p),f+=1,(g=e.onProgress)==null||g.call(e,f,$)}}await Promise.all(Array.from({length:Math.min(d,$)},()=>N()));const P=new Map;for(const g of c.toKeep)P.set(g.name,g);for(const g of L)g&&P.set(g.name,g);const _={items:r.filter(g=>g.type==="dir"||g.type==="file"&&g.name.toLowerCase().endsWith(".json")).map(g=>P.get(g.name)).filter(g=>!!g),lastRefreshed:Date.now()};return await ue(t.id,_),_}async function dt(t,e){if(t.type==="dir")return{name:t.name,type:"dir",sha:t.sha,downloadUrl:""};const r={name:t.name,type:"file",sha:t.sha,downloadUrl:t.downloadUrl??""};if(!t.downloadUrl)return{...r,error:"No download URL on folder listing"};let a;try{a=await e(t.downloadUrl)}catch(n){return{...r,error:`Fetch failed: ${n.message}`}}try{const n=K(a,{strict:!0});return{...r,scenarioName:n.name,scenarioId:n.id,stepCount:n.steps.length,scenarioJson:n}}catch(n){return{...r,error:`Invalid scenario: ${n.message}`}}}async function ut(t,e,r={}){if(e.error)throw new Error(`Cannot play item with error: ${e.error}`);if(!e.scenarioJson)throw new Error("Cached item has no scenarioJson; refresh the catalog first.");const a=K(e.scenarioJson,{strict:!0}),n=`eph-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,o={...a,id:n};return await ke(o,{kind:"github",repo:`${t.owner}/${t.repo}`,path:t.path?`${t.path}/${e.name}`:e.name,sha:e.sha}),await(r.handleStart??q)(o.id),o.id}function pt(t,e){if(e.sources.length===0){t.innerHTML=mt(e);return}t.innerHTML=ft(e)}function mt(t){return t.adding?`
      <div class="remote-empty" data-region="remote-empty">
        ${ye(t)}
      </div>
    `:`
    <div class="remote-empty" data-region="remote-empty">
      <div class="remote-empty-icon" aria-hidden="true">${H(32)}</div>
      <p class="remote-empty-copy">${u(s("popup.remote.empty.copy")||"Connect a public GitHub repo to load shared manuscripts.")}</p>
      <button
        type="button"
        class="remote-add-cta"
        data-action="remote-add-open"
      >
        <span class="remote-add-cta-icon" aria-hidden="true">${H(14)}</span>
        <span>${u(s("popup.remote.add-cta")||"+ Add a GitHub source")}</span>
      </button>
    </div>
  `}function ft(t){return`
    <div class="remote-header" data-region="remote-header">
      <div class="remote-header-actions">
        <button
          type="button"
          class="remote-icon-btn remote-icon-btn-add"
          data-action="remote-add-open"
          title="${u(s("popup.remote.add-cta-aria")||"Add source")}"
          aria-label="${u(s("popup.remote.add-cta-aria")||"Add source")}"
        ><span class="remote-icon-btn-plus" aria-hidden="true">+</span>${H(12)}</button>
        <button
          type="button"
          class="remote-icon-btn"
          data-action="remote-refresh-all"
          title="${u(s("popup.remote.refresh-all-aria")||"Refresh all")}"
          aria-label="${u(s("popup.remote.refresh-all-aria")||"Refresh all")}"
        >↻</button>
      </div>
    </div>
    ${t.adding?ye(t):""}
    <div class="remote-source-list" data-region="remote-source-list">
      ${t.sources.map(e=>ht(e,t)).join("")}
    </div>
  `}function ye(t){return`
    <form class="remote-add-form" data-region="remote-add-form">
      <input
        type="text"
        class="remote-add-input"
        data-region="remote-add-input"
        placeholder="${u(s("popup.remote.add-placeholder")||"github.com/owner/repo or owner/repo/path")}"
        autocomplete="off"
        spellcheck="false"
      />
      <div class="remote-add-actions">
        <button
          type="submit"
          class="remote-add-submit"
          data-action="remote-add-submit"
        >${u(s("popup.remote.add-submit")||"Add")}</button>
        <button
          type="button"
          class="remote-add-cancel"
          data-action="remote-add-cancel"
        >${u(s("common.cancel")||"Cancel")}</button>
      </div>
      ${t.addError?`<p class="remote-add-error" data-region="remote-add-error">${u(t.addError)}</p>`:""}
    </form>
  `}function ht(t,e){var d;const r=e.subPathBySourceId[t.id]??"",a=r.length>0,n=a?e.subViewBySourceId[t.id]??[]:((d=e.catalogs[t.id])==null?void 0:d.items)??null,o=e.loadingBySourceId[t.id],c=e.collapsedBySourceId[t.id]===!0,p=c?s("popup.remote.expand-aria")||"Expand source":s("popup.remote.collapse-aria")||"Collapse source";return`
    <section
      class="remote-source-card${c?" is-collapsed":""}"
      data-region="remote-source-card"
      data-source-id="${u(t.id)}"
    >
      <header class="remote-source-header">
        <div class="remote-source-label">
          <span class="remote-source-icon remote-source-icon-github" aria-hidden="true">${H(14)}</span>
          <span class="remote-source-title">${u(t.label)}</span>
          ${t.path?`<span class="remote-source-path">· ${u(t.path)}</span>`:""}
        </div>
        <div class="remote-source-actions">
          <button
            type="button"
            class="remote-source-toggle"
            data-action="remote-source-toggle"
            data-source-id="${u(t.id)}"
            aria-pressed="${c?"true":"false"}"
            aria-label="${u(p)}"
            title="${u(p)}"
          >${c?vt():wt()}</button>
          <button
            type="button"
            class="remote-source-remove"
            data-action="remote-source-remove"
            data-source-id="${u(t.id)}"
            title="${u(s("popup.remote.remove-aria")||"Remove source")}"
            aria-label="${u(s("popup.remote.remove-aria")||"Remove source")}"
          >×</button>
        </div>
      </header>
      ${c?"":`
            ${a?gt(t,r):""}
            <div class="remote-source-body" data-region="remote-source-body">
              ${o?`<div class="remote-progress" data-region="remote-progress">${u(s("popup.remote.progress")||"Loading")} ${o.done} / ${o.total}</div>`:""}
              ${bt(t,n,a)}
            </div>
          `}
    </section>
  `}function gt(t,e){const r=e.split("/").filter(n=>n.length>0);if(r.length===0)return"";const a=r.map((n,o)=>{const c=o===r.length-1;return`${o===0?"":'<span class="remote-breadcrumb-sep" aria-hidden="true">/</span>'}<span class="remote-breadcrumb-seg${c?" is-current":""}">${u(n)}</span>`}).join("");return`
    <nav class="remote-breadcrumb" data-region="remote-breadcrumb">
      <button
        type="button"
        class="remote-breadcrumb-button"
        data-action="remote-folder-up"
        data-source-id="${u(t.id)}"
        aria-label="${u(s("popup.remote.back-aria")||"Back")}"
        title="${u(s("popup.remote.back-aria")||"Back")}"
      >
        <span class="remote-breadcrumb-chevron" aria-hidden="true">${yt()}</span>
        <span class="remote-breadcrumb-folder" aria-hidden="true">📁</span>
        <span class="remote-breadcrumb-name">${a}</span>
      </button>
    </nav>
  `}function yt(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 2 L3 5 L6 8"/></svg>'}function bt(t,e,r){if(e===null)return`<p class="remote-source-empty">${u(s("popup.remote.source-never-refreshed")||"Click ↻ refresh to load this source.")}</p>`;if(e.length===0)return`<p class="remote-source-empty">${u(r?s("popup.remote.folder-empty")||"This folder is empty.":s("popup.remote.source-empty")||"No manuscripts in this folder yet.")}</p>`;const a=e.filter(o=>o.type==="dir"),n=e.filter(o=>o.type!=="dir");return`
    <ul class="remote-catalog">
      ${a.map(o=>ae(t,o)).join("")}
      ${n.map(o=>ae(t,o)).join("")}
    </ul>
  `}function ae(t,e){if(e.type==="dir")return`
      <li class="remote-catalog-item" data-region="remote-catalog-item">
        <button
          type="button"
          class="remote-catalog-row"
          data-action="remote-folder-into"
          data-source-id="${u(t.id)}"
          data-folder-name="${u(e.name)}"
          aria-label="${u(e.name)}"
        >
          <span class="remote-play-icon remote-folder-icon" aria-hidden="true">📁</span>
          <span class="remote-catalog-name">${u(e.name)}</span>
        </button>
      </li>
    `;const r=!!e.error,a=e.scenarioName||e.name,n=typeof e.stepCount=="number"?`<span class="remote-catalog-steps">${e.stepCount} ${u(s("popup.remote.steps-suffix")||"steps")}</span>`:"",o=r?` title="${u(e.error)}"`:"";return`
    <li class="remote-catalog-item" data-region="remote-catalog-item">
      <button
        type="button"
        class="remote-catalog-row"
        data-action="remote-play"
        data-source-id="${u(t.id)}"
        data-item-name="${u(e.name)}"
        ${r?"disabled":""}
        aria-label="${u(a)}"${o}
      >
        <span class="remote-play-icon" aria-hidden="true">${G({height:16})}</span>
        <span class="remote-catalog-name">${u(a)}</span>
        ${n}
        ${r?'<span class="remote-catalog-warn" aria-hidden="true">⚠</span>':""}
      </button>
    </li>
  `}function H(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>`}function wt(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4 L5 7 L8 4"/></svg>'}function vt(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 2 L7 5 L4 8"/></svg>'}function u(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function $t(t){const e={sources:[],catalogs:{},loadingBySourceId:{},subPathBySourceId:{},subViewBySourceId:{},collapsedBySourceId:{},adding:!1,addError:null};async function r(){e.sources=await F();for(const i of e.sources){const l=await de(i.id);l&&(e.catalogs[i.id]=l)}try{const l=(await chrome.storage.local.get(v.remoteCollapsed))[v.remoteCollapsed];if(l&&typeof l=="object")for(const[m,h]of Object.entries(l))h===!0&&(e.collapsedBySourceId[m]=!0)}catch{}}async function a(){try{await chrome.storage.local.set({[v.remoteCollapsed]:e.collapsedBySourceId})}catch{}}async function n(i){e.collapsedBySourceId[i]?delete e.collapsedBySourceId[i]:e.collapsedBySourceId[i]=!0,o(),await a()}function o(){pt(t,e)}async function c(i){e.loadingBySourceId[i.id]={done:0,total:0},o();try{const l=await lt(i,{onProgress:(m,h)=>{e.loadingBySourceId[i.id]={done:m,total:h},o()}});e.catalogs[i.id]=l}catch(l){console.error("[manuscript/remote] refresh failed",l)}finally{delete e.loadingBySourceId[i.id],o()}}async function p(){await Promise.all(e.sources.map(i=>c(i)))}function d(){e.adding=!0,e.addError=null,o(),queueMicrotask(()=>{var i;(i=t.querySelector('[data-region="remote-add-input"]'))==null||i.focus()})}function f(){e.adding=!1,e.addError=null,o()}async function $(i){const l=rt(i);if(!l){e.addError="Invalid URL. Expected github.com/owner/repo or owner/repo.",o();return}await new Promise(h=>{Y(()=>h())});const m=await ce(l);e.sources=await F(),e.adding=!1,e.addError=null,o(),await c(m)}async function L(i){await le(i),delete e.catalogs[i],delete e.loadingBySourceId[i],delete e.subPathBySourceId[i],delete e.subViewBySourceId[i],delete e.collapsedBySourceId[i],e.sources=await F(),o(),a()}async function I(i,l){const m=e.sources.find(y=>y.id===i);if(!m)return;const h=m.path?`${m.path}/${l}`:l;e.loadingBySourceId[i]={done:0,total:0},o();try{const A=(await he({...m,path:h})).filter(b=>b.type==="dir"||b.type==="file"&&b.name.toLowerCase().endsWith(".json")),S=[],w=A.length;e.loadingBySourceId[i]={done:0,total:w},o();let E=0;for(const b of A){if(b.type==="dir")S.push({name:b.name,type:"dir",sha:b.sha,downloadUrl:""});else try{const x=b.downloadUrl?await ge(b.downloadUrl):null,M=x?K(x,{strict:!0}):null;S.push({name:b.name,type:"file",sha:b.sha,downloadUrl:b.downloadUrl??"",...M?{scenarioName:M.name,scenarioId:M.id,stepCount:M.steps.length,scenarioJson:M}:{error:"No download URL or unparseable JSON"}})}catch(x){S.push({name:b.name,type:"file",sha:b.sha,downloadUrl:b.downloadUrl??"",error:`Invalid scenario: ${x.message}`})}E+=1,e.loadingBySourceId[i]={done:E,total:w},o()}e.subViewBySourceId[i]=S}catch(y){console.error("[manuscript/remote] sub-folder fetch failed",y),e.subViewBySourceId[i]=[]}finally{delete e.loadingBySourceId[i],o()}}async function N(i,l){const m=e.subPathBySourceId[i]??"",h=m?`${m}/${l}`:l;e.subPathBySourceId[i]=h,e.subViewBySourceId[i]=[],o();const y=await P(i,h);if(y){e.subViewBySourceId[i]=y,o();return}await I(i,h)}async function P(i,l){var m;try{const y=(await chrome.storage.local.get("manuscript.remoteSubStubs"))["manuscript.remoteSubStubs"],A=(m=y==null?void 0:y[i])==null?void 0:m[l];return Array.isArray(A)?A:null}catch{return null}}async function Z(i){const l=e.subPathBySourceId[i]??"";if(!l)return;const m=l.split("/").filter(y=>y.length>0);m.pop();const h=m.join("/");if(h.length===0){delete e.subPathBySourceId[i],delete e.subViewBySourceId[i],o();return}e.subPathBySourceId[i]=h,e.subViewBySourceId[i]=[],o(),await I(i,h)}async function _(i,l){var E;const m=e.sources.find(b=>b.id===i);if(!m)return;const A=((e.subPathBySourceId[i]??"").length>0?e.subViewBySourceId[i]??[]:((E=e.catalogs[i])==null?void 0:E.items)??[]).find(b=>b.name===l);if(!A)return;const S=e.subPathBySourceId[i]??"",w=S?m.path?`${m.path}/${S}`:S:m.path;try{await ut({...m,path:w},A)}catch(b){console.error("[manuscript/remote] play failed",b)}}const g=i=>{const l=i.target;if(!l)return;if(l.closest('[data-action="remote-add-open"]')){d();return}if(l.closest('[data-action="remote-add-cancel"]')){i.preventDefault(),f();return}if(l.closest('[data-action="remote-refresh-all"]')){p();return}const m=l.closest('[data-action="remote-source-toggle"]');if(m){const w=m.getAttribute("data-source-id");w&&n(w);return}const h=l.closest('[data-action="remote-source-remove"]');if(h){const w=h.getAttribute("data-source-id");w&&L(w);return}const y=l.closest('[data-action="remote-folder-into"]');if(y){const w=y.getAttribute("data-source-id"),E=y.getAttribute("data-folder-name");w&&E&&N(w,E);return}const A=l.closest('[data-action="remote-folder-up"]');if(A){const w=A.getAttribute("data-source-id");w&&Z(w);return}const S=l.closest('[data-action="remote-play"]');if(S){const w=S.getAttribute("data-source-id"),E=S.getAttribute("data-item-name");w&&E&&_(w,E);return}},C=i=>{var y;const l=i.target;if(!l||!((y=l.matches)!=null&&y.call(l,'[data-region="remote-add-form"]')))return;i.preventDefault();const m=t.querySelector('[data-region="remote-add-input"]'),h=(m==null?void 0:m.value.trim())??"";if(h.length===0){e.addError="Enter a GitHub URL or owner/repo",o();return}$(h)};return t.addEventListener("click",g),t.addEventListener("submit",C),await r(),o(),p(),{refresh:p,destroy(){t.removeEventListener("click",g),t.removeEventListener("submit",C)}}}const V="studio",St="studio-dark";function be(t){return t.endsWith("-dark")}async function At(){try{const e=(await chrome.storage.local.get(v.palette))[v.palette];if(typeof e=="string")return e}catch{}return V}function J(t){document.body.setAttribute("data-palette",t);const e=document.getElementById("palette-toggle");e==null||e.setAttribute("aria-pressed",be(t)?"true":"false")}async function Et(){const t=document.body.getAttribute("data-palette")??V,e=be(t)?V:St;J(e);try{await chrome.storage.local.set({[v.palette]:e})}catch{}}document.addEventListener("DOMContentLoaded",()=>{Lt()});async function Lt(){if(kt(),!j()&&await Me()==="detached"){await ie();return}const t=document.getElementById("start-cta"),e=document.getElementById("help-link"),r=document.getElementById("scenarios"),a=document.getElementById("detach-btn"),n=document.getElementById("palette-toggle"),o=document.getElementById("import-link");J(await At()),chrome.storage.onChanged.addListener((f,$)=>{var I;if($!=="local")return;const L=(I=f[v.palette])==null?void 0:I.newValue;typeof L=="string"&&J(L)}),n==null||n.addEventListener("click",()=>{Et()});const c=document.querySelector('[data-region="brand-logo"]');c&&(c.innerHTML=G({height:20})),j()&&a&&(a.textContent=s("popup.detach.detached"),a.setAttribute("title",s("popup.detach.inline-title")),a.setAttribute("aria-label",s("popup.detach.inline-title"))),t==null||t.addEventListener("click",()=>{Y(()=>{q(void 0,R)})}),o instanceof HTMLButtonElement&&Oe(o,{reloadList:R}),e==null||e.addEventListener("click",f=>{f.preventDefault(),chrome.tabs.create({url:"https://zendy00.github.io/manuscript-pages/"})}),r==null||r.addEventListener("click",f=>{qe(f)}),a==null||a.addEventListener("click",()=>{Re()});const p=document.querySelector(".empty-state");p&&await Ge(p);const d=document.querySelector('[data-tab-panel="remote"]');d&&(d.innerHTML="",$t(d)),R()}function kt(){for(const t of document.querySelectorAll("[data-i18n]")){const e=t.getAttribute("data-i18n");e&&(t.textContent=s(e))}for(const t of document.querySelectorAll("[data-i18n-aria]")){const e=t.getAttribute("data-i18n-aria");e&&t.setAttribute("aria-label",s(e))}for(const t of document.querySelectorAll("[data-i18n-title]")){const e=t.getAttribute("data-i18n-title");e&&t.setAttribute("title",s(e))}}
