const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-CIOFAL-T.js","assets/chunk-C8iY6jtx.js","assets/chunk-b9UwEhlW.js","assets/chunk-ClheHCf9.js","assets/chunk-BqUP5xk2.js"])))=>i.map(i=>d[i]);
import{S as z,O as j,E as Xa,P as Ac}from"./chunk-C8iY6jtx.js";import{s as Va,a as io,g as Mc,b as $c,S as Lc,c as Ya,_ as Tc,d as so,e as Ka,f as Ic,h as Cc,i as Dc,j as Pc,m as Za,k as Rc,l as _o,n as Bo}from"./chunk-b9UwEhlW.js";import{t as v}from"./chunk-ClheHCf9.js";import{a as Oc,w as Nc,l as Hc,b as Fc,g as Qa,i as qc,c as zc,d as Ja,p as _c,e as ti,s as Bc,f as Uc}from"./chunk-BqUP5xk2.js";const _r="manuscript:mode-changed";let vn="idle";function st(){return vn}function P(t){if(t===vn)return;const e=vn;vn=t,document.dispatchEvent(new CustomEvent(_r,{detail:{prev:e,next:t}}))}function $t(t){const e=n=>t(n.detail);return document.addEventListener(_r,e),()=>document.removeEventListener(_r,e)}function ei(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),a=n*(1-e),i=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,d=0;switch(r){case 0:c=n,l=s,d=a;break;case 1:c=i,l=n,d=a;break;case 2:c=a,l=n,d=s;break;case 3:c=a,l=i,d=n;break;case 4:c=s,l=a,d=n;break;case 5:c=n,l=a,d=i;break}return[Math.round(c*255),Math.round(l*255),Math.round(d*255)]}function ni(t,e,n){const r=t/255,o=e/255,a=n/255,i=Math.max(r,o,a),s=Math.min(r,o,a),c=i-s;let l=0;return c!==0&&(i===r?l=(o-a)/c%6:i===o?l=(a-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:i===0?0:c/i,v:i}}function ri(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function oi(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(a=>a+a).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(a=>!Number.isFinite(a))?{h:0,s:1,v:1}:ni(n,r,o)}function Er(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function Uo(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function jc(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const Wc=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── PALETTE E — STUDIO-DARK ─────
   Cool slate dark, mirrors PALETTE D STUDIO. See docs/design/dark-mode-design.md §4.1.
   Chroma ≤ 0.09 doctrine maintained (focus only allowed slight excess at 0.13). */
[data-palette="studio-dark"] {
  --c-bg:        oklch(0.16  0.012 245);
  --c-surface:   oklch(0.22  0.014 245);
  --c-surface-2: oklch(0.19  0.012 245);
  --c-text:      oklch(0.97  0.003 245);
  --c-text-mute: oklch(0.78  0.006 245);
  --c-text-soft: oklch(0.62  0.008 245);
  --c-border:    oklch(0.32  0.012 245);
  --c-border-strong: oklch(0.42 0.014 245);
  --c-primary:   oklch(0.70  0.09  245);
  --c-primary-h: oklch(0.78  0.09  245);
  --c-primary-fg: oklch(0.14  0.020 245);
  --c-tint:      oklch(0.32  0.045 245);
  --c-focus:     oklch(0.74  0.13  245);
}

/* ───── PALETTE F — INK-DARK ─────
   Warm-on-cool dark, mirrors PALETTE A INK. docs/design/dark-mode-design.md §4.2.
   Absorbs \`08.DARK-MODE-TOKENS.md\` §1 (spotlight-editor) and §2 (launcher pill) tones. */
[data-palette="ink-dark"] {
  --c-bg:        oklch(0.14  0.015 250);
  --c-surface:   oklch(0.20  0.018 250);
  --c-surface-2: oklch(0.17  0.016 250);
  --c-text:      oklch(0.98  0.003  80);
  --c-text-mute: oklch(0.76  0.006  80);
  --c-text-soft: oklch(0.60  0.008  80);
  --c-border:    oklch(0.30  0.014 250);
  --c-border-strong: oklch(0.40 0.016 250);
  --c-primary:   oklch(0.66  0.06  250);
  --c-primary-h: oklch(0.74  0.07  250);
  --c-primary-fg: oklch(0.14  0.018 250);
  --c-tint:      oklch(0.30  0.05  250);
  --c-focus:     oklch(0.70  0.10  250);
}

/* ───── Dark-palette shared overrides ─────
   Shadows: alpha ~4× because black-on-black shadow is weak; pair with
   surface-lightness steps (--c-bg < --c-surface-2 < --c-surface) for elevation.
   Functional accents: lightness ↑ for contrast on dark surface (L≈0.22). */
[data-palette$="-dark"] {
  --shadow-sm:   0 1px 2px  rgb(0 0 0 / 0.40);
  --shadow-md:   0 2px 6px  rgb(0 0 0 / 0.45), 0 1px 2px rgb(0 0 0 / 0.35);
  --shadow-lg:   0 12px 28px rgb(0 0 0 / 0.55), 0 4px 8px rgb(0 0 0 / 0.40);
  --shadow-card: 0 1px 2px  rgb(0 0 0 / 0.35),
                 0 4px 10px rgb(0 0 0 / 0.40),
                 0 12px 24px rgb(0 0 0 / 0.50);

  --c-success: oklch(0.66 0.10 150);
  --c-warning: oklch(0.78 0.11  75);
  --c-error:   oklch(0.66 0.15  27);
  --c-info:    oklch(0.66 0.09 245);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function Rt(){return Wc.replace(/:root\s*\{/g,":host {").replace(/\[data-palette([^\]]*)\]\s*\{/g,":host([data-palette$1]) {")}const ai="studio",Gc=["studio","ink","graphite","sepia","studio-dark","ink-dark"];function ii(t){return typeof t=="string"&&Gc.includes(t)}function co(t){return t.endsWith("-dark")}let be=null;const Br=new Set;let jo=!1;async function Xc(){if(be)return be;try{const e=(await chrome.storage.local.get(z.palette))[z.palette];if(ii(e))return be=e,e}catch{}return ai}function lo(){return be??ai}async function Vc(t){be=t,si(t);try{await chrome.storage.local.set({[z.palette]:t})}catch{}}async function Yc(){const t=lo(),e=co(t)?"studio":"studio-dark";return await Vc(e),e}function Kc(t){Br.add(new WeakRef(t)),t.setAttribute("data-palette",lo()),Xc().then(e=>{t.isConnected&&t.setAttribute("data-palette",e)}),Zc()}function Zc(){if(!jo){jo=!0;try{chrome.storage.onChanged.addListener((t,e)=>{var r;if(e!=="local")return;const n=(r=t[z.palette])==null?void 0:r.newValue;ii(n)&&(be=n,si(n))})}catch{}}}function si(t){for(const e of[...Br]){const n=e.deref();n&&n.isConnected?(n.setAttribute("data-palette",t),Qc(n,t)):Br.delete(e)}}function Qc(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="palette-toggle"]');n&&n.setAttribute("aria-pressed",co(e)?"true":"false")}const Jc=140,tl=140;function el(){return`
    ${Rt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${Jc}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${tl}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function nl(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function rl(){return[el(),nl()].join(`
`)}const Ur="manuscript:scenario-changed",ol=500,al=5e3,g={scenario:null,currentStepIndex:0,saveTimer:null,ephemeral:!1,ephemeralSource:null};function il(){return g.ephemeral}function sl(){return g.ephemeralSource}function ci(t){g.ephemeral=!0,g.ephemeralSource=t}function Jn(){g.ephemeral=!1,g.ephemeralSource=null}function L(){return g.scenario}function H(){return g.currentStepIndex}function ut(){return g.scenario?g.scenario.steps[g.currentStepIndex]??null:null}function De(t){return document.addEventListener(Ur,t),()=>document.removeEventListener(Ur,t)}function C(){document.dispatchEvent(new CustomEvent(Ur)),cl()}function G(){g.scenario&&(g.scenario.updatedAt=new Date().toISOString())}function ie(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function uo(){return{id:ie("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:al,waitForNavigation:!1}}function cl(){if(!g.scenario)return;if(g.ephemeral){Va(g.scenario,g.ephemeralSource).catch(e=>{console.error("[manuscript] ephemeral save failed",e)});return}g.saveTimer!==null&&window.clearTimeout(g.saveTimer);const t=g.scenario;g.saveTimer=window.setTimeout(()=>{g.saveTimer=null,io(t).catch(e=>{console.error("[manuscript] save failed",e)})},ol)}function tr(){if(g.ephemeral){g.scenario&&Va(g.scenario,g.ephemeralSource).catch(t=>{console.error("[manuscript] ephemeral flush save failed",t)});return}g.saveTimer!==null&&(window.clearTimeout(g.saveTimer),g.saveTimer=null,g.scenario&&io(g.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const ll=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],dl=8,ul=5;function pl(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const i=jr(e.getAttribute("content"));i&&t.add(i)}const n=getComputedStyle(document.documentElement);for(const i of ll){const s=jr(n.getPropertyValue(i));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:i,prop:s}of r)Wo(t,i,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let i=0;i<o.length&&i<ul;i++)Wo(t,o[i]??null,"background-color");const a=Array.from(t).filter(fl).slice(0,dl);return{text:a,background:a}}function Wo(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=jr(r);o&&t.add(o)}function jr(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],a=e[3];return`#${r}${r}${o}${o}${a}${a}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=Ar(n[1]),a=Ar(n[2]),i=Ar(n[3]);return`#${Mr(o)}${Mr(a)}${Mr(i)}`}return null}function Ar(t){return Math.max(0,Math.min(255,Number(t)|0))}function Mr(t){return t.toString(16).padStart(2,"0")}function fl(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const a=Math.max(n,r,o),i=Math.min(n,r,o);return!(a-i<12)}const hl="'Asta Sans', sans-serif",ml=6,gl=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function bl(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const a=o.trim();if(!a)continue;const i=li(a);if(!i)continue;const s=i.toLowerCase();if(!gl.has(s)&&!e.has(s)&&(e.add(s),n.push(xl(a)),n.length>=ml))break}return n}function vl(t){const e=yl(t)??t;return e.length>14?`${e.slice(0,13)}…`:e}function yl(t){return li(t)}function li(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function xl(t){return/asta\s*sans/i.test(t)?t:`${t}, ${hl}`}function Go(){tr();const t=wl(),e=kl();g.scenario={schemaVersion:Lc,id:ie("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[uo()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},g.currentStepIndex=0,C()}function wl(){try{const t=pl();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function kl(){try{return bl()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function Xo(t){tr();const e=await Mc();if(e&&e.scenario.id===t)return g.scenario=e.scenario,g.currentStepIndex=0,ci(e.source??{kind:"bridge",origin:""}),C(),!0;const n=await $c(t);return n?(g.scenario=n,g.currentStepIndex=0,Jn(),C(),!0):!1}function Sl(t,e){tr(),g.scenario=t,g.currentStepIndex=0,e.source?ci(e.source):Jn(),C()}async function El(){if(!g.ephemeral||!g.scenario)return null;const t=new Date().toISOString(),e={...g.scenario,id:ie("scn"),createdAt:t,updatedAt:t};return await io(e),await Ya(),Jn(),g.scenario=e,C(),e.id}function Al(t){if(!g.scenario)return;const e=t.trim();!e||e===g.scenario.name||(g.scenario.name=e,g.scenario.updatedAt=new Date().toISOString(),C())}function Ml(t){g.scenario&&!!g.scenario.strictUrlMatch!==t&&(g.scenario.strictUrlMatch=t,g.scenario.updatedAt=new Date().toISOString(),C())}function di(){const t=g.ephemeral;tr(),g.scenario=null,g.currentStepIndex=0,Jn(),t&&Ya(),C()}function Vo(t={}){if(!g.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>g.scenario.steps.length?g.scenario.steps.length:t.insertIndex;return g.scenario.steps.splice(e,0,uo()),G(),g.currentStepIndex=e,C(),g.currentStepIndex}function Pt(t,e){if(!g.scenario)return;const n=g.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(G(),C())}function $l(t){const e=ut();!e||!g.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,G(),C())}function Ll(t){g.scenario&&(t<0||t>=g.scenario.steps.length||(g.scenario.steps.splice(t,1),g.scenario.steps.length===0?(g.scenario.steps.push(uo()),g.currentStepIndex=0):g.currentStepIndex>=g.scenario.steps.length?g.currentStepIndex=g.scenario.steps.length-1:t<g.currentStepIndex&&(g.currentStepIndex-=1),G(),C()))}function ib(t){const e=ut();if(!e||!g.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,G(),C()}function Lt(t){g.scenario&&(t<0||t>=g.scenario.steps.length||t!==g.currentStepIndex&&(g.currentStepIndex=t,C()))}function Tl(t,e){if(!g.scenario||t===e||t<0||t>=g.scenario.steps.length||e<0||e>=g.scenario.steps.length)return;const[n]=g.scenario.steps.splice(t,1);n&&(g.scenario.steps.splice(e,0,n),g.currentStepIndex===t?g.currentStepIndex=e:t<g.currentStepIndex&&e>=g.currentStepIndex?g.currentStepIndex-=1:t>g.currentStepIndex&&e<=g.currentStepIndex&&(g.currentStepIndex+=1),G(),C())}function Il(t){const e=ut();!e||!g.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),G(),C())}function er(t){const e=ut();!e||!g.scenario||(e.annotations.push(t),G(),C())}function po(t){const e=ut();!e||!g.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),G(),C())}function O(t,e){const n=ut();!n||!g.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),G(),C())}function ui(){var t;return((t=ut())==null?void 0:t.annotations)??[]}function R(t){return ui().find(e=>e.id===t)}const q=100,En=2e3,Cl=100;function fo(t,e){const n=t+1;if(e===null)return Array(n).fill(En);const r=Math.max(n*q,e),o=Math.floor(r/n),a=Array(n).fill(o);return a[n-1]=r-o*(n-1),a}function Dl(t,e,n,r){const o=[...t],a=Math.max(q,Math.round(n));if(r===null)return o[e]=a,o;const i=t.length-1;if(i===0)return o[e]=Math.max(q,r),o;const s=i*q,c=Math.max(q,r-s),l=Math.min(a,c);o[e]=l;const d=r-l,p=t.reduce((h,b,y)=>y===e?h:h+b,0);let u=-1;for(let h=o.length-1;h>=0;h--)if(h!==e){u=h;break}let f=d;for(let h=0;h<o.length;h++)if(h!==e)if(h===u)o[h]=Math.max(q,f);else{const b=p===0?Math.floor(d/i):Math.round((t[h]??0)*d/p),y=Math.max(q,b);o[h]=y,f-=y}return o}function Pl(t,e){const n=t.length;if(n===0)return[];const r=n*q;if(e<=r){const c=Array(n).fill(q);return c[n-1]=Math.max(q,e-q*(n-1)),c}const o=t.reduce((c,l)=>c+l,0);if(o===0)return fo(n-1,e);const a=e/o,i=t.map(c=>Math.round(c*a));for(let c=0;c<5;c++){let l=0;for(let p=0;p<i.length;p++){const u=i[p]??0;u<q&&(l+=q-u,i[p]=q)}if(l===0)break;const d=i.reduce((p,u)=>p+(u>q?u-q:0),0);if(d<=0)break;for(let p=0;p<i.length;p++){const u=i[p]??0;if(u>q){const f=Math.ceil((u-q)*l/d);i[p]=Math.max(q,u-f)}}}const s=i.slice(0,-1).reduce((c,l)=>c+l,0);return i[n-1]=Math.max(q,e-s),i}function Rl(t,e,n,r,o,a=Cl){const i=t.indexOf(n);if(i<0)return{dwells:[...e]};const s=new Set(r);let c=i,l=i;if(s.has(n)){for(;c>0;){const b=t[c-1];if(!b||!s.has(b))break;c--}for(;l<t.length-1;){const b=t[l+1];if(!b||!s.has(b))break;l++}}const d=c,p=l+1,u=[...e],f=u[d]??0,h=u[p]??0;if(o===-1){if(f-a<q)return{dwells:u};u[d]=f-a,u[p]=h+a}else{if(h-a<q)return{dwells:u};u[d]=f+a,u[p]=h-a}return{dwells:u}}function Ol(t,e,n,r){const o=new Set(n),a=e[0]??En,i=t.map((u,f)=>({sub:u,dwell:e[f+1]??En})),s=i.filter(u=>o.has(u.sub));if(s.length===0)return{subs:[...t],dwells:[...e]};const c=i.filter(u=>!o.has(u.sub)),l=Math.max(0,Math.min(t.length,r));let d=0;for(let u=0;u<l;u++){const f=t[u];f!==void 0&&!o.has(f)&&d++}const p=[...c.slice(0,d),...s,...c.slice(d)];return{subs:p.map(u=>u.sub),dwells:[a,...p.map(u=>u.dwell)]}}function Nl(t){const e=ut();if(!e||!g.scenario)return null;const n={id:ie("sub"),selectors:t.selectors,thumbnailDataUrl:t.thumbnailDataUrl,pickedAtUrl:t.pickedAtUrl},r=e.subElements??[];e.subElements=[...r,n];const o=e.subElements.length;return e.autoAdvanceMs===null&&(e.autoAdvanceMs=(o+1)*En),e.subDwellsMs=fo(o,e.autoAdvanceMs),G(),C(),n}function Hl(t,e){var a;if(!g.scenario)return;const n=g.scenario.steps.find(i=>i.id===t);if(!n||!((a=n.subElements)!=null&&a.length))return;const r=new Set(e),o=n.subElements.filter(i=>!r.has(i.id));o.length!==n.subElements.length&&(o.length===0?(delete n.subElements,delete n.subDwellsMs):(n.subElements=o,n.subDwellsMs=fo(o.length,n.autoAdvanceMs)),G(),C())}function Fl(t,e,n){if(!g.scenario)return;const r=g.scenario.steps.find(i=>i.id===t);if(!(r!=null&&r.subElements))return;const o=r.subElements.findIndex(i=>i.id===e);if(o<0)return;const a=r.subElements[o];a&&(r.subElements[o]={...a,...n},G(),C())}function ql(t,e,n,r){if(!g.scenario)return;const o=g.scenario.steps.find(s=>s.id===t);if(!(o!=null&&o.subElements))return;const a=o.subElements.findIndex(s=>s.id===e);if(a<0)return;const i=o.subElements[a];i&&(o.subElements[a]={...i,selectors:n,pickedAtUrl:r,thumbnailDataUrl:null},G(),C())}function Yo(t,e,n){if(!g.scenario)return;const r=g.scenario.steps.find(l=>l.id===t);if(!r||!r.subElements||!r.subDwellsMs||e.length===0)return;const o=r.subElements.map(l=>l.id),a=Ol(o,r.subDwellsMs,e,n),i=new Map(r.subElements.map(l=>[l.id,l])),s=[];for(const l of a.subs){const d=i.get(l);d&&s.push(d)}s.length===r.subElements.length&&s.every((l,d)=>{var p,u;return l.id===((u=(p=r.subElements)==null?void 0:p[d])==null?void 0:u.id)})||(r.subElements=s,r.subDwellsMs=a.dwells,G(),C())}function zl(t,e,n){if(!g.scenario)return;const r=g.scenario.steps.find(o=>o.id===t);!r||!r.subDwellsMs||e<0||e>=r.subDwellsMs.length||(r.subDwellsMs=Dl(r.subDwellsMs,e,n,r.autoAdvanceMs),G(),C())}function ho(t,e,n,r){if(!g.scenario)return;const o=g.scenario.steps.find(s=>s.id===t);if(!(o!=null&&o.subElements)||!o.subDwellsMs)return;const a=o.subElements.map(s=>s.id),i=Rl(a,o.subDwellsMs,e,n,r);i.dwells.every((s,c)=>{var l;return s===((l=o.subDwellsMs)==null?void 0:l[c])})||(o.subDwellsMs=i.dwells,G(),C())}function _l(t,e){if(!g.scenario)return;const n=g.scenario.steps.find(r=>r.id===t);n&&(n.autoAdvanceMs=e,n.subDwellsMs&&n.subDwellsMs.length>1&&(n.subDwellsMs=Pl(n.subDwellsMs,e)),G(),C())}function Bl(t,e){if(!g.scenario)return;const n=e.trim();if(!n)return;const r=g.scenario.customColors??{},o=r[t]??[];o.includes(n)||(g.scenario.customColors={...r,[t]:[...o,n]},G(),C())}function Ul(t,e){if(!g.scenario||!g.scenario.customColors)return;const n=g.scenario.customColors[t];!n||!n.includes(e)||(g.scenario.customColors={...g.scenario.customColors,[t]:n.filter(r=>r!==e)},G(),C())}function jl(){return`
    <style>${rl()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Wl()}
      ${Gl()}
      ${Xl()}
      ${Vl()}
    </div>
  `}function Wl(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Gl(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function Xl(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function Vl(){var a,i;const t=L(),e=((a=t==null?void 0:t.customColors)==null?void 0:a.text)??[],n=((i=t==null?void 0:t.customColors)==null?void 0:i.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${on(s)}" style="background: ${on(s)}" aria-label="Use ${on(s)}" title="${on(s)}"></button>`).join("")}</div>
    </div>
  `}function on(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Yl(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let a=n.left;a+r.width>window.innerWidth-8&&(a=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,a)}px`}function yt(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Kc(t);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}let bt=null,V=null,_t=0,Jt=1,te=1,Bt=null;function Kl(t){ee(),Bt=t.onConfirm;const e=oi(t.initialColor);_t=e.h,Jt=e.s,te=e.v,{host:bt,shadow:V}=yt(),bt.style.cssText=["position: fixed",`z-index: ${j+7}`,"pointer-events: auto"].join("; "),V.innerHTML=jl(),Ql(),document.body.appendChild(bt),Yl(bt,t.anchor),Xe(),document.addEventListener("mousedown",fi,!0),document.addEventListener("keydown",hi,!0)}function ee(){bt&&(document.removeEventListener("mousedown",fi,!0),document.removeEventListener("keydown",hi,!0),bt.remove(),bt=null,V=null,Bt=null)}function Zl(){return bt!==null}function Xe(){if(!V)return;const t=V.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${_t}deg, 100%, 50%)`);const e=V.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Jt*100}%`,e.style.top=`${(1-te)*100}%`);const n=V.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${_t/360*100}%`);const[r,o,a]=ei(_t,Jt,te),i=ri(r,o,a),s=V.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${a})`);const c=V.querySelector('[data-region="hex"]');c&&(c.textContent=i),V.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===bt&&V.activeElement===l)return;const d=l.dataset.channel;d==="r"?l.value=String(r):d==="g"?l.value=String(o):d==="b"&&(l.value=String(a))})}function pi(){const[t,e,n]=ei(_t,Jt,te);return ri(t,e,n)}function Ql(){if(!V)return;const t=V.querySelector('[data-region="sv"]');t&&Uo(t,n=>Jl(t,n));const e=V.querySelector('[data-region="hue"]');e&&Uo(e,n=>td(e,n)),V.addEventListener("input",n=>{var c,l,d;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Er((c=V.querySelector('[data-channel="r"]'))==null?void 0:c.value),a=Er((l=V.querySelector('[data-channel="g"]'))==null?void 0:l.value),i=Er((d=V.querySelector('[data-channel="b"]'))==null?void 0:d.value),s=ni(o,a,i);_t=s.h,Jt=s.s,te=s.v,Xe()}),V.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),a=o==null?void 0:o.getAttribute("data-action");if(a==="confirm")Bt==null||Bt(pi()),ee();else if(a==="eyedrop")jc(Ko);else if(a==="recent"){const i=o==null?void 0:o.getAttribute("data-color");i&&Ko(i)}})}function Ko(t){const e=oi(t);_t=e.h,Jt=e.s,te=e.v,Xe()}function Jl(t,e){const n=t.getBoundingClientRect();Jt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),te=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),Xe()}function td(t,e){const n=t.getBoundingClientRect();_t=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,Xe()}function fi(t){if(!bt)return;const e=t.target;e instanceof HTMLElement&&bt.contains(e)||ee()}function hi(t){t.key==="Escape"?(t.preventDefault(),ee()):t.key==="Enter"&&(t.preventDefault(),Bt==null||Bt(pi()),ee())}const an=8,de=6,mi=32,Zo=16,sn=4,gi=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function Qo(t,e,n,r){let{x:o,y:a,width:i,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,i-=n):(t==="ne"||t==="e"||t==="se")&&(i+=n),t==="nw"||t==="n"||t==="ne"?(a+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),i<de&&(o=e.x+e.width-de,i=de),s<de&&(a=e.y+e.height-de,s=de),{x:o,y:a,width:i,height:s}}function bi(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const a of t)a.x<e&&(e=a.x),a.y<n&&(n=a.y),a.x>r&&(r=a.x),a.y>o&&(o=a.y);return{x:e,y:n,width:r-e,height:o-n}}function ed(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const T={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},W="http://www.w3.org/2000/svg";function nd(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const a=r.tagName.toLowerCase(),i=r.parentElement,s=r.tagName;if(i){const c=Array.from(i.children).filter(l=>{var d;return l.tagName===s&&!((d=l.matches)!=null&&d.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${a}:nth-of-type(${l})`)}else n.unshift(a)}else n.unshift(a);r=i,o++}return n.join(" > ")}function rd(t,e=document,n=8){const r=[];let o=t,a=0;for(;o&&o!==document.body&&a<n;){const i=o.tagName.toLowerCase(),s=o.parentElement,c=o.tagName;if(s){const d=Array.from(s.children).filter(p=>{var u;return p.tagName===c&&!((u=p.matches)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length>1){const p=d.indexOf(o)+1;r.unshift(`${i}:nth-of-type(${p})`)}else r.unshift(i)}else r.unshift(i);const l=r.join(" > ");try{const d=Array.from(e.querySelectorAll(l)).filter(p=>{var u;return!((u=p.closest)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length===1&&d[0]===t)return l}catch{}o=s,a++}return r.join(" > ")}function mo(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function od(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const ad=["data-testid","data-test","id","aria-label"];function id(t){for(const e of ad){const n=t.getAttribute(e);if(n&&n.length>0){const r=`[${e}="${od(n)}"]`;try{const o=Array.from(document.querySelectorAll(r)).filter(a=>{var i;return!((i=a.closest)!=null&&i.call(a,'[data-manuscript="ui"]'))});if(o.length===1&&o[0]===t)return{kind:"stable-attr",cssSelector:r}}catch{}}}return{kind:"stable-attr",cssSelector:rd(t)}}function An(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!mo(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function sd(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?nd(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Mn(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!mo(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function cd(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const a of Array.from(r.children)){if(a===t)continue;const i=(a.textContent??"").trim();if(i.length>0&&i.length<60&&n.push(i),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function $n(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||mo(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const a=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>a.includes(c))?n:null}function ld(t){return{layer1:id(t),layer2:sd(t),layer3:cd(t)}}function dd(t,e){const n=e.ownerDocument;return n?An(t.layer1,n)===e||Mn(t.layer2,n)===e||$n(t.layer3,n)===e:!1}function Ae(t){var e;return((e=Wr(t))==null?void 0:e.el)??null}function Wr(t){const e=vi(t.framePath);if(!e)return null;const n=An(t.layer1,e);if(n)return{el:n,layer:1};const r=Mn(t.layer2,e);if(r)return{el:r,layer:2};const o=$n(t.layer3,e);return o?{el:o,layer:3}:null}function vi(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function ud(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function ct(){const t=ut();if(!t||!t.selectors)return null;try{const e=Ae(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function pd(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function nr(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function fd(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function rr(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function yi(t){if(!t.bounds)return t;const e=ct();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function hd(t){if(!t.points)return t;const e=ct();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function md(){document.removeEventListener("mousemove",go,!0),document.removeEventListener("mouseup",bo,!0),document.removeEventListener("keydown",wi,!0)}function gd(){document.addEventListener("keydown",wi,!0)}function bd(t,e){if(!T.activeId)return;t.stopPropagation(),t.preventDefault();const n=R(T.activeId);if(!n||n.kind!=="shape")return;const r=nr(n,ct());T.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},or()}function vd(t){if(!T.activeId)return;t.stopPropagation(),t.preventDefault();const e=R(T.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;T.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},or()}function xi(t,e){if(!T.activeId)return;t.stopPropagation(),t.preventDefault();const n=R(T.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,a=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;T.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:a},or()}function yd(t,e){if(!T.activeId)return;t.stopPropagation(),t.preventDefault();const n=R(T.activeId);if(!n||n.kind!=="freedraw")return;const r=rr(n,ct()),o=bi(r);!o||o.width===0||o.height===0||(T.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(a=>({...a}))},or())}function or(){document.addEventListener("mousemove",go,!0),document.addEventListener("mouseup",bo,!0)}function go(t){const{activeId:e,dragState:n}=T;if(!e||!n)return;t.preventDefault();const r=R(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,a=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const i=Qo(n.handle,n.startBounds,o,a);O(e,yi({bounds:i}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const i=n.startBounds,s=Qo(n.handle,i,o,a),c=i.width===0?1:s.width/i.width,l=i.height===0?1:s.height/i.height,d=n.startPoints.map(p=>({x:s.x+(p.x-i.x)*c,y:s.y+(p.y-i.y)*l}));O(e,hd({points:d}))}else if(n.kind==="rotate"){const i=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(i-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?O(e,{rotate:s}):r.kind==="freedraw"?O(e,{rotate:s}):r.kind==="text"&&O(e,{rotate:s})}}function bo(){document.removeEventListener("mousemove",go,!0),document.removeEventListener("mouseup",bo,!0),T.dragState=null}function wi(t){var o;const{activeId:e}=T;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),po(e);return}if(t.key.startsWith("Arrow")){const a=R(e);if(!a||a.kind!=="shape")return;const i=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-i:t.key==="ArrowRight"?i:0,c=t.key==="ArrowUp"?-i:t.key==="ArrowDown"?i:0;if(s!==0||c!==0){t.preventDefault();const l=nr(a,ct());O(e,yi({bounds:{...a.bounds,x:l.x+s,y:l.y+c}}))}}}}function ki(t,e,n,r,o){const a=document.createElementNS(W,"rect");return a.setAttribute("x",String(t-an/2)),a.setAttribute("y",String(e-an/2)),a.setAttribute("width",String(an)),a.setAttribute("height",String(an)),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),a.style.cursor=r,a.style.pointerEvents="auto",a.setAttribute("pointer-events","all"),a.addEventListener("mousedown",i=>o(i,n)),a}function Si(t,e,n){const r=document.createElementNS(W,"g"),o=e-18,a=e-mi,i=12,s=document.createElementNS(W,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(W,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(a+1)),c.setAttribute("r",String(i)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(W,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(a)),l.setAttribute("r",String(i)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const d=t-8,p=a-8,u=document.createElementNS(W,"path");u.setAttribute("d",`M ${d+4} ${p+11} A 5 5 0 1 1 ${d+11} ${p+4}`),u.setAttribute("fill","none"),u.setAttribute("stroke","oklch(0.48 0.085 245)"),u.setAttribute("stroke-width","1.5"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.style.pointerEvents="none",r.appendChild(u);const f=document.createElementNS(W,"path");return f.setAttribute("d",`M ${d+11} ${p+1.5} L ${d+14} ${p+4} L ${d+11} ${p+6.5} Z`),f.setAttribute("fill","oklch(0.48 0.085 245)"),f.setAttribute("stroke","oklch(0.48 0.085 245)"),f.setAttribute("stroke-width","1.5"),f.setAttribute("stroke-linejoin","round"),f.style.pointerEvents="none",r.appendChild(f),l.addEventListener("mousedown",h=>n(h)),r}function vo(t,e){const n=document.createElementNS(W,"g"),r=t.x-Zo,o=t.y-Zo;return n.appendChild(xd(r,o,e)),n}function xd(t,e,n){const r=document.createElementNS(W,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(W,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const a=document.createElementNS(W,"circle");a.setAttribute("cx",String(t)),a.setAttribute("cy",String(e)),a.setAttribute("r","12"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.92 0.008 240)"),a.setAttribute("stroke-width","1"),r.appendChild(a);const i=t-6,s=e-6,c=document.createElementNS(W,"path");return c.setAttribute("d",[`M ${i+1.5} ${s+3.5} L ${i+10.5} ${s+3.5}`,`M ${i+4.5} ${s+3.5} L ${i+4.5} ${s+2} L ${i+7.5} ${s+2} L ${i+7.5} ${s+3.5}`,`M ${i+3} ${s+3.5} L ${i+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${i+4.3} ${s+11} L ${i+7.7} ${s+11} A 0.8 0.8 0 0 0 ${i+8.5} ${s+10.5} L ${i+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function yo(t){const e=document.createElementNS(W,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function ar(){const{host:t,activeId:e,activeMode:n}=T;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=R(e);if(!r){Gr();return}if(n==="freedraw"&&r.kind==="freedraw"){Ed(t,r);return}if(n==="text"&&r.kind==="text"){Sd(t,r);return}if(r.kind!=="shape"){Gr();return}wd(t,r)}function wd(t,e){const n=nr(e,ct()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,a=r.x+r.width/2,i=r.y+r.height/2,s=document.createElementNS(W,"g");o&&s.setAttribute("transform",`rotate(${o} ${a} ${i})`),s.appendChild(yo(r));for(const c of gi){const{x:l,y:d}=c.offset(r);s.appendChild(ki(l,d,c.name,c.cursor,bd))}s.appendChild(kd(r)),t.appendChild(s),t.appendChild(vo(r,xo))}function kd(t){const e=t.x+t.width/2,n=t.y-mi,r=document.createElementNS(W,"g"),o=document.createElementNS(W,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const a=document.createElementNS(W,"g");a.style.cursor="grab",a.style.pointerEvents="auto",a.setAttribute("pointer-events","all");const i=document.createElementNS(W,"circle");i.setAttribute("cx",String(e)),i.setAttribute("cy",String(n)),i.setAttribute("r","9"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),a.appendChild(i);const s=document.createElementNS(W,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",a.appendChild(s),a.addEventListener("mousedown",c=>vd(c)),r.appendChild(a),r}function Sd(t,e){const n=ed(e.id);if(!n)return;const r=Ei(n),o=r.x+r.width/2,a=r.y+r.height/2;t.appendChild(yo(r)),t.appendChild(Si(o,r.y,i=>xi(i,()=>({x:o,y:a})))),t.appendChild(vo(r,xo))}function Ed(t,e){const n=rr(e,ct()),r=bi(n);if(!r)return;const o=Ei(r),a=o.x+o.width/2,i=o.y+o.height/2;t.appendChild(yo(o));for(const s of gi){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(ki(c,l,s.name,s.cursor,yd))}t.appendChild(Si(a,o.y,s=>xi(s,()=>({x:a,y:i})))),t.appendChild(vo(o,xo))}function Ei(t){return{x:t.x-sn,y:t.y-sn,width:t.width+sn*2,height:t.height+sn*2}}function xo(){const t=T.activeId;t&&po(t)}function Ad(t){const e=R(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const a=document.querySelectorAll(o);if(a.length===0)return;const i=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;a.forEach(s=>{s.style.animation=""}),a[0].getBoundingClientRect(),a.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${i}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function Md(t){const e=R(t);!e||e.kind!=="shape"||(T.activeId=t,T.activeMode="shape",wo(),ar())}function $d(t){const e=R(t);!e||e.kind!=="freedraw"||(T.activeId=t,T.activeMode="freedraw",wo(),ar())}function Ld(t){const e=R(t);!e||e.kind!=="text"||(T.activeId=t,T.activeMode="text",wo(),ar())}function Gr(){var t;T.host&&(md(),(t=T.unsubscribeScenario)==null||t.call(T),T.unsubscribeScenario=null,T.host.remove(),T.host=null,T.activeId=null,T.activeMode="shape",T.dragState=null)}function Td(t){return T.host!==null&&t!==null&&T.host.contains(t)}function wo(){if(T.host)return;const t=document.createElementNS(W,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${j+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),T.host=t,gd(),T.unsubscribeScenario=De(ar)}const Id=400,Cd=0;function Dd(t){return{kind:t,durationMs:Id,delayMs:Cd}}function Pd(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const Jo=10,Rd=46,Ai=12,Mi=36,$i=0,Li=20,Od=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],Nd=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],ta=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}];function Hd(t){return!t||t.length===0?[...ta]:[...t.map(e=>({label:vl(e),value:e})),...ta]}const Fd=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],$={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function wt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Ti(t){const e=$.activeId;if(!e)return;const n=R(e);n&&(n.kind==="text"?O(e,{style:{...n.style,color:t}}):n.kind==="shape"?O(e,{stroke:t}):n.kind==="freedraw"&&O(e,{stroke:t}))}function Ii(t){const e=$.activeId;if(!e)return;const n=R(e);n&&(n.kind==="text"?O(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&O(e,{fill:t}))}function Ci(t){const e=$.activeId;if(!e)return;const n=R(e);!n||n.kind!=="text"||O(e,{style:{...n.style,borderColor:t}})}function qd(t){const e=$.activeId;if(!e)return;const n=R(e);!n||n.kind!=="text"||O(e,{style:{...n.style,fontFamily:t}})}function zd(t){const e=$.activeId;if(!e)return;const n=R(e);!n||n.kind!=="text"||O(e,{style:{...n.style,fontSize:t}})}function _d(){const t=$.activeId;if(!t)return;const e=R(t);!e||e.kind!=="text"||O(t,{style:{...e.style,bold:!e.style.bold}})}function Bd(){const t=$.activeId;if(!t)return;const e=R(t);!e||e.kind!=="text"||O(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Ud(t){const e=$.activeId;e&&O(e,{entryAnimation:t==="none"?void 0:Dd(t)})}function jd(t){const e=$.activeId;if(!e)return;const n=R(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?O(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?O(e,{fillOpacity:r}):n.kind==="freedraw"&&O(e,{strokeOpacity:r})}function Wd(t){const e=$.activeId;if(!e)return;const n=R(e);n&&(n.kind==="shape"?O(e,{strokeWidth:t}):n.kind==="freedraw"&&O(e,{strokeWidth:t}))}function Gd(){const{shadow:t}=$;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=i=>{r&&$r(e,i.clientX)},a=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",a,!0)};n.addEventListener("mousedown",i=>{r=!0,$r(e,i.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0),i.preventDefault()}),e.addEventListener("mousedown",i=>{const s=i.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||($r(e,i.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0))})}function $r(t,e){const n=t.getBoundingClientRect();jd(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function Xr(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function Xd(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function Lr(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function Tr(t,e,n){var l,d,p;const r=$.swatchMode==="muted"?Od:Nd,o=[];if(n&&(t==="bg"||t==="border")){const u=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${u}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let u=0;u<r.length;u++){const f=r[u];if(!f)continue;const h=u===1,b=Lr(e,f.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${f.resolved}" style="background:${f.resolved}" aria-pressed="${b}" title="${t} ${f.resolved}"></button>
    `)}const a=L(),i=(t==="text"||t==="border"?(l=a==null?void 0:a.siteColors)==null?void 0:l.text:(d=a==null?void 0:a.siteColors)==null?void 0:d.background)??[];for(const u of i){const f=Lr(e,u);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${wt(u)}" style="background:${wt(u)}" aria-pressed="${f}" title="Site color ${wt(u)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((p=a==null?void 0:a.customColors)==null?void 0:p[s])??[];for(const u of c){const f=Lr(e,u);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${wt(u)}" style="background:${wt(u)}" aria-pressed="${f}" title="Custom ${wt(u)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${wt(u)}" title="Remove" aria-label="Remove color ${wt(u)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function ko(){const{shadow:t,activeId:e,activeKind:n}=$;if(!t||!e||!n)return;const r=R(e);if(!r||r.kind==="arrow")return;const o=r,a=t.querySelector('[data-region="caption"]');a&&(a.textContent=tu(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(i=>{const s=i.getAttribute("data-mode");i.setAttribute("aria-pressed",String(s===$.swatchMode))}),Vd(t,n),Yd(t,n,o),Kd(t,n,o),Zd(t,n,o),Qd(t,o),Jd(t,o)}function Vd(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const a=t.querySelector('[data-region="width-row"]'),i=e==="shape"||e==="freedraw";a&&(a.hidden=!i);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const d=t.querySelector('[data-region="bg-label"]');d&&(d.textContent=e==="text"?"Bg":"Fill")}function Yd(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const a=t.querySelector('[data-region="bold"]');a&&a.setAttribute("aria-pressed",String(n.style.bold));const i=t.querySelector('[data-region="italic"]');i&&i.setAttribute("aria-pressed",String(n.style.italic===!0))}function Kd(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),a=n.strokeWidth;r&&(r.value=String(a)),o&&(o.textContent=String(a))}function Zd(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),a=t.querySelector('[data-region="border-swatches"]'),i=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=Xr(n,"text"),l=Xr(n,"bg");if(r&&(r.innerHTML=Tr("text",c,!1)),o&&!(i!=null&&i.hidden)&&(o.innerHTML=Tr("bg",l,e==="text")),a&&!(s!=null&&s.hidden)&&n.kind==="text"){const d=n.style.borderColor??"#000000";a.innerHTML=Tr("border",d,!0)}}function Qd(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=Pd(e))}function Jd(t,e){const n=Math.round(Xd(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),a=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),a&&(a.textContent=`${n}%`)}function tu(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function eu(t){const{shadow:e,host:n}=$;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>nu(o)),e.addEventListener("change",o=>ru(o)),e.addEventListener("input",o=>ou(o)),Gd(),document.addEventListener("mousedown",o=>iu(o,t),!0),document.addEventListener("keydown",o=>su(o,t),!0)}function nu(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&($.swatchMode=c,ko());return}if(e.closest('[data-region="bold"]'))return _d();if(e.closest('[data-region="italic"]'))return Bd();if(e.closest('[data-region="effect-play"]')){$.activeId&&Ad($.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return Ti(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return Ii(o.getAttribute("data-value")??"");const a=e.closest('[data-swatch="border"]');if(a)return Ci(a.getAttribute("data-value")??"");const i=e.closest('[data-action="more-colors"]');if(i instanceof HTMLElement)return au(i);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&Ul(c==="text"||c==="border"?"text":"background",l)}}function ru(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?qd(e.value):e.dataset.region==="effect"&&Ud(e.value))}function ou(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(Ai,Math.min(Mi,Number(e.value)||16));zd(n)}else if(e.dataset.region==="width"){const n=Math.max($i,Math.min(Li,Number(e.value)||0));Wd(n)}}}function au(t){const{activeId:e,activeKind:n}=$;if(!e||!n)return;const r=R(e);if(!r||r.kind==="arrow")return;const o=r,a=t.getAttribute("data-slot");if(!a)return;const i=Xr(o,a)||"#ffffff";Kl({anchor:t,initialColor:i,onConfirm:s=>{Bl(a==="text"||a==="border"?"text":"background",s),a==="text"?Ti(s):a==="border"?Ci(s):Ii(s)}})}function iu(t,e){const{host:n,activeAnchorSelector:r}=$,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||Td(o)||Zl()||r&&o instanceof Element&&o.closest(r)||o instanceof Element&&o.closest('[data-manuscript="ui"]')||(e(),ee())}function su(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function Di(t){const{host:e}=$;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-Jo-Rd;o<8&&(o=r.bottom+Jo);const a=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${a}px`}function cu(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function lu(t,e){t==="text"?Ld(e):t==="shape"?Md(e):$d(e)}function du(){return`
    ${Rt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function uu(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function pu(){return[du(),uu()].join(`
`)}function fu(){return`
    <style>${pu()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${hu()}
      ${mu()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${gu()}
      <div class="divider"></div>
      ${bu()}
      ${vu()}
      ${yu()}
      ${xu()}
    </div>
  `}function hu(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function mu(){var e;return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Hd((e=L())==null?void 0:e.siteFonts).map(n=>`<option value="${wt(n.value)}" style="font-family: ${wt(n.value)};">${n.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${Ai}" max="${Mi}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function gu(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function bu(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${$i}" max="${Li}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function vu(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Fd.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function yu(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function xu(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function Ve(t,e,n){R(t)&&($.activeId=t,$.activeKind=n,$.activeAnchorSelector=cu(n,t),$.host||Eu(),ko(),Di(e),lu(n,t),document.dispatchEvent(new CustomEvent("manuscript:annotation-selected",{detail:{id:t}})))}function ir(){var t;$.host&&((t=$.unsubscribeScenario)==null||t.call($),$.unsubscribeScenario=null,ee(),Gr(),$.host.remove(),$.host=null,$.shadow=null,$.activeId=null,$.activeKind=null,$.activeAnchorSelector=null,document.dispatchEvent(new CustomEvent("manuscript:annotation-selected",{detail:{id:null}})))}function So(){return $.activeId}function wu(t,e){Ve(t,e,"text")}function Pi(){ir()}function ku(t,e){Ve(t,e,"shape")}function Su(t,e){Ve(t,e,"freedraw")}function Eu(){const{host:t,shadow:e}=yt();t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${j+5}`,"pointer-events: auto"].join("; "),e.innerHTML=fu(),$.host=t,$.shadow=e,document.body.appendChild(t),eu(ir),$.unsubscribeScenario=De(Au)}function Au(){const{activeId:t,host:e,activeAnchorSelector:n}=$;if(!t||!e)return;if(!R(t)){ir();return}if(ko(),n){const o=document.querySelector(n);o&&Di(o)}}const At=20;let Ln=null,ea=!1;function Mu(){ea||(ea=!0,document.addEventListener("keydown",Tu,!0)),$u()}async function $u(){try{const e=(await chrome.storage.local.get(z.annotationClipboard))[z.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(Ln=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function Lu(t){try{await chrome.storage.local.set({[z.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function Tu(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||st()!=="replay"&&(Iu()||(e==="c"?Cu(t):Du(t)))}function Iu(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function Cu(t){const e=So();if(!e)return;const n=R(e);n&&(Ln=n,Lu(n),t.preventDefault())}function Du(t){if(!Ln||!ut())return;const e=Pu(Ln);er(e),t.preventDefault()}function Pu(t){switch(t.kind){case"text":return Ru(t);case"shape":return Ou(t);case"freedraw":return Nu(t);case"arrow":return Hu(t)}}function Ru(t){return{...t,id:sr("text"),position:{x:t.position.x+At,y:t.position.y+At},style:{...t.style}}}function Ou(t){return{...t,id:sr("shape"),bounds:{...t.bounds,x:t.bounds.x+At,y:t.bounds.y+At}}}function Nu(t){return{...t,id:sr("freedraw"),points:t.points.map(e=>({x:e.x+At,y:e.y+At}))}}function Hu(t){return{...t,id:sr("arrow"),from:{x:t.from.x+At,y:t.from.y+At},to:{x:t.to.x+At,y:t.to.y+At}}}function sr(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const na="http://www.w3.org/2000/svg",Fu="#1a1a1a",qu="oklch(0.97 0.003 245)";function Ri(){return co(lo())?qu:Fu}const Oi=3,zu=2,_u=2;let Tn=!1,ra=null,Me=!1,vt=[],ft=null,kt=null;function Bu(){ra||(ra=$t(({prev:t,next:e})=>{e==="freedraw"?Uu():t==="freedraw"&&ju()}))}function Uu(){Tn||(Tn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Ni,!0),document.addEventListener("mousemove",Hi,!0),document.addEventListener("mouseup",Fi,!0),document.addEventListener("keydown",qi,!0))}function ju(){Tn&&(Tn=!1,Me=!1,vt=[],document.body.style.cursor="",document.removeEventListener("mousedown",Ni,!0),document.removeEventListener("mousemove",Hi,!0),document.removeEventListener("mouseup",Fi,!0),document.removeEventListener("keydown",qi,!0),Eo())}function Ni(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Me=!0,vt=[{x:t.clientX,y:t.clientY}],Wu(),zi())}function Hi(t){if(!Me)return;t.preventDefault();const e=vt[vt.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<_u||(vt.push({x:t.clientX,y:t.clientY}),zi())}function Fi(t){if(!Me)return;if(Me=!1,Eo(),vt.length<zu){vt=[],P("idle");return}t.preventDefault(),t.stopPropagation();const e=vt.slice(),n=ct(),r={kind:"freedraw",id:ie("freedraw"),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:Ri(),strokeWidth:Oi};er(r),vt=[],P("idle")}function qi(t){t.key==="Escape"&&(t.preventDefault(),Me=!1,vt=[],Eo(),P("idle"))}function Wu(){ft||(ft=document.createElementNS(na,"svg"),ft.setAttribute("data-manuscript","ui"),ft.setAttribute("width","100%"),ft.setAttribute("height","100%"),ft.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${j+4}`,"overflow: visible"].join("; "),kt=document.createElementNS(na,"polyline"),kt.setAttribute("fill","none"),kt.setAttribute("stroke",Ri()),kt.setAttribute("stroke-width",String(Oi)),kt.setAttribute("stroke-linecap","round"),kt.setAttribute("stroke-linejoin","round"),ft.appendChild(kt),document.body.appendChild(ft))}function Eo(){ft==null||ft.remove(),ft=null,kt=null}function zi(){kt&&kt.setAttribute("points",vt.map(t=>`${t.x},${t.y}`).join(" "))}const Ye="manuscript:element-selected";let In=!1,pt=null,oa=null;function Gu(){oa||(oa=$t(({prev:t,next:e})=>{e==="picker"?Xu():t==="picker"&&Vu()}))}function Xu(){In||(In=!0,document.addEventListener("mouseover",_i,!0),document.addEventListener("mouseout",Bi,!0),document.addEventListener("click",Ui,!0),document.addEventListener("keydown",ji,!0))}function Vu(){In&&(In=!1,document.removeEventListener("mouseover",_i,!0),document.removeEventListener("mouseout",Bi,!0),document.removeEventListener("click",Ui,!0),document.removeEventListener("keydown",ji,!0),Wi())}function _i(t){const e=t.target;!(e instanceof HTMLElement)||Gi(e)||Ku(e)}function Bi(t){Wi()}function Ui(t){const e=t.target;if(!(e instanceof HTMLElement)||Gi(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=ld(e),r=e.ownerDocument??document;if(console.log("[manuscript/picker] selectorChain",{target:e,chain:n,resolve:{layer1:An(n.layer1,r),layer2:Mn(n.layer2,r),layer3:$n(n.layer3,r)},matchesTarget:{layer1:An(n.layer1,r)===e,layer2:Mn(n.layer2,r)===e,layer3:$n(n.layer3,r)===e}}),!dd(n,e)){Yu();return}const o=e.getBoundingClientRect(),a={chain:n,rect:{x:o.x,y:o.y,width:o.width,height:o.height}};document.dispatchEvent(new CustomEvent(Ye,{detail:a})),P("idle")}let mt=null,cn=null;function Yu(){mt&&mt.remove(),mt=document.createElement("div"),mt.setAttribute("data-manuscript","ui"),mt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${j+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),mt.textContent=v("toast.ambiguous-selector"),document.body.appendChild(mt),cn!==null&&window.clearTimeout(cn),cn=window.setTimeout(()=>{mt==null||mt.remove(),mt=null,cn=null},3500)}function ji(t){t.key==="Escape"&&(t.preventDefault(),P("idle"))}function Ku(t){pt||(pt=document.createElement("div"),pt.setAttribute("data-manuscript","ui"),pt.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${j+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(pt));const e=t.getBoundingClientRect();pt.style.left=`${e.left}px`,pt.style.top=`${e.top}px`,pt.style.width=`${e.width}px`,pt.style.height=`${e.height}px`,pt.style.display="block"}function Wi(){pt&&(pt.style.display="none")}function Gi(t){return t.closest('[data-manuscript="ui"]')!==null}const Ke="http://www.w3.org/2000/svg";function Ao(t,e){let n;switch(t){case"rectangle":n=Zu(e);break;case"ellipse":n=Qu(e);break;case"triangle":n=ln(ep(e),e);break;case"diamond":n=ln(np(e),e);break;case"star":n=ln(rp(e),e);break;case"callout":n=tp(op(e),e);break;case"line":n=Ju(e);break;case"block-arrow":n=ln(ap(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function Zu(t){const e=document.createElementNS(Ke,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),cr(e,t),e}function Qu(t){const e=document.createElementNS(Ke,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),cr(e,t),e}function Ju(t){const e=document.createElementNS(Ke,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function ln(t,e){const n=document.createElementNS(Ke,"polygon");return n.setAttribute("points",t),cr(n,e),n.setAttribute("stroke-linejoin","round"),n}function tp(t,e){const n=document.createElementNS(Ke,"path");return n.setAttribute("d",t),cr(n,e),n.setAttribute("stroke-linejoin","round"),n}function cr(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function ep(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function np(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function rp(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,a=[];for(let i=0;i<10;i++){const s=Math.PI/5*i-Math.PI/2,c=i%2===0?r:o;a.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return a.join(" ")}function op(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,a=t.x+t.width*.5,i=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${a} ${r}`,`L ${i} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function ap(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const ip="http://www.w3.org/2000/svg",sp="#ffffff",cp="#1a1a1a",lp=2;let Z=null,St=null;function Xi(t){return{fill:t==="line"?"transparent":sp,stroke:cp,strokeWidth:lp}}function dp(){St||(St=document.createElement("div"),St.setAttribute("data-manuscript","ui"),St.textContent="Click and drag to draw a shape · Esc to cancel",St.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${j+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(St))}function Vi(){St==null||St.remove(),St=null}function up(){Z||(Z=document.createElementNS(ip,"svg"),Z.setAttribute("data-manuscript","ui"),Z.setAttribute("width","100%"),Z.setAttribute("height","100%"),Z.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${j+4}`,"overflow: visible"].join("; "),document.body.appendChild(Z))}function Mo(){Z==null||Z.remove(),Z=null}function Yi(t,e,n,r,o){if(!Z)return;for(;Z.firstChild;)Z.removeChild(Z.firstChild);const a=t==="line"?r-e:Math.abs(r-e),i=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=Xi(t),d=Ao(t,{x:s,y:c,width:a,height:i,...l});d&&Z.appendChild(d)}const pp=6;let Nt="rectangle",Cn=!1,aa=null,$e=!1,Ht=0,Ft=0;function fp(t){Nt=t}function hp(){aa||(aa=$t(({prev:t,next:e})=>{e==="shape"?mp():t==="shape"&&gp()}))}function mp(){Cn||(Cn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Ki,!0),document.addEventListener("mousemove",Zi,!0),document.addEventListener("mouseup",Qi,!0),document.addEventListener("keydown",Ji,!0),dp())}function gp(){Cn&&(Cn=!1,$e=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Ki,!0),document.removeEventListener("mousemove",Zi,!0),document.removeEventListener("mouseup",Qi,!0),document.removeEventListener("keydown",Ji,!0),Mo(),Vi())}function Ki(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),$e=!0,Ht=t.clientX,Ft=t.clientY,Vi(),up(),Yi(Nt,Ht,Ft,Ht,Ft))}function Zi(t){$e&&(t.preventDefault(),Yi(Nt,Ht,Ft,t.clientX,t.clientY))}function Qi(t){if(!$e)return;$e=!1,Mo();const e=t.clientX,n=t.clientY,r=Nt==="line"?e-Ht:Math.abs(e-Ht),o=Nt==="line"?n-Ft:Math.abs(n-Ft);if(Math.max(Math.abs(r),Math.abs(o))<pp){P("idle");return}t.preventDefault(),t.stopPropagation();const a=Nt==="line"?{x:Ht,y:Ft,width:r,height:o}:{x:Math.min(Ht,e),y:Math.min(Ft,n),width:r,height:o},i=Xi(Nt),s=ct(),c={kind:"shape",id:ie("shape"),shapeKind:Nt,bounds:a,...s?{boundsAnchorOffset:{x:a.x-s.left,y:a.y-s.top}}:{},...i};er(c),P("idle")}function Ji(t){t.key==="Escape"&&(t.preventDefault(),$e=!1,Mo(),P("idle"))}const bp={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},vp="Text";let Dn=!1,ia=null;function yp(){ia||(ia=$t(({prev:t,next:e})=>{e==="text"?xp():t==="text"&&wp()}))}function xp(){Dn||(Dn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",ts,!0),document.addEventListener("keydown",es,!0))}function wp(){Dn&&(Dn=!1,document.body.style.cursor="",document.removeEventListener("click",ts,!0),document.removeEventListener("keydown",es,!0))}function ts(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=ct(),o={kind:"text",id:ie("text"),text:vp,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...bp}};er(o),requestAnimationFrame(()=>{const a=document.querySelector(`[data-annotation-text="${o.id}"]`);a&&a.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),P("idle")}function es(t){t.key==="Escape"&&(t.preventDefault(),P("idle"))}const kp="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",Sp="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",sa="Asta Sans",Ep="fonts/AstaSans-VariableFont_wght.ttf";let ca=!1;function Ap(){ca||(ca=!0,la(kp),la(Sp),Mp())}function la(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function Mp(){try{for(const t of document.fonts)if(t.family===sa)return}catch{}try{const t=chrome.runtime.getURL(Ep);new FontFace(sa,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const gt="manuscript";function lr(...t){}function Ir(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function ue(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function ns(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===gt&&typeof e.type=="string"}function $p(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const a=o.data;if(ns(a)){if(lr("child received",a.type,"in",location.href),a.type==="set-mode"){P(a.mode),t=a.mode;return}if(a.type==="top-drag-start"){n=!0;return}if(a.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(Ye,(o=>{const a=o.detail;ue({source:gt,type:"element-selected",detail:a})})),$t(({prev:o,next:a})=>{o==="picker"&&a==="idle"&&ue({source:gt,type:"exit-picker"})}),ue({source:gt,type:"frame-ready"}),document.addEventListener("mousedown",o=>{ue({source:gt,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&ue({source:gt,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&ue({source:gt,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function Lp(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const a=o.getBoundingClientRect();return{x:a.left,y:a.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function Tp(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Ip(){$t(({next:t})=>{Ir({source:gt,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Ir({source:gt,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Ir({source:gt,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(ns(e)){if(lr("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){Cp(t.source,e.detail);return}if(e.type==="exit-picker"){P("idle");return}if(e.type==="iframe-mousedown"){da("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";da(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){Dp(t.source);return}}})}function Cp(t,e){const n=Tp(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};lr("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(Ye,{detail:o})),P("idle")}function da(t,e,n,r){const o=Lp(e),a=n+o.x,i=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:a,clientY:i}))}function Dp(t){if(st()==="picker")try{t==null||t.postMessage({source:gt,type:"set-mode",mode:"picker"},"*"),lr("top → late child: set-mode picker")}catch{}}function Pp(){if(typeof window>"u")return;window===window.top?Ip():$p()}const Rp="iframe-tool-overlay",ua=new Set(["text","shape","freedraw"]);let ve=[],Cr=!1,fe=null;function Op(){typeof window>"u"||window===window.top&&($t(({next:t})=>{ua.has(t)?pa():rs()}),ua.has(st())&&pa())}function pa(){rs(),fa(),window.addEventListener("scroll",Pn,!0),window.addEventListener("resize",Pn),fe=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&fa()}),fe.observe(document.body,{childList:!0,subtree:!0})}function rs(){ve.forEach(t=>t.remove()),ve=[],window.removeEventListener("scroll",Pn,!0),window.removeEventListener("resize",Pn),fe==null||fe.disconnect(),fe=null}function fa(){ve.forEach(e=>e.remove()),ve=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",Rp),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${j+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),ve.push(n),os(n,e)})}const dn=8;function os(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-dn}px`,t.style.top=`${n.top-dn}px`,t.style.width=`${n.width+dn*2}px`,t.style.height=`${n.height+dn*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function Pn(){Cr||(Cr=!0,requestAnimationFrame(()=>{Cr=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=ve[e];r&&os(r,n),e++})}))}function Rn(t){const e={name:t.name,description:t.description,autoAdvanceMs:t.autoAdvanceMs??null,waitForNavigation:t.waitForNavigation,thumbnailDataUrl:t.thumbnailDataUrl??null},n=t.subElements,r=t.subDwellsMs;return n&&n.length>0&&r&&r.length===n.length+1&&(e.primaryDwellMs=r[0]??0,e.subs=n.map((o,a)=>({id:o.id,thumbnailDataUrl:o.thumbnailDataUrl,dwellMs:r[a+1]??0}))),e}let Ut=!1;function dr(){return Ut}async function Np(){try{if(typeof(await chrome.storage.local.get(z.prompterWindowId))[z.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(Ut=!0)}catch{}}async function as(){if(Ut){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}Ut=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(Ut=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function is(){if(Ut){Ut=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function ss(t){try{await chrome.storage.local.set({[z.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function Hp(){Ut=!1}const Ot="http://www.w3.org/2000/svg",ha="manuscript-spotlight-mask",Fp="oklch(0.42 0.09 250)",qp=3,zp="rgb(0, 0, 0)",_p=.55,Ne=14;let ne=null,nt=null,J=null,Q=null,X=null,Ct=null,Fe=0,Vr=[],he=null;function $o(t){Fe++,ne=t,nt||jp(),Yr(),Te(),cs(t),he||(he=De(Yr))}function Le(){Fe++,ne=null,ls(),he==null||he(),he=null,nt&&(nt.remove(),nt=null,J=null,Q=null,X=null,Ct=null)}function Lo(t,e={}){var s;const n=e.durationMs??300;if(!ne||!nt||n<=0){$o(t),(s=e.onDone)==null||s.call(e);return}const r=Bp();Fe++;const o=Fe;ne=t,Yr(),cs(t);const a=performance.now();function i(c){var u;if(o!==Fe)return;const l=Math.min(1,(c-a)/n),d=Up(l),p=ds(t);us({x:un(r.x,p.x,d),y:un(r.y,p.y,d),width:un(r.width,p.width,d),height:un(r.height,p.height,d)}),l<1?requestAnimationFrame(i):(Te(),(u=e.onDone)==null||u.call(e))}requestAnimationFrame(i)}function Bp(){if(!J)return{x:0,y:0,width:0,height:0};const t=4,e=Number(J.getAttribute("x")??0)+t,n=Number(J.getAttribute("y")??0)+t,r=Number(J.getAttribute("width")??0)-t*2,o=Number(J.getAttribute("height")??0)-t*2;return{x:e,y:n,width:r,height:o}}function un(t,e,n){return t+(e-t)*n}function Up(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2}function cs(t){var n;ls();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=Te;r.addEventListener("scroll",o,!0),Vr.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",Te)}function ls(){for(const t of Vr)t.remove();Vr=[],window.removeEventListener("resize",Te)}function jp(){nt=document.createElementNS(Ot,"svg"),nt.setAttribute("data-manuscript","ui"),nt.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${j}`].join("; "),nt.setAttribute("width","100%"),nt.setAttribute("height","100%");const t=document.createElementNS(Ot,"defs"),e=document.createElementNS(Ot,"mask");e.setAttribute("id",ha);const n=document.createElementNS(Ot,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),J=document.createElementNS(Ot,"rect"),J.setAttribute("fill","black"),J.setAttribute("rx","4"),J.setAttribute("ry","4"),e.appendChild(J),t.appendChild(e),nt.appendChild(t),Ct=document.createElementNS(Ot,"rect"),Ct.setAttribute("width","100%"),Ct.setAttribute("height","100%"),Ct.setAttribute("mask",`url(#${ha})`),nt.appendChild(Ct),Q=document.createElementNS(Ot,"rect"),Q.setAttribute("fill","none"),Q.setAttribute("rx","4"),Q.setAttribute("ry","4"),Q.style.pointerEvents="none",nt.appendChild(Q),X=document.createElementNS(Ot,"rect"),X.setAttribute("fill","none"),X.setAttribute("stroke","transparent"),X.setAttribute("stroke-width",String(Ne)),X.setAttribute("rx","4"),X.setAttribute("ry","4"),X.setAttribute("pointer-events","stroke"),X.style.cursor="pointer",X.addEventListener("click",Wp),nt.appendChild(X),document.body.appendChild(nt)}function Yr(){var a;if(!Q||!Ct)return;const t=((a=ut())==null?void 0:a.spotlight)??{},e=t.stroke??Fp,n=t.strokeWidth??qp,r=t.dimColor??zp,o=t.dimOpacity??_p;Q.setAttribute("stroke",e),Q.setAttribute("stroke-width",String(n)),Ct.setAttribute("fill",r),Ct.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),Te()}function Wp(t){st()!=="replay"&&(!ne||!X||(t.stopPropagation(),t.preventDefault(),Tc(()=>import("./chunk-CIOFAL-T.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{X&&e.openSpotlightEditor(X)})))}function Te(){ne&&us(ds(ne))}function ds(t){const e=t.getBoundingClientRect(),n=Gp(t);return{x:e.left+n.x,y:e.top+n.y,width:e.width,height:e.height}}function us(t){if(!J||!Q||!X)return;const e=4,n=t.x-e,r=t.y-e,o=t.width+e*2,a=t.height+e*2;J.setAttribute("x",String(n)),J.setAttribute("y",String(r)),J.setAttribute("width",String(o)),J.setAttribute("height",String(a));const i=Math.max(0,Number(Q.getAttribute("stroke-width")??0)),s=n-i/2,c=r-i/2,l=o+i,d=a+i;Q.setAttribute("x",String(s)),Q.setAttribute("y",String(c)),Q.setAttribute("width",String(l)),Q.setAttribute("height",String(d));const p=s-Ne/2,u=c-Ne/2,f=l+Ne,h=d+Ne;X.setAttribute("x",String(p)),X.setAttribute("y",String(u)),X.setAttribute("width",String(f)),X.setAttribute("height",String(h))}function Gp(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}function Dr(t,e,n){if(t&&t.length){const[r,o]=e,a=Math.PI/180*n,i=Math.cos(a),s=Math.sin(a);for(const c of t){const[l,d]=c;c[0]=(l-r)*i-(d-o)*s+r,c[1]=(l-r)*s+(d-o)*i+o}}}function Xp(t,e){return t[0]===e[0]&&t[1]===e[1]}function Vp(t,e,n,r=1){const o=n,a=Math.max(e,.1),i=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of i)Dr(l,s,o);const c=(function(l,d,p){const u=[];for(const x of l){const S=[...x];Xp(S[0],S[S.length-1])||S.push([S[0][0],S[0][1]]),S.length>2&&u.push(S)}const f=[];d=Math.max(d,.1);const h=[];for(const x of u)for(let S=0;S<x.length-1;S++){const _=x[S],F=x[S+1];if(_[1]!==F[1]){const I=Math.min(_[1],F[1]);h.push({ymin:I,ymax:Math.max(_[1],F[1]),x:I===_[1]?_[0]:F[0],islope:(F[0]-_[0])/(F[1]-_[1])})}}if(h.sort(((x,S)=>x.ymin<S.ymin?-1:x.ymin>S.ymin?1:x.x<S.x?-1:x.x>S.x?1:x.ymax===S.ymax?0:(x.ymax-S.ymax)/Math.abs(x.ymax-S.ymax))),!h.length)return f;let b=[],y=h[0].ymin,w=0;for(;b.length||h.length;){if(h.length){let x=-1;for(let S=0;S<h.length&&!(h[S].ymin>y);S++)x=S;h.splice(0,x+1).forEach((S=>{b.push({s:y,edge:S})}))}if(b=b.filter((x=>!(x.edge.ymax<=y))),b.sort(((x,S)=>x.edge.x===S.edge.x?0:(x.edge.x-S.edge.x)/Math.abs(x.edge.x-S.edge.x))),(p!==1||w%d==0)&&b.length>1)for(let x=0;x<b.length;x+=2){const S=x+1;if(S>=b.length)break;const _=b[x].edge,F=b[S].edge;f.push([[Math.round(_.x),y],[Math.round(F.x),y]])}y+=p,b.forEach((x=>{x.edge.x=x.edge.x+p*x.edge.islope})),w++}return f})(i,a,r);if(o){for(const l of i)Dr(l,s,-o);(function(l,d,p){const u=[];l.forEach((f=>u.push(...f))),Dr(u,d,p)})(c,s,-o)}return c}function Ze(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let a=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(a=o),Vp(t,o,r,a||1)}class To{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=Ze(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function ur(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Yp extends To{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=Ze(e,Object.assign({},n,{hachureGap:r})),a=Math.PI/180*n.hachureAngle,i=[],s=.5*r*Math.cos(a),c=.5*r*Math.sin(a);for(const[l,d]of o)ur([l,d])&&i.push([[l[0]-s,l[1]+c],[...d]],[[l[0]+s,l[1]-c],[...d]]);return{type:"fillSketch",ops:this.renderLines(i,n)}}}class Kp extends To{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),a=this._fillPolygons(e,o);return r.ops=r.ops.concat(a.ops),r}}class Zp{constructor(e){this.helper=e}fillPolygons(e,n){const r=Ze(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let a=n.fillWeight;a<0&&(a=n.strokeWidth/2);const i=o/4;for(const s of e){const c=ur(s),l=c/o,d=Math.ceil(l)-1,p=c-d*o,u=(s[0][0]+s[1][0])/2-o/4,f=Math.min(s[0][1],s[1][1]);for(let h=0;h<d;h++){const b=f+p+h*o,y=u-i+2*Math.random()*i,w=b-i+2*Math.random()*i,x=this.helper.ellipse(y,w,a,a,n);r.push(...x.ops)}}return{type:"fillSketch",ops:r}}}class Qp{constructor(e){this.helper=e}fillPolygons(e,n){const r=Ze(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,a=[];return e.forEach((i=>{const s=ur(i),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let d=i[0],p=i[1];d[0]>p[0]&&(d=i[1],p=i[0]);const u=Math.atan((p[1]-d[1])/(p[0]-d[0]));for(let f=0;f<c;f++){const h=f*(r+o),b=h+r,y=[d[0]+h*Math.cos(u)+l*Math.cos(u),d[1]+h*Math.sin(u)+l*Math.sin(u)],w=[d[0]+b*Math.cos(u)+l*Math.cos(u),d[1]+b*Math.sin(u)+l*Math.sin(u)];a.push(...this.helper.doubleLineOps(y[0],y[1],w[0],w[1],n))}})),a}}class Jp{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,a=Ze(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(a,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((a=>{const i=ur(a),s=Math.round(i/(2*n));let c=a[0],l=a[1];c[0]>l[0]&&(c=a[1],l=a[0]);const d=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let p=0;p<s;p++){const u=2*p*n,f=2*(p+1)*n,h=Math.sqrt(2*Math.pow(n,2)),b=[c[0]+u*Math.cos(d),c[1]+u*Math.sin(d)],y=[c[0]+f*Math.cos(d),c[1]+f*Math.sin(d)],w=[b[0]+h*Math.cos(d+Math.PI/4),b[1]+h*Math.sin(d+Math.PI/4)];o.push(...this.helper.doubleLineOps(b[0],b[1],w[0],w[1],r),...this.helper.doubleLineOps(w[0],w[1],y[0],y[1],r))}})),o}}const it={};class tf{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const ef=0,Pr=1,ma=2,pn={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Rr(t,e){return t.type===e}function Io(t){const e=[],n=(function(i){const s=new Array;for(;i!=="";)if(i.match(/^([ \t\r\n,]+)/))i=i.substr(RegExp.$1.length);else if(i.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:ef,text:RegExp.$1},i=i.substr(RegExp.$1.length);else{if(!i.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:Pr,text:`${parseFloat(RegExp.$1)}`},i=i.substr(RegExp.$1.length)}return s[s.length]={type:ma,text:""},s})(t);let r="BOD",o=0,a=n[o];for(;!Rr(a,ma);){let i=0;const s=[];if(r==="BOD"){if(a.text!=="M"&&a.text!=="m")return Io("M0,0"+t);o++,i=pn[a.text],r=a.text}else Rr(a,Pr)?i=pn[r]:(o++,i=pn[a.text],r=a.text);if(!(o+i<n.length))throw new Error("Path data ended short");for(let c=o;c<o+i;c++){const l=n[c];if(!Rr(l,Pr))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof pn[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=i,a=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function ps(t){let e=0,n=0,r=0,o=0;const a=[];for(const{key:i,data:s}of t)switch(i){case"M":a.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],a.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":a.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],a.push({key:"L",data:[e,n]});break;case"C":a.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":a.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":a.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],a.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":a.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],a.push({key:"H",data:[e]});break;case"V":a.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],a.push({key:"V",data:[n]});break;case"S":a.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":a.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],a.push({key:"T",data:[e,n]});break;case"Z":case"z":a.push({key:"Z",data:[]}),e=r,n=o}return a}function fs(t){const e=[];let n="",r=0,o=0,a=0,i=0,s=0,c=0;for(const{key:l,data:d}of t){switch(l){case"M":e.push({key:"M",data:[...d]}),[r,o]=d,[a,i]=d;break;case"C":e.push({key:"C",data:[...d]}),r=d[4],o=d[5],s=d[2],c=d[3];break;case"L":e.push({key:"L",data:[...d]}),[r,o]=d;break;case"H":r=d[0],e.push({key:"L",data:[r,o]});break;case"V":o=d[0],e.push({key:"L",data:[r,o]});break;case"S":{let p=0,u=0;n==="C"||n==="S"?(p=r+(r-s),u=o+(o-c)):(p=r,u=o),e.push({key:"C",data:[p,u,...d]}),s=d[0],c=d[1],r=d[2],o=d[3];break}case"T":{const[p,u]=d;let f=0,h=0;n==="Q"||n==="T"?(f=r+(r-s),h=o+(o-c)):(f=r,h=o);const b=r+2*(f-r)/3,y=o+2*(h-o)/3,w=p+2*(f-p)/3,x=u+2*(h-u)/3;e.push({key:"C",data:[b,y,w,x,p,u]}),s=f,c=h,r=p,o=u;break}case"Q":{const[p,u,f,h]=d,b=r+2*(p-r)/3,y=o+2*(u-o)/3,w=f+2*(p-f)/3,x=h+2*(u-h)/3;e.push({key:"C",data:[b,y,w,x,f,h]}),s=p,c=u,r=f,o=h;break}case"A":{const p=Math.abs(d[0]),u=Math.abs(d[1]),f=d[2],h=d[3],b=d[4],y=d[5],w=d[6];p===0||u===0?(e.push({key:"C",data:[r,o,y,w,y,w]}),r=y,o=w):(r!==y||o!==w)&&(hs(r,o,y,w,p,u,f,h,b).forEach((function(x){e.push({key:"C",data:x})})),r=y,o=w);break}case"Z":e.push({key:"Z",data:[]}),r=a,o=i}n=l}return e}function Re(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function hs(t,e,n,r,o,a,i,s,c,l){const d=(p=i,Math.PI*p/180);var p;let u=[],f=0,h=0,b=0,y=0;if(l)[f,h,b,y]=l;else{[t,e]=Re(t,e,-d),[n,r]=Re(n,r,-d);const et=(t-n)/2,B=(e-r)/2;let xt=et*et/(o*o)+B*B/(a*a);xt>1&&(xt=Math.sqrt(xt),o*=xt,a*=xt);const ce=o*o,le=a*a,Sc=ce*le-ce*B*B-le*et*et,Ec=ce*B*B+le*et*et,zo=(s===c?-1:1)*Math.sqrt(Math.abs(Sc/Ec));b=zo*o*B/a+(t+n)/2,y=zo*-a*et/o+(e+r)/2,f=Math.asin(parseFloat(((e-y)/a).toFixed(9))),h=Math.asin(parseFloat(((r-y)/a).toFixed(9))),t<b&&(f=Math.PI-f),n<b&&(h=Math.PI-h),f<0&&(f=2*Math.PI+f),h<0&&(h=2*Math.PI+h),c&&f>h&&(f-=2*Math.PI),!c&&h>f&&(h-=2*Math.PI)}let w=h-f;if(Math.abs(w)>120*Math.PI/180){const et=h,B=n,xt=r;h=c&&h>f?f+120*Math.PI/180*1:f+120*Math.PI/180*-1,u=hs(n=b+o*Math.cos(h),r=y+a*Math.sin(h),B,xt,o,a,i,0,c,[h,et,b,y])}w=h-f;const x=Math.cos(f),S=Math.sin(f),_=Math.cos(h),F=Math.sin(h),I=Math.tan(w/4),K=4/3*o*I,tt=4/3*a*I,se=[t,e],lt=[t+K*S,e-tt*x],Tt=[n+K*F,r-tt*_],rn=[n,r];if(lt[0]=2*se[0]-lt[0],lt[1]=2*se[1]-lt[1],l)return[lt,Tt,rn].concat(u);{u=[lt,Tt,rn].concat(u);const et=[];for(let B=0;B<u.length;B+=3){const xt=Re(u[B][0],u[B][1],d),ce=Re(u[B+1][0],u[B+1][1],d),le=Re(u[B+2][0],u[B+2][1],d);et.push([xt[0],xt[1],ce[0],ce[1],le[0],le[1]])}return et}}const nf={randOffset:function(t,e){return E(t,e)},randOffsetWithRange:function(t,e,n){return On(t,e,n)},ellipse:function(t,e,n,r,o){const a=gs(n,r,o);return Kr(t,e,o,a).opset},doubleLineOps:function(t,e,n,r,o){return jt(t,e,n,r,o,!0)}};function ms(t,e,n,r,o){return{type:"path",ops:jt(t,e,n,r,o)}}function yn(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let a=0;a<r-1;a++)o.push(...jt(t[a][0],t[a][1],t[a+1][0],t[a+1][1],n));return e&&o.push(...jt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?ms(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function rf(t,e,n,r,o){return(function(a,i){return yn(a,!0,i)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function ga(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=fn(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:fn(n[0],1.5*(1+.22*e.roughness),ya(e));for(let a=1;a<n.length;a++){const i=n[a];if(i.length){const s=fn(i,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:fn(i,1.5*(1+.22*e.roughness),ya(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function gs(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),a=2*Math.PI/o;let i=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return i+=E(i*c,n),s+=E(s*c,n),{increment:a,rx:i,ry:s}}function Kr(t,e,n,r){const[o,a]=xa(r.increment,t,e,r.rx,r.ry,1,r.increment*On(.1,On(.4,1,n),n),n);let i=Nn(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=xa(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=Nn(s,null,n);i=i.concat(c)}return{estimatedPoints:a,opset:{type:"path",ops:i}}}function ba(t,e,n,r,o,a,i,s,c){const l=t,d=e;let p=Math.abs(n/2),u=Math.abs(r/2);p+=E(.01*p,c),u+=E(.01*u,c);let f=o,h=a;for(;f<0;)f+=2*Math.PI,h+=2*Math.PI;h-f>2*Math.PI&&(f=0,h=2*Math.PI);const b=2*Math.PI/c.curveStepCount,y=Math.min(b/2,(h-f)/2),w=wa(y,l,d,p,u,f,h,1,c);if(!c.disableMultiStroke){const x=wa(y,l,d,p,u,f,h,1.5,c);w.push(...x)}return i&&(s?w.push(...jt(l,d,l+p*Math.cos(f),d+u*Math.sin(f),c),...jt(l,d,l+p*Math.cos(h),d+u*Math.sin(h),c)):w.push({op:"lineTo",data:[l,d]},{op:"lineTo",data:[l+p*Math.cos(f),d+u*Math.sin(f)]})),{type:"path",ops:w}}function va(t,e){const n=fs(ps(Io(t))),r=[];let o=[0,0],a=[0,0];for(const{key:i,data:s}of n)switch(i){case"M":a=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...jt(a[0],a[1],s[0],s[1],e)),a=[s[0],s[1]];break;case"C":{const[c,l,d,p,u,f]=s;r.push(...of(c,l,d,p,u,f,a,e)),a=[u,f];break}case"Z":r.push(...jt(a[0],a[1],o[0],o[1],e)),a=[o[0],o[1]]}return{type:"path",ops:r}}function Or(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,a=r.length;if(a>2){n.push({op:"move",data:[r[0][0]+E(o,e),r[0][1]+E(o,e)]});for(let i=1;i<a;i++)n.push({op:"lineTo",data:[r[i][0]+E(o,e),r[i][1]+E(o,e)]})}}return{type:"fillPath",ops:n}}function pe(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!it[o])switch(o){case"zigzag":it[o]||(it[o]=new Yp(r));break;case"cross-hatch":it[o]||(it[o]=new Kp(r));break;case"dots":it[o]||(it[o]=new Zp(r));break;case"dashed":it[o]||(it[o]=new Qp(r));break;case"zigzag-line":it[o]||(it[o]=new Jp(r));break;default:o="hachure",it[o]||(it[o]=new To(r))}return it[o]})(e,nf).fillPolygons(t,e)}function ya(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function bs(t){return t.randomizer||(t.randomizer=new tf(t.seed||0)),t.randomizer.next()}function On(t,e,n,r=1){return n.roughness*r*(bs(n)*(e-t)+t)}function E(t,e,n=1){return On(-t,t,e,n)}function jt(t,e,n,r,o,a=!1){const i=a?o.disableMultiStrokeFill:o.disableMultiStroke,s=Zr(t,e,n,r,o,!0,!1);if(i)return s;const c=Zr(t,e,n,r,o,!0,!0);return s.concat(c)}function Zr(t,e,n,r,o,a,i){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let d=o.maxRandomnessOffset||0;d*d*100>s&&(d=c/10);const p=d/2,u=.2+.2*bs(o);let f=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;f=E(f,o,l),h=E(h,o,l);const b=[],y=()=>E(p,o,l),w=()=>E(d,o,l),x=o.preserveVertices;return i?b.push({op:"move",data:[t+(x?0:y()),e+(x?0:y())]}):b.push({op:"move",data:[t+(x?0:E(d,o,l)),e+(x?0:E(d,o,l))]}),i?b.push({op:"bcurveTo",data:[f+t+(n-t)*u+y(),h+e+(r-e)*u+y(),f+t+2*(n-t)*u+y(),h+e+2*(r-e)*u+y(),n+(x?0:y()),r+(x?0:y())]}):b.push({op:"bcurveTo",data:[f+t+(n-t)*u+w(),h+e+(r-e)*u+w(),f+t+2*(n-t)*u+w(),h+e+2*(r-e)*u+w(),n+(x?0:w()),r+(x?0:w())]}),b}function fn(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+E(e,n),t[0][1]+E(e,n)]),r.push([t[0][0]+E(e,n),t[0][1]+E(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+E(e,n),t[o][1]+E(e,n)]),o===t.length-1&&r.push([t[o][0]+E(e,n),t[o][1]+E(e,n)]);return Nn(r,null,n)}function Nn(t,e,n){const r=t.length,o=[];if(r>3){const a=[],i=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*t[s+1][0]-i*t[s-1][0])/6,c[1]+(i*t[s+1][1]-i*t[s-1][1])/6],a[2]=[t[s+1][0]+(i*t[s][0]-i*t[s+2][0])/6,t[s+1][1]+(i*t[s][1]-i*t[s+2][1])/6],a[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[a[1][0],a[1][1],a[2][0],a[2][1],a[3][0],a[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...Zr(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function xa(t,e,n,r,o,a,i,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let d=0;d<=2*Math.PI;d+=t){const p=[e+r*Math.cos(d),n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const d=E(.5,s)-Math.PI/2;l.push([E(a,s)+e+.9*r*Math.cos(d-t),E(a,s)+n+.9*o*Math.sin(d-t)]);const p=2*Math.PI+d-.01;for(let u=d;u<p;u+=t){const f=[E(a,s)+e+r*Math.cos(u),E(a,s)+n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([E(a,s)+e+r*Math.cos(d+2*Math.PI+.5*i),E(a,s)+n+o*Math.sin(d+2*Math.PI+.5*i)]),l.push([E(a,s)+e+.98*r*Math.cos(d+i),E(a,s)+n+.98*o*Math.sin(d+i)]),l.push([E(a,s)+e+.9*r*Math.cos(d+.5*i),E(a,s)+n+.9*o*Math.sin(d+.5*i)])}return[l,c]}function wa(t,e,n,r,o,a,i,s,c){const l=a+E(.1,c),d=[];d.push([E(s,c)+e+.9*r*Math.cos(l-t),E(s,c)+n+.9*o*Math.sin(l-t)]);for(let p=l;p<=i;p+=t)d.push([E(s,c)+e+r*Math.cos(p),E(s,c)+n+o*Math.sin(p)]);return d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),Nn(d,null,c)}function of(t,e,n,r,o,a,i,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let d=[0,0];const p=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let f=0;f<p;f++)f===0?c.push({op:"move",data:[i[0],i[1]]}):c.push({op:"move",data:[i[0]+(u?0:E(l[0],s)),i[1]+(u?0:E(l[0],s))]}),d=u?[o,a]:[o+E(l[f],s),a+E(l[f],s)],c.push({op:"bcurveTo",data:[t+E(l[f],s),e+E(l[f],s),n+E(l[f],s),r+E(l[f],s),d[0],d[1]]});return c}function Oe(t){return[...t]}function ka(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(Oe(t[0]),Oe(t[1]),Oe(t[2]),Oe(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const a=[],i=1-e;r.push(Oe(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*o[s+1][0]-i*o[s-1][0])/6,c[1]+(i*o[s+1][1]-i*o[s-1][1])/6],a[2]=[o[s+1][0]+(i*o[s][0]-i*o[s+2][0])/6,o[s+1][1]+(i*o[s][1]-i*o[s+2][1])/6],a[3]=[o[s+1][0],o[s+1][1]],r.push(a[1],a[2],a[3])}}return r}function xn(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function af(t,e,n){const r=xn(e,n);if(r===0)return xn(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),xn(t,Xt(e,n,o))}function Xt(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function Qr(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],d=s[c+1],p=s[c+2],u=s[c+3];let f=3*d[0]-2*l[0]-u[0];f*=f;let h=3*d[1]-2*l[1]-u[1];h*=h;let b=3*p[0]-2*u[0]-l[0];b*=b;let y=3*p[1]-2*u[1]-l[1];return y*=y,f<b&&(f=b),h<y&&(h=y),f+h})(t,e)<n){const s=t[e+0];o.length?(a=o[o.length-1],i=s,Math.sqrt(xn(a,i))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],d=t[e+2],p=t[e+3],u=Xt(c,l,.5),f=Xt(l,d,.5),h=Xt(d,p,.5),b=Xt(u,f,.5),y=Xt(f,h,.5),w=Xt(b,y,.5);Qr([c,u,b,w],0,n,o),Qr([w,y,h,p],0,n,o)}var a,i;return o}function sf(t,e){return Hn(t,0,t.length,e)}function Hn(t,e,n,r,o){const a=o||[],i=t[e],s=t[n-1];let c=0,l=1;for(let d=e+1;d<n-1;++d){const p=af(t[d],i,s);p>c&&(c=p,l=d)}return Math.sqrt(c)>r?(Hn(t,e,l+1,r,a),Hn(t,l,n,r,a)):(a.length||a.push(i),a.push(s)),a}function Nr(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let a=0;a<o;a++)Qr(t,3*a,e,r);return n&&n>0?Hn(r,0,r.length,n):r}const dt="none";class Fn{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,a){const i=this._o(a);return this._d("line",[ms(e,n,r,o,i)],i)}rectangle(e,n,r,o,a){const i=this._o(a),s=[],c=rf(e,n,r,o,i);if(i.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];i.fillStyle==="solid"?s.push(Or([l],i)):s.push(pe([l],i))}return i.stroke!==dt&&s.push(c),this._d("rectangle",s,i)}ellipse(e,n,r,o,a){const i=this._o(a),s=[],c=gs(r,o,i),l=Kr(e,n,i,c);if(i.fill)if(i.fillStyle==="solid"){const d=Kr(e,n,i,c).opset;d.type="fillPath",s.push(d)}else s.push(pe([l.estimatedPoints],i));return i.stroke!==dt&&s.push(l.opset),this._d("ellipse",s,i)}circle(e,n,r,o){const a=this.ellipse(e,n,r,r,o);return a.shape="circle",a}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[yn(e,!1,r)],r)}arc(e,n,r,o,a,i,s=!1,c){const l=this._o(c),d=[],p=ba(e,n,r,o,a,i,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const u=Object.assign({},l);u.disableMultiStroke=!0;const f=ba(e,n,r,o,a,i,!0,!1,u);f.type="fillPath",d.push(f)}else d.push((function(u,f,h,b,y,w,x){const S=u,_=f;let F=Math.abs(h/2),I=Math.abs(b/2);F+=E(.01*F,x),I+=E(.01*I,x);let K=y,tt=w;for(;K<0;)K+=2*Math.PI,tt+=2*Math.PI;tt-K>2*Math.PI&&(K=0,tt=2*Math.PI);const se=(tt-K)/x.curveStepCount,lt=[];for(let Tt=K;Tt<=tt;Tt+=se)lt.push([S+F*Math.cos(Tt),_+I*Math.sin(Tt)]);return lt.push([S+F*Math.cos(tt),_+I*Math.sin(tt)]),lt.push([S,_]),pe([lt],x)})(e,n,r,o,a,i,l));return l.stroke!==dt&&d.push(p),this._d("arc",d,l)}curve(e,n){const r=this._o(n),o=[],a=ga(e,r);if(r.fill&&r.fill!==dt)if(r.fillStyle==="solid"){const i=ga(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(i.ops)})}else{const i=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?i.push(...l):l.length===3?i.push(...Nr(ka([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):i.push(...Nr(ka(l),10,(1+r.roughness)/2))}i.length&&o.push(pe([i],r))}return r.stroke!==dt&&o.push(a),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],a=yn(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(Or([e],r)):o.push(pe([e],r))),r.stroke!==dt&&o.push(a),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const a=r.fill&&r.fill!=="transparent"&&r.fill!==dt,i=r.stroke!==dt,s=!!(r.simplification&&r.simplification<1),c=(function(d,p,u){const f=fs(ps(Io(d))),h=[];let b=[],y=[0,0],w=[];const x=()=>{w.length>=4&&b.push(...Nr(w,p)),w=[]},S=()=>{x(),b.length&&(h.push(b),b=[])};for(const{key:F,data:I}of f)switch(F){case"M":S(),y=[I[0],I[1]],b.push(y);break;case"L":x(),b.push([I[0],I[1]]);break;case"C":if(!w.length){const K=b.length?b[b.length-1]:y;w.push([K[0],K[1]])}w.push([I[0],I[1]]),w.push([I[2],I[3]]),w.push([I[4],I[5]]);break;case"Z":x(),b.push([y[0],y[1]])}if(S(),!u)return h;const _=[];for(const F of h){const I=sf(F,u);I.length&&_.push(I)}return _})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=va(e,r);if(a)if(r.fillStyle==="solid")if(c.length===1){const d=va(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(d.ops)})}else o.push(Or(c,r));else o.push(pe(c,r));return i&&(s?c.forEach((d=>{o.push(yn(d,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const a=typeof n=="number"&&n>=0?o.data.map((i=>+i.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${a[0]} ${a[1]} `;break;case"bcurveTo":r+=`C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;break;case"lineTo":r+=`L${a[0]} ${a[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const a of n){let i=null;switch(a.type){case"path":i={d:this.opsToPath(a),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:dt};break;case"fillPath":i={d:this.opsToPath(a),stroke:dt,strokeWidth:0,fill:r.fill||dt};break;case"fillSketch":i=this.fillSketch(a,r)}i&&o.push(i)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||dt,strokeWidth:r,fill:dt}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class cf{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new Fn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,a=e.options.fixedDecimalPlaceDigits;for(const i of n)switch(i.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,i,a),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,i,a,s),o.restore();break}case"fillSketch":this.fillSketch(o,i,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const a of n.ops){const i=typeof r=="number"&&r>=0?a.data.map((s=>+s.toFixed(r))):a.data;switch(a.op){case"move":e.moveTo(i[0],i[1]);break;case"bcurveTo":e.bezierCurveTo(i[0],i[1],i[2],i[3],i[4],i[5]);break;case"lineTo":e.lineTo(i[0],i[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i),i}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i),i}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i),i}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a),a}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const hn="http://www.w3.org/2000/svg";class lf{constructor(e,n){this.svg=e,this.gen=new Fn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,a=o.createElementNS(hn,"g"),i=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(hn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(hn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&a.appendChild(c)}return a}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const a=e.createElementNS(hn,"path");return a.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),a.setAttribute("stroke",r.fill||""),a.setAttribute("stroke-width",o+""),a.setAttribute("fill","none"),r.fillLineDash&&a.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&a.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),a}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i)}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i)}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i)}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var df={canvas:(t,e)=>new cf(t,e),svg:(t,e)=>new lf(t,e),generator:t=>new Fn(t),newSeed:()=>Fn.newSeed()};const Sa="data-wp-animations";function uf(){if(document.head.querySelector(`[${Sa}]`))return;const t=document.createElement("style");t.setAttribute(Sa,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function Ue(t,e,n){if(!e||e.kind==="none"||st()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const a=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",a),t.removeEventListener("animationcancel",a)};t.addEventListener("animationend",a),t.addEventListener("animationcancel",a)}const qn="http://www.w3.org/2000/svg",vs="data-annotation-text",Ea="data-annotation-arrow",ys="data-annotation-shape",Aa="data-annotation-freedraw",D={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function pf(t,e){const{svg:n,roughSvg:r}=D;if(!n||!r)return;const o=hf(t.id),{from:a,to:i}=fd(t,e);xs(t,s=>r.line(a.x,a.y,i.x,i.y,{roughness:1.5,bowing:1,seed:o,...s})),ff(t,a,i,o+1)}function ff(t,e,n,r){const{roughSvg:o}=D;if(!o)return;const a=Math.atan2(n.y-e.y,n.x-e.x),i=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-i*Math.cos(a-s),l=n.y-i*Math.sin(a-s),d=n.x-i*Math.cos(a+s),p=n.y-i*Math.sin(a+s),u=`M ${c} ${l} L ${n.x} ${n.y} L ${d} ${p}`;xs(t,f=>o.path(u,{roughness:1.5,bowing:1,seed:r,...f}))}function xs(t,e){const{svg:n}=D;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(Ea,t.id),Ue(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(Ea,t.id),Ue(o,t.entryAnimation,0),n.appendChild(o)}function hf(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const k={state:null,unsubscribeStep:null};function Y(){return k.state!==null}function pr(){var t;return((t=k.state)==null?void 0:t.standalone)===!0}function mf(t,e){const{svg:n}=D;if(!n)return;const r=rr(t,e),o=gf(t,r),a=r.map(c=>`${c.x},${c.y}`).join(" "),i=document.createElementNS(qn,"polyline");if(i.setAttribute("points",a),i.setAttribute("fill","none"),i.setAttribute("stroke",t.stroke),i.setAttribute("stroke-width",String(t.strokeWidth)),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute(Aa,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&i.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&i.setAttribute("transform",o),i.style.pointerEvents="none",Ue(i,t.entryAnimation,t.rotate??0),n.appendChild(i),pr())return;const s=document.createElementNS(qn,"polyline");s.setAttribute(Aa,t.id),s.setAttribute("points",a),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),bf(t.id,c,s))}),n.appendChild(s)}function gf(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,a=-1/0,i=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>a&&(a=l.x),l.y>i&&(i=l.y);const s=(r+a)/2,c=(o+i)/2;return`rotate(${n} ${s} ${c})`}function bf(t,e,n){const r=R(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},a=ct(),i=rr(r,a).map(d=>({...d}));let s=!1;const c=d=>{const p=d.clientX-o.x,u=d.clientY-o.y;if(!s&&Math.hypot(p,u)<3)return;s=!0,d.preventDefault();const f=i.map(b=>({x:b.x+p,y:b.y+u})),h=a?{points:f,pointsAnchorOffset:f.map(b=>({x:b.x-a.left,y:b.y-a.top}))}:{points:f,pointsAnchorOffset:void 0};O(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const d=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),p=d[d.length-1]??n;Su(t,p)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function vf(t,e){const{svg:n}=D;if(!n)return;const r=nr(t,e),o=Ao(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(ys,t.id),o.style.pointerEvents="none",Ue(o,t.entryAnimation,t.rotate??0),n.appendChild(o),pr()||n.appendChild(yf(t,r)))}function yf(t,e){const n=document.createElementNS(qn,"rect");if(n.setAttribute(ys,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>xf(t.id,r,n)),n}function xf(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=R(t);if(!o||o.kind!=="shape")return;const a=ct(),i=o.boundsAnchorOffset&&a?{x:a.left+o.boundsAnchorOffset.x,y:a.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:i.x,y:i.y};let c=!1;const l=p=>{const u=p.clientX-r.x,f=p.clientY-r.y;if(!c&&Math.hypot(u,f)<3)return;c=!0,p.preventDefault();const h=s.x+u,b=s.y+f,y=a?{bounds:{...s,x:h,y:b},boundsAnchorOffset:{x:h-a.left,y:b-a.top}}:{bounds:{...s,x:h,y:b},boundsAnchorOffset:void 0};O(t,y)},d=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const p=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=p[p.length-1]??n;ku(t,u)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)}function wf(t,e){const{host:n}=D;if(!n)return;const r=document.createElement("div");r.setAttribute(vs,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,a=t.style.backgroundColor??"#ffffff",i=t.style.backgroundOpacity??.96,s=a==="transparent"?"transparent":kf(a,i),c=t.rotate??0,l=t.style.borderColor??"#000000",d=l==="transparent"?"none":`2px solid ${l}`,p=pd(t,e),u=pr();r.style.cssText=["position: absolute",`left: ${p.x}px`,`top: ${p.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${d}`,"border-radius: 8px",u?"pointer-events: none":"pointer-events: auto",u?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,u||Sf(r,t.id),Ue(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function kf(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,a=0,i=0;return r.length===4?(o=parseInt(r[1]+r[1],16),a=parseInt(r[2]+r[2],16),i=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),a=parseInt(r.slice(3,5),16),i=parseInt(r.slice(5,7),16)),`rgba(${o}, ${a}, ${i}, ${n})`}return t}function Sf(t,e){let n=!1,r=0,o=0,a=0,i=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();a=l.left,i=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,d=c.clientY-o;Math.abs(l)+Math.abs(d)>2&&(s=!0),t.style.left=`${a+l}px`,t.style.top=`${i+d}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),d=ct(),p=d?{position:{x:c,y:l},anchorOffset:{x:c-d.left,y:l-d.top}}:{position:{x:c,y:l},anchorOffset:void 0};O(e,p)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),wu(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Ef(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",O(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Ef(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function ws(){if(D.host)return;uf();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${j+3}`].join("; ");const e=document.createElementNS(qn,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),D.host=t,D.svg=e,D.roughSvg=df.svg(e),document.body.appendChild(t),D.unsubscribe=De(wn),D.unsubscribeMode=$t(wn),Af(),wn()}let ye=null;function qe(){ye===null&&(ye=requestAnimationFrame(()=>{ye=null,wn()}))}let Zt=null,Jr=null;function Af(){window.addEventListener("resize",qe),window.addEventListener("scroll",qe,!0),typeof ResizeObserver<"u"&&(Zt=new ResizeObserver(qe))}function Mf(){window.removeEventListener("resize",qe),window.removeEventListener("scroll",qe,!0),Zt&&(Zt.disconnect(),Zt=null),Jr=null,ye!==null&&(cancelAnimationFrame(ye),ye=null)}function ks(){var t,e;(t=D.unsubscribe)==null||t.call(D),D.unsubscribe=null,(e=D.unsubscribeMode)==null||e.call(D),D.unsubscribeMode=null,Mf(),D.host&&(D.host.remove(),D.host=null,D.svg=null,D.roughSvg=null)}function $f(){return D.host!==null}function wn(){const{host:t,svg:e}=D;if(!t||!e)return;for(t.querySelectorAll(`[${vs}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=ct();if(Zt){let o=null;try{o=Lf()}catch{o=null}o!==Jr&&(Zt.disconnect(),o&&Zt.observe(o),Jr=o)}const r=ui();for(const o of r)o.kind==="text"?wf(o,n):o.kind==="arrow"?pf(o,n):o.kind==="shape"?vf(o,n):o.kind==="freedraw"&&mf(o,n)}function Lf(){const t=ut();if(!(t!=null&&t.selectors))return null;try{return Ae(t.selectors)}catch{return null}}const A={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function me(t,e,n){return Math.max(e,Math.min(n,t))}function Ss(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=Df()),Tf()}function Tf(){const{host:t}=A;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),a=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${me(o,0,n)}px`),Number.isFinite(a)&&(t.style.top=`${me(a,0,r)}px`)}async function If(){try{return(await chrome.storage.local.get(z.replayControlsOrientation))[z.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Cf(t){try{await chrome.storage.local.set({[z.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function Df(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function Pf(){try{const e=(await chrome.storage.local.get(z.replayControlsPosition))[z.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function Ma(t){try{await chrome.storage.local.set({[z.replayControlsPosition]:t})}catch{}}function Rf(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function Of(){const{host:t,shadow:e}=A;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,a=0,i=0,s=0;const c=u=>{if(!A.host)return;u.preventDefault(),u.stopPropagation(),r=!0,n.classList.add("dragging");const f=A.host.getBoundingClientRect();A.host.style.left=`${f.left}px`,A.host.style.top=`${f.top}px`,A.host.style.bottom="auto",A.host.style.transform="none",o=u.clientX,a=u.clientY,i=f.left,s=f.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)},l=u=>{if(!r||!A.host)return;const f=A.host.getBoundingClientRect(),h=u.clientX-o,b=u.clientY-a,y=me(i+h,0,window.innerWidth-f.width),w=me(s+b,0,window.innerHeight-f.height);A.host.style.left=`${y}px`,A.host.style.top=`${w}px`},d=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const u=A.host;if(u){const f=parseFloat(u.style.left||"0"),h=parseFloat(u.style.top||"0");Number.isFinite(f)&&Number.isFinite(h)&&Ma({left:f,top:h})}},p=()=>{if(A.host&&A.host.style.transform==="none"){const u=A.host.getBoundingClientRect(),f=me(u.left,0,window.innerWidth-u.width),h=me(u.top,0,window.innerHeight-u.height);A.host.style.left=`${f}px`,A.host.style.top=`${h}px`,Ma({left:f,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",p),A.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",p),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0)}}function Es(){return`
    ${Rt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function As(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Nf(t){return As(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Hf(t,e){const{shadow:n}=A;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,a)=>{const i=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${a===e?" active":""}" role="option" data-action="step-jump" data-index="${a}" aria-selected="${a===e}" title="${Nf(i)}">${a+1}. ${As(i)}</li>`}).join(""))}function Ff(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function to(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function Ms(t){const{host:e,shadow:n}=A;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||to()}let kn=-1,Sn=!1;function qf(){kn=-1,Sn=!1}function zf(t,e,n,r=0){const{shadow:o}=A;if(!o)return;const a=o.querySelector('[data-region="progress"]');if(!a)return;if(e===null||e<=0){a.classList.add("hidden"),a.innerHTML="",kn=-1,Sn=!1;return}a.classList.remove("hidden");const c=t!==kn||Sn&&!n;kn=t,Sn=n;let l=a.querySelector(".progress-fill");if(!l||c){l==null||l.remove(),l=document.createElement("div"),l.className="progress-fill",l.style.animationDuration=`${e}ms`;const d=Math.max(0,Math.min(r,e-1));d>0&&(l.style.animationDelay=`-${d}ms`),a.appendChild(l)}l.classList.toggle("paused",n)}function _f(){return`
    ${Rt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid color-mix(in oklch, currentColor, transparent 40%);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: color-mix(in oklch, currentColor, transparent 92%); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: color-mix(in oklch, currentColor, transparent 85%); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: color-mix(in oklch, currentColor, transparent 80%);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: color-mix(in oklch, currentColor, transparent 82%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: color-mix(in oklch, currentColor, transparent 45%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: color-mix(in oklch, currentColor, transparent 25%);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: color-mix(in oklch, currentColor, transparent 92%); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function Bf(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function Uf(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function jf(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?Bf(14):Uf(14))}let $s=!1;function Wf(t){if(A.host)return;const{host:e,shadow:n}=yt();A.host=e,A.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${j+6}`,"pointer-events: auto",$s?"display: none":""].filter(Boolean).join("; "),n.innerHTML=`<style>${_f()}</style>${Gf()}`,n.addEventListener("click",r=>Xf(r,t)),document.body.appendChild(e),Of(),document.addEventListener("mousedown",Ms,!0),A.orientationApplied=!1,If().then(r=>{A.orientationApplied||(A.orientationApplied=!0,Ss(r))}),Pf().then(r=>{A.host&&r&&A.host.style.transform!=="none"&&Rf(A.host,r)})}function Gf(){return`
    <div class="bar" role="toolbar" aria-label="${v("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${v("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${v("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${v("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${v("replay.prompter-aria")}" title="${v("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${v("replay.tts-aria")}" title="${v("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${v("replay.move-aria")}" title="${v("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${v("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${v("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Xf(t,e){var a;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){Ff();return}const r=n.closest('[data-action="step-jump"]');if(r){const i=Number(r.getAttribute("data-index"));Number.isFinite(i)&&(to(),e.onStepSelect(i));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(a=n.closest("[data-action]"))==null?void 0:a.getAttribute("data-action");switch(o&&to(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Vf();break}}function Vf(){const{shadow:t}=A;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";A.orientationApplied=!0,Ss(n),Cf(n)}function Yf(t){$s=t;const{host:e}=A;e&&(e.dataset.recordingHidden=t?"1":"",e.style.display=t?"none":"")}function Kf(){var t,e;(t=A.cleanupDrag)==null||t.call(A),A.cleanupDrag=null,document.removeEventListener("mousedown",Ms,!0),(e=A.host)==null||e.remove(),A.host=null,A.shadow=null,A.orientationApplied=!1,qf()}function $a(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const a=e.querySelector('[data-action="prev"]');a&&a.toggleAttribute("disabled",t.currentIndex<=0);const i=e.querySelector('[data-action="next"]');i&&(i.toggleAttribute("disabled",!1),i.setAttribute("aria-label",t.currentIndex>=t.total-1?v("replay.finish-aria"):v("replay.next-aria"))),zf(t.currentIndex,t.timerDurationMs??null,t.paused,t.timerElapsedMs??0),Hf(t.steps??[],t.currentIndex),jf(t.ttsEnabled===!0)}let qt=null;function Zf(t){Qe();const{host:e,shadow:n}=yt();qt=e,qt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${j+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${Es()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${v("replay.notfound.title")}</h2>
          <p>${v("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${v("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${v("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const a=o.target;if(!(a instanceof HTMLElement))return;const i=(s=a.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");i==="skip"?t.onSkip():i==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),qt.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(qt)}function Qe(){if(!qt)return;const t=qt.__cleanup;t==null||t(),qt.remove(),qt=null}let zt=null;function Qf(t){zn();const{host:e,shadow:n}=yt();zt=e,zt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${j+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${Es()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${v("replay.url-mismatch.title")}</h2>
          <p>${v("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${v("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${v("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${v("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",a=>{var c;const i=a.target;if(!(i instanceof HTMLElement))return;const s=(c=i.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=a=>{a.key==="Escape"?(a.preventDefault(),t.onCancel()):a.key==="Enter"&&(a.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),zt.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(zt)}function zn(){if(!zt)return;const t=zt.__cleanup;t==null||t(),zt.remove(),zt=null}let Kt=null;function Ls(t){Je();const e=t.getBoundingClientRect(),n=Jf(t),r=e.left+n.x,o=e.top+n.y,a=e.bottom+n.y,i=36,s=8,c=o-s-i<8,l=c?Math.min(window.innerHeight-8-i,a+s):Math.max(8,o-s-i),d=Math.max(8,Math.min(r,window.innerWidth-200)),p=c?"up":"down",{host:u,shadow:f}=yt();Kt=u,Kt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${d}px`,`z-index: ${j+6}`,"pointer-events: none"].join("; "),f.innerHTML=`
    <style>
      ${Rt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${v("prompter.action-step")}</span>
      <span>${v("replay.action-prompt")}</span>
      <span class="tip ${p}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Kt)}function Je(){Kt==null||Kt.remove(),Kt=null}function Jf(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let xe=null;function th(t){xe||(xe=e=>{if(k.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",xe,!0))}function eh(){xe&&(document.removeEventListener("keydown",xe,!0),xe=null)}function fr(t,e,n=!1){try{const r=new URL(t),o=new URL(e);return r.origin!==o.origin||r.pathname!==o.pathname?!1:n?r.search===o.search&&r.hash===o.hash:!0}catch{return!1}}function Ts(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function nh(t,e){var r,o,a;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||fr(n,location.href,!!t.strictUrlMatch)||((o=k.state)==null?void 0:o.standalone)===!0)return!1;try{await so({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((a=k.state)==null?void 0:a.paused)??!1})}catch(i){console.warn("[manuscript] persist activeReplay before nav failed",i)}return location.href=n,!0}function rh(t){return new Promise(e=>{Qf({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{zn(),e("force")},onCancel:()=>{zn(),e("cancel")}})})}async function oh(t){try{const e=await Ka();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Co(){const t=L();if(!(!t||!k.state)&&k.state.standalone!==!0)try{await so({scenarioId:t.id,stepIndex:H(),startedAt:Date.now(),paused:k.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function Is(t,e,n){const r=L();if(!r)return{ok:!1};if(n&&await oh(r.id))return{ok:!0};const o=Ts(r);if(!o||fr(o,location.href,!!r.strictUrlMatch))return{ok:!0};const a=await rh(o);return a==="cancel"?{ok:!1}:a==="navigate"?(await so({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class Cs extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function Ds(t,e=Xa){return eo(t,e).then(n=>n.el)}function eo(t,e=Xa){const n=Wr(t);return n?Promise.resolve(n):new Promise((r,o)=>{let a=!1;const s=(vi(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(a)return;const d=Wr(t);d&&(a=!0,c.disconnect(),clearTimeout(l),r(d))}),l=setTimeout(()=>{a||(a=!0,c.disconnect(),o(new Cs(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function ah(t,e){if(!e){t.hidden=!0,t.innerHTML="";return}t.hidden=!1,t.innerHTML=ih(e)}function ih(t){const e=t.kind==="github"?"📡":"🔗",n=sh(t),r=v("panel.ephemeral.warning")||"Edits are temporary",o=v("panel.ephemeral.import")||"Save to local";return`
    <div class="ephemeral-row ephemeral-row-source">
      <span class="ephemeral-icon" aria-hidden="true">${e}</span>
      <span class="ephemeral-label">${mn(n)}</span>
    </div>
    <div class="ephemeral-row ephemeral-row-action">
      <span class="ephemeral-warn">${mn(r)}</span>
      <button
        type="button"
        class="ephemeral-import"
        data-action="ephemeral-import"
        aria-label="${mn(o)}"
      >${mn(o)}</button>
    </div>
  `}function sh(t){if(t.kind==="github")return`${t.repo} · ${t.path}`;if(!t.origin)return v("panel.ephemeral.bridge-fallback")||"External page";try{return new URL(t.origin).host||t.origin}catch{return t.origin}}function mn(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}const hr="manuscript:selector-health-changed",_n=new Map,Bn=new Map;function Ps(t,e){return`${t}::${e}`}function mr(t){return t===void 0?"none":t===null?"red":t===1?"green":t===2?"yellow":"orange"}function gr(t,e){return e?Bn.get(Ps(t,e)):_n.get(t)}function ch(t,e){return t===void 0?!0:t!==e}function Yt(t){const e=gr(t.stepId,t.subId);ch(e,t.layer)&&(t.subId?Bn.set(Ps(t.stepId,t.subId),t.layer):_n.set(t.stepId,t.layer),typeof document<"u"&&document.dispatchEvent(new CustomEvent(hr,{detail:{stepId:t.stepId,subId:t.subId??null,layer:t.layer}})))}function lh(){_n.size===0&&Bn.size===0||(_n.clear(),Bn.clear(),typeof document<"u"&&document.dispatchEvent(new CustomEvent(hr,{detail:{stepId:"",subId:null,layer:null,cleared:!0}})))}const dh=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],It=28,gn=4,uh="http://www.w3.org/2000/svg";let rt=null,re=null,ze=null;function ph(t,e){br(),ze=e,{host:rt,shadow:re}=yt(),rt.style.cssText=["position: fixed",`z-index: ${j+5}`,"pointer-events: auto"].join("; "),re.innerHTML=fh(),mh(),document.body.appendChild(rt),La(t),hh(),requestAnimationFrame(()=>{rt&&La(t)}),document.addEventListener("mousedown",Rs,!0),document.addEventListener("keydown",Os,!0)}function br(){rt&&(document.removeEventListener("mousedown",Rs,!0),document.removeEventListener("keydown",Os,!0),rt.remove(),rt=null,re=null,ze=null)}function fh(){return`
    <style>
      ${Rt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${It+gn*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${It+gn*2}px;
        height: ${It+gn*2}px;
        padding: ${gn}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function hh(){if(!re)return;const t=re.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of dh){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(uh,"svg");o.setAttribute("width",String(It)),o.setAttribute("height",String(It)),o.setAttribute("viewBox",`0 0 ${It} ${It}`);const a=Ao(e,{x:3,y:3,width:It-6,height:It-6,fill:"transparent",stroke:"currentColor",strokeWidth:1.5});a&&o.appendChild(a),r.appendChild(o),t.appendChild(r)}}}function mh(){re&&re.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(ze==null||ze(r),br())})}function La(t){if(!rt)return;const e=t.getBoundingClientRect();rt.style.top="0px",rt.style.left="0px";const n=rt.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),rt.style.top=`${Math.max(8,r)}px`,rt.style.left=`${Math.max(8,o)}px`}function Rs(t){if(!rt)return;const e=t.target;e instanceof Node&&rt.contains(e)||br()}function Os(t){t.key==="Escape"&&(t.preventDefault(),br())}const Ie={stepId:null,selectedIds:[],anchorId:null,primarySelected:!1};function Ns(t,e,n){return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1}}function gh(t,e,n){if(t.stepId!==e)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=t.selectedIds.includes(n)?t.selectedIds.filter(a=>a!==n):[...t.selectedIds,n];return{stepId:e,selectedIds:o,anchorId:n,primarySelected:!1}}function bh(t,e,n,r){if(t.stepId!==e||!t.anchorId)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=r.indexOf(t.anchorId),a=r.indexOf(n);if(o<0||a<0)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const i=Math.min(o,a),s=Math.max(o,a);return{stepId:e,selectedIds:r.slice(i,s+1),anchorId:t.anchorId,primarySelected:!1}}function vh(t,e){return{stepId:e,selectedIds:[],anchorId:null,primarySelected:!0}}function vr(t,e){return t.stepId===e?t.selectedIds:[]}function Hs(t,e){return t.stepId===e&&t.primarySelected}const yh=320,we=32,xh=.8,Un=200,m={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null,pickerTarget:{type:"primary"},subSelection:Ie,subDragSet:null,subDragStepId:null,expandedAnnotationSteps:new Set,collapsedSubSteps:new Set};function at(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function M(t){return at(t)}function oe(t,e=!1,n=5e3){const{shadow:r}=m;if(!r)return;const o=r.querySelector('[data-region="toast"]');o&&(o.textContent=t,o.classList.add("visible"),o.classList.toggle("error",e),m.toastTimer!==null&&window.clearTimeout(m.toastTimer),m.toastTimer=window.setTimeout(()=>{o.classList.remove("visible"),m.toastTimer=null},n))}function jn(t,e,n){return Math.max(e,Math.min(n,t))}function wh(){const t=L();if(t)try{const e=Ic(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Sh(t.name)}-${Eh(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),oe(v("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),oe(v("toast.export-failed"),!0)}}async function kh(){const t=L();if(t){if(t.steps.length===0){oe(v("toast.no-steps"),!0);return}Pi(),await Pe(0,{paused:!0})}}function Sh(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Eh(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function yr(t){const e=L(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!tn(n.pickedAtUrl,location.href,!!(e!=null&&e.strictUrlMatch))?(Do(n.pickedAtUrl,t),!0):!1}function Mt(){const t=L();if(!t)return;const e=H(),n=t.steps[e],r=t.steps[e+1];ss({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?Rn(n):null,next:r?Rn(r):null})}function tn(t,e,n=!1){try{const r=new URL(t),o=new URL(e);return r.origin!==o.origin||r.pathname!==o.pathname?!1:n?r.search===o.search&&r.hash===o.hash:!0}catch{return!1}}async function Do(t,e){const n=L();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let Wn=!1,Fs=0,qs=0,no=0,ro=0;function Ah(){const{shadow:t}=m;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=m;if(!o)return;Wn=!0,Fs=n.clientX,qs=n.clientY;const a=o.getBoundingClientRect();no=a.left,ro=a.top,o.style.left=`${no}px`,o.style.top=`${ro}px`,o.style.right="auto",document.addEventListener("mousemove",zs,!0),document.addEventListener("mouseup",_s,!0),n.preventDefault()})}function zs(t){const{host:e}=m;if(!Wn||!e)return;const n=t.clientX-Fs,r=t.clientY-qs,o=e.offsetWidth,a=e.offsetHeight,i=jn(no+n,0,window.innerWidth-o),s=jn(ro+r,0,window.innerHeight-a);e.style.left=`${i}px`,e.style.top=`${s}px`}function _s(){Wn&&(Wn=!1,document.removeEventListener("mousemove",zs,!0),document.removeEventListener("mouseup",_s,!0))}let Gn=!1,Bs=0,Us=0;function Mh(){const{shadow:t}=m;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=m;r&&(Gn=!0,Bs=n.clientY,Us=r.getBoundingClientRect().height,document.addEventListener("mousemove",js,!0),document.addEventListener("mouseup",Ws,!0),n.preventDefault(),n.stopPropagation())})}function js(t){const{host:e}=m;if(!Gn||!e)return;const n=t.clientY-Bs,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-we,a=jn(Us+n,Un,o);e.style.height=`${a}px`,e.style.maxHeight=`${a}px`}function Ws(){Gn&&(Gn=!1,document.removeEventListener("mousemove",js,!0),document.removeEventListener("mouseup",Ws,!0))}function $h(t){const e=window.innerHeight-we*2;return jn(t,Un,Math.max(Un,e))}function Gs(){const{host:t}=m;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-we;if(e.bottom>n){const o=Math.max(Un,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),a=window.innerWidth-r.width;o>a&&(t.style.left=`${Math.max(0,a)}px`)}if(t.style.top){const o=parseFloat(t.style.top),a=window.innerHeight-r.height;o>a&&(t.style.top=`${Math.max(0,a)}px`)}}function Po(){var t;return((t=m.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function Xs(){var t;return((t=m.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function Vs(){var t;return((t=m.shadow)==null?void 0:t.querySelector('[data-region="strict-url-toggle"]'))??null}function Lh(){const t=Po();t&&(t.hidden?(Ih(),Th(),t.hidden=!1):t.hidden=!0)}function Th(){var e;const t=Vs();t&&(t.checked=!!((e=L())!=null&&e.strictUrlMatch))}function Ys(){const t=Po();t&&(t.hidden=!0)}async function Ih(){const t=Xs();if(!t)return;await Nc();const e=Hc(),n=await Fc(),r=a=>a.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const a of e){const i=a.name===n?" selected":"";o.push(`<option value="${r(a.name)}"${i}>${r(a.name)} (${r(a.lang)})</option>`)}t.innerHTML=o.join("")}function Ch(){var r;const t=Xs();t&&t.addEventListener("change",()=>{const o=t.value;Oc(o.length>0?o:null)});const e=Vs();e&&e.addEventListener("change",()=>Ml(e.checked));const n=(r=m.shadow)==null?void 0:r.querySelector('[data-region="settings-close"]');n==null||n.addEventListener("click",()=>Ys())}function Ks(t){var o;const e=Po();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=m.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Ys()}const Dh=.125;function en(t,e={}){const{behavior:n}=e,r=window.innerHeight,o=t.getBoundingClientRect(),a=window.scrollY+o.top;let i;o.height>r?i=a-r*Dh:i=a-(r-o.height)/2,i=Math.max(0,Math.round(i)),window.scrollTo(n?{top:i,behavior:n}:{top:i})}let He=null;function Zs(t){He=t}function ht(t){const e=t===H();Lt(t),e&&Ro()}function Ro(){var r;const t=ut();if(!(t!=null&&t.selectors)){He=null,Le();return}let e=null;const n=m.subSelection;if(n.stepId===t.id&&n.anchorId){const o=(r=t.subElements)==null?void 0:r.find(a=>a.id===n.anchorId);o&&(e=Ae(o.selectors))}if(e||(e=Ae(t.selectors)),!e){He=null,Le();return}e!==He&&en(e,{behavior:"smooth"}),He=e,$o(e)}function Ta(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function Oo(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function Qs(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function Ph(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function Rh(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function Oh(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function Nh(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function Hh(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=L(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));ht(l)}const a=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${a}" aria-label="Auto-advance seconds" />
    ${Oo(10)}
  `;const i=t.querySelector("input");if(!i)return;i.focus(),i.select();const s=l=>{if(t.classList.remove("editing"),l){Ia(t,a);return}const d=i.value.trim();let p=5;if(d===""||d==="0")Pt(r.id,{autoAdvanceMs:null});else{const u=Number(d);Number.isFinite(u)&&u>0?(Pt(r.id,{autoAdvanceMs:Math.round(u*1e3)}),p=u):Pt(r.id,{autoAdvanceMs:null})}Ia(t,p)};i.addEventListener("blur",()=>s(!1)),i.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),i.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),i.addEventListener("mousedown",l=>l.stopPropagation())}function Ia(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${Oo(10)}
  `}function Fh(t){const e=[],n=new Map;for(const r of t.steps){const o=r.pickedAtUrl&&r.pickedAtUrl.length>0?r.pickedAtUrl:t.url,a=qh(o);let i=n.get(a);i||(i={url:o??"",stepIds:[]},n.set(a,i),e.push(i)),i.stepIds.push(r.id)}return e}function qh(t){if(!t)return"";try{const e=new URL(t);return`${e.origin}${e.pathname}`}catch{return t}}function zh(t,e){return{scenarioId:t.id,startedAt:Date.now(),returnTo:e,groups:Fh(t),currentGroupIdx:0,stepResults:{},subResults:{}}}function Ca(t){return t===1?"green":t===2?"yellow":t===3?"orange":"red"}const Da=2e3;async function _h(t,e,n){const r=e.groups[e.currentGroupIdx];r&&(await Promise.allSettled(r.stepIds.map(async o=>{const a=t.steps.find(i=>i.id===o);if(a){if(!a.selectors)e.stepResults[o]="no-element",Yt({stepId:o,layer:null}),n==null||n();else{try{const i=await eo(a.selectors,Da);e.stepResults[o]=Ca(i.layer),Yt({stepId:o,layer:i.layer})}catch{e.stepResults[o]="red",Yt({stepId:o,layer:null})}n==null||n()}await Promise.allSettled((a.subElements??[]).map(async i=>{try{const s=await eo(i.selectors,Da);e.subResults[`${o}::${i.id}`]=Ca(s.layer),Yt({stepId:o,subId:i.id,layer:s.layer})}catch{e.subResults[`${o}::${i.id}`]="red",Yt({stepId:o,subId:i.id,layer:null})}n==null||n()}))}})),e.currentGroupIdx+=1)}function Js(t){return t.currentGroupIdx>=t.groups.length}function Bh(t){const e=t.groups[t.currentGroupIdx];return e?e.url:null}async function Uh(t){await Dc(t)}async function Dt(){await Cc()}function tc(t){for(const[e,n]of Object.entries(t.stepResults))Yt({stepId:e,layer:Pa(n)});for(const[e,n]of Object.entries(t.subResults)){const r=e.indexOf("::");if(r<0)continue;const o=e.slice(0,r),a=e.slice(r+2);Yt({stepId:o,subId:a,layer:Pa(n)})}}function Pa(t){return t==="green"?1:t==="yellow"?2:t==="orange"?3:null}function jh(t){return`
    <style>${Rt()}${Zh()}</style>
    ${Wh(t)}
  `}function Wh(t){var i;const{scenario:e,session:n,phase:r}=t,o=Kh(e,n),a=typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.getURL)?chrome.runtime.getURL("icons/manuscript.svg"):"";return`
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="vm-title">
      <div class="head">
        <div class="brand-row">
          <div class="brand">
            ${a?`<img class="brand-mark" src="${M(a)}" alt="" aria-hidden="true">`:""}
            <span class="brand-wordmark">Manuscript</span>
          </div>
          <div class="head-actions">
            ${Xh(r)}
            <button type="button" class="close-x" data-action="close" aria-label="${M(v("validate.close"))}" title="${M(v("validate.close"))}">×</button>
          </div>
        </div>
        <div class="title-row">
          <h2 id="vm-title">${at(v("validate.modal-title"))}</h2>
          <div class="summary">${Gh(o)}</div>
        </div>
      </div>
      ${Vh(t)}
      <ul class="rows">${e.steps.map((s,c)=>Yh(s,c,n)).join("")}</ul>
    </div>
  `}function Gh(t){const e=(n,r,o)=>`<span class="sum-item"><span class="sum-dot" data-status="${n}"></span>${at(v(r))} ${o}</span>`;return[e("green","validate.label-ok",t.ok),e("yellow","validate.label-fallback",t.fallback),e("red","validate.label-broken",t.broken),e("pending","validate.label-pending",t.pending)].join('<span class="sum-sep">·</span>')}function Xh(t){return t==="initial"?`<button class="primary" data-action="start">${at(v("validate.start"))}</button>`:t==="complete"?`<span class="pill complete">${at(v("validate.complete"))}</span>`:`<span class="pill">${at(v("validate.in-progress"))}</span>`}function Vh(t){var e;if(t.phase==="navigating")return`<div class="banner">${at(v("validate.navigating-to",{url:t.navigatingTo??""}))}</div>`;if(t.phase==="validating"){const n=(e=t.session.groups[t.session.currentGroupIdx])==null?void 0:e.url;return`<div class="banner">${at(v("validate.checking",{url:n??""}))}</div>`}return""}function Yh(t,e,n){const r=n.stepResults[t.id],o=r??"pending",a=t.thumbnailDataUrl?` style="background-image: url('${M(t.thumbnailDataUrl)}')"`:"",i=Ra(r,t.selectors===null),s=(t.subElements??[]).map(c=>`<span class="sub-dot" data-status="${n.subResults[`${t.id}::${c.id}`]??"pending"}" title="${M(Ra(n.subResults[`${t.id}::${c.id}`],!1))}"></span>`).join("");return`
    <li class="row" data-status="${o}">
      <div class="thumb"${a}><span class="row-idx">${e+1}</span></div>
      <div class="meta">
        <div class="name">${at(t.name)||'<span class="muted">(unnamed)</span>'}</div>
        <div class="status-line">
          <span class="dot" data-status="${o}"></span>
          <span class="status-text">${at(i)}</span>
          ${s?`<span class="sub-dots">${s}</span>`:""}
        </div>
      </div>
      <div class="actions">
        <button class="action-btn" data-action="go-step" data-step-id="${M(t.id)}">${at(v("validate.row-go"))}</button>
        ${r==="red"||r==="orange"?`<button class="action-btn primary" data-action="repick" data-step-id="${M(t.id)}">${at(v("validate.row-repick"))}</button>`:""}
      </div>
    </li>
  `}function Ra(t,e){return e?v("validate.status-no-element"):t===void 0?v("validate.status-pending"):t==="green"?v("validate.status-green"):t==="yellow"?v("validate.status-yellow"):t==="orange"?v("validate.status-orange"):t==="red"?v("validate.status-red"):t==="no-element"?v("validate.status-no-element"):""}function Kh(t,e){let n=0,r=0,o=0,a=0;for(const i of t.steps){const s=e.stepResults[i.id];s==="green"?n++:s==="yellow"||s==="orange"?r++:s==="red"?o++:a++}return{ok:n,fallback:r,broken:o,pending:a}}function Zh(){return`
    :host { font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }
    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px;
      width: min(580px, calc(100vw - 32px));
      max-height: calc(100vh - 64px);
      display: flex;
      flex-direction: column;
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-primary);
    }
    .head {
      margin-bottom: 12px;
    }
    .brand-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 10px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--c-text);
    }
    .brand-mark {
      width: 20px;
      height: 20px;
      display: block;
    }
    .brand-wordmark {
      font-family: var(--ff-serif);
      font-size: 18px;
      font-weight: 500;
      letter-spacing: -0.005em;
      line-height: 1;
    }
    .head-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .close-x {
      width: 24px;
      height: 24px;
      padding: 0;
      background: transparent;
      border: none;
      color: var(--c-text-mute);
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      border-radius: var(--r-xs);
      font-family: inherit;
    }
    .close-x:hover { color: var(--c-text); background: var(--c-surface-2); }

    /* Title row — H2 on the left, summary chips pinned right. Same line
       gives a tight, scannable header instead of the prior stacked
       title/summary block. */
    .title-row {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
    }
    .title-row h2 { margin: 0; font-size: 15px; font-weight: 600; }
    .summary {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text-mute);
      font-family: inherit;
      font-variant-numeric: tabular-nums;
      flex-wrap: wrap;
    }
    .sum-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .sum-sep { color: var(--c-text-soft); }
    .sum-dot {
      width: 7px;
      height: 7px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .sum-dot[data-status="green"]  { background: var(--c-success); }
    .sum-dot[data-status="yellow"] { background: var(--c-warning); }
    .sum-dot[data-status="red"]    { background: var(--c-error); }
    .sum-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .primary {
      flex-shrink: 0;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      font-family: inherit;
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: 1px solid var(--c-primary);
    }
    .pill {
      flex-shrink: 0;
      padding: 5px 10px;
      border-radius: var(--r-pill);
      background: var(--c-tint);
      color: var(--c-primary);
      font-size: 11px;
      font-family: inherit;
      font-weight: 500;
    }
    .pill.complete {
      background: color-mix(in oklab, var(--c-success) 14%, transparent);
      color: var(--c-success);
    }
    .banner {
      padding: 8px 12px;
      border-radius: var(--r-sm);
      background: var(--c-tint);
      color: var(--c-text);
      font-size: 12px;
      font-weight: 500;
      margin-bottom: 8px;
      font-family: inherit;
      word-break: break-all;
    }
    .rows {
      list-style: none;
      margin: 0;
      padding: 0;
      overflow-y: auto;
      max-height: 60vh;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px;
      border-radius: var(--r-sm);
      background: var(--c-surface-2);
    }
    .row[data-status="red"]    { background: color-mix(in oklab, var(--c-error) 8%, var(--c-surface-2)); }
    .row[data-status="orange"] { background: color-mix(in oklab, var(--c-warning) 7%, var(--c-surface-2)); }
    .row[data-status="pending"] { opacity: 0.85; }
    .thumb {
      position: relative;
      width: 36px; height: 36px;
      border-radius: var(--r-xs);
      border: 1px solid var(--c-border);
      background-color: var(--c-surface);
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      flex-shrink: 0;
    }
    .row-idx {
      position: absolute;
      top: -2px; left: -2px;
      background: var(--c-surface);
      color: var(--c-text-mute);
      font-family: var(--ff-mono);
      font-size: 9px;
      font-weight: 600;
      padding: 1px 3px;
      border-radius: 2px;
    }
    .meta { flex: 1; min-width: 0; }
    .name {
      font-size: 13px;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .muted { color: var(--c-text-soft); font-style: italic; }
    .status-line {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: var(--c-text-mute);
      margin-top: 2px;
    }
    .dot, .sub-dot {
      width: 8px; height: 8px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .dot[data-status="green"],  .sub-dot[data-status="green"]  { background: var(--c-success); }
    .dot[data-status="yellow"], .sub-dot[data-status="yellow"] { background: var(--c-warning); }
    .dot[data-status="orange"], .sub-dot[data-status="orange"] {
      background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%);
    }
    .dot[data-status="red"],    .sub-dot[data-status="red"]    { background: var(--c-error); }
    .dot[data-status="pending"], .sub-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .dot[data-status="no-element"] { background: transparent; border-color: var(--c-text-soft); }
    .sub-dots { display: inline-flex; gap: 3px; margin-left: 4px; }
    .actions { display: flex; gap: 6px; flex-shrink: 0; }
    .action-btn {
      padding: 4px 10px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      font-size: 11px;
      font-weight: 500;
      font-family: inherit;
      cursor: pointer;
    }
    .action-btn:hover { border-color: var(--c-border-strong); }
    .action-btn.primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border-color: var(--c-primary);
    }
  `}let _e=null,Xn=null,ot=null,Be=null;function oo(t){ot=t,_e||Qh(),ec(t)}function Gt(t){ot&&(ot={...ot,...t},ec(ot))}function ke(){Be&&(document.removeEventListener("keydown",Be,!0),Be=null),_e&&(_e.remove(),_e=null,Xn=null,ot=null)}function Qh(){const{host:t,shadow:e}=yt();_e=t,Xn=e,t.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${j+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),e.addEventListener("click",Jh),Be=n=>{n.key==="Escape"&&ot&&ot.phase!=="validating"&&ot.phase!=="navigating"&&(n.preventDefault(),ot.onClose())},document.addEventListener("keydown",Be,!0),document.body.appendChild(t)}function Jh(t){if(!ot)return;const e=t.target;if(!(e instanceof HTMLElement))return;if(e.closest('[data-action="close"]')){ot.onClose();return}if(e.closest('[data-action="start"]')){ot.onStart();return}const n=e.closest('[data-action="go-step"]');if(n!=null&&n.dataset.stepId){ot.onGoToStep(n.dataset.stepId);return}const r=e.closest('[data-action="repick"]');if(r!=null&&r.dataset.stepId){ot.onRepick(r.dataset.stepId);return}}function ec(t){Xn&&(Xn.innerHTML=jh(t))}let Et=null;function Vn(t){const{shadow:e}=m;e&&requestAnimationFrame(()=>{const n=e.querySelector(`[data-step-card="${t}"]`);n==null||n.scrollIntoView({behavior:"smooth",block:"center"})})}function tm(){const t=L();if(!t)return;const e=typeof location<"u"?location.href:"";Et=zh(t,e),oo({scenario:t,session:Et,phase:"initial",onStart:()=>{nc(t)},onGoToStep:n=>{ke(),Et=null,Dt();const r=t.steps.findIndex(o=>o.id===n);r>=0&&(ht(r),Vn(r))},onRepick:n=>{ke(),Et=null,Dt();const r=t.steps.findIndex(o=>o.id===n);r<0||(ht(r),Vn(r),m.pickerTarget={type:"primary"},P("picker"))},onClose:()=>{ke(),Et=null,Dt()}})}async function em(){const t=await Pc();if(!t)return;const e=L();if(!e||e.id!==t.scenarioId){await Dt();return}Et=t,tc(t);const n={onStart:()=>{},onGoToStep:r=>{ke(),Et=null,Dt();const o=e.steps.findIndex(a=>a.id===r);o>=0&&(ht(o),Vn(o))},onRepick:r=>{ke(),Et=null,Dt();const o=e.steps.findIndex(a=>a.id===r);o<0||(ht(o),Vn(o),m.pickerTarget={type:"primary"},P("picker"))},onClose:()=>{ke(),Et=null,Dt()}};if(Js(t)){oo({scenario:e,session:t,phase:"complete",...n});return}oo({scenario:e,session:t,phase:"validating",...n}),await nc(e)}async function nc(t){var r;if(!t)return;const e=Et;if(!e)return;if(Gt({phase:"validating"}),await new Promise(o=>setTimeout(o,30)),await _h(t,e,()=>{Gt({session:e})}),await Uh(e),Gt({session:e}),Js(e)){tc(e),Gt({phase:"complete"});const o=((r=t.steps[0])==null?void 0:r.pickedAtUrl)||t.url||"";if(o&&!tn(o,location.href)){await new Promise(a=>setTimeout(a,700)),Gt({phase:"navigating",navigatingTo:o}),await new Promise(a=>setTimeout(a,600)),location.href=o;return}await Dt();return}const n=Bh(e);if(!n){Gt({phase:"complete"}),await Dt();return}Gt({phase:"navigating",navigatingTo:n}),await new Promise(o=>setTimeout(o,600)),location.href=n}function rc(t){if(t.key==="Escape"){const r=m.subSelection;if(r.selectedIds.length===0&&!r.primarySelected)return;const o=Hr();if(o&&Fr(o)||st()==="picker")return;const a=r.stepId;m.subSelection=Ie,a&&Se(a);return}if(t.key==="ArrowLeft"||t.key==="ArrowRight"){const r=m.subSelection;if(!r.stepId||!r.anchorId)return;const o=Hr();if(o&&Fr(o))return;t.preventDefault(),ho(r.stepId,r.anchorId,r.selectedIds,t.key==="ArrowLeft"?-1:1);return}if(t.key!=="Delete"&&t.key!=="Backspace")return;const e=m.subSelection;if(!e.stepId||e.selectedIds.length===0)return;const n=Hr();n&&Fr(n)||(t.preventDefault(),Hl(e.stepId,e.selectedIds),m.subSelection=Ie)}function oc(t){const e=m.subSelection;if(e.selectedIds.length===0&&!e.primarySelected||st()==="picker")return;const n=t.composedPath();for(const o of n)if(o instanceof Element&&o.matches('.sub-node, .sub-add, .sub-gap, [data-action="step-wand"]'))return;const r=e.stepId;m.subSelection=Ie,r&&Se(r)}function nm(t){const e=t.dataset.subId??"",n=Number(t.dataset.direction??"0");if(!e||n!==-1&&n!==1)return;const r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!o)return;const a=vr(m.subSelection,o);ho(o,e,a,n)}function rm(t){const e=t.dataset.stepId??"";if(!e)return;const n=L(),r=n==null?void 0:n.steps.find(a=>a.id===e);if(!r||!r.selectors)return;const o=r.pickedAtUrl;if(o&&!fr(o,location.href,!!(n!=null&&n.strictUrlMatch))){oe(v("sub.same-url-required"),!0);return}m.pickerTarget={type:"sub-add",stepId:e},P("picker")}function om(t,e){var h;const n=t.dataset.subId??"",r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!n||!o)return;const a=L(),i=(a==null?void 0:a.steps.findIndex(b=>b.id===o))??-1;if(!a||i<0)return;const s=a.steps[i],c=(h=s==null?void 0:s.subElements)==null?void 0:h.find(b=>b.id===n);if(!s||!c)return;const l=e;if(l.shiftKey){const b=(s.subElements??[]).map(y=>y.id);m.subSelection=bh(m.subSelection,o,n,b),Se(o);return}if(l.ctrlKey||l.metaKey){m.subSelection=gh(m.subSelection,o,n),Se(o);return}const d=m.subSelection,p=d.stepId===o&&d.anchorId===n,u=st()==="picker"&&m.pickerTarget.type==="sub-repick"&&m.pickerTarget.subId===n;if(p&&u){P("idle");return}if(p){m.pickerTarget={type:"sub-repick",stepId:o,subId:n},P("picker");return}m.subSelection=Ns(m.subSelection,o,n),i!==H()&&Lt(i);const f=Ae(c.selectors);f&&(en(f,{behavior:"smooth"}),Lo(f,{durationMs:350}),Zs(f)),st()==="picker"?P("idle"):Se(o)}function am(t){const e=t.closest('[data-region="sub-track"]'),n=(e==null?void 0:e.dataset.stepId)??"";if(!n)return;const r=L(),o=(r==null?void 0:r.steps.findIndex(s=>s.id===n))??-1;if(o<0)return;const a=r==null?void 0:r.steps[o],i=(a==null?void 0:a.pickedAtUrl)||(r==null?void 0:r.url)||"";if(i&&!tn(i,location.href)){Do(i,o);return}if(m.subSelection=vh(m.subSelection,n),o!==H()&&Lt(o),Se(n),a!=null&&a.selectors){const s=Ae(a.selectors);s&&(en(s,{behavior:"smooth"}),Lo(s,{durationMs:350}),Zs(s))}}function Se(t){const{shadow:e}=m;if(!e)return;const n=e.querySelector(`[data-region="sub-track"][data-step-id="${im(t)}"]`);if(!n)return;const r=new Set(vr(m.subSelection,t));n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{const i=a.dataset.subId;i&&a.classList.toggle("selected",r.has(i))});const o=n.querySelector(".sub-node.primary");o&&o.classList.toggle("selected",Hs(m.subSelection,t))}function im(t){return t.replace(/[^a-zA-Z0-9_-]/g,"\\$&")}function Hr(){var e;let t=document.activeElement;for(;t&&((e=t.shadowRoot)!=null&&e.activeElement);)t=t.shadowRoot.activeElement;return t}function Fr(t){return!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLElement&&t.isContentEditable)}function sm(t,e){const{shadow:n,host:r}=m;if(!n||!r)return;Ah(),Mh(),pm(),Ch(),document.addEventListener("mousedown",Ks,!0);const o=a=>a.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",a=>lm(a,t,e)),document.addEventListener("keydown",rc,!0),document.addEventListener("mousedown",oc,!0)}function cm(){document.removeEventListener("mousedown",Ks,!0),document.removeEventListener("keydown",rc,!0),document.removeEventListener("mousedown",oc,!0)}function lm(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="palette-toggle"]')){t.stopPropagation(),Yc();return}if(o.closest('[data-action="recording-toggle"]')){t.stopPropagation(),ac();return}if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void kh();if(o.closest('[data-action="prompter"]')){n(!0),as().then(()=>{Mt()});return}if(o.closest('[data-action="export"]'))return wh();if(o.closest('[data-action="ephemeral-import"]'))return void fm();if(o.closest('[data-action="validate"]'))return tm();if(o.closest('[data-action="settings-toggle"]'))return Lh();const a=o.closest('[data-action="tool-set"]');if(a instanceof HTMLElement){t.stopPropagation();const s=a.getAttribute("data-tool");if(s==="shape"){ph(a,c=>{fp(c),P("shape")});return}P(st()===s?"idle":s);return}if(dm(t,o))return;const i=o.closest("[data-step-card]");if(i&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(i.getAttribute("data-step-card"));if(yr(s))return;ht(s)}}async function ac(){Eg().then(t=>{t||oe("Recording cancelled or unsupported.")})}function dm(t,e){var u;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const f=Number(n.getAttribute("data-insert-index"));return Vo({insertIndex:f}),!0}if(e.closest('[data-action="step-add"]'))return Vo(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const f=Number(r.getAttribute("data-step-index"));return yr(f)||um(f),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),Ll(Number(o.getAttribute("data-step-index"))),!0;const a=e.closest('[data-action="step-link"]');if(a){t.stopPropagation();const f=a.getAttribute("data-url")??"",h=a.closest("[data-step-card]"),b=h?Number(h.getAttribute("data-step-card")):0;return f?tn(f,location.href)?(Number.isFinite(b)&&ht(b),!0):(Do(f,Number.isFinite(b)?b:0),!0):!0}const i=e.closest('[data-action="step-action-toggle"]');if(i instanceof HTMLElement){t.stopPropagation();const f=Number(i.getAttribute("data-step-index")),h=(u=L())==null?void 0:u.steps[f];return h&&(ht(f),Pt(h.id,{waitForNavigation:!h.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');if(s instanceof HTMLElement)return t.stopPropagation(),s.classList.contains("disabled")||Hh(s),!0;const c=e.closest('[data-action="sub-add"]');if(c instanceof HTMLElement)return t.stopPropagation(),rm(c),!0;const l=e.closest('[data-action="sub-shift"]');if(l instanceof HTMLElement)return t.stopPropagation(),t.preventDefault(),nm(l),!0;const d=e.closest(".sub-node[data-sub-id]");if(d instanceof HTMLElement)return t.stopPropagation(),om(d,t),!0;const p=e.closest(".sub-node.primary[data-primary]");return p instanceof HTMLElement?(t.stopPropagation(),am(p),!0):!1}function um(t){if(ht(t),st()==="picker"&&m.pickerTarget.type==="primary"){P("idle");return}m.subSelection=Ie,m.pickerTarget={type:"primary"},P("picker")}function pm(){const{shadow:t}=m;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>ao(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=L();r&&(e.textContent=r.name),ao(e),e.blur()}}),e.addEventListener("blur",()=>{Al(e.textContent??"")}))}function ao(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}async function fm(){try{await El()&&oe(v("panel.ephemeral.saved")||"Saved to local")}catch(t){console.error("[manuscript] ephemeral import failed",t),oe(v("panel.ephemeral.save-failed")||"Save failed",!0)}}const hm='[data-manuscript="ui"][data-region="permission-banner"]';function ic(){return document.querySelector(hm)}function mm(t){const e=ic();if(e){cc(e,t);return}gm(t)}function sc(){const t=ic();t&&t.remove()}function cc(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function gm(t){var r;const{host:e,shadow:n}=yt();e.setAttribute("data-region","permission-banner"),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${j+5}`,"pointer-events: none"].join("; "),n.innerHTML=bm(),cc(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>sc()),document.body.appendChild(e)}function bm(){return`
    <style>
      ${Rt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const bn=16,vm=240,ym=/permission|<all_urls>|activeTab/i;async function lc(t){const e=xm({x:t.x-bn,y:t.y-bn,width:t.width+bn*2,height:t.height+bn*2});if(e.width<=0||e.height<=0)return null;const n=await wm();if(!n.ok)return ym.test(n.error)?mm(v("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await Em(n.dataUrl,e,vm)}catch(r){return console.error("[manuscript] crop failed",r),null}}function xm(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function wm(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await Sm();try{return{ok:!0,dataUrl:await km()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function km(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function Sm(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function Em(t,e,n){const r=await Am(t),o=r.naturalWidth/window.innerWidth||1,a=e.x*o,i=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),d=Math.max(1,Math.round(e.width*l)),p=Math.max(1,Math.round(e.height*l)),u=document.createElement("canvas");u.width=d,u.height=p;const f=u.getContext("2d");if(!f)throw new Error("No 2d context");return f.drawImage(r,a,i,s,c,0,0,d,p),u.toDataURL("image/png")}function Am(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function dc(t){const e=t.detail,n=m.pickerTarget;m.pickerTarget={type:"primary"};const r=Mm(e.rect,e.chain.framePath);if(n.type==="sub-add"){const o=Nl({selectors:e.chain,thumbnailDataUrl:null,pickedAtUrl:location.href});o&&(m.subSelection=Ns(m.subSelection,n.stepId,o.id),Ro(),Oa(n.stepId,o.id,r));return}if(n.type==="sub-repick"){ql(n.stepId,n.subId,e.chain,location.href),Oa(n.stepId,n.subId,r);return}Il(e.chain),$m(r)}function Mm(t,e){if(!e||e.length===0)return t;const n=ud(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function $m(t){try{const e=await lc(t);$l(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}async function Oa(t,e,n){try{const r=await lc(n);Fl(t,e,{thumbnailDataUrl:r})}catch(r){console.warn("[manuscript] sub thumbnail capture skipped",r)}}function Lm(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }
      .settings-divider {
        height: 1px;
        margin: 12px 0;
        background: var(--c-border);
      }
      .settings-check-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
        gap: 8px;
        cursor: pointer;
      }
      .settings-check {
        width: 14px;
        height: 14px;
        margin: 0;
        flex: none;
        accent-color: var(--c-primary);
        cursor: pointer;
      }
      .settings-check-row .settings-label { cursor: pointer; }
      .settings-help {
        margin: 6px 0 0;
        font-size: 11px;
        line-height: 1.4;
        color: var(--c-text-mute);
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Record button — same primary fill as play / prompter so the
         footer trio reads as one cluster (the design-system way of
         saying "these are the three CTAs"). The red dot icon is the
         only theme-independent piece — it carries the "record"
         affordance without making the whole button red at rest.
         Pressed flips to var(--c-error) + stop square + pulse halo so
         the recording state is unmistakable. Hidden during bridge
         standalone sessions; that branch is enforced at the controller
         layer. */
      .record-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        /* Record dot reads as an activity indicator, not an error
           state, so brighten --c-error locally with a 22% white mix.
           Stays palette-aware (light/dark both shift together) without
           touching the global error token or its other consumers. */
        color: color-mix(in oklch, var(--c-error), white 22%);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease, color 160ms ease;
      }
      .record-btn:hover { background: var(--c-primary-h); }
      .record-btn .record-stop { display: none; }
      .record-btn[aria-pressed="true"] {
        background: var(--c-error);
        color: var(--c-primary-fg);
        animation: record-pulse 1.6s ease-in-out infinite;
      }
      .record-btn[aria-pressed="true"] .record-dot { display: none; }
      .record-btn[aria-pressed="true"] .record-stop { display: inline-block; }
      @keyframes record-pulse {
        0%, 100% { box-shadow: 0 0 0 0 color-mix(in oklch, var(--c-error), transparent 60%); }
        50%      { box-shadow: 0 0 0 6px color-mix(in oklch, var(--c-error), transparent 100%); }
      }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
        /* Sit above the footer chrome (play-btn / record-btn / icon-btn
           / settings-popup at z-index 4) so the toast isn't clipped by
           those siblings. */
        z-index: 10;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Tm(){return`
      ${Rt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Ephemeral banner ----
         docs/15.REMOTE-LIBRARY-PLAN.md § 8. Sticky 28px band shown when
         the loaded scenario is ephemeral (bridge or GitHub-fetched).
         Background is a low-alpha tint of --c-primary so it integrates
         with the active palette without introducing a new warning token.
         Dark-mode variant inherits through --c-primary / --c-text-mute.
      */
      .ephemeral-banner {
        display: flex;
        flex-direction: column;
        gap: 4px;
        padding: 8px 12px;
        background: color-mix(in srgb, var(--c-primary) 12%, transparent);
        border-bottom: 1px solid color-mix(in srgb, var(--c-primary) 22%, transparent);
        color: var(--c-text-mute);
        font-size: 12px;
        line-height: 1.3;
        flex-shrink: 0;
      }
      .ephemeral-banner[hidden] { display: none; }
      .ephemeral-row {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .ephemeral-row-action { justify-content: space-between; }
      .ephemeral-icon { font-size: 13px; line-height: 1; flex-shrink: 0; }
      .ephemeral-label {
        font-weight: 500;
        color: var(--c-text);
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        flex: 1;
        min-width: 0;
      }
      .ephemeral-warn {
        flex: 1;
        min-width: 0;
      }
      .ephemeral-import {
        flex-shrink: 0;
        background: transparent;
        border: 1px solid color-mix(in srgb, var(--c-primary) 45%, transparent);
        color: var(--c-primary);
        font: inherit;
        font-weight: 500;
        padding: 3px 10px;
        border-radius: var(--r-sm);
        cursor: pointer;
        white-space: nowrap;
      }
      .ephemeral-import:hover {
        background: color-mix(in srgb, var(--c-primary) 18%, transparent);
      }
      .ephemeral-import:focus-visible {
        outline: 2px solid var(--c-primary);
        outline-offset: 1px;
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .palette-toggle {
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        color: var(--c-text-mute);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: border-color 160ms ease, color 160ms ease;
      }
      .palette-toggle:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .palette-toggle:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
      }
      .palette-toggle .palette-sun { display: none; }
      .palette-toggle .palette-moon { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-sun { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-moon { display: none; }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Im(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -3px;
        left: 2px;
        font-family: var(--ff-mono);
        font-size: 13px;
        font-weight: 700;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 2px 5px;
        border-radius: 3px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* Selector health dot — Phase A telemetry. Hover shows which layer
         resolved the element on the last replay / sync; red = miss. */
      .health-dot {
        position: absolute;
        top: -3px;
        right: -3px;
        width: 9px;
        height: 9px;
        border-radius: 999px;
        border: 1.5px solid var(--c-surface);
        box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
        pointer-events: auto;
        z-index: 4;
      }
      .health-dot[data-health="green"]  { background: var(--c-success); }
      .health-dot[data-health="yellow"] { background: var(--c-warning); }
      .health-dot[data-health="orange"] { background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%); }
      .health-dot[data-health="red"]    { background: var(--c-error); }
      .sub-node .health-dot { top: -2px; right: -2px; width: 7px; height: 7px; border-width: 1px; }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

      /* ---- Sub-element track (v0.1.2) ---- */
      .step-sub-track {
        position: relative;
        flex-basis: 100%;
        margin-top: 4px;
        padding: 6px 4px;
        border-top: 1px dashed var(--c-border);
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px;
        cursor: default;
        user-select: none;
      }
      .sub-rubber-band {
        position: absolute;
        pointer-events: none;
        border: 1px dashed var(--c-primary);
        background: var(--c-tint);
        opacity: 0.55;
        z-index: 5;
      }
      .sub-node {
        position: relative;
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        cursor: pointer;
      }
      /* Hover bridge — a transparent pseudo extends the sub-node's
         hover area outward so the cursor can move from the thumbnail to
         the outside-positioned shift buttons without losing :hover.
         pointer-events default off so the bridge doesn't intercept
         clicks in the gap area between sub-nodes (which would select
         the neighboring sub by mistake); it activates only while the
         node is already hovered/selected — i.e. once the cursor is on
         the body, the bridge takes over for the trip out to the buttons. */
      .sub-node::after {
        content: '';
        position: absolute;
        inset: -2px -10px -10px -10px;
        z-index: 1;
        pointer-events: none;
      }
      .sub-node:hover::after,
      .sub-node.selected::after {
        pointer-events: auto;
      }
      .sub-node.primary { border-color: var(--c-primary); }
      .sub-node.selected {
        outline: 2px solid var(--c-primary);
        outline-offset: 1px;
      }
      /* Picker-armed sub: same heartbeat as .step-thumb.is-picking so
         the user gets a consistent "now pick a replacement element" cue.
         Re-uses the thumb-pulse keyframes defined above. */
      .sub-node.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      /* Time-shift buttons sit just outside the thumbnail edges so they
         don't cover the picked image content. They're always in the
         DOM but hidden until either the user hovers the sub or the sub
         is selected — that way a click that flips .selected via direct
         DOM manipulation surfaces them immediately, no re-render needed.
         Arrow keys do the same job for keyboard users (anchor sub). */
      .sub-shift {
        position: absolute;
        width: 13px;
        height: 13px;
        padding: 0;
        border: 1px solid var(--c-primary);
        background: rgba(255, 255, 255, 0.92);
        color: var(--c-primary);
        border-radius: 3px;
        font-size: 11px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        z-index: 3;
        user-select: none;
        opacity: 0;
        pointer-events: none;
      }
      /* No opacity transition — each click rebuilds the step card and a
         fade-in on the fresh sub-node element would visibly flicker on
         every press. Snap to 1 once hover re-applies on the next paint. */
      /* Buttons sit fully inside the sub-node thumbnail so moving the
         mouse from thumb → button never leaves the .sub-node hover area
         (avoids the disappear-mid-move flicker). */
      .sub-node:hover .sub-shift {
        opacity: 1;
        pointer-events: auto;
      }
      .sub-shift:hover { background: var(--c-tint); color: var(--c-primary); }
      .sub-shift-left { left: -8px; bottom: -7px; z-index: 3; }
      .sub-shift-right { right: -8px; bottom: -7px; z-index: 3; }
      .sub-node[draggable="true"] { cursor: grab; }
      .sub-node.dragging { opacity: 0.4; cursor: grabbing; }
      /* Insert-before / insert-after drop indicators — a 2px vertical
         bar flush against the hovered sub-node on the matching side. */
      .sub-node.drop-before::before,
      .sub-node.drop-after::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-node.drop-before::before { left: -5px; }
      .sub-node.drop-after::after { right: -5px; }
      .sub-gap.drop-on {
        position: relative;
      }
      .sub-gap.drop-on::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        left: 50%;
        transform: translateX(-50%);
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-badge {
        position: absolute;
        top: -4px;
        left: -4px;
        background: var(--c-surface);
        color: var(--c-primary);
        font-family: var(--ff-mono);
        font-size: 9px;
        font-weight: 700;
        padding: 1px 4px;
        border-radius: 999px;
        border: 1px solid var(--c-primary);
        line-height: 1;
      }
      .sub-gap {
        display: inline-flex;
        align-items: center;
        font-family: var(--ff-mono);
        font-size: 10px;
        color: var(--c-text-mute);
        white-space: nowrap;
        padding: 0 2px;
        user-select: none;
      }
      .sub-gap::before,
      .sub-gap::after {
        content: '';
        width: 6px;
        height: 1px;
        background: var(--c-border-strong);
        opacity: 0.6;
      }
      .sub-gap::before { margin-right: 4px; }
      .sub-gap::after  { margin-left: 4px; }
      .sub-add {
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px dashed var(--c-border-strong);
        background: transparent;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .sub-add:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }

      /* v0.5.0 — Sub-elements collapsible section. */
      .step-subs-section {
        flex-basis: 100%;
        width: 100%;
        min-width: 0;
      }
      .step-subs-header {
        display: flex;
        align-items: center;
        gap: 6px;
        width: 100%;
        background: transparent;
        border: 0;
        padding: 4px 2px;
        cursor: pointer;
        color: var(--c-text-mute);
        font-size: 11px;
        font-weight: 600;
        text-align: left;
      }
      .step-subs-header:hover { color: var(--c-text); }
      .step-subs-chevron {
        display: inline-block;
        transition: transform 120ms ease;
      }
      .step-subs-section.is-expanded .step-subs-chevron { transform: rotate(90deg); }
      .step-subs-title { flex: 1; }
      .step-subs-count {
        font-variant-numeric: tabular-nums;
        color: var(--c-text-mute);
      }

      /* v0.5.0 — Annotation list section inside step card. */
      .step-annotations {
        flex-basis: 100%;
        width: 100%;
        min-width: 0;
        border-top: 1px dashed var(--c-border);
      }
      .step-ann-header {
        display: flex;
        align-items: center;
        gap: 6px;
        width: 100%;
        background: transparent;
        border: 0;
        padding: 4px 2px;
        cursor: pointer;
        color: var(--c-text-mute);
        font-size: 11px;
        font-weight: 600;
        text-align: left;
      }
      .step-ann-header:hover { color: var(--c-text); }
      .step-ann-chevron {
        display: inline-block;
        transition: transform 120ms ease;
      }
      .step-annotations.is-expanded .step-ann-chevron { transform: rotate(90deg); }
      .step-ann-title { flex: 1; }
      .step-ann-count {
        font-variant-numeric: tabular-nums;
        color: var(--c-text-mute);
      }
      .step-ann-list {
        list-style: none;
        margin: 4px 0 0;
        padding: 0;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        gap: 4px;
      }
      .step-ann-row {
        display: inline-flex;
        align-items: center;
        gap: 2px;
        padding: 2px 4px 2px 2px;
        border-radius: 6px;
        border: 1px solid transparent;
        background: var(--c-surface-2, rgba(255,255,255,0.03));
      }
      .step-ann-row:hover { border-color: var(--c-border); }
      .step-ann-row.selected {
        background: color-mix(in oklch, var(--c-primary, currentColor), transparent 86%);
        border-color: var(--c-primary, currentColor);
      }
      .step-ann-pick {
        display: inline-flex;
        align-items: center;
        gap: 4px;
        background: transparent;
        border: 0;
        padding: 2px;
        cursor: pointer;
        color: inherit;
      }
      .step-ann-icon {
        color: var(--c-text-mute);
        flex-shrink: 0;
      }
      .step-ann-row.selected .step-ann-icon,
      .step-ann-row:hover .step-ann-icon { color: var(--c-text); }
      .step-ann-thumb {
        width: 32px;
        height: 32px;
        flex-shrink: 0;
        border-radius: 4px;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        overflow: hidden;
        background: var(--c-surface-2, rgba(255,255,255,0.04));
        border: 1px solid var(--c-border);
      }
      .step-ann-thumb-text {
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        border-style: solid;
        border-width: 1px;
      }
      .step-ann-thumb-arrow::before { content: "↗"; opacity: 0.6; }
      .step-ann-delete {
        background: transparent;
        border: 0;
        padding: 2px;
        color: var(--c-text-mute);
        cursor: pointer;
        border-radius: 3px;
        opacity: 0.55;
        transition: opacity 120ms ease, color 120ms ease;
      }
      .step-ann-row:hover .step-ann-delete { opacity: 1; }
      .step-ann-delete:hover { color: var(--c-danger, #d96b6b); }

  `}function Cm(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Dm(){return[Tm(),Im(),Cm(),Lm()].join(`
`)}function Pm(){return`
    <style>${Dm()}</style>
    <div class="panel" role="region" aria-label="${v("panel.aria.region")}">
      ${Rm()}
      <div class="ephemeral-banner" data-region="ephemeral-banner" hidden></div>
      ${Om()}
      <div class="body" data-region="steps"></div>
      ${Nm()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${v("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Rm(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${Za({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <div class="header-actions">
          <button type="button" class="palette-toggle" data-action="palette-toggle" data-region="palette-toggle" aria-label="${v("panel.palette-toggle-aria")}" aria-pressed="false" title="${v("panel.palette-toggle-aria")}">
            <svg class="palette-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <circle cx="8" cy="8" r="3"></circle>
              <path d="M8 1.2v1.6M8 13.2v1.6M14.8 8h-1.6M2.8 8H1.2M12.8 3.2l-1.13 1.13M4.33 11.67l-1.13 1.13M12.8 12.8l-1.13-1.13M4.33 4.33L3.2 3.2"></path>
            </svg>
            <svg class="palette-moon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path d="M6.5 1.5a6.5 6.5 0 1 0 8 8 5.4 5.4 0 0 1-8-8z"></path>
            </svg>
          </button>
          <button type="button" class="close-btn" data-action="close" aria-label="${v("panel.close-aria")}">×</button>
        </div>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${v("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Om(){return`
    <div class="tool-bar" role="toolbar" aria-label="${v("panel.tool-label")}">
      <span class="eyebrow">${v("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${v("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${v("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${v("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Nm(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${v("panel.replay-aria")}" title="${v("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${v("panel.prompter-aria")}" title="${v("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
        <button type="button" class="record-btn" data-action="recording-toggle" data-region="record-btn" aria-pressed="false" aria-label="${v("panel.record-aria")}" title="${v("panel.record-aria")}">
          <svg class="record-dot" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="8" cy="8" r="5"/></svg>
          <svg class="record-stop" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="10" height="10" rx="1"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="export" aria-label="${v("panel.export-aria")}" title="${v("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="validate" aria-label="${v("panel.validate-aria")}" title="${v("panel.validate-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 12l2 2 4-4"></path>
            <circle cx="12" cy="12" r="9"></circle>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${v("panel.settings-aria")}" title="${v("panel.settings.title")}" data-region="settings-toggle">
          ${Nh(16)}
        </button>
      </div>
      ${Hm()}
    </div>
  `}function Hm(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${v("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${v("panel.settings.close-aria")}" title="${v("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${v("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${v("panel.settings.voice-auto")}</option>
        </select>
      </div>
      <div class="settings-divider" role="separator"></div>
      <div class="settings-row">
        <label class="settings-check-row">
          <span class="settings-label">${v("panel.settings.strict-url-label")}</span>
          <input type="checkbox" class="settings-check" data-region="strict-url-toggle" />
        </label>
        <p class="settings-help">${v("panel.settings.strict-url-help")}</p>
      </div>
    </div>
  `}function Fm(t,e=[],n=!1,r=null){if(!t.selectors)return"";const o=t.subElements??[],a=t.subDwellsMs??[],i=new Set(e),s=[];s.push(qm(t,n)),o.forEach((p,u)=>{s.push(Na(u,a[u]??0)),s.push(zm(t.id,p,u,i.has(p.id),p.id===r))}),o.length>0&&s.push(Na(o.length,a[o.length]??0)),s.push(_m(t.id));const c=`<div class="step-sub-track" data-region="sub-track" data-step-id="${M(t.id)}">${s.join("")}</div>`,l=m.collapsedSubSteps.has(t.id),d=M(v("step.subs-title"));return`
    <div class="step-subs-section${l?"":" is-expanded"}" data-region="step-subs-section" data-step-id="${M(t.id)}">
      <button
        type="button"
        class="step-subs-header"
        data-action="step-subs-toggle"
        data-step-id="${M(t.id)}"
        aria-expanded="${l?"false":"true"}"
      >
        <span class="step-subs-chevron" aria-hidden="true">▸</span>
        <span class="step-subs-title">${d}</span>
        <span class="step-subs-count">${o.length+1}</span>
      </button>
      ${l?"":c}
    </div>
  `}function qm(t,e){const n=t.thumbnailDataUrl?` style="background-image: url('${M(t.thumbnailDataUrl)}')"`:"",r=e?"sub-node primary selected":"sub-node primary",o=gr(t.id),a=mr(o),i=a!=="none"?`<span class="health-dot" data-health="${a}" data-target="primary-mirror" title="${M(uc(o))}"></span>`:"";return`<div class="${r}" data-primary="1"${n}><span class="sub-badge">1</span>${i}</div>`}function zm(t,e,n,r,o){const a=e.thumbnailDataUrl?` style="background-image: url('${M(e.thumbnailDataUrl)}')"`:"",i=["sub-node"];r&&i.push("selected"),o&&i.push("is-picking");const s=i.join(" "),c=`<span class="sub-badge">${n+2}</span>`,l=gr(t,e.id),d=mr(l),p=d!=="none"?`<span class="health-dot" data-health="${d}" data-target="sub" title="${M(uc(l))}"></span>`:"",u=M(v("sub.shift-left")),f=M(v("sub.shift-right")),h=M(e.id),b=`<button type="button" class="sub-shift sub-shift-left" data-action="sub-shift" data-sub-id="${h}" data-direction="-1" aria-label="${u}" title="${u}" tabindex="-1">‹</button><button type="button" class="sub-shift sub-shift-right" data-action="sub-shift" data-sub-id="${h}" data-direction="1" aria-label="${f}" title="${f}" tabindex="-1">›</button>`;return`<div class="${s}" data-sub-id="${h}" data-sub-idx="${n}" draggable="true"${a}>${c}${p}${b}</div>`}function uc(t){return t===1?v("health.layer1"):t===2?v("health.layer2"):t===3?v("health.layer3"):t===null?v("health.broken"):""}function Na(t,e){return`<div class="sub-gap" data-gap-idx="${t}"><span>${Bm(e)}</span></div>`}function _m(t){const e=v("sub.add-aria")||"Add another element";return`<button type="button" class="sub-add" data-action="sub-add" data-step-id="${M(t)}" aria-label="${M(e)}" title="${M(e)}">+</button>`}function Bm(t){const e=t/1e3;return Number.isInteger(e)?`${e}s`:`${e.toFixed(1)}s`}const N=32;function Qt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Um(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function jm(t){switch(t.kind){case"text":return Wm(t);case"shape":return Xm(t);case"freedraw":return Ym(t);case"arrow":return'<span class="step-ann-thumb step-ann-thumb-arrow" aria-hidden="true"></span>'}}function Wm(t){const e=t.style.color||"#000000",n=t.style.backgroundColor??"#ffffff",r=t.style.backgroundOpacity??.96,o=n==="transparent"?"transparent":Gm(n,r),a=t.style.borderColor??"#000000",i=a==="transparent"?"0":`1px solid ${Qt(a)}`,s=t.style.bold?"700":"400",c=t.style.italic===!0?"italic":"normal",l=(t.text??"").trim().slice(0,2)||"T";return`<span class="step-ann-thumb step-ann-thumb-text" style="color: ${Qt(e)}; background: ${Qt(o)}; border: ${i}; font-weight: ${s}; font-style: ${c};">${Um(l)}</span>`}function Gm(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,a=0,i=0;return r.length===4?(o=parseInt(r[1]+r[1],16),a=parseInt(r[2]+r[2],16),i=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),a=parseInt(r.slice(3,5),16),i=parseInt(r.slice(5,7),16)),`rgba(${o}, ${a}, ${i}, ${n})`}return t}function Xm(t){const e=t.fill==="transparent"||!t.fill?"none":t.fill,n=t.stroke||"#000000",r=Math.max(1,Math.min(3,t.strokeWidth??2));return`<span class="step-ann-thumb step-ann-thumb-shape"><svg width="${N}" height="${N}" viewBox="0 0 ${N} ${N}" xmlns="http://www.w3.org/2000/svg">${Vm(t.shapeKind,e,n,r)}</svg></span>`}function Vm(t,e,n,r){const a=N-8,i=N-8,s=N/2,c=N/2,l=`fill="${Qt(e)}" stroke="${Qt(n)}" stroke-width="${r}"`;switch(t){case"rectangle":return`<rect x="4" y="4" width="${a}" height="${i}" rx="2" ${l}/>`;case"ellipse":return`<ellipse cx="${s}" cy="${c}" rx="${a/2}" ry="${i/2}" ${l}/>`;case"triangle":return`<polygon points="${s},4 ${N-4},${N-4} 4,${N-4}" ${l}/>`;case"diamond":return`<polygon points="${s},4 ${N-4},${c} ${s},${N-4} 4,${c}" ${l}/>`;case"star":{const d=(N-8)/2,p=d*.45,u=[];for(let f=0;f<10;f++){const h=f%2===0?d:p,b=-Math.PI/2+Math.PI/5*f;u.push(`${(s+h*Math.cos(b)).toFixed(2)},${(c+h*Math.sin(b)).toFixed(2)}`)}return`<polygon points="${u.join(" ")}" ${l}/>`}case"callout":return`<path d="M4 4 h${a} v${i-6} h-${a-6} l-3 4 v-4 h-3 z" ${l}/>`;case"line":return`<line x1="4" y1="${N-4}" x2="${N-4}" y2="4" stroke="${Qt(n)}" stroke-width="${r}" stroke-linecap="round"/>`;case"block-arrow":return`<path d="M4 ${c-3} h${a-8} v-4 l8 7 -8 7 v-4 h-${a-8} z" ${l}/>`}}function Ym(t){const e=t.stroke||"#000000",n=Km(t.points,12);if(n.length<2)return'<span class="step-ann-thumb step-ann-thumb-freedraw"></span>';let r=1/0,o=1/0,a=-1/0,i=-1/0;for(const h of n)h.x<r&&(r=h.x),h.x>a&&(a=h.x),h.y<o&&(o=h.y),h.y>i&&(i=h.y);const s=Math.max(1,a-r),c=Math.max(1,i-o),l=4,d=Math.min((N-l*2)/s,(N-l*2)/c),p=l+(N-l*2-s*d)/2,u=l+(N-l*2-c*d)/2,f=n.map(h=>`${((h.x-r)*d+p).toFixed(2)},${((h.y-o)*d+u).toFixed(2)}`).join(" ");return`<span class="step-ann-thumb step-ann-thumb-freedraw"><svg width="${N}" height="${N}" viewBox="0 0 ${N} ${N}" xmlns="http://www.w3.org/2000/svg"><polyline points="${f}" fill="none" stroke="${Qt(e)}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/></svg></span>`}function Km(t,e){if(t.length<=e)return[...t];const n=[],r=(t.length-1)/(e-1);for(let o=0;o<e;o++)n.push(t[Math.round(o*r)]);return n}function Zm(t){switch(t.kind){case"text":return'<svg class="step-ann-icon" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" aria-hidden="true"><path d="M2 3 h8 M6 3 v7"/></svg>';case"shape":return'<svg class="step-ann-icon" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" aria-hidden="true"><rect x="2" y="2" width="8" height="8" rx="1"/></svg>';case"freedraw":return'<svg class="step-ann-icon" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M1.5 10 C 3 7.5, 5 9, 6 7 C 7 5, 9 6.5, 10.5 4"/></svg>';case"arrow":return'<svg class="step-ann-icon" width="12" height="12" viewBox="0 0 12 12" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 10 L10 2 M6 2 H10 V6"/></svg>'}}function Qm(t){switch(t.kind){case"text":return"Text";case"arrow":return"Arrow";case"freedraw":return"Drawing";case"shape":return Jm(t.shapeKind)}}function Jm(t){return t&&t.charAt(0).toUpperCase()+t.slice(1)}const tg={text:"data-annotation-text",arrow:"data-annotation-arrow",shape:"data-annotation-shape",freedraw:"data-annotation-freedraw"};function eg(t){return t==="text"||t==="shape"||t==="freedraw"}function ng(t){const e=t.annotations.length;if(e===0)return"";const n=m.expandedAnnotationSteps.has(t.id),r=So(),o=n?t.annotations.map(a=>rg(a,r===a.id)).join(""):"";return`
    <div class="step-annotations${n?" is-expanded":""}" data-region="step-annotations" data-step-id="${M(t.id)}">
      <button
        type="button"
        class="step-ann-header"
        data-action="step-ann-toggle"
        data-step-id="${M(t.id)}"
        aria-expanded="${n?"true":"false"}"
      >
        <span class="step-ann-chevron" aria-hidden="true">▸</span>
        <span class="step-ann-title">${M(v("step.annotations-title"))}</span>
        <span class="step-ann-count">${e}</span>
      </button>
      ${n?`<ul class="step-ann-list" role="list">${o}</ul>`:""}
    </div>
  `}function rg(t,e){const n=M(Qm(t));return`
    <li class="step-ann-row${e?" selected":""}" data-ann-id="${M(t.id)}" data-ann-kind="${t.kind}">
      <button type="button" class="step-ann-pick" data-action="step-ann-pick" data-ann-id="${M(t.id)}" data-ann-kind="${t.kind}" aria-label="${n}" title="${n}">
        ${Zm(t)}
        ${jm(t)}
      </button>
      <button type="button" class="step-ann-delete" data-action="step-ann-delete" data-ann-id="${M(t.id)}" aria-label="${M(v("step.annotation-delete-aria"))}" title="${M(v("step.annotation-delete-aria"))}">${Qs(11)}</button>
    </li>
  `}function og(t,e,n){const r=t.querySelector('[data-region="step-annotations"]');if(!r)return;const o=r.querySelector('[data-action="step-ann-toggle"]');o==null||o.addEventListener("click",a=>{a.stopPropagation(),m.expandedAnnotationSteps.has(e.id)?m.expandedAnnotationSteps.delete(e.id):m.expandedAnnotationSteps.add(e.id),n()}),r.querySelectorAll('[data-action="step-ann-pick"]').forEach(a=>{a.addEventListener("click",i=>{i.stopPropagation();const s=a.getAttribute("data-ann-id"),c=a.getAttribute("data-ann-kind");!s||!eg(c)||ag(e,s,c)})}),r.querySelectorAll('[data-action="step-ann-delete"]').forEach(a=>{a.addEventListener("click",i=>{i.stopPropagation();const s=a.getAttribute("data-ann-id");s&&(So()===s&&ir(),po(s))})})}async function ag(t,e,n){const r=L();if(!r)return;const o=r.steps.findIndex(i=>i.id===t.id);if(o<0)return;if(!t.pickedAtUrl||tn(t.pickedAtUrl,location.href,!!r.strictUrlMatch)){o!==H()&&Lt(o);const i=(s=0)=>{const c=pc(e,n);if(c){Ve(e,c,n);return}s<5&&setTimeout(()=>i(s+1),50)};i();return}if(t.pickedAtUrl){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:r.id,stepIndex:o,annotationId:e})}catch(i){console.warn("[manuscript] markPending for annotation failed",i)}location.href=t.pickedAtUrl}}function pc(t,e){const r=`[${tg[e]}="${ig(t)}"]`,o=document.querySelector(r);return o&&(o instanceof HTMLElement||o instanceof SVGElement)?o:null}function ig(t){return t.replace(/(["\\])/g,"\\$1")}function sg(t){var n;const e=t.pickedAtUrl||((n=L())==null?void 0:n.url)||"";return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${M(e)}"
        aria-label="Open ${M(e)}"
      >${Oh(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${at(e)}</span>
    </div>
  `:""}function cg(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,a=t.thumbnailDataUrl!==null,i=n&&st()==="picker",s=i&&m.pickerTarget.type==="primary",c="step-thumb"+(o?" has-element":"")+(s?" is-picking":""),l=a?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",d=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,p=t.waitForNavigation,u=gr(t.id),f=mr(u);return r.innerHTML=`
    <button
      type="button"
      class="${c}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${M(v("step.wand-aria",{n:e+1}))}"
      title="${M(v("step.wand-title"))}"${l}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!a?`<span class="step-thumb-icon">${Rh(18)}</span>`:""}
      ${!o&&!a?'<span class="step-thumb-plus">+</span>':""}
      ${f!=="none"?`<span class="health-dot" data-health="${f}" data-target="step" title="${M(lg(u))}"></span>`:""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${M(v("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${at(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${M(v("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${at(t.description)}</div>
    </div>
    ${sg(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${p}" aria-label="${M(v("step.action-aria"))}" title="${M(v("step.action-aria"))}">${Ph(10)}</button>
      <div class="step-timer${p?" disabled":""}" data-action="step-timer" data-step-id="${M(t.id)}" title="${M(v("step.timer-aria"))}" ${p?'aria-disabled="true"':""}>
        <span class="step-timer-num">${d}</span>
        ${Oo(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${M(v("step.delete-aria"))}" title="${M(v("step.delete-aria"))}">${Qs(12)}</button>
    </div>
    ${Fm(t,vr(m.subSelection,t.id),Hs(m.subSelection,t.id),i&&m.subSelection.stepId===t.id?m.subSelection.anchorId:null)}
    ${ng(t)}
  `,r}function lg(t){return t===1?v("health.layer1"):t===2?v("health.layer2"):t===3?v("health.layer3"):t===null?v("health.broken"):""}function dg(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function ug(t,e,n,r){Fa(t,"step-name",n,o=>Pt(e.id,{name:o})),Fa(t,"step-desc",n,o=>Pt(e.id,{description:o}),{escapeBlurs:!0}),mg(t,n),hg(t,e),fg(t,e),og(t,e,r),pg(t,e,r)}function pg(t,e,n){const r=t.querySelector('[data-action="step-subs-toggle"]');r==null||r.addEventListener("click",o=>{o.stopPropagation(),m.collapsedSubSteps.has(e.id)?m.collapsedSubSteps.delete(e.id):m.collapsedSubSteps.add(e.id),n()})}function fg(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id;n.addEventListener("mousedown",o=>{if(o.button!==0)return;const a=o.target;if(!a||a.closest(".sub-node, .sub-add"))return;const i=n.getBoundingClientRect(),s=o.clientX-i.left,c=o.clientY-i.top,l=document.createElement("div");l.className="sub-rubber-band",l.style.left=`${s}px`,l.style.top=`${c}px`,l.style.width="0px",l.style.height="0px",n.appendChild(l),o.preventDefault();const d=()=>{document.removeEventListener("mousemove",p),document.removeEventListener("mouseup",u),document.removeEventListener("keydown",f),l.remove()},p=h=>{const b=n.getBoundingClientRect(),y=h.clientX-b.left,w=h.clientY-b.top,x=Math.min(s,y),S=Math.min(c,w),_=Math.max(s,y),F=Math.max(c,w);l.style.left=`${x}px`,l.style.top=`${S}px`,l.style.width=`${_-x}px`,l.style.height=`${F-S}px`;const I=[];n.querySelectorAll(".sub-node[data-sub-id]").forEach(K=>{const tt=K.getBoundingClientRect(),se=tt.left-b.left,lt=tt.top-b.top,Tt=tt.right-b.left,rn=tt.bottom-b.top,et=x<Tt&&_>se&&S<rn&&F>lt;if(et){const B=K.dataset.subId;B&&I.push(B)}K.classList.toggle("selected",et)}),m.subSelection={stepId:r,selectedIds:I,anchorId:I[I.length-1]??null,primarySelected:!1}},u=()=>d(),f=h=>{h.key==="Escape"&&(d(),m.subSelection=Ie,n.querySelectorAll(".sub-node.selected").forEach(b=>b.classList.remove("selected")))};document.addEventListener("mousemove",p),document.addEventListener("mouseup",u,{once:!0}),document.addEventListener("keydown",f)})}function hg(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id,o=()=>{n.querySelectorAll(".sub-node.drop-before, .sub-node.drop-after, .sub-gap.drop-on").forEach(a=>a.classList.remove("drop-before","drop-after","drop-on"))};n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{a.addEventListener("dragstart",i=>{i.stopPropagation();const s=a.dataset.subId??"";if(!s)return;const c=vr(m.subSelection,r),l=c.includes(s)?[...c]:[s];m.subDragSet=l,m.subDragStepId=r,l.forEach(d=>{const p=n.querySelector(`.sub-node[data-sub-id="${d.replace(/"/g,'\\"')}"]`);p==null||p.classList.add("dragging")}),i.dataTransfer&&(i.dataTransfer.setData("text/plain",`sub:${l.join(",")}`),i.dataTransfer.effectAllowed="move")}),a.addEventListener("dragend",()=>{n.querySelectorAll(".sub-node.dragging").forEach(i=>i.classList.remove("dragging")),m.subDragSet=null,m.subDragStepId=null,o()}),a.addEventListener("dragover",i=>{if(!m.subDragSet||m.subDragStepId!==r)return;const s=Number(a.dataset.subIdx);if(!Number.isFinite(s))return;const c=a.getBoundingClientRect(),l=i.clientX<c.left+c.width/2,d=l?s:s+1;if(Ha(e,m.subDragSet,d)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add(l?"drop-before":"drop-after")}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-before","drop-after")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.subIdx);if(!Number.isFinite(s)||!m.subDragSet||m.subDragStepId!==r){o();return}const c=a.getBoundingClientRect(),d=i.clientX<c.left+c.width/2?s:s+1,p=m.subDragSet;m.subDragSet=null,m.subDragStepId=null,o(),Yo(r,p,d)})}),n.querySelectorAll(".sub-gap[data-gap-idx]").forEach(a=>{a.addEventListener("dragover",i=>{if(!m.subDragSet||m.subDragStepId!==r)return;const s=Number(a.dataset.gapIdx);if(Number.isFinite(s)){if(Ha(e,m.subDragSet,s)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add("drop-on")}}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-on")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.gapIdx);if(!Number.isFinite(s)||!m.subDragSet||m.subDragStepId!==r){o();return}const c=m.subDragSet;m.subDragSet=null,m.subDragStepId=null,o(),Yo(r,c,s)})})}function Ha(t,e,n){const r=t.subElements??[];if(r.length===0||e.length===0)return!0;const o=new Set(e);let a=0;for(let s=0;s<n&&s<r.length;s++){const c=r[s];c&&!o.has(c.id)&&a++}let i=0;for(let s=0;s<r.length;s++){const c=r[s];if(c){if(o.has(c.id))break;i++}}return a===i}function Fa(t,e,n,r,o={}){const a=t.querySelector(`[data-region="${e}"]`);a&&(a.addEventListener("input",()=>dg(a)),a.addEventListener("focus",()=>{yr(n)||Lt(n)}),a.addEventListener("mousedown",i=>i.stopPropagation()),a.addEventListener("blur",()=>r(a.textContent??"")),a.addEventListener("keydown",i=>{(i.key==="Enter"&&e==="step-name"||i.key==="Escape"&&o.escapeBlurs)&&(i.preventDefault(),a.blur())}))}function mg(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}m.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),m.dragFromIndex=null,(n=m.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{m.dragFromIndex===null||m.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(m.dragFromIndex===null||m.dragFromIndex===e)&&(Tl(m.dragFromIndex,e),m.dragFromIndex=null)})}function No(){const{shadow:t}=m;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=L();if(e.innerHTML="",!n)return;const r=H();n.steps.forEach((a,i)=>{if(i>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(i)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${i+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${i}" aria-label="Insert step here">
          ${Ta(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=cg(a,i,r===i);e.appendChild(s),ug(s,a,i,No)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${Ta(10,1.8)}
    </button>
  `,e.appendChild(o)}function gg(){return m.host!==null}function fc(t){const{host:e}=m;e&&(e.dataset.promptedHidden=t?"1":"",hc(e))}function bg(t){const{host:e}=m;e&&(e.dataset.recordingHidden=t?"1":"",hc(e))}function hc(t){const e=st(),n=t.dataset.promptedHidden==="1",r=t.dataset.recordingHidden==="1",o=e==="replay";t.style.display=o||n||r?"none":""}async function Yn(t){if(m.host){t&&(await Xo(t),await qa());return}const{host:e,shadow:n}=yt(),r=$h(window.innerHeight*xh);e.style.cssText=["position: fixed",`top: ${we}px`,`right: ${we}px`,`width: ${yh}px`,`height: ${r}px`,`max-height: calc(100vh - ${we*2}px)`,`z-index: ${j+2}`,"display: none"].join("; "),n.innerHTML=Pm(),m.host=e,m.shadow=n,sm(mc,fc),document.body.appendChild(e),t&&await Xo(t)||Go(),ws(),document.addEventListener(Ye,dc),document.addEventListener(hr,gc),document.addEventListener("manuscript:annotation-selected",No),window.addEventListener("resize",Gs),m.unsubscribeMode=$t(zr),m.unsubscribeScenario=De(zr),zr(),await qa()}async function qa(){const t=L();if(t)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:t.id})}catch(e){console.warn("[manuscript] markActive failed",e)}}function mc(){var e,n;const{host:t}=m;t&&(document.removeEventListener(Ye,dc),document.removeEventListener(hr,gc),window.removeEventListener("resize",Gs),cm(),(e=m.unsubscribeMode)==null||e.call(m),m.unsubscribeMode=null,(n=m.unsubscribeScenario)==null||n.call(m),m.unsubscribeScenario=null,P("idle"),Le(),Pi(),ks(),di(),lh(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),m.host=null,m.shadow=null)}function gc(t){const e=t.detail,{shadow:n}=m;if(!n)return;if(e.cleared){n.querySelectorAll(".health-dot").forEach(o=>o.remove());return}const r=mr(e.layer);if(e.subId){const o=n.querySelector(`.sub-node[data-sub-id="${e.subId.replace(/"/g,'\\"')}"]`);o&&qr(o,r,"sub")}else n.querySelectorAll("[data-step-card]").forEach(a=>{var p;const i=(p=a.querySelector("[data-step-id]"))==null?void 0:p.dataset.stepId,s=a.querySelector('[data-region="sub-track"]'),c=s==null?void 0:s.dataset.stepId;if(i!==e.stepId&&c!==e.stepId)return;const l=a.querySelector(".step-thumb");l&&qr(l,r,"step");const d=a.querySelector(".sub-node.primary");d&&qr(d,r,"primary-mirror")})}function qr(t,e,n){const r=t.querySelector(`.health-dot[data-target="${n}"]`);if(e==="none"){r==null||r.remove();return}if(r)r.setAttribute("data-health",e);else{const o=document.createElement("span");o.className="health-dot",o.dataset.health=e,o.dataset.target=n,t.appendChild(o)}}function zr(){const{host:t,shadow:e}=m;if(!e||!t)return;const n=st(),r=t.dataset.promptedHidden==="1",o=t.dataset.recordingHidden==="1",a=n==="replay";t.style.display=a||r||o?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(l=>{const d=l.getAttribute("data-tool");l.setAttribute("aria-pressed",String(d===n))});const i=L(),s=e.querySelector('[data-region="title-edit"]');s&&i&&s!==e.activeElement&&(s.textContent!==i.name&&(s.textContent=i.name),ao(s));const c=e.querySelector('[data-region="ephemeral-banner"]');c&&ah(c,il()?sl():null),No(),Ro(),dr()&&!Y()&&Mt()}let Ee=null;function vg(t){Ee||(Ee=e=>{const n=e.target;if(!(n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement||n instanceof HTMLElement&&n.isContentEditable)){if(e.key===" "||e.key==="Spacebar"){e.preventDefault(),e.stopPropagation(),bc();return}if(e.key==="Escape"){e.preventDefault(),e.stopPropagation(),t.stop();return}}},window.addEventListener("keydown",Ee,!0))}function yg(){Ee&&(window.removeEventListener("keydown",Ee,!0),Ee=null)}function bc(){var e;if(!Y())return;Ge();const t=((e=k.state)==null?void 0:e.paused)===!0;chrome.runtime.sendMessage({type:t?"recording.paused":"recording.resumed"}).catch(()=>{})}let ge=null;function Ho(){if(ge)return;const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-region","watermark"),t.style.cssText=["position: fixed","right: 24px","bottom: 24px",`z-index: ${j+5}`,"pointer-events: none"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=`
    <style>
      .wm {
        display: inline-flex;
        align-items: center;
        gap: 6px;
        font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif;
        font-size: 12px;
        font-weight: 500;
        line-height: 1;
        color: #fff;
        opacity: 0.7;
        text-shadow: 0 1px 3px rgba(0, 0, 0, 0.55);
        white-space: nowrap;
      }
      .wm svg { display: block; filter: drop-shadow(0 1px 3px rgba(0, 0, 0, 0.55)); }
    </style>
    <span class="wm">${Za({height:14,color:"#fff"})}<span>Created with Manuscript</span></span>
  `,document.body.appendChild(t),ge=t}function vc(){ge==null||ge.remove(),ge=null}let U=null;function xg(t){if(U!==null)return;const e=t.from??3,n=t.tickMs??1e3,r=t.scheduler??kg(),{host:o,shadow:a}=yt();o.setAttribute("data-region","countdown"),o.style.cssText=["position: fixed","inset: 0",`z-index: ${j+10}`,"pointer-events: auto"].join("; "),a.innerHTML=Sg(e),document.body.appendChild(o);const i=a.querySelector('[data-region="number"]'),s=a.querySelector('[data-action="cancel"]'),c=l=>{(l.key==="Escape"||l.key===" "||l.key==="Spacebar")&&(l.preventDefault(),za())};window.addEventListener("keydown",c),s==null||s.addEventListener("click",()=>za()),U={host:o,shadow:a,numberEl:i,scheduler:r,tickMs:n,timerId:null,remaining:e,onComplete:t.onComplete,onCancel:t.onCancel??null,keyListener:c},yc()}function Fo(){U&&(U.timerId!==null&&U.scheduler.cancel(U.timerId),window.removeEventListener("keydown",U.keyListener),U.host.remove(),U=null)}function yc(){U&&(U.timerId=U.scheduler.schedule(wg,U.tickMs))}function wg(){if(U){if(U.remaining-=1,U.remaining<=0){const t=U.onComplete;Fo(),t();return}U.numberEl.textContent=String(U.remaining),yc()}}function za(){if(!U)return;const t=U.onCancel;Fo(),t==null||t()}function kg(){return{schedule(t,e){return window.setTimeout(t,e)},cancel(t){window.clearTimeout(t)}}}function Sg(t){return`
    <style>
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .ring {
        width: 220px;
        height: 220px;
        border-radius: 999px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #0a0a0a);
        box-shadow: 0 24px 60px rgb(0 0 0 / 0.35), 0 4px 12px rgb(0 0 0 / 0.20);
        display: grid;
        place-items: center;
        position: relative;
        animation: ring-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes ring-pop {
        from { transform: scale(0.85); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .number {
        font-size: 140px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        font-variant-numeric: tabular-nums;
        animation: digit-pop 200ms ease-out;
      }
      .number[data-changed] { animation: digit-pop 200ms ease-out; }
      @keyframes digit-pop {
        from { transform: scale(1.25); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .caption {
        position: absolute;
        bottom: -52px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 13px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.92);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint {
        position: absolute;
        bottom: -78px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 11px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.62);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid rgb(255 255 255 / 0.35);
        border-radius: 4px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        margin: 0 2px;
      }
      .cancel {
        appearance: none;
        background: rgb(255 255 255 / 0.10);
        color: rgb(255 255 255 / 0.92);
        border: 1px solid rgb(255 255 255 / 0.25);
        border-radius: 999px;
        padding: 6px 14px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        position: absolute;
        bottom: -120px;
        left: 50%;
        transform: translateX(-50%);
        transition: background 120ms ease, border-color 120ms ease;
      }
      .cancel:hover { background: rgb(255 255 255 / 0.20); border-color: rgb(255 255 255 / 0.45); }
    </style>
    <div class="scrim" role="dialog" aria-label="Recording starts soon">
      <div class="ring">
        <span class="number" data-region="number">${t}</span>
        <span class="caption">Recording starts in…</span>
        <span class="hint"><kbd>Esc</kbd> / <kbd>Space</kbd> to cancel</span>
        <button type="button" class="cancel" data-action="cancel">Cancel</button>
      </div>
    </div>
  `}let Wt=!1;const Kn=z.recordingActive;async function Eg(){if(pr()||Wt)return!1;try{const t=await chrome.runtime.sendMessage({type:"recording.open"});return t!=null&&t.ok?!0:(console.warn("[manuscript/recording] open recorder window failed:",t==null?void 0:t.error),!1)}catch(t){return console.warn("[manuscript/recording] open recorder window failed:",t),!1}}function xc(){chrome.runtime.sendMessage({type:"recording.stopRequest"}).catch(()=>{})}function je(t){Yf(t),gg()&&bg(t)}function wc(){Wt=!0,je(!0),vg({stop:xc}),Ho()}function Ag(){je(!0),Ho(),requestAnimationFrame(()=>requestAnimationFrame(()=>{chrome.runtime.sendMessage({type:"recording.uiHidden"}).catch(()=>{})}))}function Mg(){je(!0),Ho(),xg({from:3,onComplete:()=>{requestAnimationFrame(()=>requestAnimationFrame(()=>{setTimeout(()=>{chrome.runtime.sendMessage({type:"recording.countdownDone"}).catch(()=>{})},Ac)}))},onCancel:()=>{je(!1),vc(),chrome.runtime.sendMessage({type:"recording.countdownCancelled"}).catch(()=>{})}})}function $g(){Wt||(wc(),chrome.storage.local.set({[Kn]:!0}),!Y()&&L()&&Pe(0))}function Lg(){Wt&&(Wt=!1,yg(),vc(),je(!1),Y()&&Ce(),chrome.runtime.sendMessage({type:"recording.exitFullscreen"}).catch(()=>{}),chrome.storage.local.remove(Kn))}chrome.runtime.onMessage.addListener(t=>{if(!t||typeof t!="object")return;const e=t.type;e==="recording.armed"?$g():e==="recording.ended"?(Lg(),Fo()):e==="recording.togglePause"?bc():e==="recording.hideUi"?Ag():e==="recording.countdown"&&Mg()});document.addEventListener("manuscript:replay-end",()=>{Wt&&xc()});chrome.storage.local.get([Kn,z.recordingPendingArm]).then(t=>{t[Kn]&&!Wt&&wc(),t[z.recordingPendingArm]&&(chrome.storage.local.remove(z.recordingPendingArm),chrome.runtime.sendMessage({type:"recording.pageReady"}).catch(()=>{}))}).catch(()=>{});function Tg(){return Wt}function ae(){const{state:t}=k;if(!t)return;const e=L();if(!e)return;const n=e.steps[H()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;let o=0;if(r!==null){if(t.autoAdvanceResumeMs!==null)o=Math.max(0,r-t.autoAdvanceResumeMs);else if(t.subSeqResume&&(n!=null&&n.subDwellsMs)){const{idx:a,elapsedMs:i}=t.subSeqResume,s=n.subDwellsMs;let c=0;const l=a+1;for(let d=0;d<l;d++)c+=s[d]??0;o=Math.max(0,Math.min(r,c+i))}}if(Qa().then(a=>{$a({currentIndex:H(),total:e.steps.length,paused:t.paused,timerDurationMs:r,timerElapsedMs:o,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:a})}),$a({currentIndex:H(),total:e.steps.length,paused:t.paused,timerDurationMs:r,timerElapsedMs:o,steps:e.steps.map(a=>({name:a.name}))}),dr()||Tg()){const a=H(),i=e.steps[a],s=e.steps[a+1];ss({scenarioId:e.id,scenarioName:e.name,currentIndex:a,total:e.steps.length,paused:t.paused,timerElapsedMs:o,steps:e.steps.map(c=>({name:c.name})),current:i?Rn(i):null,next:s?Rn(s):null})}}async function Ig(){if(dr()){await is(),Zn(!1);return}Zn(!0),await as(),ae()}function Cg(){Zn(!1)}function Zn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function xr(t){var i,s;const{state:e}=k;if(!e)return;const n=L();if(!n)return;const r=n.steps[H()];if(ae(),!r)return;Qe(),Je();const o=H();if(qc()&&!e.paused&&e.narratedStepIndex!==o&&zc(r.description).then(c=>{c&&k.state&&H()===o&&(k.state.narratedStepIndex=o)}),!r.selectors){Le(),r.waitForNavigation||Ua(t);return}const a=new AbortController;e.pendingWait=a;try{const c=await Ds(r.selectors);if(a.signal.aborted)return;en(c),$o(c);const l=r.subElements??[];if(l.length>0){if(e.paused)return;const d=new AbortController;(i=e.subSequenceAbort)==null||i.abort(),e.subSequenceAbort=d,Dg(c,r,l,d,t).finally(()=>{var p;((p=k.state)==null?void 0:p.subSequenceAbort)===d&&(k.state.subSequenceAbort=null)});return}r.waitForNavigation?(Ls(c),kc(c,a,t.onNext)):Ua(t)}catch(c){if(a.signal.aborted)return;if(c instanceof Cs){Le(),Zf({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",c)}finally{((s=k.state)==null?void 0:s.pendingWait)===a&&(k.state.pendingWait=null)}}async function Dg(t,e,n,r,o){var f;const a=e.subDwellsMs??[],i=a[0]??0;let s=t;const c=((f=k.state)==null?void 0:f.subSeqResume)??null,l=(c==null?void 0:c.idx)??-1,d=(c==null?void 0:c.elapsedMs)??0;if(k.state&&(k.state.subSeqResume=null),l===-1){_a(-1);const h=Math.max(0,i-d);if(await Ba(h,r.signal),r.signal.aborted)return}const p=Math.max(0,l);for(let h=p;h<n.length;h++){const b=n[h];if(!b)continue;let y;try{y=await Ds(b.selectors)}catch(S){console.warn("[manuscript] sub element not resolved, skipping",S);continue}if(r.signal.aborted)return;en(y),Lo(y,{durationMs:350}),s=y,_a(h);const w=a[h+1]??0,x=h===l?Math.max(0,w-d):w;if(await Ba(x,r.signal),r.signal.aborted)return}if(k.state&&(k.state.subSeqNodeIdx=null,k.state.subSeqNodeStartMs=null),e.waitForNavigation){Ls(s),kc(s,r,o.onNext);return}const u=Ja();u&&(await Promise.race([u,new Promise(h=>{r.signal.aborted?h():r.signal.addEventListener("abort",()=>h(),{once:!0})})]),r.signal.aborted)||!k.state||k.state.paused||o.onNext()}function _a(t){const{state:e}=k;e&&(e.subSeqNodeIdx=t,e.subSeqNodeStartMs=Date.now())}function Ba(t,e){return t<=0?Promise.resolve():new Promise(n=>{const r=window.setTimeout(()=>n(),t);e.addEventListener("abort",()=>{window.clearTimeout(r),n()},{once:!0})})}function kc(t,e,n){if(!k.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!k.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function Ua(t){var c;const{state:e}=k;if(!e||e.paused)return;const n=L();if(!n)return;const r=H(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(c=e.autoAdvanceAbort)==null||c.abort();const a=new AbortController;e.autoAdvanceAbort=a;const i=e.autoAdvanceResumeMs;e.autoAdvanceResumeMs=null;const s=i??o.autoAdvanceMs;e.autoAdvanceDeadlineMs=s&&s>0?Date.now()+s:null,(async()=>{const l=[],d=Ja();d&&l.push(d),s&&s>0&&l.push(new Promise(p=>{const u=window.setTimeout(()=>{k.state&&k.state.autoAdvanceTimer===u&&(k.state.autoAdvanceTimer=null),p()},s);k.state&&(k.state.autoAdvanceTimer=u),a.signal.addEventListener("abort",()=>{window.clearTimeout(u),p()})})),l.length!==0&&(await Promise.race([Promise.all(l).then(()=>{}),new Promise(p=>{a.signal.aborted?p():a.signal.addEventListener("abort",()=>p(),{once:!0})})]),!a.signal.aborted&&(!k.state||k.state.paused||H()===r&&t.onNext()))})()}function wr(t={}){var n,r,o;const{state:e}=k;if(e){if(t.pauseTts){if(e.subSeqNodeIdx!==null&&e.subSeqNodeStartMs!==null){const a=Math.max(0,Date.now()-e.subSeqNodeStartMs);e.subSeqResume={idx:e.subSeqNodeIdx,elapsedMs:a}}if(e.autoAdvanceDeadlineMs!==null){const a=Math.max(0,e.autoAdvanceDeadlineMs-Date.now());e.autoAdvanceResumeMs=a>0?a:null}}else e.subSeqResume=null,e.autoAdvanceResumeMs=null,e.narratedStepIndex=null;e.subSeqNodeIdx=null,e.subSeqNodeStartMs=null,e.autoAdvanceDeadlineMs=null,e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(n=e.autoAdvanceAbort)==null||n.abort(),e.autoAdvanceAbort=null,(r=e.pendingWait)==null||r.abort(),e.pendingWait=null,(o=e.subSequenceAbort)==null||o.abort(),e.subSequenceAbort=null,t.pauseTts?_c():ti()}}const kr={onNext:()=>void We(),onExit:()=>void Ce()};async function Pe(t=0,e={}){if(k.state)return;const n=L();if(!n||n.steps.length===0||e.standalone!==!0&&!(await Is(n.id,t,!0)).ok)return;k.state={originalStepIndex:H(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,subSequenceAbort:null,subSeqNodeIdx:null,subSeqNodeStartMs:null,subSeqResume:null,autoAdvanceDeadlineMs:null,autoAdvanceResumeMs:null,narratedStepIndex:null,atEnd:!1,standalone:e.standalone===!0,dirtyStepIndex:null},P("replay"),Wf({onPrev:Qn,onNext:We,onTogglePause:Ge,onExit:Ce,onStepSelect:o=>void qo(o),onTogglePrompter:()=>void Ig(),onToggleTts:()=>void Pg()}),dr()&&Zn(!0),th({onNext:()=>void We(),onPrev:()=>void Qn(),onTogglePause:Ge,onExit:()=>void Ce()}),k.unsubscribeStep=De(ae);const r=Math.min(Math.max(0,t),n.steps.length-1);Lt(r),await Co(),await xr(kr)}async function Sr(t){if(!k.state)return;const e=L();e&&(t<0||t>=e.steps.length||(wr(),Qe(),Je(),k.state.atEnd=!1,k.state.dirtyStepIndex=null,!await nh(e,t)&&(Lt(t),await Co(),await xr(kr))))}function nn(){const{state:t}=k;t&&(t.dirtyStepIndex=H())}async function qo(t){t!==H()&&await Sr(t)}async function We(){const{state:t}=k;if(!t)return;const e=L();if(!e)return;const n=H();if(n>=e.steps.length-1){wr(),Qe(),Je(),t.paused=!0,t.atEnd=!0,ae(),document.dispatchEvent(new CustomEvent("manuscript:replay-end"));return}await Sr(n+1)}async function Qn(){await Sr(H()-1)}async function Pg(){const t=!await Qa();await Bc(t),t||ti(),ae()}function Ge(){const{state:t}=k;if(!t)return;if(t.atEnd&&t.paused){Rg();return}if(t.paused&&t.dirtyStepIndex===H()){t.dirtyStepIndex=null,t.paused=!1,Sr(H()),ae();return}t.paused=!t.paused,t.paused?wr({pauseTts:!0}):xr(kr),ae()}async function Rg(){if(!k.state)return;const t=L();!t||!(await Is(t.id,0,!1)).ok||k.state&&(k.state.paused=!1,k.state.atEnd=!1,Lt(0),await Co(),await xr(kr))}async function Ce(){var r;const{state:t}=k;if(!t)return;wr(),Qe(),Je(),zn(),Le(),Kf(),is(),eh(),(r=k.unsubscribeStep)==null||r.call(k),k.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;k.state=null,Lt(e),P("idle"),await Rc(),n&&(ks(),di())}function Og(t,e,n){switch(t.type){case"panel.open":return Yn(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return mc(),n({ok:!0}),!1;case"scenario.replay":return Yn(t.scenarioId).then(()=>Pe(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return Ng(t.cmd,t.index),n({ok:!0}),!1;case"prompter.edit":return Hg(t.stepIndex,t.name,t.description),n({ok:!0}),!1;case"prompter.toggleAction":return Fg(t.stepIndex),n({ok:!0}),!1;case"prompter.editStepDwell":return qg(t.stepIndex,t.ms),n({ok:!0}),!1;case"prompter.editSubDwell":return _g(t.stepIndex,t.subIndex,t.ms),n({ok:!0}),!1;case"prompter.shiftSubDwell":return zg(t.stepIndex,t.subId,t.direction),n({ok:!0}),!1;case"prompter.closed-by-user":return Hp(),Y()&&Ce(),Cg(),fc(!1),n({ok:!0}),!1;case"recording.start":return ac(),n({ok:!0}),!1;case"recording.prepare":{const r=L(),o=r?Ts(r):"";return!o||fr(o,location.href,!!(r!=null&&r.strictUrlMatch))?(n({ready:!0}),!1):(chrome.storage.local.set({[z.recordingPendingArm]:!0}),n({ready:!1}),location.href=o,!1)}case"recording.enterFullscreen":return chrome.runtime.sendMessage({type:"recording.enterFullscreen"}).catch(()=>{}),n({ok:!0}),!1;case"recording.exitFullscreen":return chrome.runtime.sendMessage({type:"recording.exitFullscreen"}).catch(()=>{}),n({ok:!0}),!1}return!1}function Ng(t,e){if(Y()){t==="prev"?Qn():t==="next"?We():t==="jump"&&typeof e=="number"?qo(e):t==="pause"&&Ge();return}const n=L();if(!n)return;const r=H();if(t==="prev")r>0&&ht(r-1),Mt();else if(t==="next")r<n.steps.length-1&&ht(r+1),Mt();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(yr(e))return;ht(e)}Mt()}else t==="pause"&&Pe(r)}function Hg(t,e,n){const r=L();if(!r)return;const o=r.steps[t];if(!o)return;const a={};e!==void 0&&(a.name=e),n!==void 0&&(a.description=n),Object.keys(a).length!==0&&(Pt(o.id,a),Y()?nn():Mt())}function Fg(t){const e=L();if(!e)return;const n=e.steps[t];n&&(Pt(n.id,{waitForNavigation:!n.waitForNavigation}),Y()?nn():Mt())}function qg(t,e){const n=L();if(!n)return;const r=n.steps[t];r&&(!Number.isFinite(e)||e<=0||(r.subDwellsMs&&r.subDwellsMs.length>1?_l(r.id,e):Pt(r.id,{autoAdvanceMs:e}),Y()?nn():Mt()))}function zg(t,e,n){const r=L();if(!r)return;const o=r.steps[t];o!=null&&o.subElements&&(ho(o.id,e,[e],n),Y()?nn():Mt())}function _g(t,e,n){const r=L();if(!r)return;const o=r.steps[t];if(!(o!=null&&o.subDwellsMs))return;const a=e+1;a<=0||a>=o.subDwellsMs.length||!Number.isFinite(n)||n<=0||(zl(o.id,a,n),Y()?nn():Mt())}async function Bg(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;if(!e||typeof e.scenarioId!="string"||e.scenarioId.length===0)return null;const n={scenarioId:e.scenarioId};return typeof e.stepIndex=="number"&&(n.stepIndex=e.stepIndex),typeof e.annotationId=="string"&&e.annotationId.length>0&&(n.annotationId=e.annotationId),n}catch{return null}}async function Ug(){try{const t=await Ka();return t?Wg()?(await chrome.storage.local.remove(z.activeReplay),!1):(P("replay"),await Yn(t.scenarioId),await Pe(t.stepIndex,{paused:t.paused===!0}),!0):!1}catch(t){return console.warn("[manuscript] resume replay failed",t),!1}}function jg(t){const e=L();if(!e)return null;for(const n of e.steps){const r=n.annotations.find(o=>o.id===t);if(r)return r}return null}function Wg(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function Gg(){try{const t=await Bg();if(!t)return;if(await Yn(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Lt(t.stepIndex),await em(),t.annotationId){const e=t.annotationId,n=(r=0)=>{const o=jg(e);if(!o||o.kind==="arrow")return;const a=pc(e,o.kind);if(a){Ve(e,a,o.kind);return}r<5&&setTimeout(()=>n(r+1),80)};n()}}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const Xg="manuscript:host",Vg="manuscript:ext",Yg="manuscript:ready";let ja=!1;function Kg(){ja||(window.addEventListener("message",Qg),ja=!0,$t(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Vt("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(Yg)))}function Zg(t){return typeof t=="object"&&t!==null&&t.source===Xg&&typeof t.type=="string"}function Vt(t,e,n){const r={source:Vg,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function Qg(t){const e=t.data;if(Zg(e))switch(e.type){case"ping":Vt("pong",e.requestId,{version:tb()});return;case"load":try{const n=Jg(e.scenario);Sl(n,{ephemeral:!0,source:{kind:"bridge",origin:t.origin||""}}),Vt("load-ack",e.requestId,{ok:!0})}catch(n){Vt("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!$f()&&ws(),Vt("play-ack",e.requestId,{ok:!0}),Pe(r,{paused:o,standalone:n}).catch(a=>{console.warn("[manuscript] startReplay failed",a)});return}case"pause":Y()&&Ge(),Vt("pause-ack",e.requestId,{ok:Y()});return;case"next":Y()&&We();return;case"prev":Y()&&Qn();return;case"jump":Y()&&typeof e.index=="number"&&qo(e.index);return;case"exit":(async()=>(Y()&&await Ce(),Vt("exit-ack",e.requestId,{ok:!0})))();return}}function Jg(t){if(t==null)throw new _o("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new _o("Invalid JSON",n)}return Bo(e,{strict:!0})}return Bo(t,{strict:!0})}function tb(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const eb=window===window.top;Ap();Uc();Gu();yp();hp();Bu();Mu();Pp();Op();var Wa,Ga;eb&&(Np().then(async()=>{await Ug()||await Gg()}),chrome.runtime.onMessage.addListener(Og),(Ga=(Wa=chrome.permissions)==null?void 0:Wa.onAdded)==null||Ga.addListener(()=>sc()),Kg());export{Od as M,Nd as V,Rt as d,ut as g,yt as m,De as o,ib as u};
