import './assets/chunk-DZo0e_kU.js';
