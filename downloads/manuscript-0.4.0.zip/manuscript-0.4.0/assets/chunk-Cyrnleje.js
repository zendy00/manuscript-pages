const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-BtjPllW8.js","assets/chunk-3M7yL2Iv.js","assets/chunk-DbUxhscj.js","assets/chunk-ClheHCf9.js","assets/chunk-A6W9uuOd.js"])))=>i.map(i=>d[i]);
import{S as X,O,E as li}from"./chunk-3M7yL2Iv.js";import{s as di,g as Wc,S as Vc,a as vo,b as ui,c as Xc,d as Gc,e as Yc,m as pi,f as Kc,h as Zc,i as Qc,j as Ko,k as Zo}from"./chunk-DbUxhscj.js";import{t as g}from"./chunk-ClheHCf9.js";import{g as fi,i as Jc,a as tl,b as hi,p as el,c as gi,s as nl,d as rl,w as ol,l as al,e as il,f as sl}from"./chunk-A6W9uuOd.js";const Yr="manuscript:mode-changed";let $n="idle";function At(){return $n}function R(t){if(t===$n)return;const e=$n;$n=t,document.dispatchEvent(new CustomEvent(Yr,{detail:{prev:e,next:t}}))}function ht(t){const e=n=>t(n.detail);return document.addEventListener(Yr,e),()=>document.removeEventListener(Yr,e)}function mi(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),a=n*(1-e),i=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,d=0;switch(r){case 0:c=n,l=s,d=a;break;case 1:c=i,l=n,d=a;break;case 2:c=a,l=n,d=s;break;case 3:c=a,l=i,d=n;break;case 4:c=s,l=a,d=n;break;case 5:c=n,l=a,d=i;break}return[Math.round(c*255),Math.round(l*255),Math.round(d*255)]}function bi(t,e,n){const r=t/255,o=e/255,a=n/255,i=Math.max(r,o,a),s=Math.min(r,o,a),c=i-s;let l=0;return c!==0&&(i===r?l=(o-a)/c%6:i===o?l=(a-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:i===0?0:c/i,v:i}}function vi(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function yi(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(a=>a+a).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(a=>!Number.isFinite(a))?{h:0,s:1,v:1}:bi(n,r,o)}function Ir(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function Qo(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function cl(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const ll=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── PALETTE E — STUDIO-DARK ─────
   Cool slate dark, mirrors PALETTE D STUDIO. See design/dark-mode-design.md §4.1.
   Chroma ≤ 0.09 doctrine maintained (focus only allowed slight excess at 0.13). */
[data-palette="studio-dark"] {
  --c-bg:        oklch(0.16  0.012 245);
  --c-surface:   oklch(0.22  0.014 245);
  --c-surface-2: oklch(0.19  0.012 245);
  --c-text:      oklch(0.97  0.003 245);
  --c-text-mute: oklch(0.78  0.006 245);
  --c-text-soft: oklch(0.62  0.008 245);
  --c-border:    oklch(0.32  0.012 245);
  --c-border-strong: oklch(0.42 0.014 245);
  --c-primary:   oklch(0.70  0.09  245);
  --c-primary-h: oklch(0.78  0.09  245);
  --c-primary-fg: oklch(0.14  0.020 245);
  --c-tint:      oklch(0.32  0.045 245);
  --c-focus:     oklch(0.74  0.13  245);
}

/* ───── PALETTE F — INK-DARK ─────
   Warm-on-cool dark, mirrors PALETTE A INK. design/dark-mode-design.md §4.2.
   Absorbs \`08.DARK-MODE-TOKENS.md\` §1 (spotlight-editor) and §2 (launcher pill) tones. */
[data-palette="ink-dark"] {
  --c-bg:        oklch(0.14  0.015 250);
  --c-surface:   oklch(0.20  0.018 250);
  --c-surface-2: oklch(0.17  0.016 250);
  --c-text:      oklch(0.98  0.003  80);
  --c-text-mute: oklch(0.76  0.006  80);
  --c-text-soft: oklch(0.60  0.008  80);
  --c-border:    oklch(0.30  0.014 250);
  --c-border-strong: oklch(0.40 0.016 250);
  --c-primary:   oklch(0.66  0.06  250);
  --c-primary-h: oklch(0.74  0.07  250);
  --c-primary-fg: oklch(0.14  0.018 250);
  --c-tint:      oklch(0.30  0.05  250);
  --c-focus:     oklch(0.70  0.10  250);
}

/* ───── Dark-palette shared overrides ─────
   Shadows: alpha ~4× because black-on-black shadow is weak; pair with
   surface-lightness steps (--c-bg < --c-surface-2 < --c-surface) for elevation.
   Functional accents: lightness ↑ for contrast on dark surface (L≈0.22). */
[data-palette$="-dark"] {
  --shadow-sm:   0 1px 2px  rgb(0 0 0 / 0.40);
  --shadow-md:   0 2px 6px  rgb(0 0 0 / 0.45), 0 1px 2px rgb(0 0 0 / 0.35);
  --shadow-lg:   0 12px 28px rgb(0 0 0 / 0.55), 0 4px 8px rgb(0 0 0 / 0.40);
  --shadow-card: 0 1px 2px  rgb(0 0 0 / 0.35),
                 0 4px 10px rgb(0 0 0 / 0.40),
                 0 12px 24px rgb(0 0 0 / 0.50);

  --c-success: oklch(0.66 0.10 150);
  --c-warning: oklch(0.78 0.11  75);
  --c-error:   oklch(0.66 0.15  27);
  --c-info:    oklch(0.66 0.09 245);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function vt(){return ll.replace(/:root\s*\{/g,":host {").replace(/\[data-palette([^\]]*)\]\s*\{/g,":host([data-palette$1]) {")}const xi="studio",dl=["studio","ink","graphite","sepia","studio-dark","ink-dark"];function wi(t){return typeof t=="string"&&dl.includes(t)}function ki(t){return t.endsWith("-dark")}let he=null;const Kr=new Set;let Jo=!1;async function ul(){if(he)return he;try{const e=(await chrome.storage.local.get(X.palette))[X.palette];if(wi(e))return he=e,e}catch{}return xi}function Si(){return he??xi}async function pl(t){he=t,Ei(t);try{await chrome.storage.local.set({[X.palette]:t})}catch{}}async function fl(){const t=Si(),e=ki(t)?"studio":"studio-dark";return await pl(e),e}function It(t){Kr.add(new WeakRef(t)),t.setAttribute("data-palette",Si()),ul().then(e=>{t.isConnected&&t.setAttribute("data-palette",e)}),hl()}function hl(){if(!Jo){Jo=!0;try{chrome.storage.onChanged.addListener((t,e)=>{var r;if(e!=="local")return;const n=(r=t[X.palette])==null?void 0:r.newValue;wi(n)&&(he=n,Ei(n))})}catch{}}}function Ei(t){for(const e of[...Kr]){const n=e.deref();n&&n.isConnected?(n.setAttribute("data-palette",t),gl(n,t)):Kr.delete(e)}}function gl(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="palette-toggle"]');n&&n.setAttribute("aria-pressed",ki(e)?"true":"false")}const ml=140,bl=140;function vl(){return`
    ${vt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${ml}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${bl}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function yl(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function xl(){return[vl(),yl()].join(`
`)}const Zr="manuscript:scenario-changed",wl=500,kl=5e3,y={scenario:null,currentStepIndex:0,saveTimer:null};function L(){return y.scenario}function W(){return y.currentStepIndex}function lt(){return y.scenario?y.scenario.steps[y.currentStepIndex]??null:null}function Ce(t){return document.addEventListener(Zr,t),()=>document.removeEventListener(Zr,t)}function N(){document.dispatchEvent(new CustomEvent(Zr)),Sl()}function G(){y.scenario&&(y.scenario.updatedAt=new Date().toISOString())}function yo(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function xo(){return{id:yo("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:kl,waitForNavigation:!1}}function Sl(){if(!y.scenario)return;y.saveTimer!==null&&window.clearTimeout(y.saveTimer);const t=y.scenario;y.saveTimer=window.setTimeout(()=>{y.saveTimer=null,di(t).catch(e=>{console.error("[manuscript] save failed",e)})},wl)}function lr(){y.saveTimer!==null&&(window.clearTimeout(y.saveTimer),y.saveTimer=null,y.scenario&&di(y.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const El=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],Al=8,$l=5;function Ml(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const i=Qr(e.getAttribute("content"));i&&t.add(i)}const n=getComputedStyle(document.documentElement);for(const i of El){const s=Qr(n.getPropertyValue(i));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:i,prop:s}of r)ta(t,i,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let i=0;i<o.length&&i<$l;i++)ta(t,o[i]??null,"background-color");const a=Array.from(t).filter(Ll).slice(0,Al);return{text:a,background:a}}function ta(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Qr(r);o&&t.add(o)}function Qr(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],a=e[3];return`#${r}${r}${o}${o}${a}${a}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=Dr(n[1]),a=Dr(n[2]),i=Dr(n[3]);return`#${Pr(o)}${Pr(a)}${Pr(i)}`}return null}function Dr(t){return Math.max(0,Math.min(255,Number(t)|0))}function Pr(t){return t.toString(16).padStart(2,"0")}function Ll(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const a=Math.max(n,r,o),i=Math.min(n,r,o);return!(a-i<12)}const Tl="'Asta Sans', sans-serif",Cl=6,Il=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function Dl(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const a=o.trim();if(!a)continue;const i=Ai(a);if(!i)continue;const s=i.toLowerCase();if(!Il.has(s)&&!e.has(s)&&(e.add(s),n.push(Ol(a)),n.length>=Cl))break}return n}function Pl(t){const e=Rl(t)??t;return e.length>14?`${e.slice(0,13)}…`:e}function Rl(t){return Ai(t)}function Ai(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function Ol(t){return/asta\s*sans/i.test(t)?t:`${t}, ${Tl}`}function ea(){lr();const t=Nl(),e=Hl();y.scenario={schemaVersion:Vc,id:yo("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[xo()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},y.currentStepIndex=0,N()}function Nl(){try{const t=Ml();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function Hl(){try{return Dl()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function na(t){lr();const e=await Wc(t);return e?(y.scenario=e,y.currentStepIndex=0,N(),!0):!1}function $i(t){lr(),y.scenario=t,y.currentStepIndex=0,N()}function zl(t){if(!y.scenario)return;const e=t.trim();!e||e===y.scenario.name||(y.scenario.name=e,y.scenario.updatedAt=new Date().toISOString(),N())}function Mi(){lr(),y.scenario=null,y.currentStepIndex=0,N()}function ra(t={}){if(!y.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>y.scenario.steps.length?y.scenario.steps.length:t.insertIndex;return y.scenario.steps.splice(e,0,xo()),G(),y.currentStepIndex=e,N(),y.currentStepIndex}function ge(t,e){if(!y.scenario)return;const n=y.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(G(),N())}function Fl(t){const e=lt();!e||!y.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,G(),N())}function _l(t){y.scenario&&(t<0||t>=y.scenario.steps.length||(y.scenario.steps.splice(t,1),y.scenario.steps.length===0?(y.scenario.steps.push(xo()),y.currentStepIndex=0):y.currentStepIndex>=y.scenario.steps.length?y.currentStepIndex=y.scenario.steps.length-1:t<y.currentStepIndex&&(y.currentStepIndex-=1),G(),N()))}function pb(t){const e=lt();if(!e||!y.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,G(),N()}function Dt(t){y.scenario&&(t<0||t>=y.scenario.steps.length||t!==y.currentStepIndex&&(y.currentStepIndex=t,N()))}function ql(t,e){if(!y.scenario||t===e||t<0||t>=y.scenario.steps.length||e<0||e>=y.scenario.steps.length)return;const[n]=y.scenario.steps.splice(t,1);n&&(y.scenario.steps.splice(e,0,n),y.currentStepIndex===t?y.currentStepIndex=e:t<y.currentStepIndex&&e>=y.currentStepIndex?y.currentStepIndex-=1:t>y.currentStepIndex&&e<=y.currentStepIndex&&(y.currentStepIndex+=1),G(),N())}function Bl(t){const e=lt();!e||!y.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),G(),N())}function en(t){const e=lt();!e||!y.scenario||(e.annotations.push(t),G(),N())}function Li(t){const e=lt();!e||!y.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),G(),N())}function P(t,e){const n=lt();!n||!y.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),G(),N())}function Ti(){var t;return((t=lt())==null?void 0:t.annotations)??[]}function D(t){return Ti().find(e=>e.id===t)}const Jr=100,Ke=2e3;function Ci(t,e){const n=t+1;if(e===null)return Array(n).fill(Ke);const r=Math.max(n*Jr,e),o=Math.floor(r/n),a=Array(n).fill(o);return a[n-1]=r-o*(n-1),a}const Ul=100;function jl(t,e,n,r,o,a=Ul){const i=t.indexOf(n);if(i<0)return{dwells:[...e]};const s=new Set(r);let c=i,l=i;if(s.has(n)){for(;c>0;){const m=t[c-1];if(!m||!s.has(m))break;c--}for(;l<t.length-1;){const m=t[l+1];if(!m||!s.has(m))break;l++}}const d=c,p=l+1,u=[...e],f=u[d]??0,h=u[p]??0;if(o===-1){if(f-a<Jr)return{dwells:u};u[d]=f-a,u[p]=h+a}else{if(h-a<Jr)return{dwells:u};u[d]=f+a,u[p]=h-a}return{dwells:u}}function Wl(t,e,n,r){const o=new Set(n),a=e[0]??Ke,i=t.map((u,f)=>({sub:u,dwell:e[f+1]??Ke})),s=i.filter(u=>o.has(u.sub));if(s.length===0)return{subs:[...t],dwells:[...e]};const c=i.filter(u=>!o.has(u.sub)),l=Math.max(0,Math.min(t.length,r));let d=0;for(let u=0;u<l;u++){const f=t[u];f!==void 0&&!o.has(f)&&d++}const p=[...c.slice(0,d),...s,...c.slice(d)];return{subs:p.map(u=>u.sub),dwells:[a,...p.map(u=>u.dwell)]}}function Vl(t){const e=lt();if(!e||!y.scenario)return null;const n={id:yo("sub"),selectors:t.selectors,thumbnailDataUrl:t.thumbnailDataUrl,pickedAtUrl:t.pickedAtUrl},r=e.subElements??[];e.subElements=[...r,n];const o=e.subElements.length;return e.waitForNavigation?e.subDwellsMs=Array(o+1).fill(Ke):e.subDwellsMs=Ci(o,e.autoAdvanceMs),G(),N(),n}function Xl(t,e){var a;if(!y.scenario)return;const n=y.scenario.steps.find(i=>i.id===t);if(!n||!((a=n.subElements)!=null&&a.length))return;const r=new Set(e),o=n.subElements.filter(i=>!r.has(i.id));o.length!==n.subElements.length&&(o.length===0?(delete n.subElements,delete n.subDwellsMs):(n.subElements=o,n.waitForNavigation?n.subDwellsMs=Array(o.length+1).fill(Ke):n.subDwellsMs=Ci(o.length,n.autoAdvanceMs)),G(),N())}function Gl(t,e,n){if(!y.scenario)return;const r=y.scenario.steps.find(i=>i.id===t);if(!(r!=null&&r.subElements))return;const o=r.subElements.findIndex(i=>i.id===e);if(o<0)return;const a=r.subElements[o];a&&(r.subElements[o]={...a,...n},G(),N())}function oa(t,e,n){if(!y.scenario)return;const r=y.scenario.steps.find(l=>l.id===t);if(!r||!r.subElements||!r.subDwellsMs||e.length===0)return;const o=r.subElements.map(l=>l.id),a=Wl(o,r.subDwellsMs,e,n),i=new Map(r.subElements.map(l=>[l.id,l])),s=[];for(const l of a.subs){const d=i.get(l);d&&s.push(d)}s.length===r.subElements.length&&s.every((l,d)=>{var p,u;return l.id===((u=(p=r.subElements)==null?void 0:p[d])==null?void 0:u.id)})||(r.subElements=s,r.subDwellsMs=a.dwells,G(),N())}function Ii(t,e,n,r){if(!y.scenario)return;const o=y.scenario.steps.find(s=>s.id===t);if(!(o!=null&&o.subElements)||!o.subDwellsMs)return;const a=o.subElements.map(s=>s.id),i=jl(a,o.subDwellsMs,e,n,r);i.dwells.every((s,c)=>{var l;return s===((l=o.subDwellsMs)==null?void 0:l[c])})||(o.subDwellsMs=i.dwells,G(),N())}function Yl(t,e){if(!y.scenario)return;const n=e.trim();if(!n)return;const r=y.scenario.customColors??{},o=r[t]??[];o.includes(n)||(y.scenario.customColors={...r,[t]:[...o,n]},G(),N())}function Kl(t,e){if(!y.scenario||!y.scenario.customColors)return;const n=y.scenario.customColors[t];!n||!n.includes(e)||(y.scenario.customColors={...y.scenario.customColors,[t]:n.filter(r=>r!==e)},G(),N())}function Zl(){return`
    <style>${xl()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Ql()}
      ${Jl()}
      ${td()}
      ${ed()}
    </div>
  `}function Ql(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Jl(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function td(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function ed(){var a,i;const t=L(),e=((a=t==null?void 0:t.customColors)==null?void 0:a.text)??[],n=((i=t==null?void 0:t.customColors)==null?void 0:i.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${fn(s)}" style="background: ${fn(s)}" aria-label="Use ${fn(s)}" title="${fn(s)}"></button>`).join("")}</div>
    </div>
  `}function fn(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function nd(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let a=n.left;a+r.width>window.innerWidth-8&&(a=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,a)}px`}let it=null,U=null,Ft=0,Qt=1,Jt=1,_t=null;function rd(t){te(),_t=t.onConfirm;const e=yi(t.initialColor);Ft=e.h,Qt=e.s,Jt=e.v,it=document.createElement("div"),it.setAttribute("data-manuscript","ui"),It(it),it.style.cssText=["position: fixed",`z-index: ${O+7}`,"pointer-events: auto"].join("; "),U=it.attachShadow({mode:"open"}),U.innerHTML=Zl(),ad(),document.body.appendChild(it),nd(it,t.anchor),nn(),document.addEventListener("mousedown",Pi,!0),document.addEventListener("keydown",Ri,!0)}function te(){it&&(document.removeEventListener("mousedown",Pi,!0),document.removeEventListener("keydown",Ri,!0),it.remove(),it=null,U=null,_t=null)}function od(){return it!==null}function nn(){if(!U)return;const t=U.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${Ft}deg, 100%, 50%)`);const e=U.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Qt*100}%`,e.style.top=`${(1-Jt)*100}%`);const n=U.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${Ft/360*100}%`);const[r,o,a]=mi(Ft,Qt,Jt),i=vi(r,o,a),s=U.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${a})`);const c=U.querySelector('[data-region="hex"]');c&&(c.textContent=i),U.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===it&&U.activeElement===l)return;const d=l.dataset.channel;d==="r"?l.value=String(r):d==="g"?l.value=String(o):d==="b"&&(l.value=String(a))})}function Di(){const[t,e,n]=mi(Ft,Qt,Jt);return vi(t,e,n)}function ad(){if(!U)return;const t=U.querySelector('[data-region="sv"]');t&&Qo(t,n=>id(t,n));const e=U.querySelector('[data-region="hue"]');e&&Qo(e,n=>sd(e,n)),U.addEventListener("input",n=>{var c,l,d;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Ir((c=U.querySelector('[data-channel="r"]'))==null?void 0:c.value),a=Ir((l=U.querySelector('[data-channel="g"]'))==null?void 0:l.value),i=Ir((d=U.querySelector('[data-channel="b"]'))==null?void 0:d.value),s=bi(o,a,i);Ft=s.h,Qt=s.s,Jt=s.v,nn()}),U.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),a=o==null?void 0:o.getAttribute("data-action");if(a==="confirm")_t==null||_t(Di()),te();else if(a==="eyedrop")cl(aa);else if(a==="recent"){const i=o==null?void 0:o.getAttribute("data-color");i&&aa(i)}})}function aa(t){const e=yi(t);Ft=e.h,Qt=e.s,Jt=e.v,nn()}function id(t,e){const n=t.getBoundingClientRect();Qt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Jt=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),nn()}function sd(t,e){const n=t.getBoundingClientRect();Ft=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,nn()}function Pi(t){if(!it)return;const e=t.target;e instanceof HTMLElement&&it.contains(e)||te()}function Ri(t){t.key==="Escape"?(t.preventDefault(),te()):t.key==="Enter"&&(t.preventDefault(),_t==null||_t(Di()),te())}const hn=8,ie=6,Oi=32,ia=16,gn=4,Ni=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function sa(t,e,n,r){let{x:o,y:a,width:i,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,i-=n):(t==="ne"||t==="e"||t==="se")&&(i+=n),t==="nw"||t==="n"||t==="ne"?(a+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),i<ie&&(o=e.x+e.width-ie,i=ie),s<ie&&(a=e.y+e.height-ie,s=ie),{x:o,y:a,width:i,height:s}}function Hi(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const a of t)a.x<e&&(e=a.x),a.y<n&&(n=a.y),a.x>r&&(r=a.x),a.y>o&&(o=a.y);return{x:e,y:n,width:r-e,height:o-n}}function cd(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const M={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},q="http://www.w3.org/2000/svg";function ld(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const a=r.tagName.toLowerCase(),i=r.parentElement,s=r.tagName;if(i){const c=Array.from(i.children).filter(l=>{var d;return l.tagName===s&&!((d=l.matches)!=null&&d.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${a}:nth-of-type(${l})`)}else n.unshift(a)}else n.unshift(a);r=i,o++}return n.join(" > ")}function dd(t,e=document,n=8){const r=[];let o=t,a=0;for(;o&&o!==document.body&&a<n;){const i=o.tagName.toLowerCase(),s=o.parentElement,c=o.tagName;if(s){const d=Array.from(s.children).filter(p=>{var u;return p.tagName===c&&!((u=p.matches)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length>1){const p=d.indexOf(o)+1;r.unshift(`${i}:nth-of-type(${p})`)}else r.unshift(i)}else r.unshift(i);const l=r.join(" > ");try{const d=Array.from(e.querySelectorAll(l)).filter(p=>{var u;return!((u=p.closest)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length===1&&d[0]===t)return l}catch{}o=s,a++}return r.join(" > ")}function wo(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function ud(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const pd=["data-testid","data-test","id","aria-label"];function fd(t){for(const e of pd){const n=t.getAttribute(e);if(n&&n.length>0){const r=`[${e}="${ud(n)}"]`;try{const o=Array.from(document.querySelectorAll(r)).filter(a=>{var i;return!((i=a.closest)!=null&&i.call(a,'[data-manuscript="ui"]'))});if(o.length===1&&o[0]===t)return{kind:"stable-attr",cssSelector:r}}catch{}}}return{kind:"stable-attr",cssSelector:dd(t)}}function Pn(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!wo(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function hd(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?ld(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Rn(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!wo(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function gd(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const a of Array.from(r.children)){if(a===t)continue;const i=(a.textContent??"").trim();if(i.length>0&&i.length<60&&n.push(i),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function On(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||wo(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const a=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>a.includes(c))?n:null}function md(t){return{layer1:fd(t),layer2:hd(t),layer3:gd(t)}}function bd(t,e){const n=e.ownerDocument;return n?Pn(t.layer1,n)===e||Rn(t.layer2,n)===e||On(t.layer3,n)===e:!1}function Se(t){var e;return((e=to(t))==null?void 0:e.el)??null}function to(t){const e=zi(t.framePath);if(!e)return null;const n=Pn(t.layer1,e);if(n)return{el:n,layer:1};const r=Rn(t.layer2,e);if(r)return{el:r,layer:2};const o=On(t.layer3,e);return o?{el:o,layer:3}:null}function zi(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function vd(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function ot(){const t=lt();if(!t||!t.selectors)return null;try{const e=Se(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function yd(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function dr(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function xd(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function ur(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function Fi(t){if(!t.bounds)return t;const e=ot();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function wd(t){if(!t.points)return t;const e=ot();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function kd(){document.removeEventListener("mousemove",ko,!0),document.removeEventListener("mouseup",So,!0),document.removeEventListener("keydown",qi,!0)}function Sd(){document.addEventListener("keydown",qi,!0)}function Ed(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=D(M.activeId);if(!n||n.kind!=="shape")return;const r=dr(n,ot());M.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},pr()}function Ad(t){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const e=D(M.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;M.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},pr()}function _i(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=D(M.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,a=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;M.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:a},pr()}function $d(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=D(M.activeId);if(!n||n.kind!=="freedraw")return;const r=ur(n,ot()),o=Hi(r);!o||o.width===0||o.height===0||(M.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(a=>({...a}))},pr())}function pr(){document.addEventListener("mousemove",ko,!0),document.addEventListener("mouseup",So,!0)}function ko(t){const{activeId:e,dragState:n}=M;if(!e||!n)return;t.preventDefault();const r=D(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,a=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const i=sa(n.handle,n.startBounds,o,a);P(e,Fi({bounds:i}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const i=n.startBounds,s=sa(n.handle,i,o,a),c=i.width===0?1:s.width/i.width,l=i.height===0?1:s.height/i.height,d=n.startPoints.map(p=>({x:s.x+(p.x-i.x)*c,y:s.y+(p.y-i.y)*l}));P(e,wd({points:d}))}else if(n.kind==="rotate"){const i=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(i-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?P(e,{rotate:s}):r.kind==="freedraw"?P(e,{rotate:s}):r.kind==="text"&&P(e,{rotate:s})}}function So(){document.removeEventListener("mousemove",ko,!0),document.removeEventListener("mouseup",So,!0),M.dragState=null}function qi(t){var o;const{activeId:e}=M;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Li(e);return}if(t.key.startsWith("Arrow")){const a=D(e);if(!a||a.kind!=="shape")return;const i=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-i:t.key==="ArrowRight"?i:0,c=t.key==="ArrowUp"?-i:t.key==="ArrowDown"?i:0;if(s!==0||c!==0){t.preventDefault();const l=dr(a,ot());P(e,Fi({bounds:{...a.bounds,x:l.x+s,y:l.y+c}}))}}}}function Bi(t,e,n,r,o){const a=document.createElementNS(q,"rect");return a.setAttribute("x",String(t-hn/2)),a.setAttribute("y",String(e-hn/2)),a.setAttribute("width",String(hn)),a.setAttribute("height",String(hn)),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),a.style.cursor=r,a.style.pointerEvents="auto",a.setAttribute("pointer-events","all"),a.addEventListener("mousedown",i=>o(i,n)),a}function Ui(t,e,n){const r=document.createElementNS(q,"g"),o=e-18,a=e-Oi,i=12,s=document.createElementNS(q,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(q,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(a+1)),c.setAttribute("r",String(i)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(q,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(a)),l.setAttribute("r",String(i)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const d=t-8,p=a-8,u=document.createElementNS(q,"path");u.setAttribute("d",`M ${d+4} ${p+11} A 5 5 0 1 1 ${d+11} ${p+4}`),u.setAttribute("fill","none"),u.setAttribute("stroke","oklch(0.48 0.085 245)"),u.setAttribute("stroke-width","1.5"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.style.pointerEvents="none",r.appendChild(u);const f=document.createElementNS(q,"path");return f.setAttribute("d",`M ${d+11} ${p+1.5} L ${d+14} ${p+4} L ${d+11} ${p+6.5} Z`),f.setAttribute("fill","oklch(0.48 0.085 245)"),f.setAttribute("stroke","oklch(0.48 0.085 245)"),f.setAttribute("stroke-width","1.5"),f.setAttribute("stroke-linejoin","round"),f.style.pointerEvents="none",r.appendChild(f),l.addEventListener("mousedown",h=>n(h)),r}function Eo(t,e){const n=document.createElementNS(q,"g"),r=t.x-ia,o=t.y-ia;return n.appendChild(Md(r,o,e)),n}function Md(t,e,n){const r=document.createElementNS(q,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(q,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const a=document.createElementNS(q,"circle");a.setAttribute("cx",String(t)),a.setAttribute("cy",String(e)),a.setAttribute("r","12"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.92 0.008 240)"),a.setAttribute("stroke-width","1"),r.appendChild(a);const i=t-6,s=e-6,c=document.createElementNS(q,"path");return c.setAttribute("d",[`M ${i+1.5} ${s+3.5} L ${i+10.5} ${s+3.5}`,`M ${i+4.5} ${s+3.5} L ${i+4.5} ${s+2} L ${i+7.5} ${s+2} L ${i+7.5} ${s+3.5}`,`M ${i+3} ${s+3.5} L ${i+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${i+4.3} ${s+11} L ${i+7.7} ${s+11} A 0.8 0.8 0 0 0 ${i+8.5} ${s+10.5} L ${i+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function Ao(t){const e=document.createElementNS(q,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function fr(){const{host:t,activeId:e,activeMode:n}=M;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=D(e);if(!r){eo();return}if(n==="freedraw"&&r.kind==="freedraw"){Id(t,r);return}if(n==="text"&&r.kind==="text"){Cd(t,r);return}if(r.kind!=="shape"){eo();return}Ld(t,r)}function Ld(t,e){const n=dr(e,ot()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,a=r.x+r.width/2,i=r.y+r.height/2,s=document.createElementNS(q,"g");o&&s.setAttribute("transform",`rotate(${o} ${a} ${i})`),s.appendChild(Ao(r));for(const c of Ni){const{x:l,y:d}=c.offset(r);s.appendChild(Bi(l,d,c.name,c.cursor,Ed))}s.appendChild(Td(r)),t.appendChild(s),t.appendChild(Eo(r,$o))}function Td(t){const e=t.x+t.width/2,n=t.y-Oi,r=document.createElementNS(q,"g"),o=document.createElementNS(q,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const a=document.createElementNS(q,"g");a.style.cursor="grab",a.style.pointerEvents="auto",a.setAttribute("pointer-events","all");const i=document.createElementNS(q,"circle");i.setAttribute("cx",String(e)),i.setAttribute("cy",String(n)),i.setAttribute("r","9"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),a.appendChild(i);const s=document.createElementNS(q,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",a.appendChild(s),a.addEventListener("mousedown",c=>Ad(c)),r.appendChild(a),r}function Cd(t,e){const n=cd(e.id);if(!n)return;const r=ji(n),o=r.x+r.width/2,a=r.y+r.height/2;t.appendChild(Ao(r)),t.appendChild(Ui(o,r.y,i=>_i(i,()=>({x:o,y:a})))),t.appendChild(Eo(r,$o))}function Id(t,e){const n=ur(e,ot()),r=Hi(n);if(!r)return;const o=ji(r),a=o.x+o.width/2,i=o.y+o.height/2;t.appendChild(Ao(o));for(const s of Ni){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(Bi(c,l,s.name,s.cursor,$d))}t.appendChild(Ui(a,o.y,s=>_i(s,()=>({x:a,y:i})))),t.appendChild(Eo(o,$o))}function ji(t){return{x:t.x-gn,y:t.y-gn,width:t.width+gn*2,height:t.height+gn*2}}function $o(){const t=M.activeId;t&&Li(t)}function Dd(t){const e=D(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const a=document.querySelectorAll(o);if(a.length===0)return;const i=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;a.forEach(s=>{s.style.animation=""}),a[0].getBoundingClientRect(),a.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${i}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function Pd(t){const e=D(t);!e||e.kind!=="shape"||(M.activeId=t,M.activeMode="shape",Mo(),fr())}function Rd(t){const e=D(t);!e||e.kind!=="freedraw"||(M.activeId=t,M.activeMode="freedraw",Mo(),fr())}function Od(t){const e=D(t);!e||e.kind!=="text"||(M.activeId=t,M.activeMode="text",Mo(),fr())}function eo(){var t;M.host&&(kd(),(t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,M.host.remove(),M.host=null,M.activeId=null,M.activeMode="shape",M.dragState=null)}function Nd(t){return M.host!==null&&t!==null&&M.host.contains(t)}function Mo(){if(M.host)return;const t=document.createElementNS(q,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),M.host=t,Sd(),M.unsubscribeScenario=Ce(fr)}const Hd=400,zd=0;function Fd(t){return{kind:t,durationMs:Hd,delayMs:zd}}function _d(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const ca=10,qd=46,Wi=12,Vi=36,Xi=0,Gi=20,Bd=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],Ud=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],la=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}];function jd(t){return!t||t.length===0?[...la]:[...t.map(e=>({label:Pl(e),value:e})),...la]}const Wd=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],$={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function xt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Yi(t){const e=$.activeId;if(!e)return;const n=D(e);n&&(n.kind==="text"?P(e,{style:{...n.style,color:t}}):n.kind==="shape"?P(e,{stroke:t}):n.kind==="freedraw"&&P(e,{stroke:t}))}function Ki(t){const e=$.activeId;if(!e)return;const n=D(e);n&&(n.kind==="text"?P(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&P(e,{fill:t}))}function Zi(t){const e=$.activeId;if(!e)return;const n=D(e);!n||n.kind!=="text"||P(e,{style:{...n.style,borderColor:t}})}function Vd(t){const e=$.activeId;if(!e)return;const n=D(e);!n||n.kind!=="text"||P(e,{style:{...n.style,fontFamily:t}})}function Xd(t){const e=$.activeId;if(!e)return;const n=D(e);!n||n.kind!=="text"||P(e,{style:{...n.style,fontSize:t}})}function Gd(){const t=$.activeId;if(!t)return;const e=D(t);!e||e.kind!=="text"||P(t,{style:{...e.style,bold:!e.style.bold}})}function Yd(){const t=$.activeId;if(!t)return;const e=D(t);!e||e.kind!=="text"||P(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Kd(t){const e=$.activeId;e&&P(e,{entryAnimation:t==="none"?void 0:Fd(t)})}function Zd(t){const e=$.activeId;if(!e)return;const n=D(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?P(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?P(e,{fillOpacity:r}):n.kind==="freedraw"&&P(e,{strokeOpacity:r})}function Qd(t){const e=$.activeId;if(!e)return;const n=D(e);n&&(n.kind==="shape"?P(e,{strokeWidth:t}):n.kind==="freedraw"&&P(e,{strokeWidth:t}))}function Jd(){const{shadow:t}=$;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=i=>{r&&Rr(e,i.clientX)},a=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",a,!0)};n.addEventListener("mousedown",i=>{r=!0,Rr(e,i.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0),i.preventDefault()}),e.addEventListener("mousedown",i=>{const s=i.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(Rr(e,i.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0))})}function Rr(t,e){const n=t.getBoundingClientRect();Zd(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function no(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function tu(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function Or(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function Nr(t,e,n){var l,d,p;const r=$.swatchMode==="muted"?Bd:Ud,o=[];if(n&&(t==="bg"||t==="border")){const u=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${u}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let u=0;u<r.length;u++){const f=r[u];if(!f)continue;const h=u===1,m=Or(e,f.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${f.resolved}" style="background:${f.resolved}" aria-pressed="${m}" title="${t} ${f.resolved}"></button>
    `)}const a=L(),i=(t==="text"||t==="border"?(l=a==null?void 0:a.siteColors)==null?void 0:l.text:(d=a==null?void 0:a.siteColors)==null?void 0:d.background)??[];for(const u of i){const f=Or(e,u);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${xt(u)}" style="background:${xt(u)}" aria-pressed="${f}" title="Site color ${xt(u)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((p=a==null?void 0:a.customColors)==null?void 0:p[s])??[];for(const u of c){const f=Or(e,u);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${xt(u)}" style="background:${xt(u)}" aria-pressed="${f}" title="Custom ${xt(u)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${xt(u)}" title="Remove" aria-label="Remove color ${xt(u)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function Lo(){const{shadow:t,activeId:e,activeKind:n}=$;if(!t||!e||!n)return;const r=D(e);if(!r||r.kind==="arrow")return;const o=r,a=t.querySelector('[data-region="caption"]');a&&(a.textContent=su(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(i=>{const s=i.getAttribute("data-mode");i.setAttribute("aria-pressed",String(s===$.swatchMode))}),eu(t,n),nu(t,n,o),ru(t,n,o),ou(t,n,o),au(t,o),iu(t,o)}function eu(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const a=t.querySelector('[data-region="width-row"]'),i=e==="shape"||e==="freedraw";a&&(a.hidden=!i);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const d=t.querySelector('[data-region="bg-label"]');d&&(d.textContent=e==="text"?"Bg":"Fill")}function nu(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const a=t.querySelector('[data-region="bold"]');a&&a.setAttribute("aria-pressed",String(n.style.bold));const i=t.querySelector('[data-region="italic"]');i&&i.setAttribute("aria-pressed",String(n.style.italic===!0))}function ru(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),a=n.strokeWidth;r&&(r.value=String(a)),o&&(o.textContent=String(a))}function ou(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),a=t.querySelector('[data-region="border-swatches"]'),i=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=no(n,"text"),l=no(n,"bg");if(r&&(r.innerHTML=Nr("text",c,!1)),o&&!(i!=null&&i.hidden)&&(o.innerHTML=Nr("bg",l,e==="text")),a&&!(s!=null&&s.hidden)&&n.kind==="text"){const d=n.style.borderColor??"#000000";a.innerHTML=Nr("border",d,!0)}}function au(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=_d(e))}function iu(t,e){const n=Math.round(tu(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),a=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),a&&(a.textContent=`${n}%`)}function su(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function cu(t){const{shadow:e,host:n}=$;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>lu(o)),e.addEventListener("change",o=>du(o)),e.addEventListener("input",o=>uu(o)),Jd(),document.addEventListener("mousedown",o=>fu(o,t),!0),document.addEventListener("keydown",o=>hu(o,t),!0)}function lu(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&($.swatchMode=c,Lo());return}if(e.closest('[data-region="bold"]'))return Gd();if(e.closest('[data-region="italic"]'))return Yd();if(e.closest('[data-region="effect-play"]')){$.activeId&&Dd($.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return Yi(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return Ki(o.getAttribute("data-value")??"");const a=e.closest('[data-swatch="border"]');if(a)return Zi(a.getAttribute("data-value")??"");const i=e.closest('[data-action="more-colors"]');if(i instanceof HTMLElement)return pu(i);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&Kl(c==="text"||c==="border"?"text":"background",l)}}function du(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Vd(e.value):e.dataset.region==="effect"&&Kd(e.value))}function uu(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(Wi,Math.min(Vi,Number(e.value)||16));Xd(n)}else if(e.dataset.region==="width"){const n=Math.max(Xi,Math.min(Gi,Number(e.value)||0));Qd(n)}}}function pu(t){const{activeId:e,activeKind:n}=$;if(!e||!n)return;const r=D(e);if(!r||r.kind==="arrow")return;const o=r,a=t.getAttribute("data-slot");if(!a)return;const i=no(o,a)||"#ffffff";rd({anchor:t,initialColor:i,onConfirm:s=>{Yl(a==="text"||a==="border"?"text":"background",s),a==="text"?Yi(s):a==="border"?Zi(s):Ki(s)}})}function fu(t,e){const{host:n,activeAnchorSelector:r}=$,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||Nd(o)||od()||r&&o instanceof Element&&o.closest(r)||(e(),te())}function hu(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function Qi(t){const{host:e}=$;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-ca-qd;o<8&&(o=r.bottom+ca);const a=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${a}px`}function gu(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function mu(t,e){t==="text"?Od(e):t==="shape"?Pd(e):Rd(e)}function bu(){return`
    ${vt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function vu(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function yu(){return[bu(),vu()].join(`
`)}function xu(){return`
    <style>${yu()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${wu()}
      ${ku()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${Su()}
      <div class="divider"></div>
      ${Eu()}
      ${Au()}
      ${$u()}
      ${Mu()}
    </div>
  `}function wu(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function ku(){var e;return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${jd((e=L())==null?void 0:e.siteFonts).map(n=>`<option value="${xt(n.value)}" style="font-family: ${xt(n.value)};">${n.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${Wi}" max="${Vi}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function Su(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function Eu(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${Xi}" max="${Gi}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function Au(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Wd.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function $u(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function Mu(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function To(t,e,n){D(t)&&($.activeId=t,$.activeKind=n,$.activeAnchorSelector=gu(n,t),$.host||Du(),Lo(),Qi(e),mu(n,t))}function Co(){var t;$.host&&((t=$.unsubscribeScenario)==null||t.call($),$.unsubscribeScenario=null,te(),eo(),$.host.remove(),$.host=null,$.shadow=null,$.activeId=null,$.activeKind=null,$.activeAnchorSelector=null)}function Lu(){return $.activeId}function Tu(t,e){To(t,e,"text")}function Ji(){Co()}function Cu(t,e){To(t,e,"shape")}function Iu(t,e){To(t,e,"freedraw")}function Du(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),It(t),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=xu(),$.host=t,$.shadow=e,document.body.appendChild(t),cu(Co),$.unsubscribeScenario=Ce(Pu)}function Pu(){const{activeId:t,host:e,activeAnchorSelector:n}=$;if(!t||!e)return;if(!D(t)){Co();return}if(Lo(),n){const o=document.querySelector(n);o&&Qi(o)}}const Et=20;let Nn=null,da=!1;function Ru(){da||(da=!0,document.addEventListener("keydown",Hu,!0)),Ou()}async function Ou(){try{const e=(await chrome.storage.local.get(X.annotationClipboard))[X.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(Nn=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function Nu(t){try{await chrome.storage.local.set({[X.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function Hu(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||At()!=="replay"&&(zu()||(e==="c"?Fu(t):_u(t)))}function zu(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function Fu(t){const e=Lu();if(!e)return;const n=D(e);n&&(Nn=n,Nu(n),t.preventDefault())}function _u(t){if(!Nn||!lt())return;const e=qu(Nn);en(e),t.preventDefault()}function qu(t){switch(t.kind){case"text":return Bu(t);case"shape":return Uu(t);case"freedraw":return ju(t);case"arrow":return Wu(t)}}function Bu(t){return{...t,id:hr("text"),position:{x:t.position.x+Et,y:t.position.y+Et},style:{...t.style}}}function Uu(t){return{...t,id:hr("shape"),bounds:{...t.bounds,x:t.bounds.x+Et,y:t.bounds.y+Et}}}function ju(t){return{...t,id:hr("freedraw"),points:t.points.map(e=>({x:e.x+Et,y:e.y+Et}))}}function Wu(t){return{...t,id:hr("arrow"),from:{x:t.from.x+Et,y:t.from.y+Et},to:{x:t.to.x+Et,y:t.to.y+Et}}}function hr(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Hr(t,e,n){if(t&&t.length){const[r,o]=e,a=Math.PI/180*n,i=Math.cos(a),s=Math.sin(a);for(const c of t){const[l,d]=c;c[0]=(l-r)*i-(d-o)*s+r,c[1]=(l-r)*s+(d-o)*i+o}}}function Vu(t,e){return t[0]===e[0]&&t[1]===e[1]}function Xu(t,e,n,r=1){const o=n,a=Math.max(e,.1),i=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of i)Hr(l,s,o);const c=(function(l,d,p){const u=[];for(const x of l){const S=[...x];Vu(S[0],S[S.length-1])||S.push([S[0][0],S[0][1]]),S.length>2&&u.push(S)}const f=[];d=Math.max(d,.1);const h=[];for(const x of u)for(let S=0;S<x.length-1;S++){const z=x[S],H=x[S+1];if(z[1]!==H[1]){const C=Math.min(z[1],H[1]);h.push({ymin:C,ymax:Math.max(z[1],H[1]),x:C===z[1]?z[0]:H[0],islope:(H[0]-z[0])/(H[1]-z[1])})}}if(h.sort(((x,S)=>x.ymin<S.ymin?-1:x.ymin>S.ymin?1:x.x<S.x?-1:x.x>S.x?1:x.ymax===S.ymax?0:(x.ymax-S.ymax)/Math.abs(x.ymax-S.ymax))),!h.length)return f;let m=[],v=h[0].ymin,w=0;for(;m.length||h.length;){if(h.length){let x=-1;for(let S=0;S<h.length&&!(h[S].ymin>v);S++)x=S;h.splice(0,x+1).forEach((S=>{m.push({s:v,edge:S})}))}if(m=m.filter((x=>!(x.edge.ymax<=v))),m.sort(((x,S)=>x.edge.x===S.edge.x?0:(x.edge.x-S.edge.x)/Math.abs(x.edge.x-S.edge.x))),(p!==1||w%d==0)&&m.length>1)for(let x=0;x<m.length;x+=2){const S=x+1;if(S>=m.length)break;const z=m[x].edge,H=m[S].edge;f.push([[Math.round(z.x),v],[Math.round(H.x),v]])}v+=p,m.forEach((x=>{x.edge.x=x.edge.x+p*x.edge.islope})),w++}return f})(i,a,r);if(o){for(const l of i)Hr(l,s,-o);(function(l,d,p){const u=[];l.forEach((f=>u.push(...f))),Hr(u,d,p)})(c,s,-o)}return c}function rn(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let a=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(a=o),Xu(t,o,r,a||1)}class Io{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=rn(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function gr(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Gu extends Io{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=rn(e,Object.assign({},n,{hachureGap:r})),a=Math.PI/180*n.hachureAngle,i=[],s=.5*r*Math.cos(a),c=.5*r*Math.sin(a);for(const[l,d]of o)gr([l,d])&&i.push([[l[0]-s,l[1]+c],[...d]],[[l[0]+s,l[1]-c],[...d]]);return{type:"fillSketch",ops:this.renderLines(i,n)}}}class Yu extends Io{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),a=this._fillPolygons(e,o);return r.ops=r.ops.concat(a.ops),r}}class Ku{constructor(e){this.helper=e}fillPolygons(e,n){const r=rn(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let a=n.fillWeight;a<0&&(a=n.strokeWidth/2);const i=o/4;for(const s of e){const c=gr(s),l=c/o,d=Math.ceil(l)-1,p=c-d*o,u=(s[0][0]+s[1][0])/2-o/4,f=Math.min(s[0][1],s[1][1]);for(let h=0;h<d;h++){const m=f+p+h*o,v=u-i+2*Math.random()*i,w=m-i+2*Math.random()*i,x=this.helper.ellipse(v,w,a,a,n);r.push(...x.ops)}}return{type:"fillSketch",ops:r}}}class Zu{constructor(e){this.helper=e}fillPolygons(e,n){const r=rn(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,a=[];return e.forEach((i=>{const s=gr(i),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let d=i[0],p=i[1];d[0]>p[0]&&(d=i[1],p=i[0]);const u=Math.atan((p[1]-d[1])/(p[0]-d[0]));for(let f=0;f<c;f++){const h=f*(r+o),m=h+r,v=[d[0]+h*Math.cos(u)+l*Math.cos(u),d[1]+h*Math.sin(u)+l*Math.sin(u)],w=[d[0]+m*Math.cos(u)+l*Math.cos(u),d[1]+m*Math.sin(u)+l*Math.sin(u)];a.push(...this.helper.doubleLineOps(v[0],v[1],w[0],w[1],n))}})),a}}class Qu{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,a=rn(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(a,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((a=>{const i=gr(a),s=Math.round(i/(2*n));let c=a[0],l=a[1];c[0]>l[0]&&(c=a[1],l=a[0]);const d=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let p=0;p<s;p++){const u=2*p*n,f=2*(p+1)*n,h=Math.sqrt(2*Math.pow(n,2)),m=[c[0]+u*Math.cos(d),c[1]+u*Math.sin(d)],v=[c[0]+f*Math.cos(d),c[1]+f*Math.sin(d)],w=[m[0]+h*Math.cos(d+Math.PI/4),m[1]+h*Math.sin(d+Math.PI/4)];o.push(...this.helper.doubleLineOps(m[0],m[1],w[0],w[1],r),...this.helper.doubleLineOps(w[0],w[1],v[0],v[1],r))}})),o}}const at={};class Ju{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const tp=0,zr=1,ua=2,mn={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Fr(t,e){return t.type===e}function Do(t){const e=[],n=(function(i){const s=new Array;for(;i!=="";)if(i.match(/^([ \t\r\n,]+)/))i=i.substr(RegExp.$1.length);else if(i.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:tp,text:RegExp.$1},i=i.substr(RegExp.$1.length);else{if(!i.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:zr,text:`${parseFloat(RegExp.$1)}`},i=i.substr(RegExp.$1.length)}return s[s.length]={type:ua,text:""},s})(t);let r="BOD",o=0,a=n[o];for(;!Fr(a,ua);){let i=0;const s=[];if(r==="BOD"){if(a.text!=="M"&&a.text!=="m")return Do("M0,0"+t);o++,i=mn[a.text],r=a.text}else Fr(a,zr)?i=mn[r]:(o++,i=mn[a.text],r=a.text);if(!(o+i<n.length))throw new Error("Path data ended short");for(let c=o;c<o+i;c++){const l=n[c];if(!Fr(l,zr))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof mn[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=i,a=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function ts(t){let e=0,n=0,r=0,o=0;const a=[];for(const{key:i,data:s}of t)switch(i){case"M":a.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],a.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":a.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],a.push({key:"L",data:[e,n]});break;case"C":a.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":a.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":a.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],a.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":a.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],a.push({key:"H",data:[e]});break;case"V":a.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],a.push({key:"V",data:[n]});break;case"S":a.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":a.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],a.push({key:"T",data:[e,n]});break;case"Z":case"z":a.push({key:"Z",data:[]}),e=r,n=o}return a}function es(t){const e=[];let n="",r=0,o=0,a=0,i=0,s=0,c=0;for(const{key:l,data:d}of t){switch(l){case"M":e.push({key:"M",data:[...d]}),[r,o]=d,[a,i]=d;break;case"C":e.push({key:"C",data:[...d]}),r=d[4],o=d[5],s=d[2],c=d[3];break;case"L":e.push({key:"L",data:[...d]}),[r,o]=d;break;case"H":r=d[0],e.push({key:"L",data:[r,o]});break;case"V":o=d[0],e.push({key:"L",data:[r,o]});break;case"S":{let p=0,u=0;n==="C"||n==="S"?(p=r+(r-s),u=o+(o-c)):(p=r,u=o),e.push({key:"C",data:[p,u,...d]}),s=d[0],c=d[1],r=d[2],o=d[3];break}case"T":{const[p,u]=d;let f=0,h=0;n==="Q"||n==="T"?(f=r+(r-s),h=o+(o-c)):(f=r,h=o);const m=r+2*(f-r)/3,v=o+2*(h-o)/3,w=p+2*(f-p)/3,x=u+2*(h-u)/3;e.push({key:"C",data:[m,v,w,x,p,u]}),s=f,c=h,r=p,o=u;break}case"Q":{const[p,u,f,h]=d,m=r+2*(p-r)/3,v=o+2*(u-o)/3,w=f+2*(p-f)/3,x=h+2*(u-h)/3;e.push({key:"C",data:[m,v,w,x,f,h]}),s=p,c=u,r=f,o=h;break}case"A":{const p=Math.abs(d[0]),u=Math.abs(d[1]),f=d[2],h=d[3],m=d[4],v=d[5],w=d[6];p===0||u===0?(e.push({key:"C",data:[r,o,v,w,v,w]}),r=v,o=w):(r!==v||o!==w)&&(ns(r,o,v,w,p,u,f,h,m).forEach((function(x){e.push({key:"C",data:x})})),r=v,o=w);break}case"Z":e.push({key:"Z",data:[]}),r=a,o=i}n=l}return e}function Pe(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function ns(t,e,n,r,o,a,i,s,c,l){const d=(p=i,Math.PI*p/180);var p;let u=[],f=0,h=0,m=0,v=0;if(l)[f,h,m,v]=l;else{[t,e]=Pe(t,e,-d),[n,r]=Pe(n,r,-d);const tt=(t-n)/2,F=(e-r)/2;let yt=tt*tt/(o*o)+F*F/(a*a);yt>1&&(yt=Math.sqrt(yt),o*=yt,a*=yt);const oe=o*o,ae=a*a,Uc=oe*ae-oe*F*F-ae*tt*tt,jc=oe*F*F+ae*tt*tt,Yo=(s===c?-1:1)*Math.sqrt(Math.abs(Uc/jc));m=Yo*o*F/a+(t+n)/2,v=Yo*-a*tt/o+(e+r)/2,f=Math.asin(parseFloat(((e-v)/a).toFixed(9))),h=Math.asin(parseFloat(((r-v)/a).toFixed(9))),t<m&&(f=Math.PI-f),n<m&&(h=Math.PI-h),f<0&&(f=2*Math.PI+f),h<0&&(h=2*Math.PI+h),c&&f>h&&(f-=2*Math.PI),!c&&h>f&&(h-=2*Math.PI)}let w=h-f;if(Math.abs(w)>120*Math.PI/180){const tt=h,F=n,yt=r;h=c&&h>f?f+120*Math.PI/180*1:f+120*Math.PI/180*-1,u=ns(n=m+o*Math.cos(h),r=v+a*Math.sin(h),F,yt,o,a,i,0,c,[h,tt,m,v])}w=h-f;const x=Math.cos(f),S=Math.sin(f),z=Math.cos(h),H=Math.sin(h),C=Math.tan(w/4),Y=4/3*o*C,J=4/3*a*C,re=[t,e],st=[t+Y*S,e-J*x],$t=[n+Y*H,r-J*z],pn=[n,r];if(st[0]=2*re[0]-st[0],st[1]=2*re[1]-st[1],l)return[st,$t,pn].concat(u);{u=[st,$t,pn].concat(u);const tt=[];for(let F=0;F<u.length;F+=3){const yt=Pe(u[F][0],u[F][1],d),oe=Pe(u[F+1][0],u[F+1][1],d),ae=Pe(u[F+2][0],u[F+2][1],d);tt.push([yt[0],yt[1],oe[0],oe[1],ae[0],ae[1]])}return tt}}const ep={randOffset:function(t,e){return k(t,e)},randOffsetWithRange:function(t,e,n){return Hn(t,e,n)},ellipse:function(t,e,n,r,o){const a=os(n,r,o);return ro(t,e,o,a).opset},doubleLineOps:function(t,e,n,r,o){return Bt(t,e,n,r,o,!0)}};function rs(t,e,n,r,o){return{type:"path",ops:Bt(t,e,n,r,o)}}function Mn(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let a=0;a<r-1;a++)o.push(...Bt(t[a][0],t[a][1],t[a+1][0],t[a+1][1],n));return e&&o.push(...Bt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?rs(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function np(t,e,n,r,o){return(function(a,i){return Mn(a,!0,i)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function pa(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=bn(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:bn(n[0],1.5*(1+.22*e.roughness),ga(e));for(let a=1;a<n.length;a++){const i=n[a];if(i.length){const s=bn(i,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:bn(i,1.5*(1+.22*e.roughness),ga(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function os(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),a=2*Math.PI/o;let i=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return i+=k(i*c,n),s+=k(s*c,n),{increment:a,rx:i,ry:s}}function ro(t,e,n,r){const[o,a]=ma(r.increment,t,e,r.rx,r.ry,1,r.increment*Hn(.1,Hn(.4,1,n),n),n);let i=zn(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=ma(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=zn(s,null,n);i=i.concat(c)}return{estimatedPoints:a,opset:{type:"path",ops:i}}}function fa(t,e,n,r,o,a,i,s,c){const l=t,d=e;let p=Math.abs(n/2),u=Math.abs(r/2);p+=k(.01*p,c),u+=k(.01*u,c);let f=o,h=a;for(;f<0;)f+=2*Math.PI,h+=2*Math.PI;h-f>2*Math.PI&&(f=0,h=2*Math.PI);const m=2*Math.PI/c.curveStepCount,v=Math.min(m/2,(h-f)/2),w=ba(v,l,d,p,u,f,h,1,c);if(!c.disableMultiStroke){const x=ba(v,l,d,p,u,f,h,1.5,c);w.push(...x)}return i&&(s?w.push(...Bt(l,d,l+p*Math.cos(f),d+u*Math.sin(f),c),...Bt(l,d,l+p*Math.cos(h),d+u*Math.sin(h),c)):w.push({op:"lineTo",data:[l,d]},{op:"lineTo",data:[l+p*Math.cos(f),d+u*Math.sin(f)]})),{type:"path",ops:w}}function ha(t,e){const n=es(ts(Do(t))),r=[];let o=[0,0],a=[0,0];for(const{key:i,data:s}of n)switch(i){case"M":a=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...Bt(a[0],a[1],s[0],s[1],e)),a=[s[0],s[1]];break;case"C":{const[c,l,d,p,u,f]=s;r.push(...rp(c,l,d,p,u,f,a,e)),a=[u,f];break}case"Z":r.push(...Bt(a[0],a[1],o[0],o[1],e)),a=[o[0],o[1]]}return{type:"path",ops:r}}function _r(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,a=r.length;if(a>2){n.push({op:"move",data:[r[0][0]+k(o,e),r[0][1]+k(o,e)]});for(let i=1;i<a;i++)n.push({op:"lineTo",data:[r[i][0]+k(o,e),r[i][1]+k(o,e)]})}}return{type:"fillPath",ops:n}}function se(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!at[o])switch(o){case"zigzag":at[o]||(at[o]=new Gu(r));break;case"cross-hatch":at[o]||(at[o]=new Yu(r));break;case"dots":at[o]||(at[o]=new Ku(r));break;case"dashed":at[o]||(at[o]=new Zu(r));break;case"zigzag-line":at[o]||(at[o]=new Qu(r));break;default:o="hachure",at[o]||(at[o]=new Io(r))}return at[o]})(e,ep).fillPolygons(t,e)}function ga(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function as(t){return t.randomizer||(t.randomizer=new Ju(t.seed||0)),t.randomizer.next()}function Hn(t,e,n,r=1){return n.roughness*r*(as(n)*(e-t)+t)}function k(t,e,n=1){return Hn(-t,t,e,n)}function Bt(t,e,n,r,o,a=!1){const i=a?o.disableMultiStrokeFill:o.disableMultiStroke,s=oo(t,e,n,r,o,!0,!1);if(i)return s;const c=oo(t,e,n,r,o,!0,!0);return s.concat(c)}function oo(t,e,n,r,o,a,i){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let d=o.maxRandomnessOffset||0;d*d*100>s&&(d=c/10);const p=d/2,u=.2+.2*as(o);let f=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;f=k(f,o,l),h=k(h,o,l);const m=[],v=()=>k(p,o,l),w=()=>k(d,o,l),x=o.preserveVertices;return i?m.push({op:"move",data:[t+(x?0:v()),e+(x?0:v())]}):m.push({op:"move",data:[t+(x?0:k(d,o,l)),e+(x?0:k(d,o,l))]}),i?m.push({op:"bcurveTo",data:[f+t+(n-t)*u+v(),h+e+(r-e)*u+v(),f+t+2*(n-t)*u+v(),h+e+2*(r-e)*u+v(),n+(x?0:v()),r+(x?0:v())]}):m.push({op:"bcurveTo",data:[f+t+(n-t)*u+w(),h+e+(r-e)*u+w(),f+t+2*(n-t)*u+w(),h+e+2*(r-e)*u+w(),n+(x?0:w()),r+(x?0:w())]}),m}function bn(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+k(e,n),t[0][1]+k(e,n)]),r.push([t[0][0]+k(e,n),t[0][1]+k(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+k(e,n),t[o][1]+k(e,n)]),o===t.length-1&&r.push([t[o][0]+k(e,n),t[o][1]+k(e,n)]);return zn(r,null,n)}function zn(t,e,n){const r=t.length,o=[];if(r>3){const a=[],i=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*t[s+1][0]-i*t[s-1][0])/6,c[1]+(i*t[s+1][1]-i*t[s-1][1])/6],a[2]=[t[s+1][0]+(i*t[s][0]-i*t[s+2][0])/6,t[s+1][1]+(i*t[s][1]-i*t[s+2][1])/6],a[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[a[1][0],a[1][1],a[2][0],a[2][1],a[3][0],a[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...oo(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function ma(t,e,n,r,o,a,i,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let d=0;d<=2*Math.PI;d+=t){const p=[e+r*Math.cos(d),n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const d=k(.5,s)-Math.PI/2;l.push([k(a,s)+e+.9*r*Math.cos(d-t),k(a,s)+n+.9*o*Math.sin(d-t)]);const p=2*Math.PI+d-.01;for(let u=d;u<p;u+=t){const f=[k(a,s)+e+r*Math.cos(u),k(a,s)+n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([k(a,s)+e+r*Math.cos(d+2*Math.PI+.5*i),k(a,s)+n+o*Math.sin(d+2*Math.PI+.5*i)]),l.push([k(a,s)+e+.98*r*Math.cos(d+i),k(a,s)+n+.98*o*Math.sin(d+i)]),l.push([k(a,s)+e+.9*r*Math.cos(d+.5*i),k(a,s)+n+.9*o*Math.sin(d+.5*i)])}return[l,c]}function ba(t,e,n,r,o,a,i,s,c){const l=a+k(.1,c),d=[];d.push([k(s,c)+e+.9*r*Math.cos(l-t),k(s,c)+n+.9*o*Math.sin(l-t)]);for(let p=l;p<=i;p+=t)d.push([k(s,c)+e+r*Math.cos(p),k(s,c)+n+o*Math.sin(p)]);return d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),zn(d,null,c)}function rp(t,e,n,r,o,a,i,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let d=[0,0];const p=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let f=0;f<p;f++)f===0?c.push({op:"move",data:[i[0],i[1]]}):c.push({op:"move",data:[i[0]+(u?0:k(l[0],s)),i[1]+(u?0:k(l[0],s))]}),d=u?[o,a]:[o+k(l[f],s),a+k(l[f],s)],c.push({op:"bcurveTo",data:[t+k(l[f],s),e+k(l[f],s),n+k(l[f],s),r+k(l[f],s),d[0],d[1]]});return c}function Re(t){return[...t]}function va(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(Re(t[0]),Re(t[1]),Re(t[2]),Re(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const a=[],i=1-e;r.push(Re(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*o[s+1][0]-i*o[s-1][0])/6,c[1]+(i*o[s+1][1]-i*o[s-1][1])/6],a[2]=[o[s+1][0]+(i*o[s][0]-i*o[s+2][0])/6,o[s+1][1]+(i*o[s][1]-i*o[s+2][1])/6],a[3]=[o[s+1][0],o[s+1][1]],r.push(a[1],a[2],a[3])}}return r}function Ln(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function op(t,e,n){const r=Ln(e,n);if(r===0)return Ln(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),Ln(t,jt(e,n,o))}function jt(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function ao(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],d=s[c+1],p=s[c+2],u=s[c+3];let f=3*d[0]-2*l[0]-u[0];f*=f;let h=3*d[1]-2*l[1]-u[1];h*=h;let m=3*p[0]-2*u[0]-l[0];m*=m;let v=3*p[1]-2*u[1]-l[1];return v*=v,f<m&&(f=m),h<v&&(h=v),f+h})(t,e)<n){const s=t[e+0];o.length?(a=o[o.length-1],i=s,Math.sqrt(Ln(a,i))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],d=t[e+2],p=t[e+3],u=jt(c,l,.5),f=jt(l,d,.5),h=jt(d,p,.5),m=jt(u,f,.5),v=jt(f,h,.5),w=jt(m,v,.5);ao([c,u,m,w],0,n,o),ao([w,v,h,p],0,n,o)}var a,i;return o}function ap(t,e){return Fn(t,0,t.length,e)}function Fn(t,e,n,r,o){const a=o||[],i=t[e],s=t[n-1];let c=0,l=1;for(let d=e+1;d<n-1;++d){const p=op(t[d],i,s);p>c&&(c=p,l=d)}return Math.sqrt(c)>r?(Fn(t,e,l+1,r,a),Fn(t,l,n,r,a)):(a.length||a.push(i),a.push(s)),a}function qr(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let a=0;a<o;a++)ao(t,3*a,e,r);return n&&n>0?Fn(r,0,r.length,n):r}const ct="none";class _n{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,a){const i=this._o(a);return this._d("line",[rs(e,n,r,o,i)],i)}rectangle(e,n,r,o,a){const i=this._o(a),s=[],c=np(e,n,r,o,i);if(i.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];i.fillStyle==="solid"?s.push(_r([l],i)):s.push(se([l],i))}return i.stroke!==ct&&s.push(c),this._d("rectangle",s,i)}ellipse(e,n,r,o,a){const i=this._o(a),s=[],c=os(r,o,i),l=ro(e,n,i,c);if(i.fill)if(i.fillStyle==="solid"){const d=ro(e,n,i,c).opset;d.type="fillPath",s.push(d)}else s.push(se([l.estimatedPoints],i));return i.stroke!==ct&&s.push(l.opset),this._d("ellipse",s,i)}circle(e,n,r,o){const a=this.ellipse(e,n,r,r,o);return a.shape="circle",a}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[Mn(e,!1,r)],r)}arc(e,n,r,o,a,i,s=!1,c){const l=this._o(c),d=[],p=fa(e,n,r,o,a,i,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const u=Object.assign({},l);u.disableMultiStroke=!0;const f=fa(e,n,r,o,a,i,!0,!1,u);f.type="fillPath",d.push(f)}else d.push((function(u,f,h,m,v,w,x){const S=u,z=f;let H=Math.abs(h/2),C=Math.abs(m/2);H+=k(.01*H,x),C+=k(.01*C,x);let Y=v,J=w;for(;Y<0;)Y+=2*Math.PI,J+=2*Math.PI;J-Y>2*Math.PI&&(Y=0,J=2*Math.PI);const re=(J-Y)/x.curveStepCount,st=[];for(let $t=Y;$t<=J;$t+=re)st.push([S+H*Math.cos($t),z+C*Math.sin($t)]);return st.push([S+H*Math.cos(J),z+C*Math.sin(J)]),st.push([S,z]),se([st],x)})(e,n,r,o,a,i,l));return l.stroke!==ct&&d.push(p),this._d("arc",d,l)}curve(e,n){const r=this._o(n),o=[],a=pa(e,r);if(r.fill&&r.fill!==ct)if(r.fillStyle==="solid"){const i=pa(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(i.ops)})}else{const i=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?i.push(...l):l.length===3?i.push(...qr(va([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):i.push(...qr(va(l),10,(1+r.roughness)/2))}i.length&&o.push(se([i],r))}return r.stroke!==ct&&o.push(a),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],a=Mn(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(_r([e],r)):o.push(se([e],r))),r.stroke!==ct&&o.push(a),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const a=r.fill&&r.fill!=="transparent"&&r.fill!==ct,i=r.stroke!==ct,s=!!(r.simplification&&r.simplification<1),c=(function(d,p,u){const f=es(ts(Do(d))),h=[];let m=[],v=[0,0],w=[];const x=()=>{w.length>=4&&m.push(...qr(w,p)),w=[]},S=()=>{x(),m.length&&(h.push(m),m=[])};for(const{key:H,data:C}of f)switch(H){case"M":S(),v=[C[0],C[1]],m.push(v);break;case"L":x(),m.push([C[0],C[1]]);break;case"C":if(!w.length){const Y=m.length?m[m.length-1]:v;w.push([Y[0],Y[1]])}w.push([C[0],C[1]]),w.push([C[2],C[3]]),w.push([C[4],C[5]]);break;case"Z":x(),m.push([v[0],v[1]])}if(S(),!u)return h;const z=[];for(const H of h){const C=ap(H,u);C.length&&z.push(C)}return z})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=ha(e,r);if(a)if(r.fillStyle==="solid")if(c.length===1){const d=ha(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(d.ops)})}else o.push(_r(c,r));else o.push(se(c,r));return i&&(s?c.forEach((d=>{o.push(Mn(d,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const a=typeof n=="number"&&n>=0?o.data.map((i=>+i.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${a[0]} ${a[1]} `;break;case"bcurveTo":r+=`C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;break;case"lineTo":r+=`L${a[0]} ${a[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const a of n){let i=null;switch(a.type){case"path":i={d:this.opsToPath(a),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:ct};break;case"fillPath":i={d:this.opsToPath(a),stroke:ct,strokeWidth:0,fill:r.fill||ct};break;case"fillSketch":i=this.fillSketch(a,r)}i&&o.push(i)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||ct,strokeWidth:r,fill:ct}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class ip{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new _n(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,a=e.options.fixedDecimalPlaceDigits;for(const i of n)switch(i.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,i,a),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,i,a,s),o.restore();break}case"fillSketch":this.fillSketch(o,i,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const a of n.ops){const i=typeof r=="number"&&r>=0?a.data.map((s=>+s.toFixed(r))):a.data;switch(a.op){case"move":e.moveTo(i[0],i[1]);break;case"bcurveTo":e.bezierCurveTo(i[0],i[1],i[2],i[3],i[4],i[5]);break;case"lineTo":e.lineTo(i[0],i[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i),i}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i),i}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i),i}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a),a}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const vn="http://www.w3.org/2000/svg";class sp{constructor(e,n){this.svg=e,this.gen=new _n(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,a=o.createElementNS(vn,"g"),i=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(vn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(vn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&a.appendChild(c)}return a}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const a=e.createElementNS(vn,"path");return a.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),a.setAttribute("stroke",r.fill||""),a.setAttribute("stroke-width",o+""),a.setAttribute("fill","none"),r.fillLineDash&&a.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&a.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),a}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i)}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i)}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i)}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var is={canvas:(t,e)=>new ip(t,e),svg:(t,e)=>new sp(t,e),generator:t=>new _n(t),newSeed:()=>_n.newSeed()};const cp="http://www.w3.org/2000/svg",ya=1,ss="#000000",qn=3;let j=null;function lp(){j||(j=document.createElementNS(cp,"svg"),j.setAttribute("data-manuscript","ui"),j.setAttribute("width","100%"),j.setAttribute("height","100%"),j.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(j))}function Po(){j==null||j.remove(),j=null}function cs(t,e,n,r){if(!j)return;for(;j.firstChild;)j.removeChild(j.firstChild);const o=is.svg(j);xa(f=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:ya,...f}));const a=Math.atan2(r-e,n-t),i=14+qn*2,s=Math.PI/7,c=n-i*Math.cos(a-s),l=r-i*Math.sin(a-s),d=n-i*Math.cos(a+s),p=r-i*Math.sin(a+s),u=`M ${c} ${l} L ${n} ${r} L ${d} ${p}`;xa(f=>o.path(u,{roughness:1.5,bowing:1,seed:ya+1,...f}))}function xa(t){j&&(j.appendChild(t({stroke:"#ffffff",strokeWidth:qn+4})),j.appendChild(t({stroke:ss,strokeWidth:qn})))}const dp=8;let Bn=!1,wa=null,Ee=!1,Yt=0,Kt=0;function up(){wa||(wa=ht(({prev:t,next:e})=>{e==="arrow"?pp():t==="arrow"&&fp()}))}function pp(){Bn||(Bn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",ls,!0),document.addEventListener("mousemove",ds,!0),document.addEventListener("mouseup",us,!0),document.addEventListener("keydown",ps,!0))}function fp(){Bn&&(Bn=!1,Ee=!1,document.body.style.cursor="",document.removeEventListener("mousedown",ls,!0),document.removeEventListener("mousemove",ds,!0),document.removeEventListener("mouseup",us,!0),document.removeEventListener("keydown",ps,!0),Po())}function ls(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Ee=!0,Yt=t.clientX,Kt=t.clientY,lp(),cs(Yt,Kt,Yt,Kt))}function ds(t){Ee&&(t.preventDefault(),cs(Yt,Kt,t.clientX,t.clientY))}function us(t){if(!Ee)return;Ee=!1,Po();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Yt,n-Kt)<dp){R("idle");return}t.preventDefault(),t.stopPropagation();const o=ot(),a={kind:"arrow",id:hp(),style:"excalidraw",from:{x:Yt,y:Kt},to:{x:e,y:n},...o?{fromAnchorOffset:{x:Yt-o.left,y:Kt-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:ss,strokeWidth:qn};en(a),R("idle")}function ps(t){t.key==="Escape"&&(t.preventDefault(),Ee=!1,Po(),R("idle"))}function hp(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const ka="http://www.w3.org/2000/svg",fs="#1a1a1a",hs=3,gp=2,mp=2;let Un=!1,Sa=null,Ae=!1,bt=[],ut=null,wt=null;function bp(){Sa||(Sa=ht(({prev:t,next:e})=>{e==="freedraw"?vp():t==="freedraw"&&yp()}))}function vp(){Un||(Un=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",gs,!0),document.addEventListener("mousemove",ms,!0),document.addEventListener("mouseup",bs,!0),document.addEventListener("keydown",vs,!0))}function yp(){Un&&(Un=!1,Ae=!1,bt=[],document.body.style.cursor="",document.removeEventListener("mousedown",gs,!0),document.removeEventListener("mousemove",ms,!0),document.removeEventListener("mouseup",bs,!0),document.removeEventListener("keydown",vs,!0),Ro())}function gs(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Ae=!0,bt=[{x:t.clientX,y:t.clientY}],xp(),ys())}function ms(t){if(!Ae)return;t.preventDefault();const e=bt[bt.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<mp||(bt.push({x:t.clientX,y:t.clientY}),ys())}function bs(t){if(!Ae)return;if(Ae=!1,Ro(),bt.length<gp){bt=[],R("idle");return}t.preventDefault(),t.stopPropagation();const e=bt.slice(),n=ot(),r={kind:"freedraw",id:wp(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:fs,strokeWidth:hs};en(r),bt=[],R("idle")}function vs(t){t.key==="Escape"&&(t.preventDefault(),Ae=!1,bt=[],Ro(),R("idle"))}function xp(){ut||(ut=document.createElementNS(ka,"svg"),ut.setAttribute("data-manuscript","ui"),ut.setAttribute("width","100%"),ut.setAttribute("height","100%"),ut.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),wt=document.createElementNS(ka,"polyline"),wt.setAttribute("fill","none"),wt.setAttribute("stroke",fs),wt.setAttribute("stroke-width",String(hs)),wt.setAttribute("stroke-linecap","round"),wt.setAttribute("stroke-linejoin","round"),ut.appendChild(wt),document.body.appendChild(ut))}function Ro(){ut==null||ut.remove(),ut=null,wt=null}function ys(){wt&&wt.setAttribute("points",bt.map(t=>`${t.x},${t.y}`).join(" "))}function wp(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const on="manuscript:element-selected";let jn=!1,dt=null,Ea=null;function kp(){Ea||(Ea=ht(({prev:t,next:e})=>{e==="picker"?Sp():t==="picker"&&Ep()}))}function Sp(){jn||(jn=!0,document.addEventListener("mouseover",xs,!0),document.addEventListener("mouseout",ws,!0),document.addEventListener("click",ks,!0),document.addEventListener("keydown",Ss,!0))}function Ep(){jn&&(jn=!1,document.removeEventListener("mouseover",xs,!0),document.removeEventListener("mouseout",ws,!0),document.removeEventListener("click",ks,!0),document.removeEventListener("keydown",Ss,!0),Es())}function xs(t){const e=t.target;!(e instanceof HTMLElement)||As(e)||$p(e)}function ws(t){Es()}function ks(t){const e=t.target;if(!(e instanceof HTMLElement)||As(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=md(e),r=e.ownerDocument??document;if(console.log("[manuscript/picker] selectorChain",{target:e,chain:n,resolve:{layer1:Pn(n.layer1,r),layer2:Rn(n.layer2,r),layer3:On(n.layer3,r)},matchesTarget:{layer1:Pn(n.layer1,r)===e,layer2:Rn(n.layer2,r)===e,layer3:On(n.layer3,r)===e}}),!bd(n,e)){Ap();return}const o=e.getBoundingClientRect(),a={chain:n,rect:{x:o.x,y:o.y,width:o.width,height:o.height}};document.dispatchEvent(new CustomEvent(on,{detail:a})),R("idle")}let gt=null,yn=null;function Ap(){gt&&gt.remove(),gt=document.createElement("div"),gt.setAttribute("data-manuscript","ui"),gt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),gt.textContent=g("toast.ambiguous-selector"),document.body.appendChild(gt),yn!==null&&window.clearTimeout(yn),yn=window.setTimeout(()=>{gt==null||gt.remove(),gt=null,yn=null},3500)}function Ss(t){t.key==="Escape"&&(t.preventDefault(),R("idle"))}function $p(t){dt||(dt=document.createElement("div"),dt.setAttribute("data-manuscript","ui"),dt.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${O+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(dt));const e=t.getBoundingClientRect();dt.style.left=`${e.left}px`,dt.style.top=`${e.top}px`,dt.style.width=`${e.width}px`,dt.style.height=`${e.height}px`,dt.style.display="block"}function Es(){dt&&(dt.style.display="none")}function As(t){return t.closest('[data-manuscript="ui"]')!==null}const an="http://www.w3.org/2000/svg";function Oo(t,e){let n;switch(t){case"rectangle":n=Mp(e);break;case"ellipse":n=Lp(e);break;case"triangle":n=xn(Ip(e),e);break;case"diamond":n=xn(Dp(e),e);break;case"star":n=xn(Pp(e),e);break;case"callout":n=Cp(Rp(e),e);break;case"line":n=Tp(e);break;case"block-arrow":n=xn(Op(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function Mp(t){const e=document.createElementNS(an,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),mr(e,t),e}function Lp(t){const e=document.createElementNS(an,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),mr(e,t),e}function Tp(t){const e=document.createElementNS(an,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function xn(t,e){const n=document.createElementNS(an,"polygon");return n.setAttribute("points",t),mr(n,e),n.setAttribute("stroke-linejoin","round"),n}function Cp(t,e){const n=document.createElementNS(an,"path");return n.setAttribute("d",t),mr(n,e),n.setAttribute("stroke-linejoin","round"),n}function mr(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function Ip(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function Dp(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function Pp(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,a=[];for(let i=0;i<10;i++){const s=Math.PI/5*i-Math.PI/2,c=i%2===0?r:o;a.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return a.join(" ")}function Rp(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,a=t.x+t.width*.5,i=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${a} ${r}`,`L ${i} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function Op(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const Np="http://www.w3.org/2000/svg",Hp="#ffffff",zp="#1a1a1a",Fp=2;let K=null,kt=null;function $s(t){return{fill:t==="line"?"transparent":Hp,stroke:zp,strokeWidth:Fp}}function _p(){kt||(kt=document.createElement("div"),kt.setAttribute("data-manuscript","ui"),kt.textContent="Click and drag to draw a shape · Esc to cancel",kt.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${O+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(kt))}function Ms(){kt==null||kt.remove(),kt=null}function qp(){K||(K=document.createElementNS(Np,"svg"),K.setAttribute("data-manuscript","ui"),K.setAttribute("width","100%"),K.setAttribute("height","100%"),K.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(K))}function No(){K==null||K.remove(),K=null}function Ls(t,e,n,r,o){if(!K)return;for(;K.firstChild;)K.removeChild(K.firstChild);const a=t==="line"?r-e:Math.abs(r-e),i=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=$s(t),d=Oo(t,{x:s,y:c,width:a,height:i,...l});d&&K.appendChild(d)}const Bp=6;let Rt="rectangle",Wn=!1,Aa=null,$e=!1,Ot=0,Nt=0;function Up(t){Rt=t}function jp(){Aa||(Aa=ht(({prev:t,next:e})=>{e==="shape"?Wp():t==="shape"&&Vp()}))}function Wp(){Wn||(Wn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Ts,!0),document.addEventListener("mousemove",Cs,!0),document.addEventListener("mouseup",Is,!0),document.addEventListener("keydown",Ds,!0),_p())}function Vp(){Wn&&(Wn=!1,$e=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Ts,!0),document.removeEventListener("mousemove",Cs,!0),document.removeEventListener("mouseup",Is,!0),document.removeEventListener("keydown",Ds,!0),No(),Ms())}function Ts(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),$e=!0,Ot=t.clientX,Nt=t.clientY,Ms(),qp(),Ls(Rt,Ot,Nt,Ot,Nt))}function Cs(t){$e&&(t.preventDefault(),Ls(Rt,Ot,Nt,t.clientX,t.clientY))}function Is(t){if(!$e)return;$e=!1,No();const e=t.clientX,n=t.clientY,r=Rt==="line"?e-Ot:Math.abs(e-Ot),o=Rt==="line"?n-Nt:Math.abs(n-Nt);if(Math.max(Math.abs(r),Math.abs(o))<Bp){R("idle");return}t.preventDefault(),t.stopPropagation();const a=Rt==="line"?{x:Ot,y:Nt,width:r,height:o}:{x:Math.min(Ot,e),y:Math.min(Nt,n),width:r,height:o},i=$s(Rt),s=ot(),c={kind:"shape",id:Xp(),shapeKind:Rt,bounds:a,...s?{boundsAnchorOffset:{x:a.x-s.left,y:a.y-s.top}}:{},...i};en(c),R("idle")}function Ds(t){t.key==="Escape"&&(t.preventDefault(),$e=!1,No(),R("idle"))}function Xp(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Gp={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},Yp="Text";let Vn=!1,$a=null;function Kp(){$a||($a=ht(({prev:t,next:e})=>{e==="text"?Zp():t==="text"&&Qp()}))}function Zp(){Vn||(Vn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Ps,!0),document.addEventListener("keydown",Rs,!0))}function Qp(){Vn&&(Vn=!1,document.body.style.cursor="",document.removeEventListener("click",Ps,!0),document.removeEventListener("keydown",Rs,!0))}function Ps(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=ot(),o={kind:"text",id:Jp(),text:Yp,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...Gp}};en(o),requestAnimationFrame(()=>{const a=document.querySelector(`[data-annotation-text="${o.id}"]`);a&&a.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),R("idle")}function Rs(t){t.key==="Escape"&&(t.preventDefault(),R("idle"))}function Jp(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const tf="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",ef="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",Ma="Asta Sans",nf="fonts/AstaSans-VariableFont_wght.ttf";let La=!1;function rf(){La||(La=!0,Ta(tf),Ta(ef),of())}function Ta(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function of(){try{for(const t of document.fonts)if(t.family===Ma)return}catch{}try{const t=chrome.runtime.getURL(nf);new FontFace(Ma,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const mt="manuscript";function br(...t){}function Br(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function ce(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function Os(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===mt&&typeof e.type=="string"}function af(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const a=o.data;if(Os(a)){if(br("child received",a.type,"in",location.href),a.type==="set-mode"){R(a.mode),t=a.mode;return}if(a.type==="top-drag-start"){n=!0;return}if(a.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(on,(o=>{const a=o.detail;ce({source:mt,type:"element-selected",detail:a})})),ht(({prev:o,next:a})=>{o==="picker"&&a==="idle"&&ce({source:mt,type:"exit-picker"})}),ce({source:mt,type:"frame-ready"}),document.addEventListener("mousedown",o=>{ce({source:mt,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&ce({source:mt,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&ce({source:mt,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function sf(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const a=o.getBoundingClientRect();return{x:a.left,y:a.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function cf(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function lf(){ht(({next:t})=>{Br({source:mt,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Br({source:mt,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Br({source:mt,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(Os(e)){if(br("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){df(t.source,e.detail);return}if(e.type==="exit-picker"){R("idle");return}if(e.type==="iframe-mousedown"){Ca("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";Ca(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){uf(t.source);return}}})}function df(t,e){const n=cf(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};br("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(on,{detail:o})),R("idle")}function Ca(t,e,n,r){const o=sf(e),a=n+o.x,i=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:a,clientY:i}))}function uf(t){if(At()==="picker")try{t==null||t.postMessage({source:mt,type:"set-mode",mode:"picker"},"*"),br("top → late child: set-mode picker")}catch{}}function pf(){if(typeof window>"u")return;window===window.top?lf():af()}const ff="iframe-tool-overlay",Ia=new Set(["text","shape","freedraw"]);let me=[],Ur=!1,de=null;function hf(){typeof window>"u"||window===window.top&&(ht(({next:t})=>{Ia.has(t)?Da():Ns()}),Ia.has(At())&&Da())}function Da(){Ns(),Pa(),window.addEventListener("scroll",Xn,!0),window.addEventListener("resize",Xn),de=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&Pa()}),de.observe(document.body,{childList:!0,subtree:!0})}function Ns(){me.forEach(t=>t.remove()),me=[],window.removeEventListener("scroll",Xn,!0),window.removeEventListener("resize",Xn),de==null||de.disconnect(),de=null}function Pa(){me.forEach(e=>e.remove()),me=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",ff),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${O+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),me.push(n),Hs(n,e)})}const wn=8;function Hs(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-wn}px`,t.style.top=`${n.top-wn}px`,t.style.width=`${n.width+wn*2}px`,t.style.height=`${n.height+wn*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function Xn(){Ur||(Ur=!0,requestAnimationFrame(()=>{Ur=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=me[e];r&&Hs(r,n),e++})}))}let qt=!1;function vr(){return qt}async function gf(){try{if(typeof(await chrome.storage.local.get(X.prompterWindowId))[X.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(qt=!0)}catch{}}async function zs(){if(qt){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}qt=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(qt=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Fs(){if(qt){qt=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function _s(t){try{await chrome.storage.local.set({[X.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function mf(){qt=!1}const bf="modulepreload",vf=function(t){return"/"+t},Ra={},yf=function(e,n,r){let o=Promise.resolve();if(n&&n.length>0){let i=function(l){return Promise.all(l.map(d=>Promise.resolve(d).then(p=>({status:"fulfilled",value:p}),p=>({status:"rejected",reason:p}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));o=i(n.map(l=>{if(l=vf(l),l in Ra)return;Ra[l]=!0;const d=l.endsWith(".css"),p=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${p}`))return;const u=document.createElement("link");if(u.rel=d?"stylesheet":bf,d||(u.as="script"),u.crossOrigin="",u.href=l,c&&u.setAttribute("nonce",c),document.head.appendChild(u),d)return new Promise((f,h)=>{u.addEventListener("load",f),u.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${l}`)))})}))}function a(i){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=i,window.dispatchEvent(s),!s.defaultPrevented)throw i}return o.then(i=>{for(const s of i||[])s.status==="rejected"&&a(s.reason);return e().catch(a)})},Pt="http://www.w3.org/2000/svg",Oa="manuscript-spotlight-mask",xf="oklch(0.42 0.09 250)",wf=3,kf="rgb(0, 0, 0)",Sf=.55,Oe=14;let ee=null,et=null,Q=null,Z=null,B=null,Lt=null,Be=0,io=[],ue=null;function Ho(t){Be++,ee=t,et||$f(),so(),Le(),qs(t),ue||(ue=Ce(so))}function Me(){Be++,ee=null,Bs(),ue==null||ue(),ue=null,et&&(et.remove(),et=null,Q=null,Z=null,B=null,Lt=null)}function zo(t,e={}){var s;const n=e.durationMs??300;if(!ee||!et||n<=0){Ho(t),(s=e.onDone)==null||s.call(e);return}const r=Ef();Be++;const o=Be;ee=t,so(),qs(t);const a=performance.now();function i(c){var u;if(o!==Be)return;const l=Math.min(1,(c-a)/n),d=Af(l),p=Us(t);js({x:kn(r.x,p.x,d),y:kn(r.y,p.y,d),width:kn(r.width,p.width,d),height:kn(r.height,p.height,d)}),l<1?requestAnimationFrame(i):(Le(),(u=e.onDone)==null||u.call(e))}requestAnimationFrame(i)}function Ef(){if(!Q)return{x:0,y:0,width:0,height:0};const t=4,e=Number(Q.getAttribute("x")??0)+t,n=Number(Q.getAttribute("y")??0)+t,r=Number(Q.getAttribute("width")??0)-t*2,o=Number(Q.getAttribute("height")??0)-t*2;return{x:e,y:n,width:r,height:o}}function kn(t,e,n){return t+(e-t)*n}function Af(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2}function qs(t){var n;Bs();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=Le;r.addEventListener("scroll",o,!0),io.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",Le)}function Bs(){for(const t of io)t.remove();io=[],window.removeEventListener("resize",Le)}function $f(){et=document.createElementNS(Pt,"svg"),et.setAttribute("data-manuscript","ui"),et.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O}`].join("; "),et.setAttribute("width","100%"),et.setAttribute("height","100%");const t=document.createElementNS(Pt,"defs"),e=document.createElementNS(Pt,"mask");e.setAttribute("id",Oa);const n=document.createElementNS(Pt,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),Q=document.createElementNS(Pt,"rect"),Q.setAttribute("fill","black"),Q.setAttribute("rx","4"),Q.setAttribute("ry","4"),e.appendChild(Q),t.appendChild(e),et.appendChild(t),Lt=document.createElementNS(Pt,"rect"),Lt.setAttribute("width","100%"),Lt.setAttribute("height","100%"),Lt.setAttribute("mask",`url(#${Oa})`),et.appendChild(Lt),Z=document.createElementNS(Pt,"rect"),Z.setAttribute("fill","none"),Z.setAttribute("rx","4"),Z.setAttribute("ry","4"),Z.style.pointerEvents="none",et.appendChild(Z),B=document.createElementNS(Pt,"rect"),B.setAttribute("fill","none"),B.setAttribute("stroke","transparent"),B.setAttribute("stroke-width",String(Oe)),B.setAttribute("rx","4"),B.setAttribute("ry","4"),B.setAttribute("pointer-events","stroke"),B.style.cursor="pointer",B.addEventListener("click",Mf),et.appendChild(B),document.body.appendChild(et)}function so(){var a;if(!Z||!Lt)return;const t=((a=lt())==null?void 0:a.spotlight)??{},e=t.stroke??xf,n=t.strokeWidth??wf,r=t.dimColor??kf,o=t.dimOpacity??Sf;Z.setAttribute("stroke",e),Z.setAttribute("stroke-width",String(n)),Lt.setAttribute("fill",r),Lt.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),Le()}function Mf(t){At()!=="replay"&&(!ee||!B||(t.stopPropagation(),t.preventDefault(),yf(()=>import("./chunk-BtjPllW8.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{B&&e.openSpotlightEditor(B)})))}function Le(){ee&&js(Us(ee))}function Us(t){const e=t.getBoundingClientRect(),n=Lf(t);return{x:e.left+n.x,y:e.top+n.y,width:e.width,height:e.height}}function js(t){if(!Q||!Z||!B)return;const e=4,n=t.x-e,r=t.y-e,o=t.width+e*2,a=t.height+e*2;Q.setAttribute("x",String(n)),Q.setAttribute("y",String(r)),Q.setAttribute("width",String(o)),Q.setAttribute("height",String(a));const i=Math.max(0,Number(Z.getAttribute("stroke-width")??0)),s=n-i/2,c=r-i/2,l=o+i,d=a+i;Z.setAttribute("x",String(s)),Z.setAttribute("y",String(c)),Z.setAttribute("width",String(l)),Z.setAttribute("height",String(d));const p=s-Oe/2,u=c-Oe/2,f=l+Oe,h=d+Oe;B.setAttribute("x",String(p)),B.setAttribute("y",String(u)),B.setAttribute("width",String(f)),B.setAttribute("height",String(h))}function Lf(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const Na="data-wp-animations";function Tf(){if(document.head.querySelector(`[${Na}]`))return;const t=document.createElement("style");t.setAttribute(Na,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function Ze(t,e,n){if(!e||e.kind==="none"||At()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const a=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",a),t.removeEventListener("animationcancel",a)};t.addEventListener("animationend",a),t.addEventListener("animationcancel",a)}const Gn="http://www.w3.org/2000/svg",Ws="data-annotation-text",Ha="data-annotation-arrow",Vs="data-annotation-shape",za="data-annotation-freedraw",I={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function Cf(t,e){const{svg:n,roughSvg:r}=I;if(!n||!r)return;const o=Df(t.id),{from:a,to:i}=xd(t,e);Xs(t,s=>r.line(a.x,a.y,i.x,i.y,{roughness:1.5,bowing:1,seed:o,...s})),If(t,a,i,o+1)}function If(t,e,n,r){const{roughSvg:o}=I;if(!o)return;const a=Math.atan2(n.y-e.y,n.x-e.x),i=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-i*Math.cos(a-s),l=n.y-i*Math.sin(a-s),d=n.x-i*Math.cos(a+s),p=n.y-i*Math.sin(a+s),u=`M ${c} ${l} L ${n.x} ${n.y} L ${d} ${p}`;Xs(t,f=>o.path(u,{roughness:1.5,bowing:1,seed:r,...f}))}function Xs(t,e){const{svg:n}=I;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(Ha,t.id),Ze(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(Ha,t.id),Ze(o,t.entryAnimation,0),n.appendChild(o)}function Df(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const A={state:null,unsubscribeStep:null};function pt(){return A.state!==null}function sn(){var t;return((t=A.state)==null?void 0:t.standalone)===!0}function Pf(t,e){const{svg:n}=I;if(!n)return;const r=ur(t,e),o=Rf(t,r),a=r.map(c=>`${c.x},${c.y}`).join(" "),i=document.createElementNS(Gn,"polyline");if(i.setAttribute("points",a),i.setAttribute("fill","none"),i.setAttribute("stroke",t.stroke),i.setAttribute("stroke-width",String(t.strokeWidth)),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute(za,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&i.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&i.setAttribute("transform",o),i.style.pointerEvents="none",Ze(i,t.entryAnimation,t.rotate??0),n.appendChild(i),sn())return;const s=document.createElementNS(Gn,"polyline");s.setAttribute(za,t.id),s.setAttribute("points",a),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),Of(t.id,c,s))}),n.appendChild(s)}function Rf(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,a=-1/0,i=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>a&&(a=l.x),l.y>i&&(i=l.y);const s=(r+a)/2,c=(o+i)/2;return`rotate(${n} ${s} ${c})`}function Of(t,e,n){const r=D(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},a=ot(),i=ur(r,a).map(d=>({...d}));let s=!1;const c=d=>{const p=d.clientX-o.x,u=d.clientY-o.y;if(!s&&Math.hypot(p,u)<3)return;s=!0,d.preventDefault();const f=i.map(m=>({x:m.x+p,y:m.y+u})),h=a?{points:f,pointsAnchorOffset:f.map(m=>({x:m.x-a.left,y:m.y-a.top}))}:{points:f,pointsAnchorOffset:void 0};P(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const d=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),p=d[d.length-1]??n;Iu(t,p)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function Nf(t,e){const{svg:n}=I;if(!n)return;const r=dr(t,e),o=Oo(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(Vs,t.id),o.style.pointerEvents="none",Ze(o,t.entryAnimation,t.rotate??0),n.appendChild(o),sn()||n.appendChild(Hf(t,r)))}function Hf(t,e){const n=document.createElementNS(Gn,"rect");if(n.setAttribute(Vs,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>zf(t.id,r,n)),n}function zf(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=D(t);if(!o||o.kind!=="shape")return;const a=ot(),i=o.boundsAnchorOffset&&a?{x:a.left+o.boundsAnchorOffset.x,y:a.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:i.x,y:i.y};let c=!1;const l=p=>{const u=p.clientX-r.x,f=p.clientY-r.y;if(!c&&Math.hypot(u,f)<3)return;c=!0,p.preventDefault();const h=s.x+u,m=s.y+f,v=a?{bounds:{...s,x:h,y:m},boundsAnchorOffset:{x:h-a.left,y:m-a.top}}:{bounds:{...s,x:h,y:m},boundsAnchorOffset:void 0};P(t,v)},d=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const p=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=p[p.length-1]??n;Cu(t,u)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)}function Ff(t,e){const{host:n}=I;if(!n)return;const r=document.createElement("div");r.setAttribute(Ws,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,a=t.style.backgroundColor??"#ffffff",i=t.style.backgroundOpacity??.96,s=a==="transparent"?"transparent":_f(a,i),c=t.rotate??0,l=t.style.borderColor??"#000000",d=l==="transparent"?"none":`2px solid ${l}`,p=yd(t,e),u=sn();r.style.cssText=["position: absolute",`left: ${p.x}px`,`top: ${p.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${d}`,"border-radius: 8px",u?"pointer-events: none":"pointer-events: auto",u?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,u||qf(r,t.id),Ze(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function _f(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,a=0,i=0;return r.length===4?(o=parseInt(r[1]+r[1],16),a=parseInt(r[2]+r[2],16),i=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),a=parseInt(r.slice(3,5),16),i=parseInt(r.slice(5,7),16)),`rgba(${o}, ${a}, ${i}, ${n})`}return t}function qf(t,e){let n=!1,r=0,o=0,a=0,i=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();a=l.left,i=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,d=c.clientY-o;Math.abs(l)+Math.abs(d)>2&&(s=!0),t.style.left=`${a+l}px`,t.style.top=`${i+d}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),d=ot(),p=d?{position:{x:c,y:l},anchorOffset:{x:c-d.left,y:l-d.top}}:{position:{x:c,y:l},anchorOffset:void 0};P(e,p)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),Tu(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Bf(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",P(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Bf(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function Gs(){if(I.host)return;Tf();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+3}`].join("; ");const e=document.createElementNS(Gn,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),I.host=t,I.svg=e,I.roughSvg=is.svg(e),document.body.appendChild(t),I.unsubscribe=Ce(Tn),I.unsubscribeMode=ht(Tn),Uf(),Tn()}let be=null;function Ue(){be===null&&(be=requestAnimationFrame(()=>{be=null,Tn()}))}let Zt=null,co=null;function Uf(){window.addEventListener("resize",Ue),window.addEventListener("scroll",Ue,!0),typeof ResizeObserver<"u"&&(Zt=new ResizeObserver(Ue))}function jf(){window.removeEventListener("resize",Ue),window.removeEventListener("scroll",Ue,!0),Zt&&(Zt.disconnect(),Zt=null),co=null,be!==null&&(cancelAnimationFrame(be),be=null)}function Ys(){var t,e;(t=I.unsubscribe)==null||t.call(I),I.unsubscribe=null,(e=I.unsubscribeMode)==null||e.call(I),I.unsubscribeMode=null,jf(),I.host&&(I.host.remove(),I.host=null,I.svg=null,I.roughSvg=null)}function Wf(){return I.host!==null}function Tn(){const{host:t,svg:e}=I;if(!t||!e)return;for(t.querySelectorAll(`[${Ws}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=ot();if(Zt){let o=null;try{o=Vf()}catch{o=null}o!==co&&(Zt.disconnect(),o&&Zt.observe(o),co=o)}const r=Ti();for(const o of r)o.kind==="text"?Ff(o,n):o.kind==="arrow"?Cf(o,n):o.kind==="shape"?Nf(o,n):o.kind==="freedraw"&&Pf(o,n)}function Vf(){const t=lt();if(!(t!=null&&t.selectors))return null;try{return Se(t.selectors)}catch{return null}}const E={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function pe(t,e,n){return Math.max(e,Math.min(n,t))}function Ks(t){const{shadow:e}=E;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=Kf()),Xf()}function Xf(){const{host:t}=E;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),a=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${pe(o,0,n)}px`),Number.isFinite(a)&&(t.style.top=`${pe(a,0,r)}px`)}async function Gf(){try{return(await chrome.storage.local.get(X.replayControlsOrientation))[X.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Yf(t){try{await chrome.storage.local.set({[X.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function Kf(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function Zf(){try{const e=(await chrome.storage.local.get(X.replayControlsPosition))[X.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function Fa(t){try{await chrome.storage.local.set({[X.replayControlsPosition]:t})}catch{}}function Qf(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function Jf(){const{host:t,shadow:e}=E;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,a=0,i=0,s=0;const c=u=>{if(!E.host)return;u.preventDefault(),u.stopPropagation(),r=!0,n.classList.add("dragging");const f=E.host.getBoundingClientRect();E.host.style.left=`${f.left}px`,E.host.style.top=`${f.top}px`,E.host.style.bottom="auto",E.host.style.transform="none",o=u.clientX,a=u.clientY,i=f.left,s=f.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)},l=u=>{if(!r||!E.host)return;const f=E.host.getBoundingClientRect(),h=u.clientX-o,m=u.clientY-a,v=pe(i+h,0,window.innerWidth-f.width),w=pe(s+m,0,window.innerHeight-f.height);E.host.style.left=`${v}px`,E.host.style.top=`${w}px`},d=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const u=E.host;if(u){const f=parseFloat(u.style.left||"0"),h=parseFloat(u.style.top||"0");Number.isFinite(f)&&Number.isFinite(h)&&Fa({left:f,top:h})}},p=()=>{if(E.host&&E.host.style.transform==="none"){const u=E.host.getBoundingClientRect(),f=pe(u.left,0,window.innerWidth-u.width),h=pe(u.top,0,window.innerHeight-u.height);E.host.style.left=`${f}px`,E.host.style.top=`${h}px`,Fa({left:f,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",p),E.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",p),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0)}}function Zs(){return`
    ${vt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function Qs(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function th(t){return Qs(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function eh(t,e){const{shadow:n}=E;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,a)=>{const i=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${a===e?" active":""}" role="option" data-action="step-jump" data-index="${a}" aria-selected="${a===e}" title="${th(i)}">${a+1}. ${Qs(i)}</li>`}).join(""))}function nh(){const{shadow:t}=E;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function lo(){const{shadow:t}=E;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function Js(t){const{host:e,shadow:n}=E;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||lo()}let Cn=-1,In=!1;function rh(){Cn=-1,In=!1}function oh(t,e,n){const{shadow:r}=E;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",Cn=-1,In=!1;return}o.classList.remove("hidden");const s=t!==Cn||In&&!n;Cn=t,In=n;let c=o.querySelector(".progress-fill");(!c||s)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function ah(){return`
    ${vt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid color-mix(in oklch, currentColor, transparent 40%);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: color-mix(in oklch, currentColor, transparent 92%); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: color-mix(in oklch, currentColor, transparent 85%); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: color-mix(in oklch, currentColor, transparent 80%);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: color-mix(in oklch, currentColor, transparent 82%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: color-mix(in oklch, currentColor, transparent 45%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: color-mix(in oklch, currentColor, transparent 25%);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: color-mix(in oklch, currentColor, transparent 92%); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function ih(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function sh(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function ch(t){const{shadow:e}=E;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?ih(14):sh(14))}function cn(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),It(t);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}let tc=!1;function lh(t){if(E.host)return;const{host:e,shadow:n}=cn();E.host=e,E.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+6}`,"pointer-events: auto",tc?"display: none":""].filter(Boolean).join("; "),n.innerHTML=`<style>${ah()}</style>${dh()}`,n.addEventListener("click",r=>uh(r,t)),document.body.appendChild(e),Jf(),document.addEventListener("mousedown",Js,!0),E.orientationApplied=!1,Gf().then(r=>{E.orientationApplied||(E.orientationApplied=!0,Ks(r))}),Zf().then(r=>{E.host&&r&&E.host.style.transform!=="none"&&Qf(E.host,r)})}function dh(){return`
    <div class="bar" role="toolbar" aria-label="${g("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${g("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${g("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${g("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${g("replay.prompter-aria")}" title="${g("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${g("replay.tts-aria")}" title="${g("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${g("replay.move-aria")}" title="${g("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${g("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${g("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function uh(t,e){var a;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){nh();return}const r=n.closest('[data-action="step-jump"]');if(r){const i=Number(r.getAttribute("data-index"));Number.isFinite(i)&&(lo(),e.onStepSelect(i));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(a=n.closest("[data-action]"))==null?void 0:a.getAttribute("data-action");switch(o&&lo(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":ph();break}}function ph(){const{shadow:t}=E;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";E.orientationApplied=!0,Ks(n),Yf(n)}function jr(t){tc=t;const{host:e}=E;e&&(e.dataset.recordingHidden=t?"1":"",e.style.display=t?"none":"")}function fh(){var t,e;(t=E.cleanupDrag)==null||t.call(E),E.cleanupDrag=null,document.removeEventListener("mousedown",Js,!0),(e=E.host)==null||e.remove(),E.host=null,E.shadow=null,E.orientationApplied=!1,rh()}function _a(t){const{shadow:e}=E;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const a=e.querySelector('[data-action="prev"]');a&&a.toggleAttribute("disabled",t.currentIndex<=0);const i=e.querySelector('[data-action="next"]');i&&(i.toggleAttribute("disabled",!1),i.setAttribute("aria-label",t.currentIndex>=t.total-1?g("replay.finish-aria"):g("replay.next-aria"))),oh(t.currentIndex,t.timerDurationMs??null,t.paused),eh(t.steps??[],t.currentIndex),ch(t.ttsEnabled===!0)}let Ht=null;function hh(t){ln();const{host:e,shadow:n}=cn();Ht=e,Ht.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${Zs()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${g("replay.notfound.title")}</h2>
          <p>${g("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${g("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${g("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const a=o.target;if(!(a instanceof HTMLElement))return;const i=(s=a.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");i==="skip"?t.onSkip():i==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),Ht.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(Ht)}function ln(){if(!Ht)return;const t=Ht.__cleanup;t==null||t(),Ht.remove(),Ht=null}let zt=null;function gh(t){Yn();const{host:e,shadow:n}=cn();zt=e,zt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${Zs()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${g("replay.url-mismatch.title")}</h2>
          <p>${g("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${g("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${g("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${g("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",a=>{var c;const i=a.target;if(!(i instanceof HTMLElement))return;const s=(c=i.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=a=>{a.key==="Escape"?(a.preventDefault(),t.onCancel()):a.key==="Enter"&&(a.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),zt.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(zt)}function Yn(){if(!zt)return;const t=zt.__cleanup;t==null||t(),zt.remove(),zt=null}let Xt=null;function ec(t){dn();const e=t.getBoundingClientRect(),n=mh(t),r=e.left+n.x,o=e.top+n.y,a=e.bottom+n.y,i=36,s=8,c=o-s-i<8,l=c?Math.min(window.innerHeight-8-i,a+s):Math.max(8,o-s-i),d=Math.max(8,Math.min(r,window.innerWidth-200)),p=c?"up":"down",{host:u,shadow:f}=cn();Xt=u,Xt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${d}px`,`z-index: ${O+6}`,"pointer-events: none"].join("; "),f.innerHTML=`
    <style>
      ${vt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${g("prompter.action-step")}</span>
      <span>${g("replay.action-prompt")}</span>
      <span class="tip ${p}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Xt)}function dn(){Xt==null||Xt.remove(),Xt=null}function mh(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let ve=null;function bh(t){ve||(ve=e=>{if(A.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",ve,!0))}function vh(){ve&&(document.removeEventListener("keydown",ve,!0),ve=null)}function yr(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function nc(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function yh(t,e){var r,o,a;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||yr(n,location.href)||((o=A.state)==null?void 0:o.standalone)===!0)return!1;try{await vo({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((a=A.state)==null?void 0:a.paused)??!1})}catch(i){console.warn("[manuscript] persist activeReplay before nav failed",i)}return location.href=n,!0}function rc(t){return new Promise(e=>{gh({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{Yn(),e("force")},onCancel:()=>{Yn(),e("cancel")}})})}async function xh(t){try{const e=await ui();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Fo(){const t=L();if(!(!t||!A.state)&&A.state.standalone!==!0)try{await vo({scenarioId:t.id,stepIndex:W(),startedAt:Date.now(),paused:A.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function oc(t,e,n){const r=L();if(!r)return{ok:!1};if(n&&await xh(r.id))return{ok:!0};const o=nc(r);if(!o||yr(o,location.href))return{ok:!0};const a=await rc(o);return a==="cancel"?{ok:!1}:a==="navigate"?(await vo({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class ac extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function ic(t,e=li){return uo(t,e).then(n=>n.el)}function uo(t,e=li){const n=to(t);return n?Promise.resolve(n):new Promise((r,o)=>{let a=!1;const s=(zi(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(a)return;const d=to(t);d&&(a=!0,c.disconnect(),clearTimeout(l),r(d))}),l=setTimeout(()=>{a||(a=!0,c.disconnect(),o(new ac(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function Ie(){const{state:t}=A;if(!t)return;const e=L();if(!e)return;const n=e.steps[W()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(fi().then(o=>{_a({currentIndex:W(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(a=>({name:a.name})),ttsEnabled:o})}),_a({currentIndex:W(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),vr()){const o=W(),a=e.steps[o],i=e.steps[o+1];_s({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(s=>({name:s.name})),current:a?{name:a.name,description:a.description,autoAdvanceMs:a.autoAdvanceMs??null,waitForNavigation:a.waitForNavigation,thumbnailDataUrl:a.thumbnailDataUrl??null}:null,next:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null})}}async function wh(){if(vr()){await Fs(),Kn(!1);return}Kn(!0),await zs(),Ie()}function kh(){Kn(!1)}function Kn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}const Sh=.125;function un(t,e={}){const{behavior:n}=e,r=window.innerHeight,o=t.getBoundingClientRect(),a=window.scrollY+o.top;let i;o.height>r?i=a-r*Sh:i=a-(r-o.height)/2,i=Math.max(0,Math.round(i)),window.scrollTo(n?{top:i,behavior:n}:{top:i})}async function xr(t){var a,i;const{state:e}=A;if(!e)return;const n=L();if(!n)return;const r=n.steps[W()];if(Ie(),!r)return;if(ln(),dn(),Jc()&&!e.paused&&tl(r.description),!r.selectors){Me(),r.waitForNavigation||Ba(t);return}const o=new AbortController;e.pendingWait=o;try{const s=await ic(r.selectors);if(o.signal.aborted)return;un(s),Ho(s);const c=r.subElements??[];if(c.length>0){const l=new AbortController;(a=e.subSequenceAbort)==null||a.abort(),e.subSequenceAbort=l,Eh(s,r,c,l,t).finally(()=>{var d;((d=A.state)==null?void 0:d.subSequenceAbort)===l&&(A.state.subSequenceAbort=null)});return}r.waitForNavigation?(ec(s),sc(s,o,t.onNext)):Ba(t)}catch(s){if(o.signal.aborted)return;if(s instanceof ac){Me(),hh({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",s)}finally{((i=A.state)==null?void 0:i.pendingWait)===o&&(A.state.pendingWait=null)}}async function Eh(t,e,n,r,o){const a=e.subDwellsMs??[],i=a[0]??0;let s=t;if(await qa(i,r.signal),r.signal.aborted)return;for(let l=0;l<n.length;l++){const d=n[l];if(!d)continue;let p;try{p=await ic(d.selectors)}catch(u){console.warn("[manuscript] sub element not resolved, skipping",u);continue}if(r.signal.aborted||(un(p),zo(p,{durationMs:350}),s=p,await qa(a[l+1]??0,r.signal),r.signal.aborted))return}if(e.waitForNavigation){ec(s),sc(s,r,o.onNext);return}const c=hi();c&&(await Promise.race([c,new Promise(l=>{r.signal.aborted?l():r.signal.addEventListener("abort",()=>l(),{once:!0})})]),r.signal.aborted)||!A.state||A.state.paused||o.onNext()}function qa(t,e){return t<=0?Promise.resolve():new Promise(n=>{const r=window.setTimeout(()=>n(),t);e.addEventListener("abort",()=>{window.clearTimeout(r),n()},{once:!0})})}function sc(t,e,n){if(!A.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!A.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function Ba(t){var i;const{state:e}=A;if(!e||e.paused)return;const n=L();if(!n)return;const r=W(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(i=e.autoAdvanceAbort)==null||i.abort();const a=new AbortController;e.autoAdvanceAbort=a,(async()=>{const s=[],c=hi();c&&s.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&s.push(new Promise(l=>{const d=window.setTimeout(()=>{A.state&&A.state.autoAdvanceTimer===d&&(A.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);A.state&&(A.state.autoAdvanceTimer=d),a.signal.addEventListener("abort",()=>{window.clearTimeout(d),l()})})),s.length!==0&&(await Promise.race([Promise.all(s).then(()=>{}),new Promise(l=>{a.signal.aborted?l():a.signal.addEventListener("abort",()=>l(),{once:!0})})]),!a.signal.aborted&&(!A.state||A.state.paused||W()===r&&t.onNext()))})()}function wr(t={}){var n,r,o;const{state:e}=A;e&&(e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(n=e.autoAdvanceAbort)==null||n.abort(),e.autoAdvanceAbort=null,(r=e.pendingWait)==null||r.abort(),e.pendingWait=null,(o=e.subSequenceAbort)==null||o.abort(),e.subSequenceAbort=null,t.pauseTts?el():gi())}const kr={onNext:()=>void Qe(),onExit:()=>void Te()};async function De(t=0,e={}){if(A.state)return;const n=L();if(!n||n.steps.length===0||e.standalone!==!0&&!(await oc(n.id,t,!0)).ok)return;A.state={originalStepIndex:W(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,subSequenceAbort:null,standalone:e.standalone===!0},R("replay"),lh({onPrev:Zn,onNext:Qe,onTogglePause:Je,onExit:Te,onStepSelect:o=>void qo(o),onTogglePrompter:()=>void wh(),onToggleTts:()=>void Ah()}),vr()&&Kn(!0),bh({onNext:()=>void Qe(),onPrev:()=>void Zn(),onTogglePause:Je,onExit:()=>void Te()}),A.unsubscribeStep=Ce(Ie);const r=Math.min(Math.max(0,t),n.steps.length-1);Dt(r),await Fo(),await xr(kr)}async function _o(t){if(!A.state)return;const e=L();e&&(t<0||t>=e.steps.length||(wr(),ln(),dn(),!await yh(e,t)&&(Dt(t),await Fo(),await xr(kr))))}async function qo(t){t!==W()&&await _o(t)}async function Qe(){const{state:t}=A;if(!t)return;const e=L();if(!e)return;const n=W();if(n>=e.steps.length-1){wr(),ln(),dn(),t.paused=!0,Ie(),document.dispatchEvent(new CustomEvent("manuscript:replay-end"));return}await _o(n+1)}async function Zn(){await _o(W()-1)}async function Ah(){const t=!await fi();await nl(t),t||gi(),Ie()}function Je(){const{state:t}=A;if(!t)return;const e=L();if(e&&t.paused&&W()>=e.steps.length-1){$h();return}t.paused=!t.paused,t.paused?wr({pauseTts:!0}):xr(kr),Ie()}async function $h(){if(!A.state)return;const t=L();!t||!(await oc(t.id,0,!1)).ok||A.state&&(A.state.paused=!1,Dt(0),await Fo(),await xr(kr))}async function Te(){var r;const{state:t}=A;if(!t)return;wr(),ln(),dn(),Yn(),Me(),fh(),Fs(),vh(),(r=A.unsubscribeStep)==null||r.call(A),A.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;A.state=null,Dt(e),R("idle"),await Xc(),n&&(Ys(),Mi())}const Sr="manuscript:selector-health-changed",Qn=new Map,Jn=new Map;function cc(t,e){return`${t}::${e}`}function Er(t){return t===void 0?"none":t===null?"red":t===1?"green":t===2?"yellow":"orange"}function Ar(t,e){return e?Jn.get(cc(t,e)):Qn.get(t)}function Mh(t,e){return t===void 0?!0:t!==e}function Vt(t){const e=Ar(t.stepId,t.subId);Mh(e,t.layer)&&(t.subId?Jn.set(cc(t.stepId,t.subId),t.layer):Qn.set(t.stepId,t.layer),typeof document<"u"&&document.dispatchEvent(new CustomEvent(Sr,{detail:{stepId:t.stepId,subId:t.subId??null,layer:t.layer}})))}function Lh(){Qn.size===0&&Jn.size===0||(Qn.clear(),Jn.clear(),typeof document<"u"&&document.dispatchEvent(new CustomEvent(Sr,{detail:{stepId:"",subId:null,layer:null,cleared:!0}})))}function Th(t){const e=[],n=new Map;for(const r of t.steps){const o=r.pickedAtUrl&&r.pickedAtUrl.length>0?r.pickedAtUrl:t.url,a=Ch(o);let i=n.get(a);i||(i={url:o??"",stepIds:[]},n.set(a,i),e.push(i)),i.stepIds.push(r.id)}return e}function Ch(t){if(!t)return"";try{const e=new URL(t);return`${e.origin}${e.pathname}`}catch{return t}}function Ih(t,e){return{scenarioId:t.id,startedAt:Date.now(),returnTo:e,groups:Th(t),currentGroupIdx:0,stepResults:{},subResults:{}}}function Ua(t){return t===1?"green":t===2?"yellow":t===3?"orange":"red"}const ja=2e3;async function Dh(t,e,n){const r=e.groups[e.currentGroupIdx];r&&(await Promise.allSettled(r.stepIds.map(async o=>{const a=t.steps.find(i=>i.id===o);if(a){if(!a.selectors)e.stepResults[o]="no-element",Vt({stepId:o,layer:null}),n==null||n();else{try{const i=await uo(a.selectors,ja);e.stepResults[o]=Ua(i.layer),Vt({stepId:o,layer:i.layer})}catch{e.stepResults[o]="red",Vt({stepId:o,layer:null})}n==null||n()}await Promise.allSettled((a.subElements??[]).map(async i=>{try{const s=await uo(i.selectors,ja);e.subResults[`${o}::${i.id}`]=Ua(s.layer),Vt({stepId:o,subId:i.id,layer:s.layer})}catch{e.subResults[`${o}::${i.id}`]="red",Vt({stepId:o,subId:i.id,layer:null})}n==null||n()}))}})),e.currentGroupIdx+=1)}function lc(t){return t.currentGroupIdx>=t.groups.length}function Ph(t){const e=t.groups[t.currentGroupIdx];return e?e.url:null}async function Rh(t){await Yc(t)}async function Tt(){await Gc()}function dc(t){for(const[e,n]of Object.entries(t.stepResults))Vt({stepId:e,layer:Wa(n)});for(const[e,n]of Object.entries(t.subResults)){const r=e.indexOf("::");if(r<0)continue;const o=e.slice(0,r),a=e.slice(r+2);Vt({stepId:o,subId:a,layer:Wa(n)})}}function Wa(t){return t==="green"?1:t==="yellow"?2:t==="orange"?3:null}const tn={stepId:null,selectedIds:[],anchorId:null,primarySelected:!1};function Oh(t,e,n){return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1}}function Nh(t,e,n){if(t.stepId!==e)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=t.selectedIds.includes(n)?t.selectedIds.filter(a=>a!==n):[...t.selectedIds,n];return{stepId:e,selectedIds:o,anchorId:n,primarySelected:!1}}function Hh(t,e,n,r){if(t.stepId!==e||!t.anchorId)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=r.indexOf(t.anchorId),a=r.indexOf(n);if(o<0||a<0)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const i=Math.min(o,a),s=Math.max(o,a);return{stepId:e,selectedIds:r.slice(i,s+1),anchorId:t.anchorId,primarySelected:!1}}function zh(t,e){return{stepId:e,selectedIds:[],anchorId:null,primarySelected:!0}}function $r(t,e){return t.stepId===e?t.selectedIds:[]}function uc(t,e){return t.stepId===e&&t.primarySelected}const Fh=320,ye=32,_h=.8,tr=200,b={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null,pickerTarget:{type:"primary"},subSelection:tn,subDragSet:null,subDragStepId:null};function rt(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function T(t){return rt(t)}function Ct(t,e=!1,n=5e3){const{shadow:r}=b;if(!r)return;const o=r.querySelector('[data-region="toast"]');o&&(o.textContent=t,o.classList.add("visible"),o.classList.toggle("error",e),b.toastTimer!==null&&window.clearTimeout(b.toastTimer),b.toastTimer=window.setTimeout(()=>{o.classList.remove("visible"),b.toastTimer=null},n))}function er(t,e,n){return Math.max(e,Math.min(n,t))}let je=null,nr=null,nt=null,We=null;function po(t){nt=t,je||qh(),pc(t)}function Ut(t){nt&&(nt={...nt,...t},pc(nt))}function xe(){We&&(document.removeEventListener("keydown",We,!0),We=null),je&&(je.remove(),je=null,nr=null,nt=null)}function qh(){const{host:t,shadow:e}=cn();je=t,nr=e,t.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),e.addEventListener("click",Bh),We=n=>{n.key==="Escape"&&nt&&nt.phase!=="validating"&&nt.phase!=="navigating"&&(n.preventDefault(),nt.onClose())},document.addEventListener("keydown",We,!0),document.body.appendChild(t)}function Bh(t){if(!nt)return;const e=t.target;if(!(e instanceof HTMLElement))return;if(e.closest('[data-action="close"]')){nt.onClose();return}if(e.closest('[data-action="start"]')){nt.onStart();return}const n=e.closest('[data-action="go-step"]');if(n!=null&&n.dataset.stepId){nt.onGoToStep(n.dataset.stepId);return}const r=e.closest('[data-action="repick"]');if(r!=null&&r.dataset.stepId){nt.onRepick(r.dataset.stepId);return}}function pc(t){nr&&(nr.innerHTML=`
    <style>${vt()}${Yh()}</style>
    ${Uh(t)}
  `)}function Uh(t){var i;const{scenario:e,session:n,phase:r}=t,o=Gh(e,n),a=typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.getURL)?chrome.runtime.getURL("icons/manuscript.svg"):"";return`
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="vm-title">
      <div class="head">
        <div class="brand-row">
          <div class="brand">
            ${a?`<img class="brand-mark" src="${T(a)}" alt="" aria-hidden="true">`:""}
            <span class="brand-wordmark">Manuscript</span>
          </div>
          <div class="head-actions">
            ${Wh(r)}
            <button type="button" class="close-x" data-action="close" aria-label="${T(g("validate.close"))}" title="${T(g("validate.close"))}">×</button>
          </div>
        </div>
        <div class="title-row">
          <h2 id="vm-title">${rt(g("validate.modal-title"))}</h2>
          <div class="summary">${jh(o)}</div>
        </div>
      </div>
      ${Vh(t)}
      <ul class="rows">${e.steps.map((s,c)=>Xh(s,c,n)).join("")}</ul>
    </div>
  `}function jh(t){const e=(n,r,o)=>`<span class="sum-item"><span class="sum-dot" data-status="${n}"></span>${rt(g(r))} ${o}</span>`;return[e("green","validate.label-ok",t.ok),e("yellow","validate.label-fallback",t.fallback),e("red","validate.label-broken",t.broken),e("pending","validate.label-pending",t.pending)].join('<span class="sum-sep">·</span>')}function Wh(t){return t==="initial"?`<button class="primary" data-action="start">${rt(g("validate.start"))}</button>`:t==="complete"?`<span class="pill complete">${rt(g("validate.complete"))}</span>`:`<span class="pill">${rt(g("validate.in-progress"))}</span>`}function Vh(t){var e;if(t.phase==="navigating")return`<div class="banner">${rt(g("validate.navigating-to",{url:t.navigatingTo??""}))}</div>`;if(t.phase==="validating"){const n=(e=t.session.groups[t.session.currentGroupIdx])==null?void 0:e.url;return`<div class="banner">${rt(g("validate.checking",{url:n??""}))}</div>`}return""}function Xh(t,e,n){const r=n.stepResults[t.id],o=r??"pending",a=t.thumbnailDataUrl?` style="background-image: url('${T(t.thumbnailDataUrl)}')"`:"",i=Va(r,t.selectors===null),s=(t.subElements??[]).map(c=>`<span class="sub-dot" data-status="${n.subResults[`${t.id}::${c.id}`]??"pending"}" title="${T(Va(n.subResults[`${t.id}::${c.id}`],!1))}"></span>`).join("");return`
    <li class="row" data-status="${o}">
      <div class="thumb"${a}><span class="row-idx">${e+1}</span></div>
      <div class="meta">
        <div class="name">${rt(t.name)||'<span class="muted">(unnamed)</span>'}</div>
        <div class="status-line">
          <span class="dot" data-status="${o}"></span>
          <span class="status-text">${rt(i)}</span>
          ${s?`<span class="sub-dots">${s}</span>`:""}
        </div>
      </div>
      <div class="actions">
        <button class="action-btn" data-action="go-step" data-step-id="${T(t.id)}">${rt(g("validate.row-go"))}</button>
        ${r==="red"||r==="orange"?`<button class="action-btn primary" data-action="repick" data-step-id="${T(t.id)}">${rt(g("validate.row-repick"))}</button>`:""}
      </div>
    </li>
  `}function Va(t,e){return e?g("validate.status-no-element"):t===void 0?g("validate.status-pending"):t==="green"?g("validate.status-green"):t==="yellow"?g("validate.status-yellow"):t==="orange"?g("validate.status-orange"):t==="red"?g("validate.status-red"):t==="no-element"?g("validate.status-no-element"):""}function Gh(t,e){let n=0,r=0,o=0,a=0;for(const i of t.steps){const s=e.stepResults[i.id];s==="green"?n++:s==="yellow"||s==="orange"?r++:s==="red"?o++:a++}return{ok:n,fallback:r,broken:o,pending:a}}function Yh(){return`
    :host { font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }
    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px;
      width: min(580px, calc(100vw - 32px));
      max-height: calc(100vh - 64px);
      display: flex;
      flex-direction: column;
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-primary);
    }
    .head {
      margin-bottom: 12px;
    }
    .brand-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 10px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--c-text);
    }
    .brand-mark {
      width: 20px;
      height: 20px;
      display: block;
    }
    .brand-wordmark {
      font-family: var(--ff-serif);
      font-size: 18px;
      font-weight: 500;
      letter-spacing: -0.005em;
      line-height: 1;
    }
    .head-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .close-x {
      width: 24px;
      height: 24px;
      padding: 0;
      background: transparent;
      border: none;
      color: var(--c-text-mute);
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      border-radius: var(--r-xs);
      font-family: inherit;
    }
    .close-x:hover { color: var(--c-text); background: var(--c-surface-2); }

    /* Title row — H2 on the left, summary chips pinned right. Same line
       gives a tight, scannable header instead of the prior stacked
       title/summary block. */
    .title-row {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
    }
    .title-row h2 { margin: 0; font-size: 15px; font-weight: 600; }
    .summary {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text-mute);
      font-family: inherit;
      font-variant-numeric: tabular-nums;
      flex-wrap: wrap;
    }
    .sum-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .sum-sep { color: var(--c-text-soft); }
    .sum-dot {
      width: 7px;
      height: 7px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .sum-dot[data-status="green"]  { background: var(--c-success); }
    .sum-dot[data-status="yellow"] { background: var(--c-warning); }
    .sum-dot[data-status="red"]    { background: var(--c-error); }
    .sum-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .primary {
      flex-shrink: 0;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      font-family: inherit;
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: 1px solid var(--c-primary);
    }
    .pill {
      flex-shrink: 0;
      padding: 5px 10px;
      border-radius: var(--r-pill);
      background: var(--c-tint);
      color: var(--c-primary);
      font-size: 11px;
      font-family: inherit;
      font-weight: 500;
    }
    .pill.complete {
      background: color-mix(in oklab, var(--c-success) 14%, transparent);
      color: var(--c-success);
    }
    .banner {
      padding: 8px 12px;
      border-radius: var(--r-sm);
      background: var(--c-tint);
      color: var(--c-text);
      font-size: 12px;
      font-weight: 500;
      margin-bottom: 8px;
      font-family: inherit;
      word-break: break-all;
    }
    .rows {
      list-style: none;
      margin: 0;
      padding: 0;
      overflow-y: auto;
      max-height: 60vh;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px;
      border-radius: var(--r-sm);
      background: var(--c-surface-2);
    }
    .row[data-status="red"]    { background: color-mix(in oklab, var(--c-error) 8%, var(--c-surface-2)); }
    .row[data-status="orange"] { background: color-mix(in oklab, var(--c-warning) 7%, var(--c-surface-2)); }
    .row[data-status="pending"] { opacity: 0.85; }
    .thumb {
      position: relative;
      width: 36px; height: 36px;
      border-radius: var(--r-xs);
      border: 1px solid var(--c-border);
      background-color: var(--c-surface);
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      flex-shrink: 0;
    }
    .row-idx {
      position: absolute;
      top: -2px; left: -2px;
      background: var(--c-surface);
      color: var(--c-text-mute);
      font-family: var(--ff-mono);
      font-size: 9px;
      font-weight: 600;
      padding: 1px 3px;
      border-radius: 2px;
    }
    .meta { flex: 1; min-width: 0; }
    .name {
      font-size: 13px;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .muted { color: var(--c-text-soft); font-style: italic; }
    .status-line {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: var(--c-text-mute);
      margin-top: 2px;
    }
    .dot, .sub-dot {
      width: 8px; height: 8px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .dot[data-status="green"],  .sub-dot[data-status="green"]  { background: var(--c-success); }
    .dot[data-status="yellow"], .sub-dot[data-status="yellow"] { background: var(--c-warning); }
    .dot[data-status="orange"], .sub-dot[data-status="orange"] {
      background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%);
    }
    .dot[data-status="red"],    .sub-dot[data-status="red"]    { background: var(--c-error); }
    .dot[data-status="pending"], .sub-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .dot[data-status="no-element"] { background: transparent; border-color: var(--c-text-soft); }
    .sub-dots { display: inline-flex; gap: 3px; margin-left: 4px; }
    .actions { display: flex; gap: 6px; flex-shrink: 0; }
    .action-btn {
      padding: 4px 10px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      font-size: 11px;
      font-weight: 500;
      font-family: inherit;
      cursor: pointer;
    }
    .action-btn:hover { border-color: var(--c-border-strong); }
    .action-btn.primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border-color: var(--c-primary);
    }
  `}const Kh=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],Mt=28,Sn=4,Zh="http://www.w3.org/2000/svg";let V=null,ne=null,Ve=null;function Qh(t,e){Mr(),Ve=e,V=document.createElement("div"),V.setAttribute("data-manuscript","ui"),It(V),V.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; "),ne=V.attachShadow({mode:"open"}),ne.innerHTML=Jh(),eg(),document.body.appendChild(V),Xa(t),tg(),requestAnimationFrame(()=>{V&&Xa(t)}),document.addEventListener("mousedown",fc,!0),document.addEventListener("keydown",hc,!0)}function Mr(){V&&(document.removeEventListener("mousedown",fc,!0),document.removeEventListener("keydown",hc,!0),V.remove(),V=null,ne=null,Ve=null)}function Jh(){return`
    <style>
      ${vt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${Mt+Sn*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${Mt+Sn*2}px;
        height: ${Mt+Sn*2}px;
        padding: ${Sn}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function tg(){if(!ne)return;const t=ne.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of Kh){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(Zh,"svg");o.setAttribute("width",String(Mt)),o.setAttribute("height",String(Mt)),o.setAttribute("viewBox",`0 0 ${Mt} ${Mt}`);const a=Oo(e,{x:3,y:3,width:Mt-6,height:Mt-6,fill:"transparent",stroke:"oklch(0.18 0.015 250)",strokeWidth:1.5});a&&o.appendChild(a),r.appendChild(o),t.appendChild(r)}}}function eg(){ne&&ne.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(Ve==null||Ve(r),Mr())})}function Xa(t){if(!V)return;const e=t.getBoundingClientRect();V.style.top="0px",V.style.left="0px";const n=V.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),V.style.top=`${Math.max(8,r)}px`,V.style.left=`${Math.max(8,o)}px`}function fc(t){if(!V)return;const e=t.target;e instanceof Node&&V.contains(e)||Mr()}function hc(t){t.key==="Escape"&&(t.preventDefault(),Mr())}let _=null;function ng(t){if(_!==null)return;const e=t.from??3,n=t.tickMs??1e3,r=t.scheduler??og(),o=document.createElement("div");o.setAttribute("data-manuscript","ui"),o.setAttribute("data-region","countdown"),o.style.cssText=["position: fixed","inset: 0",`z-index: ${O+10}`,"pointer-events: auto"].join("; "),It(o);const a=o.attachShadow({mode:"open"});a.innerHTML=ag(e),document.body.appendChild(o);const i=a.querySelector('[data-region="number"]'),s=a.querySelector('[data-action="cancel"]'),c=l=>{(l.key==="Escape"||l.key===" "||l.key==="Spacebar")&&(l.preventDefault(),Ga())};window.addEventListener("keydown",c),s==null||s.addEventListener("click",()=>Ga()),_={host:o,shadow:a,numberEl:i,scheduler:r,tickMs:n,timerId:null,remaining:e,onComplete:t.onComplete,onCancel:t.onCancel??null,keyListener:c},gc()}function Bo(){_&&(_.timerId!==null&&_.scheduler.cancel(_.timerId),window.removeEventListener("keydown",_.keyListener),_.host.remove(),_=null)}function gc(){_&&(_.timerId=_.scheduler.schedule(rg,_.tickMs))}function rg(){if(_){if(_.remaining-=1,_.remaining<=0){const t=_.onComplete;Bo(),t();return}_.numberEl.textContent=String(_.remaining),gc()}}function Ga(){if(!_)return;const t=_.onCancel;Bo(),t==null||t()}function og(){return{schedule(t,e){return window.setTimeout(t,e)},cancel(t){window.clearTimeout(t)}}}function ag(t){return`
    <style>
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .ring {
        width: 220px;
        height: 220px;
        border-radius: 999px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #0a0a0a);
        box-shadow: 0 24px 60px rgb(0 0 0 / 0.35), 0 4px 12px rgb(0 0 0 / 0.20);
        display: grid;
        place-items: center;
        position: relative;
        animation: ring-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes ring-pop {
        from { transform: scale(0.85); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .number {
        font-size: 140px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        font-variant-numeric: tabular-nums;
        animation: digit-pop 200ms ease-out;
      }
      .number[data-changed] { animation: digit-pop 200ms ease-out; }
      @keyframes digit-pop {
        from { transform: scale(1.25); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .caption {
        position: absolute;
        bottom: -52px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 13px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.92);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint {
        position: absolute;
        bottom: -78px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 11px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.62);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid rgb(255 255 255 / 0.35);
        border-radius: 4px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        margin: 0 2px;
      }
      .cancel {
        appearance: none;
        background: rgb(255 255 255 / 0.10);
        color: rgb(255 255 255 / 0.92);
        border: 1px solid rgb(255 255 255 / 0.25);
        border-radius: 999px;
        padding: 6px 14px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        position: absolute;
        bottom: -120px;
        left: 50%;
        transform: translateX(-50%);
        transition: background 120ms ease, border-color 120ms ease;
      }
      .cancel:hover { background: rgb(255 255 255 / 0.20); border-color: rgb(255 255 255 / 0.45); }
    </style>
    <div class="scrim" role="dialog" aria-label="Recording starts soon">
      <div class="ring">
        <span class="number" data-region="number">${t}</span>
        <span class="caption">Recording starts in…</span>
        <span class="hint">During recording: <kbd>Space</kbd> pauses scenario · <kbd>Esc</kbd> stops &amp; saves</span>
        <button type="button" class="cancel" data-action="cancel">Cancel</button>
      </div>
    </div>
  `}let Xe=null;function ig(t){if(Xe!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-paused-pill"),e.style.cssText=["position: fixed","top: 16px","right: 16px",`z-index: ${O+11}`,"pointer-events: auto"].join("; "),It(e);const n=e.attachShadow({mode:"open"});n.innerHTML=sg(),document.body.appendChild(e);const r=n.querySelector('[data-action="resume"]');r==null||r.addEventListener("click",()=>{const o=t.onResume;Lr(),o()}),Xe={host:e}}function Lr(){Xe&&(Xe.host.remove(),Xe=null)}function sg(){const t=g("recording.paused-label"),e=g("recording.paused-aria");return`
    <style>
      ${vt()}
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .pill {
        appearance: none;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px 6px 10px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #111);
        border: 1px solid var(--c-border, #d9dee5);
        border-radius: 999px;
        box-shadow: 0 6px 18px rgb(0 0 0 / 0.18), 0 1px 4px rgb(0 0 0 / 0.10);
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 0.02em;
        opacity: 0.7;
        cursor: pointer;
        transition: opacity 120ms ease, filter 120ms ease;
      }
      .pill:hover {
        opacity: 1;
        filter: brightness(0.98);
      }
      .dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: var(--c-error, #c52a2a);
        flex-shrink: 0;
        animation: rec-blink 1s ease-in-out infinite;
      }
      @keyframes rec-blink {
        0%, 100% { opacity: 1; }
        50%      { opacity: 0.2; }
      }
      .label { line-height: 1.2; white-space: nowrap; }
    </style>
    <button type="button" class="pill" data-action="resume" aria-label="${e}" title="${e}">
      <span class="dot" aria-hidden="true"></span>
      <span class="label">${t}</span>
    </button>
  `}function cg(t,e=n=>MediaRecorder.isTypeSupported(n)){for(const n of t)if(e(n))return n;throw new Error(`No supported MIME type for screen recording (tried: ${t.join(", ")})`)}function lg(t,e){const{factory:n,mimeType:r,timesliceMs:o}=e,a=n.create(t,{mimeType:r}),i=[];let s=!1,c=null;a.ondataavailable=p=>{p.data&&p.data.size>0&&i.push(p.data)};function l(){if(s)throw new Error("Recorder handle is single-use; create a new one.");s=!0,o!==void 0?a.start(o):a.start()}function d(){return c?Promise.reject(new Error("stop() already called")):(c=new Promise((p,u)=>{a.onstop=()=>{const f=new Blob(i,{type:r});p({blob:f,size:f.size,mimeType:r})},a.onerror=f=>{const h=f.error;u(new Error((h==null?void 0:h.message)??"MediaRecorder error"))},a.stop()}),c)}return{start:l,stop:d}}function dg(t){let e="idle";function n(){var o;e==="idle"&&(t.isStandalonePlayback()||(e="counting-down",(o=t.onRecordingStarting)==null||o.call(t),t.mountCountdown({onComplete:()=>{var a;e="recording",(a=t.onRecordingStarted)==null||a.call(t),t.sendMessage({type:"recording.fire"}).catch(()=>{var i;e="idle",(i=t.onRecordingStopped)==null||i.call(t)})},onCancel:()=>{var a;e="idle",(a=t.onRecordingStopped)==null||a.call(t),t.sendMessage({type:"recording.stop"}).catch(()=>{})}})))}async function r(){var o,a;if(e!=="idle"){if(e==="counting-down"){t.unmountCountdown(),e="idle",(o=t.onRecordingStopped)==null||o.call(t);return}try{await t.sendMessage({type:"recording.stop"})}finally{e="idle",(a=t.onRecordingStopped)==null||a.call(t)}}}return{startRecording:n,stopRecording:r,isRecording:()=>e==="recording",getPhase:()=>e}}const Ya="Created with Manuscript",ug=12,pg=500,fo=14,Ka=10,fg=6,Za=24,hg=.7;function gg(t,e,n,r){t.save(),t.globalAlpha=hg,t.fillStyle="#fff",t.font=`${pg} ${ug}px "Pretendard Variable", Pretendard, system-ui, sans-serif`,t.textAlign="right",t.textBaseline="bottom",t.shadowColor="rgba(0, 0, 0, 0.85)",t.shadowBlur=3,t.shadowOffsetX=0,t.shadowOffsetY=1;const o=n-Za,a=r-Za;t.fillText(Ya,o,a);const i=t.measureText(Ya).width,s=o-i-fg-Ka,c=a-fo;t.drawImage(e,s,c,Ka,fo),t.restore()}async function mg(){const t=pi({height:fo,color:"#ffffff"}),e=`data:image/svg+xml;utf8,${encodeURIComponent(t)}`,n=new Image;return n.src=e,await n.decode(),n}const bg=["video/webm;codecs=vp9,opus","video/webm;codecs=vp9","video/webm;codecs=vp8,opus","video/webm;codecs=vp8","video/webm"];let Dn=null,Ge=!1,Gt=null,Ne=null,He=null,ze=null,Fe=null,le=null,_e=null,ho=!1,rr=null,Uo=null,jo=null,we=null;async function vg(t={}){if(sn()||Gt)return!1;Ge=t.keepUiVisible===!0;let e;try{e=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,preferCurrentTab:!0,selfBrowserSurface:"include"})}catch(v){return console.warn("[manuscript/recording] tab share failed:",v),!1}let n=null;try{n=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,systemAudio:"include"}),n.getVideoTracks().forEach(v=>v.stop()),console.info("[manuscript/recording] step 2 OK — system audio acquired, video track dropped",{audioTracks:n.getAudioTracks().length})}catch(v){console.warn("[manuscript/recording] step 2 rejected:",v instanceof Error?`${v.name}: ${v.message}`:v),Ct("System audio not shared — TTS narration will be silent in the video.")}let r=null;if(t.withMicrophone)try{r=await navigator.mediaDevices.getUserMedia({audio:!0}),console.info("[manuscript/recording] microphone acquired",{audioTracks:r.getAudioTracks().length})}catch(v){console.warn("[manuscript/recording] microphone acquisition failed:",v instanceof Error?`${v.name}: ${v.message}`:v),Ct(g("recording.mic-failed"))}let o=null,a=null;const i=e.getAudioTracks().length>0,s=((n==null?void 0:n.getAudioTracks().length)??0)>0,c=((r==null?void 0:r.getAudioTracks().length)??0)>0;if(i||s||c){a=new AudioContext;const v=a.createMediaStreamDestination();i&&a.createMediaStreamSource(new MediaStream(e.getAudioTracks())).connect(v),s&&n&&a.createMediaStreamSource(new MediaStream(n.getAudioTracks())).connect(v),c&&r&&a.createMediaStreamSource(new MediaStream(r.getAudioTracks())).connect(v),o=v.stream.getAudioTracks()[0]??null}let l=null;try{const v=await yg(e);le=v.videoEl,_e=v.canvasStream,l=v.videoTrack}catch(v){console.warn("[manuscript/recording] watermark compositor failed; falling back to raw tab video:",v)}const d=l?[l]:[...e.getVideoTracks()];o&&d.push(o);const p=new MediaStream(d);Ne=e,He=n,ze=r,Fe=a,Gt=p;const u=e.getVideoTracks()[0],f=u&&typeof u.getSettings=="function"?u.getSettings():null,h=(f==null?void 0:f.displaySurface)??"(unknown)";console.info("[manuscript/recording] capture stream info",{displaySurface:h,tabAudioTracks:e.getAudioTracks().length,systemAudioTracks:(n==null?void 0:n.getAudioTracks().length)??0,microphoneTracks:(r==null?void 0:r.getAudioTracks().length)??0,mergedAudioTrack:!!o});const m=()=>{const v=Dn;v&&v.getPhase()!=="idle"&&v.stopRecording()};return u&&u.addEventListener("ended",m),n==null||n.getAudioTracks().forEach(v=>v.addEventListener("ended",m)),r==null||r.getAudioTracks().forEach(v=>v.addEventListener("ended",m)),Ag().startRecording(),!0}async function yg(t){const e=document.createElement("video");e.muted=!0,e.playsInline=!0,e.setAttribute("data-manuscript","ui"),e.style.cssText="position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;",document.body.appendChild(e),e.srcObject=new MediaStream(t.getVideoTracks()),await e.play();const n=t.getVideoTracks()[0],r=(n==null?void 0:n.getSettings())??{},o=(typeof r.width=="number"?r.width:void 0)??e.videoWidth??1280,a=(typeof r.height=="number"?r.height:void 0)??e.videoHeight??720,i=document.createElement("canvas");i.width=o,i.height=a;const s=i.getContext("2d");if(!s)throw new Error("2D canvas context unavailable");const c=await mg();ho=!0;const l=()=>{if(!ho)return;s.drawImage(e,0,0,i.width,i.height),gg(s,c,i.width,i.height);const u=e.requestVideoFrameCallback;typeof u=="function"?u.call(e,l):requestAnimationFrame(l)};l();const d=i.captureStream(),p=d.getVideoTracks()[0];if(!p)throw new Error("canvas.captureStream produced no video track");return{videoEl:e,canvasStream:d,videoTrack:p}}function xg(t){we||(we=e=>{const n=e.target;if(!(n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement||n instanceof HTMLElement&&n.isContentEditable)){if(e.key===" "||e.key==="Spacebar"){e.preventDefault(),e.stopPropagation(),mc();return}if(e.key==="Escape"){e.preventDefault(),e.stopPropagation(),Lr(),t.stop();return}}},window.addEventListener("keydown",we,!0))}function wg(){we&&(window.removeEventListener("keydown",we,!0),we=null)}function mc(){var e;if(!pt())return;Je(),((e=A.state)==null?void 0:e.paused)===!0?ig({onResume:mc}):Lr()}function kg(t){let e;try{e=cg(bg)}catch(n){return console.warn("[manuscript/recording] no supported mime:",n),null}return Uo=e,console.info("[manuscript/recording] using mimeType",e,{streamAudioTracks:t.getAudioTracks().length,streamVideoTracks:t.getVideoTracks().length}),lg(t,{factory:{create:(n,r)=>new MediaRecorder(n,r)},mimeType:e,timesliceMs:1e3})}function Sg(t,e){const n=new Date(t),r=i=>String(i).padStart(2,"0"),o=`${n.getFullYear()}${r(n.getMonth()+1)}${r(n.getDate())}-${r(n.getHours())}${r(n.getMinutes())}`,a=e.includes("webm")?"webm":"video";return`manuscript-recording-${o}.${a}`}function or(){ho=!1,Gt==null||Gt.getTracks().forEach(t=>t.stop()),_e==null||_e.getTracks().forEach(t=>t.stop()),Ne==null||Ne.getTracks().forEach(t=>t.stop()),He==null||He.getTracks().forEach(t=>t.stop()),ze==null||ze.getTracks().forEach(t=>t.stop()),Fe==null||Fe.close().catch(()=>{}),le&&(le.pause(),le.srcObject=null,le.remove()),Gt=null,Ne=null,He=null,ze=null,Fe=null,le=null,_e=null,rr=null,Uo=null,jo=null,Ge=!1}async function Eg(){const t=rr;if(!t){or();return}try{const e=await t.stop(),n=URL.createObjectURL(e.blob),r=Sg(jo??Date.now(),Uo??"video/webm");try{await chrome.runtime.sendMessage({type:"recording.download",url:n,filename:r})}catch(o){console.warn("[manuscript/recording] download forward failed:",o)}}catch(e){console.warn("[manuscript/recording] recorder.stop failed:",e)}finally{or()}}function Ag(){if(!Dn){const t=dg({mountCountdown:ng,unmountCountdown:Bo,sendMessage:async()=>{},isStandalonePlayback:sn,onRecordingStarting:()=>{if(Ge){An()&&ai(!0);return}An()&&oi(!0),jr(!0)},onRecordingStarted:()=>{xg({stop:()=>void t.stopRecording()}),Ge||jr(!0);const e=Gt;if(e){const n=kg(e);if(n){rr=n,jo=Date.now();try{n.start()}catch(r){console.warn("[manuscript/recording] recorder start failed:",r),or();return}}}!pt()&&L()&&De(0)},onRecordingStopped:()=>{wg(),Lr(),Ge?An()&&ai(!1):(jr(!1),An()&&oi(!1)),pt()&&Te(),rr?Eg():or()}});Dn=t,document.addEventListener("manuscript:replay-end",()=>{t.getPhase()==="recording"&&t.stopRecording()}),ht(e=>{e.prev==="replay"&&e.next!=="replay"&&t.getPhase()==="recording"&&t.stopRecording()})}return Dn}const $g="/assets/share-step-1-B4IYEXR4.png",Mg="/assets/share-step-2-B99Thpfo.png",Lg=chrome.runtime.getURL($g.replace(/^\/+/,"")),Tg=chrome.runtime.getURL(Mg.replace(/^\/+/,""));let fe=null;function Cg(t){var i,s,c;if(fe!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-guide"),e.style.cssText=["position: fixed","inset: 0",`z-index: ${O+12}`,"pointer-events: auto"].join("; "),It(e);const n=e.attachShadow({mode:"open"});n.innerHTML=Ig(),document.body.appendChild(e);function r(l){var d;Qa(),(d=t.onCancel)==null||d.call(t)}function o(){var p,u;const l=((p=n.querySelector('[data-action="keep-ui"]'))==null?void 0:p.checked)===!0,d=((u=n.querySelector('[data-action="with-mic"]'))==null?void 0:u.checked)===!0;Qa(),t.onStart({keepUiVisible:l,withMicrophone:d})}(i=n.querySelector('[data-action="start"]'))==null||i.addEventListener("click",o),(s=n.querySelector('[data-action="cancel"]'))==null||s.addEventListener("click",()=>r()),(c=n.querySelector('[data-action="scrim-close"]'))==null||c.addEventListener("click",l=>{l.target===l.currentTarget&&r()});const a=l=>{l.key==="Escape"&&(l.preventDefault(),r())};window.addEventListener("keydown",a),fe={host:e,keyListener:a}}function Qa(){fe&&(window.removeEventListener("keydown",fe.keyListener),fe.host.remove(),fe=null)}function Ig(){return`
    <style>
      ${vt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .card {
        width: min(700px, calc(100vw - 48px));
        max-height: calc(100vh - 48px);
        overflow: auto;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        animation: card-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes card-pop {
        from { transform: scale(0.96); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .head {
        padding: 22px 28px 8px;
      }
      .title {
        font-size: 19px;
        font-weight: 600;
        margin: 0 0 8px;
      }
      .subtitle {
        font-size: 13px;
        color: var(--c-text-mute, #555);
        margin: 0;
        line-height: 1.5;
      }
      .steps {
        padding: 12px 28px 8px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      .step {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .step-head {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .step-badge {
        width: 26px;
        height: 26px;
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
        display: grid;
        place-items: center;
        flex-shrink: 0;
      }
      .step-title {
        font-size: 14px;
        font-weight: 600;
      }
      .step-img {
        width: 100%;
        height: auto;
        border: 1px solid var(--c-border, #ddd);
        border-radius: 8px;
        background: var(--c-surface-2, #f6f7f8);
        display: block;
      }
      .step-desc {
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
        margin: 0;
      }
      .step-desc ol {
        margin: 0 0 8px;
        padding-left: 18px;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .step-desc ol li {
        padding-left: 2px;
      }
      .step-desc p {
        margin: 6px 0 0;
      }
      .step-desc kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .options {
        padding: 4px 28px 0;
      }
      .opt-row {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.45;
        cursor: pointer;
        user-select: none;
        padding: 6px 8px;
        border-radius: 6px;
        transition: background 0.12s ease;
      }
      .opt-row + .opt-row { margin-top: 2px; }
      .opt-row:hover { background: var(--c-surface-2, #f6f7f8); }
      .opt-row input {
        margin: 2px 0 0;
        accent-color: var(--c-primary, #1a73e8);
      }
      .opt-row .opt-label { font-weight: 500; color: var(--c-text); }
      .opt-row .opt-hint { display: block; margin-top: 1px; }
      .keys-info {
        padding: 10px 28px 0;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
      }
      .keys-info kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .actions {
        padding: 12px 28px 22px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .btn {
        appearance: none;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 18px;
        border-radius: 999px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: filter 0.12s ease, background 0.12s ease;
      }
      .btn-ghost {
        background: transparent;
        color: var(--c-text-mute, #555);
        border-color: var(--c-border-strong, #d2d6dc);
      }
      .btn-ghost:hover { color: var(--c-text, #111); }
      .btn-primary {
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
      }
      .btn-primary:hover { filter: brightness(1.06); }
    </style>
    <div class="scrim" data-action="scrim-close" role="dialog" aria-modal="true" aria-labelledby="rec-guide-title">
      <div class="card">
        <div class="head">
          <h2 id="rec-guide-title" class="title">${g("recording.guide.title")}</h2>
          <p class="subtitle">${g("recording.guide.subtitle")}</p>
        </div>
        <div class="steps">
          <div class="step">
            <div class="step-head">
              <div class="step-badge">1</div>
              <div class="step-title">${g("recording.guide.step1-title")}</div>
            </div>
            <img src="${Lg}" alt="${g("recording.guide.step1-alt")}" class="step-img" />
            <div class="step-desc">${g("recording.guide.step1-desc-html")}</div>
          </div>
          <div class="step">
            <div class="step-head">
              <div class="step-badge">2</div>
              <div class="step-title">${g("recording.guide.step2-title")}</div>
            </div>
            <img src="${Tg}" alt="${g("recording.guide.step2-alt")}" class="step-img" />
            <div class="step-desc">${g("recording.guide.step2-desc-html")}</div>
          </div>
        </div>
        <div class="options">
          <label class="opt-row">
            <input type="checkbox" data-action="keep-ui" />
            <span>
              <span class="opt-label">${g("recording.guide.keep-ui-label")}</span>
              <span class="opt-hint">${g("recording.guide.keep-ui-hint")}</span>
            </span>
          </label>
          <label class="opt-row">
            <input type="checkbox" data-action="with-mic" />
            <span>
              <span class="opt-label">${g("recording.guide.mic-label")}</span>
              <span class="opt-hint">${g("recording.guide.mic-hint")}</span>
            </span>
          </label>
        </div>
        <div class="keys-info" data-region="keys-info">
          ${g("recording.guide.keys-info-html")}
        </div>
        <div class="actions">
          <button type="button" class="btn btn-ghost" data-action="cancel">
            ${g("recording.guide.cancel")} <kbd>Esc</kbd>
          </button>
          <button type="button" class="btn btn-primary" data-action="start">
            ${g("recording.guide.start")}
          </button>
        </div>
      </div>
    </div>
  `}function Dg(){const t=L();if(t)try{const e=Kc(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Og(t.name)}-${Ng(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),Ct(g("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),Ct(g("toast.export-failed"),!0)}}async function Pg(){const t=L();if(t){if(t.steps.length===0){Ct(g("toast.no-steps"),!0);return}Ji(),await De(0,{paused:!0})}}function Rg(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Zc(r);$i(o),Ct(g("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),Ct(g("toast.import-failed"),!0)}}),t.click()}function Og(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Ng(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function Tr(t){const e=L(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!Cr(n.pickedAtUrl,location.href)?(Wo(n.pickedAtUrl,t),!0):!1}function Ye(){const t=L();if(!t)return;const e=W(),n=t.steps[e],r=t.steps[e+1];_s({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function Cr(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function Wo(t,e){const n=L();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let ar=!1,bc=0,vc=0,go=0,mo=0;function Hg(){const{shadow:t}=b;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=b;if(!o)return;ar=!0,bc=n.clientX,vc=n.clientY;const a=o.getBoundingClientRect();go=a.left,mo=a.top,o.style.left=`${go}px`,o.style.top=`${mo}px`,o.style.right="auto",document.addEventListener("mousemove",yc,!0),document.addEventListener("mouseup",xc,!0),n.preventDefault()})}function yc(t){const{host:e}=b;if(!ar||!e)return;const n=t.clientX-bc,r=t.clientY-vc,o=e.offsetWidth,a=e.offsetHeight,i=er(go+n,0,window.innerWidth-o),s=er(mo+r,0,window.innerHeight-a);e.style.left=`${i}px`,e.style.top=`${s}px`}function xc(){ar&&(ar=!1,document.removeEventListener("mousemove",yc,!0),document.removeEventListener("mouseup",xc,!0))}let ir=!1,wc=0,kc=0;function zg(){const{shadow:t}=b;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=b;r&&(ir=!0,wc=n.clientY,kc=r.getBoundingClientRect().height,document.addEventListener("mousemove",Sc,!0),document.addEventListener("mouseup",Ec,!0),n.preventDefault(),n.stopPropagation())})}function Sc(t){const{host:e}=b;if(!ir||!e)return;const n=t.clientY-wc,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-ye,a=er(kc+n,tr,o);e.style.height=`${a}px`,e.style.maxHeight=`${a}px`}function Ec(){ir&&(ir=!1,document.removeEventListener("mousemove",Sc,!0),document.removeEventListener("mouseup",Ec,!0))}function Fg(t){const e=window.innerHeight-ye*2;return er(t,tr,Math.max(tr,e))}function Ac(){const{host:t}=b;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-ye;if(e.bottom>n){const o=Math.max(tr,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),a=window.innerWidth-r.width;o>a&&(t.style.left=`${Math.max(0,a)}px`)}if(t.style.top){const o=parseFloat(t.style.top),a=window.innerHeight-r.height;o>a&&(t.style.top=`${Math.max(0,a)}px`)}}function Vo(){var t;return((t=b.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function $c(){var t;return((t=b.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function _g(){const t=Vo();t&&(t.hidden?(qg(),t.hidden=!1):t.hidden=!0)}function Mc(){const t=Vo();t&&(t.hidden=!0)}async function qg(){const t=$c();if(!t)return;await ol();const e=al(),n=await il(),r=a=>a.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const a of e){const i=a.name===n?" selected":"";o.push(`<option value="${r(a.name)}"${i}>${r(a.name)} (${r(a.lang)})</option>`)}t.innerHTML=o.join("")}function Bg(){var n;const t=$c();t&&t.addEventListener("change",()=>{const r=t.value;rl(r.length>0?r:null)});const e=(n=b.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>Mc())}function Lc(t){var o;const e=Vo();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=b.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Mc()}let qe=null;function Tc(t){qe=t}function ft(t){const e=t===W();Dt(t),e&&Cc()}function Cc(){var r;const t=lt();if(!(t!=null&&t.selectors)){qe=null,Me();return}let e=null;const n=b.subSelection;if(n.stepId===t.id&&n.anchorId){const o=(r=t.subElements)==null?void 0:r.find(a=>a.id===n.anchorId);o&&(e=Se(o.selectors))}if(e||(e=Se(t.selectors)),!e){qe=null,Me();return}e!==qe&&un(e,{behavior:"smooth"}),qe=e,Ho(e)}function Ja(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function Xo(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function Ug(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function jg(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function Wg(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function Vg(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function Xg(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function Gg(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=L(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));ft(l)}const a=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${a}" aria-label="Auto-advance seconds" />
    ${Xo(10)}
  `;const i=t.querySelector("input");if(!i)return;i.focus(),i.select();const s=l=>{if(t.classList.remove("editing"),l){ti(t,a);return}const d=i.value.trim();let p=5;if(d===""||d==="0")ge(r.id,{autoAdvanceMs:null});else{const u=Number(d);Number.isFinite(u)&&u>0?(ge(r.id,{autoAdvanceMs:Math.round(u*1e3)}),p=u):ge(r.id,{autoAdvanceMs:null})}ti(t,p)};i.addEventListener("blur",()=>s(!1)),i.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),i.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),i.addEventListener("mousedown",l=>l.stopPropagation())}function ti(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${Xo(10)}
  `}function Yg(t,e){const{shadow:n,host:r}=b;if(!n||!r)return;Hg(),zg(),sm(),Bg(),document.addEventListener("mousedown",Lc,!0);const o=a=>a.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",a=>Zg(a,t,e)),document.addEventListener("keydown",Ic,!0),document.addEventListener("mousedown",Dc,!0)}function Kg(){document.removeEventListener("mousedown",Lc,!0),document.removeEventListener("keydown",Ic,!0),document.removeEventListener("mousedown",Dc,!0)}function Ic(t){if(t.key==="Escape"){const r=b.subSelection;if(r.selectedIds.length===0&&!r.primarySelected)return;const o=Wr();if(o&&Vr(o))return;const a=r.stepId;b.subSelection=tn,a&&ke(a);return}if(t.key==="ArrowLeft"||t.key==="ArrowRight"){const r=b.subSelection;if(!r.stepId||!r.anchorId)return;const o=Wr();if(o&&Vr(o))return;t.preventDefault(),Ii(r.stepId,r.anchorId,r.selectedIds,t.key==="ArrowLeft"?-1:1);return}if(t.key!=="Delete"&&t.key!=="Backspace")return;const e=b.subSelection;if(!e.stepId||e.selectedIds.length===0)return;const n=Wr();n&&Vr(n)||(t.preventDefault(),Xl(e.stepId,e.selectedIds),b.subSelection=tn)}function Dc(t){const e=b.subSelection;if(e.selectedIds.length===0&&!e.primarySelected)return;const n=t.composedPath();for(const o of n)if(o instanceof Element&&o.matches(".sub-node, .sub-add, .sub-gap"))return;const r=e.stepId;b.subSelection=tn,r&&ke(r)}function Wr(){var e;let t=document.activeElement;for(;t&&((e=t.shadowRoot)!=null&&e.activeElement);)t=t.shadowRoot.activeElement;return t}function Vr(t){return!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLElement&&t.isContentEditable)}function Zg(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="palette-toggle"]')){t.stopPropagation(),fl();return}if(o.closest('[data-action="recording-toggle"]')){t.stopPropagation(),Qg();return}if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void Pg();if(o.closest('[data-action="prompter"]')){n(!0),zs().then(()=>{Ye()});return}if(o.closest('[data-action="export"]'))return Dg();if(o.closest('[data-action="import"]'))return Rg();if(o.closest('[data-action="validate"]'))return em();if(o.closest('[data-action="settings-toggle"]'))return _g();const a=o.closest('[data-action="tool-set"]');if(a instanceof HTMLElement){t.stopPropagation();const s=a.getAttribute("data-tool");if(s==="shape"){Qh(a,c=>{Up(c),R("shape")});return}R(At()===s?"idle":s);return}if(Jg(t,o))return;const i=o.closest("[data-step-card]");if(i&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(i.getAttribute("data-step-card"));if(Tr(s))return;ft(s)}}async function Qg(){const t=L(),e=t?nc(t):"";if(e&&!yr(e,location.href)){const n=await rc(e);if(n==="cancel")return;if(n==="navigate"){location.href=e;return}}Cg({onStart:({keepUiVisible:n,withMicrophone:r})=>{vg({keepUiVisible:n,withMicrophone:r}).then(o=>{o||Ct("Recording cancelled or unsupported.")})}})}function Jg(t,e){var u;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const f=Number(n.getAttribute("data-insert-index"));return ra({insertIndex:f}),!0}if(e.closest('[data-action="step-add"]'))return ra(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const f=Number(r.getAttribute("data-step-index"));return Tr(f)||(ft(f),R(At()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),_l(Number(o.getAttribute("data-step-index"))),!0;const a=e.closest('[data-action="step-link"]');if(a){t.stopPropagation();const f=a.getAttribute("data-url")??"",h=a.closest("[data-step-card]"),m=h?Number(h.getAttribute("data-step-card")):0;return f?Cr(f,location.href)?(Number.isFinite(m)&&ft(m),!0):(Wo(f,Number.isFinite(m)?m:0),!0):!0}const i=e.closest('[data-action="step-action-toggle"]');if(i instanceof HTMLElement){t.stopPropagation();const f=Number(i.getAttribute("data-step-index")),h=(u=L())==null?void 0:u.steps[f];return h&&(ft(f),ge(h.id,{waitForNavigation:!h.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');if(s instanceof HTMLElement)return t.stopPropagation(),s.classList.contains("disabled")||Gg(s),!0;const c=e.closest('[data-action="sub-add"]');if(c instanceof HTMLElement)return t.stopPropagation(),rm(c),!0;const l=e.closest('[data-action="sub-shift"]');if(l instanceof HTMLElement)return t.stopPropagation(),t.preventDefault(),tm(l),!0;const d=e.closest(".sub-node[data-sub-id]");if(d instanceof HTMLElement)return t.stopPropagation(),om(d,t),!0;const p=e.closest(".sub-node.primary[data-primary]");return p instanceof HTMLElement?(t.stopPropagation(),am(p),!0):!1}function tm(t){const e=t.dataset.subId??"",n=Number(t.dataset.direction??"0");if(!e||n!==-1&&n!==1)return;const r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!o)return;const a=$r(b.subSelection,o);Ii(o,e,a,n)}let St=null;function sr(t){const{shadow:e}=b;e&&requestAnimationFrame(()=>{const n=e.querySelector(`[data-step-card="${t}"]`);n==null||n.scrollIntoView({behavior:"smooth",block:"center"})})}function em(){const t=L();if(!t)return;const e=typeof location<"u"?location.href:"";St=Ih(t,e),po({scenario:t,session:St,phase:"initial",onStart:()=>{Pc(t)},onGoToStep:n=>{xe(),St=null,Tt();const r=t.steps.findIndex(o=>o.id===n);r>=0&&(ft(r),sr(r))},onRepick:n=>{xe(),St=null,Tt();const r=t.steps.findIndex(o=>o.id===n);r<0||(ft(r),sr(r),b.pickerTarget={type:"primary"},R("picker"))},onClose:()=>{xe(),St=null,Tt()}})}async function nm(){const t=await Qc();if(!t)return;const e=L();if(!e||e.id!==t.scenarioId){await Tt();return}St=t,dc(t);const n={onStart:()=>{},onGoToStep:r=>{xe(),St=null,Tt();const o=e.steps.findIndex(a=>a.id===r);o>=0&&(ft(o),sr(o))},onRepick:r=>{xe(),St=null,Tt();const o=e.steps.findIndex(a=>a.id===r);o<0||(ft(o),sr(o),b.pickerTarget={type:"primary"},R("picker"))},onClose:()=>{xe(),St=null,Tt()}};if(lc(t)){po({scenario:e,session:t,phase:"complete",...n});return}po({scenario:e,session:t,phase:"validating",...n}),await Pc(e)}async function Pc(t){var r;if(!t)return;const e=St;if(!e)return;if(Ut({phase:"validating"}),await new Promise(o=>setTimeout(o,30)),await Dh(t,e,()=>{Ut({session:e})}),await Rh(e),Ut({session:e}),lc(e)){dc(e),Ut({phase:"complete"});const o=((r=t.steps[0])==null?void 0:r.pickedAtUrl)||t.url||"";if(o&&!Cr(o,location.href)){await new Promise(a=>setTimeout(a,700)),Ut({phase:"navigating",navigatingTo:o}),await new Promise(a=>setTimeout(a,600)),location.href=o;return}await Tt();return}const n=Ph(e);if(!n){Ut({phase:"complete"}),await Tt();return}Ut({phase:"navigating",navigatingTo:n}),await new Promise(o=>setTimeout(o,600)),location.href=n}function rm(t){const e=t.dataset.stepId??"";if(!e)return;const n=L(),r=n==null?void 0:n.steps.find(a=>a.id===e);if(!r||!r.selectors)return;const o=r.pickedAtUrl;if(o&&!yr(o,location.href)){Ct(g("sub.same-url-required"),!0);return}b.pickerTarget={type:"sub-add",stepId:e},R("picker")}function om(t,e){var p;const n=t.dataset.subId??"",r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!n||!o)return;const a=L(),i=(a==null?void 0:a.steps.findIndex(u=>u.id===o))??-1;if(!a||i<0)return;const s=a.steps[i],c=(p=s==null?void 0:s.subElements)==null?void 0:p.find(u=>u.id===n);if(!s||!c)return;const l=e;if(l.shiftKey){const u=(s.subElements??[]).map(f=>f.id);b.subSelection=Hh(b.subSelection,o,n,u),ke(o);return}if(l.ctrlKey||l.metaKey){b.subSelection=Nh(b.subSelection,o,n),ke(o);return}b.subSelection=Oh(b.subSelection,o,n),i!==W()&&Dt(i);const d=Se(c.selectors);d&&(un(d,{behavior:"smooth"}),zo(d,{durationMs:350}),Tc(d)),ke(o)}function am(t){const e=t.closest('[data-region="sub-track"]'),n=(e==null?void 0:e.dataset.stepId)??"";if(!n)return;const r=L(),o=(r==null?void 0:r.steps.findIndex(s=>s.id===n))??-1;if(o<0)return;const a=r==null?void 0:r.steps[o],i=(a==null?void 0:a.pickedAtUrl)||(r==null?void 0:r.url)||"";if(i&&!Cr(i,location.href)){Wo(i,o);return}if(b.subSelection=zh(b.subSelection,n),o!==W()&&Dt(o),ke(n),a!=null&&a.selectors){const s=Se(a.selectors);s&&(un(s,{behavior:"smooth"}),zo(s,{durationMs:350}),Tc(s))}}function ke(t){const{shadow:e}=b;if(!e)return;const n=e.querySelector(`[data-region="sub-track"][data-step-id="${im(t)}"]`);if(!n)return;const r=new Set($r(b.subSelection,t));n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{const i=a.dataset.subId;i&&a.classList.toggle("selected",r.has(i))});const o=n.querySelector(".sub-node.primary");o&&o.classList.toggle("selected",uc(b.subSelection,t))}function im(t){return t.replace(/[^a-zA-Z0-9_-]/g,"\\$&")}function sm(){const{shadow:t}=b;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>bo(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=L();r&&(e.textContent=r.name),bo(e),e.blur()}}),e.addEventListener("blur",()=>{zl(e.textContent??"")}))}function bo(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const cm='[data-manuscript="ui"][data-region="permission-banner"]';function Rc(){return document.querySelector(cm)}function lm(t){const e=Rc();if(e){Nc(e,t);return}dm(t)}function Oc(){const t=Rc();t&&t.remove()}function Nc(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function dm(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),It(e),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${O+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=um(),Nc(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>Oc()),document.body.appendChild(e)}function um(){return`
    <style>
      ${vt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const En=16,pm=240,fm=/permission|<all_urls>|activeTab/i;async function Hc(t){const e=hm({x:t.x-En,y:t.y-En,width:t.width+En*2,height:t.height+En*2});if(e.width<=0||e.height<=0)return null;const n=await gm();if(!n.ok)return fm.test(n.error)?lm(g("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await vm(n.dataUrl,e,pm)}catch(r){return console.error("[manuscript] crop failed",r),null}}function hm(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function gm(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await bm();try{return{ok:!0,dataUrl:await mm()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function mm(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function bm(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function vm(t,e,n){const r=await ym(t),o=r.naturalWidth/window.innerWidth||1,a=e.x*o,i=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),d=Math.max(1,Math.round(e.width*l)),p=Math.max(1,Math.round(e.height*l)),u=document.createElement("canvas");u.width=d,u.height=p;const f=u.getContext("2d");if(!f)throw new Error("No 2d context");return f.drawImage(r,a,i,s,c,0,0,d,p),u.toDataURL("image/png")}function ym(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function zc(t){const e=t.detail,n=b.pickerTarget;b.pickerTarget={type:"primary"};const r=xm(e.rect,e.chain.framePath);if(n.type==="sub-add"){const o=Vl({selectors:e.chain,thumbnailDataUrl:null,pickedAtUrl:location.href});o&&km(n.stepId,o.id,r);return}Bl(e.chain),wm(r)}function xm(t,e){if(!e||e.length===0)return t;const n=vd(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function wm(t){try{const e=await Hc(t);Fl(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}async function km(t,e,n){try{const r=await Hc(n);Gl(t,e,{thumbnailDataUrl:r})}catch(r){console.warn("[manuscript] sub thumbnail capture skipped",r)}}function Sm(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Record button — same primary fill as play / prompter so the
         footer trio reads as one cluster (the design-system way of
         saying "these are the three CTAs"). The red dot icon is the
         only theme-independent piece — it carries the "record"
         affordance without making the whole button red at rest.
         Pressed flips to var(--c-error) + stop square + pulse halo so
         the recording state is unmistakable. Hidden during bridge
         standalone sessions; that branch is enforced at the controller
         layer. */
      .record-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        /* Record dot reads as an activity indicator, not an error
           state, so brighten --c-error locally with a 22% white mix.
           Stays palette-aware (light/dark both shift together) without
           touching the global error token or its other consumers. */
        color: color-mix(in oklch, var(--c-error), white 22%);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease, color 160ms ease;
      }
      .record-btn:hover { background: var(--c-primary-h); }
      .record-btn .record-stop { display: none; }
      .record-btn[aria-pressed="true"] {
        background: var(--c-error);
        color: var(--c-primary-fg);
        animation: record-pulse 1.6s ease-in-out infinite;
      }
      .record-btn[aria-pressed="true"] .record-dot { display: none; }
      .record-btn[aria-pressed="true"] .record-stop { display: inline-block; }
      @keyframes record-pulse {
        0%, 100% { box-shadow: 0 0 0 0 color-mix(in oklch, var(--c-error), transparent 60%); }
        50%      { box-shadow: 0 0 0 6px color-mix(in oklch, var(--c-error), transparent 100%); }
      }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
        /* Sit above the footer chrome (play-btn / record-btn / icon-btn
           / settings-popup at z-index 4) so the toast isn't clipped by
           those siblings. */
        z-index: 10;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Em(){return`
      ${vt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .palette-toggle {
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        color: var(--c-text-mute);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: border-color 160ms ease, color 160ms ease;
      }
      .palette-toggle:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .palette-toggle:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
      }
      .palette-toggle .palette-sun { display: none; }
      .palette-toggle .palette-moon { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-sun { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-moon { display: none; }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Am(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -3px;
        left: 2px;
        font-family: var(--ff-mono);
        font-size: 13px;
        font-weight: 700;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 2px 5px;
        border-radius: 3px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* Selector health dot — Phase A telemetry. Hover shows which layer
         resolved the element on the last replay / sync; red = miss. */
      .health-dot {
        position: absolute;
        top: -3px;
        right: -3px;
        width: 9px;
        height: 9px;
        border-radius: 999px;
        border: 1.5px solid var(--c-surface);
        box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
        pointer-events: auto;
        z-index: 4;
      }
      .health-dot[data-health="green"]  { background: var(--c-success); }
      .health-dot[data-health="yellow"] { background: var(--c-warning); }
      .health-dot[data-health="orange"] { background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%); }
      .health-dot[data-health="red"]    { background: var(--c-error); }
      .sub-node .health-dot { top: -2px; right: -2px; width: 7px; height: 7px; border-width: 1px; }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

      /* ---- Sub-element track (v0.1.2) ---- */
      .step-sub-track {
        position: relative;
        flex-basis: 100%;
        margin-top: 4px;
        padding: 6px 4px;
        border-top: 1px dashed var(--c-border);
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px;
        cursor: default;
        user-select: none;
      }
      .sub-rubber-band {
        position: absolute;
        pointer-events: none;
        border: 1px dashed var(--c-primary);
        background: var(--c-tint);
        opacity: 0.55;
        z-index: 5;
      }
      .sub-node {
        position: relative;
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        cursor: pointer;
      }
      /* Hover bridge — a transparent pseudo extends the sub-node's
         hover area outward so the cursor can move from the thumbnail to
         the outside-positioned shift buttons without losing :hover. */
      .sub-node::after {
        content: '';
        position: absolute;
        inset: -2px -10px -10px -10px;
        z-index: 1;
      }
      .sub-node.primary { border-color: var(--c-primary); }
      .sub-node.selected {
        outline: 2px solid var(--c-primary);
        outline-offset: 1px;
      }
      /* Time-shift buttons sit just outside the thumbnail edges so they
         don't cover the picked image content. They're always in the
         DOM but hidden until either the user hovers the sub or the sub
         is selected — that way a click that flips .selected via direct
         DOM manipulation surfaces them immediately, no re-render needed.
         Arrow keys do the same job for keyboard users (anchor sub). */
      .sub-shift {
        position: absolute;
        width: 13px;
        height: 13px;
        padding: 0;
        border: 1px solid var(--c-primary);
        background: rgba(255, 255, 255, 0.92);
        color: var(--c-primary);
        border-radius: 3px;
        font-size: 11px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        z-index: 3;
        user-select: none;
        opacity: 0;
        pointer-events: none;
      }
      /* No opacity transition — each click rebuilds the step card and a
         fade-in on the fresh sub-node element would visibly flicker on
         every press. Snap to 1 once hover re-applies on the next paint. */
      /* Buttons sit fully inside the sub-node thumbnail so moving the
         mouse from thumb → button never leaves the .sub-node hover area
         (avoids the disappear-mid-move flicker). */
      .sub-node:hover .sub-shift {
        opacity: 1;
        pointer-events: auto;
      }
      .sub-shift:hover { background: var(--c-tint); color: var(--c-primary); }
      .sub-shift-left { left: -8px; bottom: -7px; z-index: 3; }
      .sub-shift-right { right: -8px; bottom: -7px; z-index: 3; }
      .sub-node[draggable="true"] { cursor: grab; }
      .sub-node.dragging { opacity: 0.4; cursor: grabbing; }
      /* Insert-before / insert-after drop indicators — a 2px vertical
         bar flush against the hovered sub-node on the matching side. */
      .sub-node.drop-before::before,
      .sub-node.drop-after::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-node.drop-before::before { left: -5px; }
      .sub-node.drop-after::after { right: -5px; }
      .sub-gap.drop-on {
        position: relative;
      }
      .sub-gap.drop-on::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        left: 50%;
        transform: translateX(-50%);
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-badge {
        position: absolute;
        top: -4px;
        left: -4px;
        background: var(--c-surface);
        color: var(--c-primary);
        font-family: var(--ff-mono);
        font-size: 9px;
        font-weight: 700;
        padding: 1px 4px;
        border-radius: 999px;
        border: 1px solid var(--c-primary);
        line-height: 1;
      }
      .sub-gap {
        display: inline-flex;
        align-items: center;
        font-family: var(--ff-mono);
        font-size: 10px;
        color: var(--c-text-mute);
        white-space: nowrap;
        padding: 0 2px;
        user-select: none;
      }
      .sub-gap::before,
      .sub-gap::after {
        content: '';
        width: 6px;
        height: 1px;
        background: var(--c-border-strong);
        opacity: 0.6;
      }
      .sub-gap::before { margin-right: 4px; }
      .sub-gap::after  { margin-left: 4px; }
      .sub-add {
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px dashed var(--c-border-strong);
        background: transparent;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .sub-add:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }

  `}function $m(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Mm(){return[Em(),Am(),$m(),Sm()].join(`
`)}function Lm(){return`
    <style>${Mm()}</style>
    <div class="panel" role="region" aria-label="${g("panel.aria.region")}">
      ${Tm()}
      ${Cm()}
      <div class="body" data-region="steps"></div>
      ${Im()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${g("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Tm(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${pi({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <div class="header-actions">
          <button type="button" class="palette-toggle" data-action="palette-toggle" data-region="palette-toggle" aria-label="${g("panel.palette-toggle-aria")}" aria-pressed="false" title="${g("panel.palette-toggle-aria")}">
            <svg class="palette-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <circle cx="8" cy="8" r="3"></circle>
              <path d="M8 1.2v1.6M8 13.2v1.6M14.8 8h-1.6M2.8 8H1.2M12.8 3.2l-1.13 1.13M4.33 11.67l-1.13 1.13M12.8 12.8l-1.13-1.13M4.33 4.33L3.2 3.2"></path>
            </svg>
            <svg class="palette-moon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path d="M6.5 1.5a6.5 6.5 0 1 0 8 8 5.4 5.4 0 0 1-8-8z"></path>
            </svg>
          </button>
          <button type="button" class="close-btn" data-action="close" aria-label="${g("panel.close-aria")}">×</button>
        </div>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${g("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Cm(){return`
    <div class="tool-bar" role="toolbar" aria-label="${g("panel.tool-label")}">
      <span class="eyebrow">${g("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${g("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${g("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${g("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Im(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${g("panel.replay-aria")}" title="${g("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${g("panel.prompter-aria")}" title="${g("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
        <button type="button" class="record-btn" data-action="recording-toggle" data-region="record-btn" aria-pressed="false" aria-label="${g("panel.record-aria")}" title="${g("panel.record-aria")}">
          <svg class="record-dot" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="8" cy="8" r="5"/></svg>
          <svg class="record-stop" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="10" height="10" rx="1"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${g("panel.import-aria")}" title="${g("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${g("panel.export-aria")}" title="${g("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="validate" aria-label="${g("panel.validate-aria")}" title="${g("panel.validate-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 12l2 2 4-4"></path>
            <circle cx="12" cy="12" r="9"></circle>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${g("panel.settings-aria")}" title="${g("panel.settings.title")}" data-region="settings-toggle">
          ${Xg(16)}
        </button>
      </div>
      ${Dm()}
    </div>
  `}function Dm(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${g("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${g("panel.settings.close-aria")}" title="${g("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${g("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${g("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function Pm(t,e=[],n=!1){if(!t.selectors)return"";const r=t.subElements??[],o=t.subDwellsMs??[],a=new Set(e),i=[];return i.push(Rm(t,n)),r.forEach((s,c)=>{i.push(ei(c,o[c]??0)),i.push(Om(t.id,s,c,a.has(s.id)))}),r.length>0&&i.push(ei(r.length,o[r.length]??0)),i.push(Nm(t.id)),`<div class="step-sub-track" data-region="sub-track" data-step-id="${T(t.id)}">${i.join("")}</div>`}function Rm(t,e){const n=t.thumbnailDataUrl?` style="background-image: url('${T(t.thumbnailDataUrl)}')"`:"",r=e?"sub-node primary selected":"sub-node primary",o=Ar(t.id),a=Er(o),i=a!=="none"?`<span class="health-dot" data-health="${a}" data-target="primary-mirror" title="${T(Fc(o))}"></span>`:"";return`<div class="${r}" data-primary="1"${n}><span class="sub-badge">1</span>${i}</div>`}function Om(t,e,n,r){const o=e.thumbnailDataUrl?` style="background-image: url('${T(e.thumbnailDataUrl)}')"`:"",a=r?"sub-node selected":"sub-node",i=`<span class="sub-badge">${n+2}</span>`,s=Ar(t,e.id),c=Er(s),l=c!=="none"?`<span class="health-dot" data-health="${c}" data-target="sub" title="${T(Fc(s))}"></span>`:"",d=T(g("sub.shift-left")),p=T(g("sub.shift-right")),u=T(e.id),f=`<button type="button" class="sub-shift sub-shift-left" data-action="sub-shift" data-sub-id="${u}" data-direction="-1" aria-label="${d}" title="${d}" tabindex="-1">‹</button><button type="button" class="sub-shift sub-shift-right" data-action="sub-shift" data-sub-id="${u}" data-direction="1" aria-label="${p}" title="${p}" tabindex="-1">›</button>`;return`<div class="${a}" data-sub-id="${u}" data-sub-idx="${n}" draggable="true"${o}>${i}${l}${f}</div>`}function Fc(t){return t===1?g("health.layer1"):t===2?g("health.layer2"):t===3?g("health.layer3"):t===null?g("health.broken"):""}function ei(t,e){return`<div class="sub-gap" data-gap-idx="${t}"><span>${Hm(e)}</span></div>`}function Nm(t){const e=g("sub.add-aria")||"Add another element";return`<button type="button" class="sub-add" data-action="sub-add" data-step-id="${T(t)}" aria-label="${T(e)}" title="${T(e)}">+</button>`}function Hm(t){const e=t/1e3;return Number.isInteger(e)?`${e}s`:`${e.toFixed(1)}s`}function zm(t){var n;const e=t.pickedAtUrl||((n=L())==null?void 0:n.url)||"";return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${T(e)}"
        aria-label="Open ${T(e)}"
      >${Vg(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${rt(e)}</span>
    </div>
  `:""}function Fm(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,a=t.thumbnailDataUrl!==null,i=n&&At()==="picker",s="step-thumb"+(o?" has-element":"")+(i?" is-picking":""),c=a?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,d=t.waitForNavigation,p=Ar(t.id),u=Er(p);return r.innerHTML=`
    <button
      type="button"
      class="${s}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${T(g("step.wand-aria",{n:e+1}))}"
      title="${T(g("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!a?`<span class="step-thumb-icon">${Wg(18)}</span>`:""}
      ${!o&&!a?'<span class="step-thumb-plus">+</span>':""}
      ${u!=="none"?`<span class="health-dot" data-health="${u}" data-target="step" title="${T(_m(p))}"></span>`:""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${T(g("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${rt(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${T(g("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${rt(t.description)}</div>
    </div>
    ${zm(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${d}" aria-label="${T(g("step.action-aria"))}" title="${T(g("step.action-aria"))}">${jg(10)}</button>
      <div class="step-timer${d?" disabled":""}" data-action="step-timer" data-step-id="${T(t.id)}" title="${T(g("step.timer-aria"))}" ${d?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${Xo(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${T(g("step.delete-aria"))}" title="${T(g("step.delete-aria"))}">${Ug(12)}</button>
    </div>
    ${Pm(t,$r(b.subSelection,t.id),uc(b.subSelection,t.id))}
  `,r}function _m(t){return t===1?g("health.layer1"):t===2?g("health.layer2"):t===3?g("health.layer3"):t===null?g("health.broken"):""}function qm(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function Bm(t,e,n){ri(t,"step-name",n,r=>ge(e.id,{name:r})),ri(t,"step-desc",n,r=>ge(e.id,{description:r}),{escapeBlurs:!0}),Wm(t,n),jm(t,e),Um(t,e)}function Um(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id;n.addEventListener("mousedown",o=>{if(o.button!==0)return;const a=o.target;if(!a||a.closest(".sub-node, .sub-add"))return;const i=n.getBoundingClientRect(),s=o.clientX-i.left,c=o.clientY-i.top,l=document.createElement("div");l.className="sub-rubber-band",l.style.left=`${s}px`,l.style.top=`${c}px`,l.style.width="0px",l.style.height="0px",n.appendChild(l),o.preventDefault();const d=()=>{document.removeEventListener("mousemove",p),document.removeEventListener("mouseup",u),document.removeEventListener("keydown",f),l.remove()},p=h=>{const m=n.getBoundingClientRect(),v=h.clientX-m.left,w=h.clientY-m.top,x=Math.min(s,v),S=Math.min(c,w),z=Math.max(s,v),H=Math.max(c,w);l.style.left=`${x}px`,l.style.top=`${S}px`,l.style.width=`${z-x}px`,l.style.height=`${H-S}px`;const C=[];n.querySelectorAll(".sub-node[data-sub-id]").forEach(Y=>{const J=Y.getBoundingClientRect(),re=J.left-m.left,st=J.top-m.top,$t=J.right-m.left,pn=J.bottom-m.top,tt=x<$t&&z>re&&S<pn&&H>st;if(tt){const F=Y.dataset.subId;F&&C.push(F)}Y.classList.toggle("selected",tt)}),b.subSelection={stepId:r,selectedIds:C,anchorId:C[C.length-1]??null,primarySelected:!1}},u=()=>d(),f=h=>{h.key==="Escape"&&(d(),b.subSelection=tn,n.querySelectorAll(".sub-node.selected").forEach(m=>m.classList.remove("selected")))};document.addEventListener("mousemove",p),document.addEventListener("mouseup",u,{once:!0}),document.addEventListener("keydown",f)})}function jm(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id,o=()=>{n.querySelectorAll(".sub-node.drop-before, .sub-node.drop-after, .sub-gap.drop-on").forEach(a=>a.classList.remove("drop-before","drop-after","drop-on"))};n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{a.addEventListener("dragstart",i=>{i.stopPropagation();const s=a.dataset.subId??"";if(!s)return;const c=$r(b.subSelection,r),l=c.includes(s)?[...c]:[s];b.subDragSet=l,b.subDragStepId=r,l.forEach(d=>{const p=n.querySelector(`.sub-node[data-sub-id="${d.replace(/"/g,'\\"')}"]`);p==null||p.classList.add("dragging")}),i.dataTransfer&&(i.dataTransfer.setData("text/plain",`sub:${l.join(",")}`),i.dataTransfer.effectAllowed="move")}),a.addEventListener("dragend",()=>{n.querySelectorAll(".sub-node.dragging").forEach(i=>i.classList.remove("dragging")),b.subDragSet=null,b.subDragStepId=null,o()}),a.addEventListener("dragover",i=>{if(!b.subDragSet||b.subDragStepId!==r)return;const s=Number(a.dataset.subIdx);if(!Number.isFinite(s))return;const c=a.getBoundingClientRect(),l=i.clientX<c.left+c.width/2,d=l?s:s+1;if(ni(e,b.subDragSet,d)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add(l?"drop-before":"drop-after")}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-before","drop-after")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.subIdx);if(!Number.isFinite(s)||!b.subDragSet||b.subDragStepId!==r){o();return}const c=a.getBoundingClientRect(),d=i.clientX<c.left+c.width/2?s:s+1,p=b.subDragSet;b.subDragSet=null,b.subDragStepId=null,o(),oa(r,p,d)})}),n.querySelectorAll(".sub-gap[data-gap-idx]").forEach(a=>{a.addEventListener("dragover",i=>{if(!b.subDragSet||b.subDragStepId!==r)return;const s=Number(a.dataset.gapIdx);if(Number.isFinite(s)){if(ni(e,b.subDragSet,s)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add("drop-on")}}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-on")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.gapIdx);if(!Number.isFinite(s)||!b.subDragSet||b.subDragStepId!==r){o();return}const c=b.subDragSet;b.subDragSet=null,b.subDragStepId=null,o(),oa(r,c,s)})})}function ni(t,e,n){const r=t.subElements??[];if(r.length===0||e.length===0)return!0;const o=new Set(e);let a=0;for(let s=0;s<n&&s<r.length;s++){const c=r[s];c&&!o.has(c.id)&&a++}let i=0;for(let s=0;s<r.length;s++){const c=r[s];if(c){if(o.has(c.id))break;i++}}return a===i}function ri(t,e,n,r,o={}){const a=t.querySelector(`[data-region="${e}"]`);a&&(a.addEventListener("input",()=>qm(a)),a.addEventListener("focus",()=>{Tr(n)||Dt(n)}),a.addEventListener("mousedown",i=>i.stopPropagation()),a.addEventListener("blur",()=>r(a.textContent??"")),a.addEventListener("keydown",i=>{(i.key==="Enter"&&e==="step-name"||i.key==="Escape"&&o.escapeBlurs)&&(i.preventDefault(),a.blur())}))}function Wm(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}b.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),b.dragFromIndex=null,(n=b.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{b.dragFromIndex===null||b.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(b.dragFromIndex===null||b.dragFromIndex===e)&&(ql(b.dragFromIndex,e),b.dragFromIndex=null)})}function Vm(){const{shadow:t}=b;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=L();if(e.innerHTML="",!n)return;const r=W();n.steps.forEach((a,i)=>{if(i>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(i)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${i+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${i}" aria-label="Insert step here">
          ${Ja(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=Fm(a,i,r===i);e.appendChild(s),Bm(s,a,i)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${Ja(10,1.8)}
    </button>
  `,e.appendChild(o)}function An(){return b.host!==null}function _c(t){const{host:e}=b;e&&(e.dataset.promptedHidden=t?"1":"",Go(e))}function oi(t){const{host:e}=b;e&&(e.dataset.recordingHidden=t?"1":"",Go(e))}function ai(t){const{host:e}=b;e&&(e.dataset.tutorialRecording=t?"1":"",Go(e))}function Go(t){const e=At(),n=t.dataset.promptedHidden==="1",r=t.dataset.recordingHidden==="1",o=t.dataset.tutorialRecording==="1",a=e==="replay"&&!o;t.style.display=a||n||r?"none":""}async function cr(t){if(b.host){t&&await na(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),It(e);const n=Fg(window.innerHeight*_h);e.style.cssText=["position: fixed",`top: ${ye}px`,`right: ${ye}px`,`width: ${Fh}px`,`height: ${n}px`,`max-height: calc(100vh - ${ye*2}px)`,`z-index: ${O+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=Lm(),b.host=e,b.shadow=r,Yg(qc,_c),document.body.appendChild(e),t&&await na(t)||ea(),Gs(),document.addEventListener(on,zc),document.addEventListener(Sr,Bc),window.addEventListener("resize",Ac),b.unsubscribeMode=ht(Gr),b.unsubscribeScenario=Ce(Gr),Gr();const o=L();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(a){console.warn("[manuscript] markActive failed",a)}}function qc(){var e,n;const{host:t}=b;t&&(document.removeEventListener(on,zc),document.removeEventListener(Sr,Bc),window.removeEventListener("resize",Ac),Kg(),(e=b.unsubscribeMode)==null||e.call(b),b.unsubscribeMode=null,(n=b.unsubscribeScenario)==null||n.call(b),b.unsubscribeScenario=null,R("idle"),Me(),Ji(),Ys(),Mi(),Lh(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),b.host=null,b.shadow=null)}function Bc(t){const e=t.detail,{shadow:n}=b;if(!n)return;if(e.cleared){n.querySelectorAll(".health-dot").forEach(o=>o.remove());return}const r=Er(e.layer);if(e.subId){const o=n.querySelector(`.sub-node[data-sub-id="${e.subId.replace(/"/g,'\\"')}"]`);o&&Xr(o,r,"sub")}else n.querySelectorAll("[data-step-card]").forEach(a=>{var p;const i=(p=a.querySelector("[data-step-id]"))==null?void 0:p.dataset.stepId,s=a.querySelector('[data-region="sub-track"]'),c=s==null?void 0:s.dataset.stepId;if(i!==e.stepId&&c!==e.stepId)return;const l=a.querySelector(".step-thumb");l&&Xr(l,r,"step");const d=a.querySelector(".sub-node.primary");d&&Xr(d,r,"primary-mirror")})}function Xr(t,e,n){const r=t.querySelector(`.health-dot[data-target="${n}"]`);if(e==="none"){r==null||r.remove();return}if(r)r.setAttribute("data-health",e);else{const o=document.createElement("span");o.className="health-dot",o.dataset.health=e,o.dataset.target=n,t.appendChild(o)}}function Gr(){const{host:t,shadow:e}=b;if(!e||!t)return;const n=At(),r=t.dataset.promptedHidden==="1",o=t.dataset.recordingHidden==="1",a=t.dataset.tutorialRecording==="1",i=n==="replay"&&!a;t.style.display=i||r||o?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(l=>{const d=l.getAttribute("data-tool");l.setAttribute("aria-pressed",String(d===n))});const s=L(),c=e.querySelector('[data-region="title-edit"]');c&&s&&c!==e.activeElement&&(c.textContent!==s.name&&(c.textContent=s.name),bo(c)),Vm(),Cc(),vr()&&!pt()&&Ye()}function Xm(t,e,n){switch(t.type){case"panel.open":return cr(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return qc(),n({ok:!0}),!1;case"scenario.replay":return cr(t.scenarioId).then(()=>De(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return Gm(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return mf(),pt()&&Te(),kh(),_c(!1),n({ok:!0}),!1}return!1}function Gm(t,e){if(pt()){t==="prev"?Zn():t==="next"?Qe():t==="jump"&&typeof e=="number"?qo(e):t==="pause"&&Je();return}const n=L();if(!n)return;const r=W();if(t==="prev")r>0&&ft(r-1),Ye();else if(t==="next")r<n.steps.length-1&&ft(r+1),Ye();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(Tr(e))return;ft(e)}Ye()}else t==="pause"&&De(r)}async function Ym(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Km(){try{const t=await ui();if(!t)return;if(Zm()){await chrome.storage.local.remove(X.activeReplay);return}R("replay"),await cr(t.scenarioId),await De(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function Zm(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function Qm(){try{const t=await Ym();if(!t)return;await cr(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Dt(t.stepIndex),await nm()}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const Jm="manuscript:host",tb="manuscript:ext",eb="manuscript:ready";let ii=!1;function nb(){ii||(window.addEventListener("message",ob),ii=!0,ht(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Wt("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(eb)))}function rb(t){return typeof t=="object"&&t!==null&&t.source===Jm&&typeof t.type=="string"}function Wt(t,e,n){const r={source:tb,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function ob(t){const e=t.data;if(rb(e))switch(e.type){case"ping":Wt("pong",e.requestId,{version:ib()});return;case"load":try{const n=ab(e.scenario);$i(n),Wt("load-ack",e.requestId,{ok:!0})}catch(n){Wt("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!Wf()&&Gs(),Wt("play-ack",e.requestId,{ok:!0}),De(r,{paused:o,standalone:n}).catch(a=>{console.warn("[manuscript] startReplay failed",a)});return}case"pause":pt()&&Je(),Wt("pause-ack",e.requestId,{ok:pt()});return;case"next":pt()&&Qe();return;case"prev":pt()&&Zn();return;case"jump":pt()&&typeof e.index=="number"&&qo(e.index);return;case"exit":(async()=>(pt()&&await Te(),Wt("exit-ack",e.requestId,{ok:!0})))();return}}function ab(t){if(t==null)throw new Ko("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new Ko("Invalid JSON",n)}return Zo(e,{strict:!0})}return Zo(t,{strict:!0})}function ib(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const sb=window===window.top;rf();sl();kp();Kp();up();jp();bp();Ru();pf();hf();var si,ci;sb&&(gf().then(()=>{Km(),Qm()}),chrome.runtime.onMessage.addListener(Xm),(ci=(si=chrome.permissions)==null?void 0:si.onAdded)==null||ci.addListener(()=>Oc()),nb());export{Bd as M,Ud as V,vt as d,lt as g,Ce as o,It as r,pb as u};
