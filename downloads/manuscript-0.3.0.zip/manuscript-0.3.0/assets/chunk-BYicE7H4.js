const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-BnwJaGsj.js","assets/chunk-BXn8kzRm.js","assets/chunk-CS6Xu8dt.js","assets/chunk-ClheHCf9.js","assets/chunk-zhlhe4GL.js"])))=>i.map(i=>d[i]);
import{S as X,O as R,E as Ns}from"./chunk-BXn8kzRm.js";import{s as xi,g as Fs,S as Hs,a as Fr,b as wi,c as zs,m as ki,d as _s,e as Bs,f as ho,h as go}from"./chunk-CS6Xu8dt.js";import{t as m}from"./chunk-ClheHCf9.js";import{g as Si,i as qs,a as js,b as Ei,c as Ws,s as Us,d as Xs,w as Vs,l as Ys,e as Gs,f as Ks}from"./chunk-zhlhe4GL.js";const xr="manuscript:mode-changed";let cn="idle";function xt(){return cn}function D(t){if(t===cn)return;const e=cn;cn=t,document.dispatchEvent(new CustomEvent(xr,{detail:{prev:e,next:t}}))}function at(t){const e=n=>t(n.detail);return document.addEventListener(xr,e),()=>document.removeEventListener(xr,e)}function Ai(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),i=n*(1-e),a=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,d=0;switch(r){case 0:c=n,l=s,d=i;break;case 1:c=a,l=n,d=i;break;case 2:c=i,l=n,d=s;break;case 3:c=i,l=a,d=n;break;case 4:c=s,l=i,d=n;break;case 5:c=n,l=i,d=a;break}return[Math.round(c*255),Math.round(l*255),Math.round(d*255)]}function Mi(t,e,n){const r=t/255,o=e/255,i=n/255,a=Math.max(r,o,i),s=Math.min(r,o,i),c=a-s;let l=0;return c!==0&&(a===r?l=(o-i)/c%6:a===o?l=(i-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:a===0?0:c/a,v:a}}function $i(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function Li(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(i=>i+i).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(i=>!Number.isFinite(i))?{h:0,s:1,v:1}:Mi(n,r,o)}function ir(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function mo(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function Zs(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const Qs=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── PALETTE E — STUDIO-DARK ─────
   Cool slate dark, mirrors PALETTE D STUDIO. See design/dark-mode-design.md §4.1.
   Chroma ≤ 0.09 doctrine maintained (focus only allowed slight excess at 0.13). */
[data-palette="studio-dark"] {
  --c-bg:        oklch(0.16  0.012 245);
  --c-surface:   oklch(0.22  0.014 245);
  --c-surface-2: oklch(0.19  0.012 245);
  --c-text:      oklch(0.97  0.003 245);
  --c-text-mute: oklch(0.78  0.006 245);
  --c-text-soft: oklch(0.62  0.008 245);
  --c-border:    oklch(0.32  0.012 245);
  --c-border-strong: oklch(0.42 0.014 245);
  --c-primary:   oklch(0.70  0.09  245);
  --c-primary-h: oklch(0.78  0.09  245);
  --c-primary-fg: oklch(0.14  0.020 245);
  --c-tint:      oklch(0.32  0.045 245);
  --c-focus:     oklch(0.74  0.13  245);
}

/* ───── PALETTE F — INK-DARK ─────
   Warm-on-cool dark, mirrors PALETTE A INK. design/dark-mode-design.md §4.2.
   Absorbs \`08.DARK-MODE-TOKENS.md\` §1 (spotlight-editor) and §2 (launcher pill) tones. */
[data-palette="ink-dark"] {
  --c-bg:        oklch(0.14  0.015 250);
  --c-surface:   oklch(0.20  0.018 250);
  --c-surface-2: oklch(0.17  0.016 250);
  --c-text:      oklch(0.98  0.003  80);
  --c-text-mute: oklch(0.76  0.006  80);
  --c-text-soft: oklch(0.60  0.008  80);
  --c-border:    oklch(0.30  0.014 250);
  --c-border-strong: oklch(0.40 0.016 250);
  --c-primary:   oklch(0.66  0.06  250);
  --c-primary-h: oklch(0.74  0.07  250);
  --c-primary-fg: oklch(0.14  0.018 250);
  --c-tint:      oklch(0.30  0.05  250);
  --c-focus:     oklch(0.70  0.10  250);
}

/* ───── Dark-palette shared overrides ─────
   Shadows: alpha ~4× because black-on-black shadow is weak; pair with
   surface-lightness steps (--c-bg < --c-surface-2 < --c-surface) for elevation.
   Functional accents: lightness ↑ for contrast on dark surface (L≈0.22). */
[data-palette$="-dark"] {
  --shadow-sm:   0 1px 2px  rgb(0 0 0 / 0.40);
  --shadow-md:   0 2px 6px  rgb(0 0 0 / 0.45), 0 1px 2px rgb(0 0 0 / 0.35);
  --shadow-lg:   0 12px 28px rgb(0 0 0 / 0.55), 0 4px 8px rgb(0 0 0 / 0.40);
  --shadow-card: 0 1px 2px  rgb(0 0 0 / 0.35),
                 0 4px 10px rgb(0 0 0 / 0.40),
                 0 12px 24px rgb(0 0 0 / 0.50);

  --c-success: oklch(0.66 0.10 150);
  --c-warning: oklch(0.78 0.11  75);
  --c-error:   oklch(0.66 0.15  27);
  --c-info:    oklch(0.66 0.09 245);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function wt(){return Qs.replace(/:root\s*\{/g,":host {").replace(/\[data-palette([^\]]*)\]\s*\{/g,":host([data-palette$1]) {")}const Ti="studio",Js=["studio","ink","graphite","sepia","studio-dark","ink-dark"];function Ci(t){return typeof t=="string"&&Js.includes(t)}function Ii(t){return t.endsWith("-dark")}let ae=null;const wr=new Set;let bo=!1;async function tc(){if(ae)return ae;try{const e=(await chrome.storage.local.get(X.palette))[X.palette];if(Ci(e))return ae=e,e}catch{}return Ti}function Pi(){return ae??Ti}async function ec(t){ae=t,Di(t);try{await chrome.storage.local.set({[X.palette]:t})}catch{}}async function nc(){const t=Pi(),e=Ii(t)?"studio":"studio-dark";return await ec(e),e}function Et(t){wr.add(new WeakRef(t)),t.setAttribute("data-palette",Pi()),tc().then(e=>{t.isConnected&&t.setAttribute("data-palette",e)}),rc()}function rc(){if(!bo){bo=!0;try{chrome.storage.onChanged.addListener((t,e)=>{var r;if(e!=="local")return;const n=(r=t[X.palette])==null?void 0:r.newValue;Ci(n)&&(ae=n,Di(n))})}catch{}}}function Di(t){for(const e of[...wr]){const n=e.deref();n&&n.isConnected?(n.setAttribute("data-palette",t),oc(n,t)):wr.delete(e)}}function oc(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="palette-toggle"]');n&&n.setAttribute("aria-pressed",Ii(e)?"true":"false")}const ic=140,ac=140;function sc(){return`
    ${wt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${ic}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${ac}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function cc(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function lc(){return[sc(),cc()].join(`
`)}const kr="manuscript:scenario-changed",dc=500,uc=5e3,v={scenario:null,currentStepIndex:0,saveTimer:null};function T(){return v.scenario}function U(){return v.currentStepIndex}function st(){return v.scenario?v.scenario.steps[v.currentStepIndex]??null:null}function ye(t){return document.addEventListener(kr,t),()=>document.removeEventListener(kr,t)}function W(){document.dispatchEvent(new CustomEvent(kr)),pc()}function ct(){v.scenario&&(v.scenario.updatedAt=new Date().toISOString())}function Ri(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Hr(){return{id:Ri("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:uc,waitForNavigation:!1}}function pc(){if(!v.scenario)return;v.saveTimer!==null&&window.clearTimeout(v.saveTimer);const t=v.scenario;v.saveTimer=window.setTimeout(()=>{v.saveTimer=null,xi(t).catch(e=>{console.error("[manuscript] save failed",e)})},dc)}function qn(){v.saveTimer!==null&&(window.clearTimeout(v.saveTimer),v.saveTimer=null,v.scenario&&xi(v.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const fc=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],hc=8,gc=5;function mc(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const a=Sr(e.getAttribute("content"));a&&t.add(a)}const n=getComputedStyle(document.documentElement);for(const a of fc){const s=Sr(n.getPropertyValue(a));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:a,prop:s}of r)vo(t,a,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let a=0;a<o.length&&a<gc;a++)vo(t,o[a]??null,"background-color");const i=Array.from(t).filter(bc).slice(0,hc);return{text:i,background:i}}function vo(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Sr(r);o&&t.add(o)}function Sr(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],i=e[3];return`#${r}${r}${o}${o}${i}${i}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=ar(n[1]),i=ar(n[2]),a=ar(n[3]);return`#${sr(o)}${sr(i)}${sr(a)}`}return null}function ar(t){return Math.max(0,Math.min(255,Number(t)|0))}function sr(t){return t.toString(16).padStart(2,"0")}function bc(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const i=Math.max(n,r,o),a=Math.min(n,r,o);return!(i-a<12)}const vc="'Asta Sans', sans-serif",yc=6,xc=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function wc(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const i=o.trim();if(!i)continue;const a=Oi(i);if(!a)continue;const s=a.toLowerCase();if(!xc.has(s)&&!e.has(s)&&(e.add(s),n.push(Ec(i)),n.length>=yc))break}return n}function kc(t){const e=Sc(t)??t;return e.length>14?`${e.slice(0,13)}…`:e}function Sc(t){return Oi(t)}function Oi(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function Ec(t){return/asta\s*sans/i.test(t)?t:`${t}, ${vc}`}function yo(){qn();const t=Ac(),e=Mc();v.scenario={schemaVersion:Hs,id:Ri("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[Hr()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},v.currentStepIndex=0,W()}function Ac(){try{const t=mc();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function Mc(){try{return wc()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function xo(t){qn();const e=await Fs(t);return e?(v.scenario=e,v.currentStepIndex=0,W(),!0):!1}function Ni(t){qn(),v.scenario=t,v.currentStepIndex=0,W()}function $c(t){if(!v.scenario)return;const e=t.trim();!e||e===v.scenario.name||(v.scenario.name=e,v.scenario.updatedAt=new Date().toISOString(),W())}function Fi(){qn(),v.scenario=null,v.currentStepIndex=0,W()}function wo(t={}){if(!v.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>v.scenario.steps.length?v.scenario.steps.length:t.insertIndex;return v.scenario.steps.splice(e,0,Hr()),ct(),v.currentStepIndex=e,W(),v.currentStepIndex}function se(t,e){if(!v.scenario)return;const n=v.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(ct(),W())}function Lc(t){const e=st();!e||!v.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,ct(),W())}function Tc(t){v.scenario&&(t<0||t>=v.scenario.steps.length||(v.scenario.steps.splice(t,1),v.scenario.steps.length===0?(v.scenario.steps.push(Hr()),v.currentStepIndex=0):v.currentStepIndex>=v.scenario.steps.length?v.currentStepIndex=v.scenario.steps.length-1:t<v.currentStepIndex&&(v.currentStepIndex-=1),ct(),W()))}function gg(t){const e=st();if(!e||!v.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,ct(),W()}function Gt(t){v.scenario&&(t<0||t>=v.scenario.steps.length||t!==v.currentStepIndex&&(v.currentStepIndex=t,W()))}function Cc(t,e){if(!v.scenario||t===e||t<0||t>=v.scenario.steps.length||e<0||e>=v.scenario.steps.length)return;const[n]=v.scenario.steps.splice(t,1);n&&(v.scenario.steps.splice(e,0,n),v.currentStepIndex===t?v.currentStepIndex=e:t<v.currentStepIndex&&e>=v.currentStepIndex?v.currentStepIndex-=1:t>v.currentStepIndex&&e<=v.currentStepIndex&&(v.currentStepIndex+=1),ct(),W())}function Ic(t){const e=st();!e||!v.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),ct(),W())}function _e(t){const e=st();!e||!v.scenario||(e.annotations.push(t),ct(),W())}function Hi(t){const e=st();!e||!v.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),ct(),W())}function I(t,e){const n=st();!n||!v.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),ct(),W())}function zi(){var t;return((t=st())==null?void 0:t.annotations)??[]}function C(t){return zi().find(e=>e.id===t)}function Pc(t,e){if(!v.scenario)return;const n=e.trim();if(!n)return;const r=v.scenario.customColors??{},o=r[t]??[];o.includes(n)||(v.scenario.customColors={...r,[t]:[...o,n]},ct(),W())}function Dc(t,e){if(!v.scenario||!v.scenario.customColors)return;const n=v.scenario.customColors[t];!n||!n.includes(e)||(v.scenario.customColors={...v.scenario.customColors,[t]:n.filter(r=>r!==e)},ct(),W())}function Rc(){return`
    <style>${lc()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Oc()}
      ${Nc()}
      ${Fc()}
      ${Hc()}
    </div>
  `}function Oc(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Nc(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function Fc(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function Hc(){var i,a;const t=T(),e=((i=t==null?void 0:t.customColors)==null?void 0:i.text)??[],n=((a=t==null?void 0:t.customColors)==null?void 0:a.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${Ge(s)}" style="background: ${Ge(s)}" aria-label="Use ${Ge(s)}" title="${Ge(s)}"></button>`).join("")}</div>
    </div>
  `}function Ge(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function zc(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let i=n.left;i+r.width>window.innerWidth-8&&(i=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,i)}px`}let Q=null,z=null,It=0,Ut=1,Xt=1,Pt=null;function _c(t){Vt(),Pt=t.onConfirm;const e=Li(t.initialColor);It=e.h,Ut=e.s,Xt=e.v,Q=document.createElement("div"),Q.setAttribute("data-manuscript","ui"),Et(Q),Q.style.cssText=["position: fixed",`z-index: ${R+7}`,"pointer-events: auto"].join("; "),z=Q.attachShadow({mode:"open"}),z.innerHTML=Rc(),qc(),document.body.appendChild(Q),zc(Q,t.anchor),Be(),document.addEventListener("mousedown",Bi,!0),document.addEventListener("keydown",qi,!0)}function Vt(){Q&&(document.removeEventListener("mousedown",Bi,!0),document.removeEventListener("keydown",qi,!0),Q.remove(),Q=null,z=null,Pt=null)}function Bc(){return Q!==null}function Be(){if(!z)return;const t=z.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${It}deg, 100%, 50%)`);const e=z.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Ut*100}%`,e.style.top=`${(1-Xt)*100}%`);const n=z.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${It/360*100}%`);const[r,o,i]=Ai(It,Ut,Xt),a=$i(r,o,i),s=z.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${i})`);const c=z.querySelector('[data-region="hex"]');c&&(c.textContent=a),z.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===Q&&z.activeElement===l)return;const d=l.dataset.channel;d==="r"?l.value=String(r):d==="g"?l.value=String(o):d==="b"&&(l.value=String(i))})}function _i(){const[t,e,n]=Ai(It,Ut,Xt);return $i(t,e,n)}function qc(){if(!z)return;const t=z.querySelector('[data-region="sv"]');t&&mo(t,n=>jc(t,n));const e=z.querySelector('[data-region="hue"]');e&&mo(e,n=>Wc(e,n)),z.addEventListener("input",n=>{var c,l,d;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=ir((c=z.querySelector('[data-channel="r"]'))==null?void 0:c.value),i=ir((l=z.querySelector('[data-channel="g"]'))==null?void 0:l.value),a=ir((d=z.querySelector('[data-channel="b"]'))==null?void 0:d.value),s=Mi(o,i,a);It=s.h,Ut=s.s,Xt=s.v,Be()}),z.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),i=o==null?void 0:o.getAttribute("data-action");if(i==="confirm")Pt==null||Pt(_i()),Vt();else if(i==="eyedrop")Zs(ko);else if(i==="recent"){const a=o==null?void 0:o.getAttribute("data-color");a&&ko(a)}})}function ko(t){const e=Li(t);It=e.h,Ut=e.s,Xt=e.v,Be()}function jc(t,e){const n=t.getBoundingClientRect();Ut=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Xt=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),Be()}function Wc(t,e){const n=t.getBoundingClientRect();It=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,Be()}function Bi(t){if(!Q)return;const e=t.target;e instanceof HTMLElement&&Q.contains(e)||Vt()}function qi(t){t.key==="Escape"?(t.preventDefault(),Vt()):t.key==="Enter"&&(t.preventDefault(),Pt==null||Pt(_i()),Vt())}const Ke=8,Qt=6,ji=32,So=16,Ze=4,Wi=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function Eo(t,e,n,r){let{x:o,y:i,width:a,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,a-=n):(t==="ne"||t==="e"||t==="se")&&(a+=n),t==="nw"||t==="n"||t==="ne"?(i+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),a<Qt&&(o=e.x+e.width-Qt,a=Qt),s<Qt&&(i=e.y+e.height-Qt,s=Qt),{x:o,y:i,width:a,height:s}}function Ui(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of t)i.x<e&&(e=i.x),i.y<n&&(n=i.y),i.x>r&&(r=i.x),i.y>o&&(o=i.y);return{x:e,y:n,width:r-e,height:o-n}}function Uc(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const $={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},N="http://www.w3.org/2000/svg";function Xc(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const i=r.tagName.toLowerCase(),a=r.parentElement,s=r.tagName;if(a){const c=Array.from(a.children).filter(l=>{var d;return l.tagName===s&&!((d=l.matches)!=null&&d.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${i}:nth-of-type(${l})`)}else n.unshift(i)}else n.unshift(i);r=a,o++}return n.join(" > ")}function Vc(t,e=document,n=8){const r=[];let o=t,i=0;for(;o&&o!==document.body&&i<n;){const a=o.tagName.toLowerCase(),s=o.parentElement,c=o.tagName;if(s){const d=Array.from(s.children).filter(f=>{var u;return f.tagName===c&&!((u=f.matches)!=null&&u.call(f,'[data-manuscript="ui"]'))});if(d.length>1){const f=d.indexOf(o)+1;r.unshift(`${a}:nth-of-type(${f})`)}else r.unshift(a)}else r.unshift(a);const l=r.join(" > ");try{const d=Array.from(e.querySelectorAll(l)).filter(f=>{var u;return!((u=f.closest)!=null&&u.call(f,'[data-manuscript="ui"]'))});if(d.length===1&&d[0]===t)return l}catch{}o=s,i++}return r.join(" > ")}function zr(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function Yc(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const Gc=["data-testid","data-test","id","aria-label"];function Kc(t){for(const e of Gc){const n=t.getAttribute(e);if(n&&n.length>0){const r=`[${e}="${Yc(n)}"]`;try{const o=Array.from(document.querySelectorAll(r)).filter(i=>{var a;return!((a=i.closest)!=null&&a.call(i,'[data-manuscript="ui"]'))});if(o.length===1&&o[0]===t)return{kind:"stable-attr",cssSelector:r}}catch{}}}return{kind:"stable-attr",cssSelector:Vc(t)}}function gn(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!zr(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function Zc(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?Xc(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function mn(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!zr(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function Qc(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const i of Array.from(r.children)){if(i===t)continue;const a=(i.textContent??"").trim();if(a.length>0&&a.length<60&&n.push(a),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function bn(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||zr(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const i=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>i.includes(c))?n:null}function Jc(t){return{layer1:Kc(t),layer2:Zc(t),layer3:Qc(t)}}function tl(t,e){const n=e.ownerDocument;return n?gn(t.layer1,n)===e||mn(t.layer2,n)===e||bn(t.layer3,n)===e:!1}function Oe(t){const e=Xi(t.framePath);return e?el(t,e):null}function el(t,e){return gn(t.layer1,e)??mn(t.layer2,e)??bn(t.layer3,e)}function Xi(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function nl(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function G(){const t=st();if(!t||!t.selectors)return null;try{const e=Oe(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function rl(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function jn(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function ol(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function Wn(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function Vi(t){if(!t.bounds)return t;const e=G();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function il(t){if(!t.points)return t;const e=G();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function al(){document.removeEventListener("mousemove",_r,!0),document.removeEventListener("mouseup",Br,!0),document.removeEventListener("keydown",Gi,!0)}function sl(){document.addEventListener("keydown",Gi,!0)}function cl(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=C($.activeId);if(!n||n.kind!=="shape")return;const r=jn(n,G());$.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},Un()}function ll(t){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const e=C($.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;$.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},Un()}function Yi(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=C($.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,i=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;$.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:i},Un()}function dl(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=C($.activeId);if(!n||n.kind!=="freedraw")return;const r=Wn(n,G()),o=Ui(r);!o||o.width===0||o.height===0||($.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(i=>({...i}))},Un())}function Un(){document.addEventListener("mousemove",_r,!0),document.addEventListener("mouseup",Br,!0)}function _r(t){const{activeId:e,dragState:n}=$;if(!e||!n)return;t.preventDefault();const r=C(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,i=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const a=Eo(n.handle,n.startBounds,o,i);I(e,Vi({bounds:a}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const a=n.startBounds,s=Eo(n.handle,a,o,i),c=a.width===0?1:s.width/a.width,l=a.height===0?1:s.height/a.height,d=n.startPoints.map(f=>({x:s.x+(f.x-a.x)*c,y:s.y+(f.y-a.y)*l}));I(e,il({points:d}))}else if(n.kind==="rotate"){const a=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(a-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?I(e,{rotate:s}):r.kind==="freedraw"?I(e,{rotate:s}):r.kind==="text"&&I(e,{rotate:s})}}function Br(){document.removeEventListener("mousemove",_r,!0),document.removeEventListener("mouseup",Br,!0),$.dragState=null}function Gi(t){var o;const{activeId:e}=$;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Hi(e);return}if(t.key.startsWith("Arrow")){const i=C(e);if(!i||i.kind!=="shape")return;const a=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-a:t.key==="ArrowRight"?a:0,c=t.key==="ArrowUp"?-a:t.key==="ArrowDown"?a:0;if(s!==0||c!==0){t.preventDefault();const l=jn(i,G());I(e,Vi({bounds:{...i.bounds,x:l.x+s,y:l.y+c}}))}}}}function Ki(t,e,n,r,o){const i=document.createElementNS(N,"rect");return i.setAttribute("x",String(t-Ke/2)),i.setAttribute("y",String(e-Ke/2)),i.setAttribute("width",String(Ke)),i.setAttribute("height",String(Ke)),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),i.style.cursor=r,i.style.pointerEvents="auto",i.setAttribute("pointer-events","all"),i.addEventListener("mousedown",a=>o(a,n)),i}function Zi(t,e,n){const r=document.createElementNS(N,"g"),o=e-18,i=e-ji,a=12,s=document.createElementNS(N,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(N,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(i+1)),c.setAttribute("r",String(a)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(N,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(i)),l.setAttribute("r",String(a)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const d=t-8,f=i-8,u=document.createElementNS(N,"path");u.setAttribute("d",`M ${d+4} ${f+11} A 5 5 0 1 1 ${d+11} ${f+4}`),u.setAttribute("fill","none"),u.setAttribute("stroke","oklch(0.48 0.085 245)"),u.setAttribute("stroke-width","1.5"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.style.pointerEvents="none",r.appendChild(u);const p=document.createElementNS(N,"path");return p.setAttribute("d",`M ${d+11} ${f+1.5} L ${d+14} ${f+4} L ${d+11} ${f+6.5} Z`),p.setAttribute("fill","oklch(0.48 0.085 245)"),p.setAttribute("stroke","oklch(0.48 0.085 245)"),p.setAttribute("stroke-width","1.5"),p.setAttribute("stroke-linejoin","round"),p.style.pointerEvents="none",r.appendChild(p),l.addEventListener("mousedown",h=>n(h)),r}function qr(t,e){const n=document.createElementNS(N,"g"),r=t.x-So,o=t.y-So;return n.appendChild(ul(r,o,e)),n}function ul(t,e,n){const r=document.createElementNS(N,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(N,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const i=document.createElementNS(N,"circle");i.setAttribute("cx",String(t)),i.setAttribute("cy",String(e)),i.setAttribute("r","12"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.92 0.008 240)"),i.setAttribute("stroke-width","1"),r.appendChild(i);const a=t-6,s=e-6,c=document.createElementNS(N,"path");return c.setAttribute("d",[`M ${a+1.5} ${s+3.5} L ${a+10.5} ${s+3.5}`,`M ${a+4.5} ${s+3.5} L ${a+4.5} ${s+2} L ${a+7.5} ${s+2} L ${a+7.5} ${s+3.5}`,`M ${a+3} ${s+3.5} L ${a+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${a+4.3} ${s+11} L ${a+7.7} ${s+11} A 0.8 0.8 0 0 0 ${a+8.5} ${s+10.5} L ${a+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function jr(t){const e=document.createElementNS(N,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function Xn(){const{host:t,activeId:e,activeMode:n}=$;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=C(e);if(!r){Er();return}if(n==="freedraw"&&r.kind==="freedraw"){gl(t,r);return}if(n==="text"&&r.kind==="text"){hl(t,r);return}if(r.kind!=="shape"){Er();return}pl(t,r)}function pl(t,e){const n=jn(e,G()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,i=r.x+r.width/2,a=r.y+r.height/2,s=document.createElementNS(N,"g");o&&s.setAttribute("transform",`rotate(${o} ${i} ${a})`),s.appendChild(jr(r));for(const c of Wi){const{x:l,y:d}=c.offset(r);s.appendChild(Ki(l,d,c.name,c.cursor,cl))}s.appendChild(fl(r)),t.appendChild(s),t.appendChild(qr(r,Wr))}function fl(t){const e=t.x+t.width/2,n=t.y-ji,r=document.createElementNS(N,"g"),o=document.createElementNS(N,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const i=document.createElementNS(N,"g");i.style.cursor="grab",i.style.pointerEvents="auto",i.setAttribute("pointer-events","all");const a=document.createElementNS(N,"circle");a.setAttribute("cx",String(e)),a.setAttribute("cy",String(n)),a.setAttribute("r","9"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),i.appendChild(a);const s=document.createElementNS(N,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",i.appendChild(s),i.addEventListener("mousedown",c=>ll(c)),r.appendChild(i),r}function hl(t,e){const n=Uc(e.id);if(!n)return;const r=Qi(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(jr(r)),t.appendChild(Zi(o,r.y,a=>Yi(a,()=>({x:o,y:i})))),t.appendChild(qr(r,Wr))}function gl(t,e){const n=Wn(e,G()),r=Ui(n);if(!r)return;const o=Qi(r),i=o.x+o.width/2,a=o.y+o.height/2;t.appendChild(jr(o));for(const s of Wi){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(Ki(c,l,s.name,s.cursor,dl))}t.appendChild(Zi(i,o.y,s=>Yi(s,()=>({x:i,y:a})))),t.appendChild(qr(o,Wr))}function Qi(t){return{x:t.x-Ze,y:t.y-Ze,width:t.width+Ze*2,height:t.height+Ze*2}}function Wr(){const t=$.activeId;t&&Hi(t)}function ml(t){const e=C(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const i=document.querySelectorAll(o);if(i.length===0)return;const a=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;i.forEach(s=>{s.style.animation=""}),i[0].getBoundingClientRect(),i.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${a}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function bl(t){const e=C(t);!e||e.kind!=="shape"||($.activeId=t,$.activeMode="shape",Ur(),Xn())}function vl(t){const e=C(t);!e||e.kind!=="freedraw"||($.activeId=t,$.activeMode="freedraw",Ur(),Xn())}function yl(t){const e=C(t);!e||e.kind!=="text"||($.activeId=t,$.activeMode="text",Ur(),Xn())}function Er(){var t;$.host&&(al(),(t=$.unsubscribeScenario)==null||t.call($),$.unsubscribeScenario=null,$.host.remove(),$.host=null,$.activeId=null,$.activeMode="shape",$.dragState=null)}function xl(t){return $.host!==null&&t!==null&&$.host.contains(t)}function Ur(){if($.host)return;const t=document.createElementNS(N,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),$.host=t,sl(),$.unsubscribeScenario=ye(Xn)}const wl=400,kl=0;function Sl(t){return{kind:t,durationMs:wl,delayMs:kl}}function El(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const Ao=10,Al=46,Ji=12,ta=36,ea=0,na=20,Ml=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],$l=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],Mo=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}];function Ll(t){return!t||t.length===0?[...Mo]:[...t.map(e=>({label:kc(e),value:e})),...Mo]}const Tl=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],A={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function mt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function ra(t){const e=A.activeId;if(!e)return;const n=C(e);n&&(n.kind==="text"?I(e,{style:{...n.style,color:t}}):n.kind==="shape"?I(e,{stroke:t}):n.kind==="freedraw"&&I(e,{stroke:t}))}function oa(t){const e=A.activeId;if(!e)return;const n=C(e);n&&(n.kind==="text"?I(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&I(e,{fill:t}))}function ia(t){const e=A.activeId;if(!e)return;const n=C(e);!n||n.kind!=="text"||I(e,{style:{...n.style,borderColor:t}})}function Cl(t){const e=A.activeId;if(!e)return;const n=C(e);!n||n.kind!=="text"||I(e,{style:{...n.style,fontFamily:t}})}function Il(t){const e=A.activeId;if(!e)return;const n=C(e);!n||n.kind!=="text"||I(e,{style:{...n.style,fontSize:t}})}function Pl(){const t=A.activeId;if(!t)return;const e=C(t);!e||e.kind!=="text"||I(t,{style:{...e.style,bold:!e.style.bold}})}function Dl(){const t=A.activeId;if(!t)return;const e=C(t);!e||e.kind!=="text"||I(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Rl(t){const e=A.activeId;e&&I(e,{entryAnimation:t==="none"?void 0:Sl(t)})}function Ol(t){const e=A.activeId;if(!e)return;const n=C(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?I(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?I(e,{fillOpacity:r}):n.kind==="freedraw"&&I(e,{strokeOpacity:r})}function Nl(t){const e=A.activeId;if(!e)return;const n=C(e);n&&(n.kind==="shape"?I(e,{strokeWidth:t}):n.kind==="freedraw"&&I(e,{strokeWidth:t}))}function Fl(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=a=>{r&&cr(e,a.clientX)},i=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",i,!0)};n.addEventListener("mousedown",a=>{r=!0,cr(e,a.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0),a.preventDefault()}),e.addEventListener("mousedown",a=>{const s=a.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(cr(e,a.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0))})}function cr(t,e){const n=t.getBoundingClientRect();Ol(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function Ar(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function Hl(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function lr(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function dr(t,e,n){var l,d,f;const r=A.swatchMode==="muted"?Ml:$l,o=[];if(n&&(t==="bg"||t==="border")){const u=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${u}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let u=0;u<r.length;u++){const p=r[u];if(!p)continue;const h=u===1,b=lr(e,p.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${p.resolved}" style="background:${p.resolved}" aria-pressed="${b}" title="${t} ${p.resolved}"></button>
    `)}const i=T(),a=(t==="text"||t==="border"?(l=i==null?void 0:i.siteColors)==null?void 0:l.text:(d=i==null?void 0:i.siteColors)==null?void 0:d.background)??[];for(const u of a){const p=lr(e,u);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${mt(u)}" style="background:${mt(u)}" aria-pressed="${p}" title="Site color ${mt(u)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((f=i==null?void 0:i.customColors)==null?void 0:f[s])??[];for(const u of c){const p=lr(e,u);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${mt(u)}" style="background:${mt(u)}" aria-pressed="${p}" title="Custom ${mt(u)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${mt(u)}" title="Remove" aria-label="Remove color ${mt(u)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function Xr(){const{shadow:t,activeId:e,activeKind:n}=A;if(!t||!e||!n)return;const r=C(e);if(!r||r.kind==="arrow")return;const o=r,i=t.querySelector('[data-region="caption"]');i&&(i.textContent=Ul(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(a=>{const s=a.getAttribute("data-mode");a.setAttribute("aria-pressed",String(s===A.swatchMode))}),zl(t,n),_l(t,n,o),Bl(t,n,o),ql(t,n,o),jl(t,o),Wl(t,o)}function zl(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const i=t.querySelector('[data-region="width-row"]'),a=e==="shape"||e==="freedraw";i&&(i.hidden=!a);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const d=t.querySelector('[data-region="bg-label"]');d&&(d.textContent=e==="text"?"Bg":"Fill")}function _l(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const i=t.querySelector('[data-region="bold"]');i&&i.setAttribute("aria-pressed",String(n.style.bold));const a=t.querySelector('[data-region="italic"]');a&&a.setAttribute("aria-pressed",String(n.style.italic===!0))}function Bl(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),i=n.strokeWidth;r&&(r.value=String(i)),o&&(o.textContent=String(i))}function ql(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),i=t.querySelector('[data-region="border-swatches"]'),a=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=Ar(n,"text"),l=Ar(n,"bg");if(r&&(r.innerHTML=dr("text",c,!1)),o&&!(a!=null&&a.hidden)&&(o.innerHTML=dr("bg",l,e==="text")),i&&!(s!=null&&s.hidden)&&n.kind==="text"){const d=n.style.borderColor??"#000000";i.innerHTML=dr("border",d,!0)}}function jl(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=El(e))}function Wl(t,e){const n=Math.round(Hl(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),i=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),i&&(i.textContent=`${n}%`)}function Ul(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function Xl(t){const{shadow:e,host:n}=A;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>Vl(o)),e.addEventListener("change",o=>Yl(o)),e.addEventListener("input",o=>Gl(o)),Fl(),document.addEventListener("mousedown",o=>Zl(o,t),!0),document.addEventListener("keydown",o=>Ql(o,t),!0)}function Vl(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(A.swatchMode=c,Xr());return}if(e.closest('[data-region="bold"]'))return Pl();if(e.closest('[data-region="italic"]'))return Dl();if(e.closest('[data-region="effect-play"]')){A.activeId&&ml(A.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return ra(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return oa(o.getAttribute("data-value")??"");const i=e.closest('[data-swatch="border"]');if(i)return ia(i.getAttribute("data-value")??"");const a=e.closest('[data-action="more-colors"]');if(a instanceof HTMLElement)return Kl(a);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&Dc(c==="text"||c==="border"?"text":"background",l)}}function Yl(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Cl(e.value):e.dataset.region==="effect"&&Rl(e.value))}function Gl(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(Ji,Math.min(ta,Number(e.value)||16));Il(n)}else if(e.dataset.region==="width"){const n=Math.max(ea,Math.min(na,Number(e.value)||0));Nl(n)}}}function Kl(t){const{activeId:e,activeKind:n}=A;if(!e||!n)return;const r=C(e);if(!r||r.kind==="arrow")return;const o=r,i=t.getAttribute("data-slot");if(!i)return;const a=Ar(o,i)||"#ffffff";_c({anchor:t,initialColor:a,onConfirm:s=>{Pc(i==="text"||i==="border"?"text":"background",s),i==="text"?ra(s):i==="border"?ia(s):oa(s)}})}function Zl(t,e){const{host:n,activeAnchorSelector:r}=A,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||xl(o)||Bc()||r&&o instanceof Element&&o.closest(r)||(e(),Vt())}function Ql(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function aa(t){const{host:e}=A;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-Ao-Al;o<8&&(o=r.bottom+Ao);const i=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${i}px`}function Jl(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function td(t,e){t==="text"?yl(e):t==="shape"?bl(e):vl(e)}function ed(){return`
    ${wt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function nd(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function rd(){return[ed(),nd()].join(`
`)}function od(){return`
    <style>${rd()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${id()}
      ${ad()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${sd()}
      <div class="divider"></div>
      ${cd()}
      ${ld()}
      ${dd()}
      ${ud()}
    </div>
  `}function id(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function ad(){var e;return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Ll((e=T())==null?void 0:e.siteFonts).map(n=>`<option value="${mt(n.value)}" style="font-family: ${mt(n.value)};">${n.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${Ji}" max="${ta}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function sd(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function cd(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${ea}" max="${na}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function ld(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Tl.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function dd(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function ud(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function Vr(t,e,n){C(t)&&(A.activeId=t,A.activeKind=n,A.activeAnchorSelector=Jl(n,t),A.host||md(),Xr(),aa(e),td(n,t))}function Yr(){var t;A.host&&((t=A.unsubscribeScenario)==null||t.call(A),A.unsubscribeScenario=null,Vt(),Er(),A.host.remove(),A.host=null,A.shadow=null,A.activeId=null,A.activeKind=null,A.activeAnchorSelector=null)}function pd(){return A.activeId}function fd(t,e){Vr(t,e,"text")}function sa(){Yr()}function hd(t,e){Vr(t,e,"shape")}function gd(t,e){Vr(t,e,"freedraw")}function md(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Et(t),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${R+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=od(),A.host=t,A.shadow=e,document.body.appendChild(t),Xl(Yr),A.unsubscribeScenario=ye(bd)}function bd(){const{activeId:t,host:e,activeAnchorSelector:n}=A;if(!t||!e)return;if(!C(t)){Yr();return}if(Xr(),n){const o=document.querySelector(n);o&&aa(o)}}const yt=20;let vn=null,$o=!1;function vd(){$o||($o=!0,document.addEventListener("keydown",wd,!0)),yd()}async function yd(){try{const e=(await chrome.storage.local.get(X.annotationClipboard))[X.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(vn=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function xd(t){try{await chrome.storage.local.set({[X.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function wd(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||xt()!=="replay"&&(kd()||(e==="c"?Sd(t):Ed(t)))}function kd(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function Sd(t){const e=pd();if(!e)return;const n=C(e);n&&(vn=n,xd(n),t.preventDefault())}function Ed(t){if(!vn||!st())return;const e=Ad(vn);_e(e),t.preventDefault()}function Ad(t){switch(t.kind){case"text":return Md(t);case"shape":return $d(t);case"freedraw":return Ld(t);case"arrow":return Td(t)}}function Md(t){return{...t,id:Vn("text"),position:{x:t.position.x+yt,y:t.position.y+yt},style:{...t.style}}}function $d(t){return{...t,id:Vn("shape"),bounds:{...t.bounds,x:t.bounds.x+yt,y:t.bounds.y+yt}}}function Ld(t){return{...t,id:Vn("freedraw"),points:t.points.map(e=>({x:e.x+yt,y:e.y+yt}))}}function Td(t){return{...t,id:Vn("arrow"),from:{x:t.from.x+yt,y:t.from.y+yt},to:{x:t.to.x+yt,y:t.to.y+yt}}}function Vn(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function ur(t,e,n){if(t&&t.length){const[r,o]=e,i=Math.PI/180*n,a=Math.cos(i),s=Math.sin(i);for(const c of t){const[l,d]=c;c[0]=(l-r)*a-(d-o)*s+r,c[1]=(l-r)*s+(d-o)*a+o}}}function Cd(t,e){return t[0]===e[0]&&t[1]===e[1]}function Id(t,e,n,r=1){const o=n,i=Math.max(e,.1),a=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of a)ur(l,s,o);const c=(function(l,d,f){const u=[];for(const y of l){const E=[...y];Cd(E[0],E[E.length-1])||E.push([E[0][0],E[0][1]]),E.length>2&&u.push(E)}const p=[];d=Math.max(d,.1);const h=[];for(const y of u)for(let E=0;E<y.length-1;E++){const B=y[E],F=y[E+1];if(B[1]!==F[1]){const P=Math.min(B[1],F[1]);h.push({ymin:P,ymax:Math.max(B[1],F[1]),x:P===B[1]?B[0]:F[0],islope:(F[0]-B[0])/(F[1]-B[1])})}}if(h.sort(((y,E)=>y.ymin<E.ymin?-1:y.ymin>E.ymin?1:y.x<E.x?-1:y.x>E.x?1:y.ymax===E.ymax?0:(y.ymax-E.ymax)/Math.abs(y.ymax-E.ymax))),!h.length)return p;let b=[],g=h[0].ymin,x=0;for(;b.length||h.length;){if(h.length){let y=-1;for(let E=0;E<h.length&&!(h[E].ymin>g);E++)y=E;h.splice(0,y+1).forEach((E=>{b.push({s:g,edge:E})}))}if(b=b.filter((y=>!(y.edge.ymax<=g))),b.sort(((y,E)=>y.edge.x===E.edge.x?0:(y.edge.x-E.edge.x)/Math.abs(y.edge.x-E.edge.x))),(f!==1||x%d==0)&&b.length>1)for(let y=0;y<b.length;y+=2){const E=y+1;if(E>=b.length)break;const B=b[y].edge,F=b[E].edge;p.push([[Math.round(B.x),g],[Math.round(F.x),g]])}g+=f,b.forEach((y=>{y.edge.x=y.edge.x+f*y.edge.islope})),x++}return p})(a,i,r);if(o){for(const l of a)ur(l,s,-o);(function(l,d,f){const u=[];l.forEach((p=>u.push(...p))),ur(u,d,f)})(c,s,-o)}return c}function qe(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let i=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(i=o),Id(t,o,r,i||1)}class Gr{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=qe(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function Yn(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Pd extends Gr{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=qe(e,Object.assign({},n,{hachureGap:r})),i=Math.PI/180*n.hachureAngle,a=[],s=.5*r*Math.cos(i),c=.5*r*Math.sin(i);for(const[l,d]of o)Yn([l,d])&&a.push([[l[0]-s,l[1]+c],[...d]],[[l[0]+s,l[1]-c],[...d]]);return{type:"fillSketch",ops:this.renderLines(a,n)}}}class Dd extends Gr{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),i=this._fillPolygons(e,o);return r.ops=r.ops.concat(i.ops),r}}class Rd{constructor(e){this.helper=e}fillPolygons(e,n){const r=qe(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let i=n.fillWeight;i<0&&(i=n.strokeWidth/2);const a=o/4;for(const s of e){const c=Yn(s),l=c/o,d=Math.ceil(l)-1,f=c-d*o,u=(s[0][0]+s[1][0])/2-o/4,p=Math.min(s[0][1],s[1][1]);for(let h=0;h<d;h++){const b=p+f+h*o,g=u-a+2*Math.random()*a,x=b-a+2*Math.random()*a,y=this.helper.ellipse(g,x,i,i,n);r.push(...y.ops)}}return{type:"fillSketch",ops:r}}}class Od{constructor(e){this.helper=e}fillPolygons(e,n){const r=qe(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,i=[];return e.forEach((a=>{const s=Yn(a),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let d=a[0],f=a[1];d[0]>f[0]&&(d=a[1],f=a[0]);const u=Math.atan((f[1]-d[1])/(f[0]-d[0]));for(let p=0;p<c;p++){const h=p*(r+o),b=h+r,g=[d[0]+h*Math.cos(u)+l*Math.cos(u),d[1]+h*Math.sin(u)+l*Math.sin(u)],x=[d[0]+b*Math.cos(u)+l*Math.cos(u),d[1]+b*Math.sin(u)+l*Math.sin(u)];i.push(...this.helper.doubleLineOps(g[0],g[1],x[0],x[1],n))}})),i}}class Nd{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,i=qe(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(i,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((i=>{const a=Yn(i),s=Math.round(a/(2*n));let c=i[0],l=i[1];c[0]>l[0]&&(c=i[1],l=i[0]);const d=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let f=0;f<s;f++){const u=2*f*n,p=2*(f+1)*n,h=Math.sqrt(2*Math.pow(n,2)),b=[c[0]+u*Math.cos(d),c[1]+u*Math.sin(d)],g=[c[0]+p*Math.cos(d),c[1]+p*Math.sin(d)],x=[b[0]+h*Math.cos(d+Math.PI/4),b[1]+h*Math.sin(d+Math.PI/4)];o.push(...this.helper.doubleLineOps(b[0],b[1],x[0],x[1],r),...this.helper.doubleLineOps(x[0],x[1],g[0],g[1],r))}})),o}}const K={};class Fd{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const Hd=0,pr=1,Lo=2,Qe={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function fr(t,e){return t.type===e}function Kr(t){const e=[],n=(function(a){const s=new Array;for(;a!=="";)if(a.match(/^([ \t\r\n,]+)/))a=a.substr(RegExp.$1.length);else if(a.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:Hd,text:RegExp.$1},a=a.substr(RegExp.$1.length);else{if(!a.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:pr,text:`${parseFloat(RegExp.$1)}`},a=a.substr(RegExp.$1.length)}return s[s.length]={type:Lo,text:""},s})(t);let r="BOD",o=0,i=n[o];for(;!fr(i,Lo);){let a=0;const s=[];if(r==="BOD"){if(i.text!=="M"&&i.text!=="m")return Kr("M0,0"+t);o++,a=Qe[i.text],r=i.text}else fr(i,pr)?a=Qe[r]:(o++,a=Qe[i.text],r=i.text);if(!(o+a<n.length))throw new Error("Path data ended short");for(let c=o;c<o+a;c++){const l=n[c];if(!fr(l,pr))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof Qe[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=a,i=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function ca(t){let e=0,n=0,r=0,o=0;const i=[];for(const{key:a,data:s}of t)switch(a){case"M":i.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],i.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":i.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],i.push({key:"L",data:[e,n]});break;case"C":i.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":i.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":i.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],i.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":i.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],i.push({key:"H",data:[e]});break;case"V":i.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],i.push({key:"V",data:[n]});break;case"S":i.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":i.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],i.push({key:"T",data:[e,n]});break;case"Z":case"z":i.push({key:"Z",data:[]}),e=r,n=o}return i}function la(t){const e=[];let n="",r=0,o=0,i=0,a=0,s=0,c=0;for(const{key:l,data:d}of t){switch(l){case"M":e.push({key:"M",data:[...d]}),[r,o]=d,[i,a]=d;break;case"C":e.push({key:"C",data:[...d]}),r=d[4],o=d[5],s=d[2],c=d[3];break;case"L":e.push({key:"L",data:[...d]}),[r,o]=d;break;case"H":r=d[0],e.push({key:"L",data:[r,o]});break;case"V":o=d[0],e.push({key:"L",data:[r,o]});break;case"S":{let f=0,u=0;n==="C"||n==="S"?(f=r+(r-s),u=o+(o-c)):(f=r,u=o),e.push({key:"C",data:[f,u,...d]}),s=d[0],c=d[1],r=d[2],o=d[3];break}case"T":{const[f,u]=d;let p=0,h=0;n==="Q"||n==="T"?(p=r+(r-s),h=o+(o-c)):(p=r,h=o);const b=r+2*(p-r)/3,g=o+2*(h-o)/3,x=f+2*(p-f)/3,y=u+2*(h-u)/3;e.push({key:"C",data:[b,g,x,y,f,u]}),s=p,c=h,r=f,o=u;break}case"Q":{const[f,u,p,h]=d,b=r+2*(f-r)/3,g=o+2*(u-o)/3,x=p+2*(f-p)/3,y=h+2*(u-h)/3;e.push({key:"C",data:[b,g,x,y,p,h]}),s=f,c=u,r=p,o=h;break}case"A":{const f=Math.abs(d[0]),u=Math.abs(d[1]),p=d[2],h=d[3],b=d[4],g=d[5],x=d[6];f===0||u===0?(e.push({key:"C",data:[r,o,g,x,g,x]}),r=g,o=x):(r!==g||o!==x)&&(da(r,o,g,x,f,u,p,h,b).forEach((function(y){e.push({key:"C",data:y})})),r=g,o=x);break}case"Z":e.push({key:"Z",data:[]}),r=i,o=a}n=l}return e}function ke(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function da(t,e,n,r,o,i,a,s,c,l){const d=(f=a,Math.PI*f/180);var f;let u=[],p=0,h=0,b=0,g=0;if(l)[p,h,b,g]=l;else{[t,e]=ke(t,e,-d),[n,r]=ke(n,r,-d);const et=(t-n)/2,q=(e-r)/2;let gt=et*et/(o*o)+q*q/(i*i);gt>1&&(gt=Math.sqrt(gt),o*=gt,i*=gt);const Kt=o*o,Zt=i*i,Rs=Kt*Zt-Kt*q*q-Zt*et*et,Os=Kt*q*q+Zt*et*et,fo=(s===c?-1:1)*Math.sqrt(Math.abs(Rs/Os));b=fo*o*q/i+(t+n)/2,g=fo*-i*et/o+(e+r)/2,p=Math.asin(parseFloat(((e-g)/i).toFixed(9))),h=Math.asin(parseFloat(((r-g)/i).toFixed(9))),t<b&&(p=Math.PI-p),n<b&&(h=Math.PI-h),p<0&&(p=2*Math.PI+p),h<0&&(h=2*Math.PI+h),c&&p>h&&(p-=2*Math.PI),!c&&h>p&&(h-=2*Math.PI)}let x=h-p;if(Math.abs(x)>120*Math.PI/180){const et=h,q=n,gt=r;h=c&&h>p?p+120*Math.PI/180*1:p+120*Math.PI/180*-1,u=da(n=b+o*Math.cos(h),r=g+i*Math.sin(h),q,gt,o,i,a,0,c,[h,et,b,g])}x=h-p;const y=Math.cos(p),E=Math.sin(p),B=Math.cos(h),F=Math.sin(h),P=Math.tan(x/4),tt=4/3*o*P,ht=4/3*i*P,Ye=[t,e],lt=[t+tt*E,e-ht*y],Nt=[n+tt*F,r-ht*B],po=[n,r];if(lt[0]=2*Ye[0]-lt[0],lt[1]=2*Ye[1]-lt[1],l)return[lt,Nt,po].concat(u);{u=[lt,Nt,po].concat(u);const et=[];for(let q=0;q<u.length;q+=3){const gt=ke(u[q][0],u[q][1],d),Kt=ke(u[q+1][0],u[q+1][1],d),Zt=ke(u[q+2][0],u[q+2][1],d);et.push([gt[0],gt[1],Kt[0],Kt[1],Zt[0],Zt[1]])}return et}}const zd={randOffset:function(t,e){return w(t,e)},randOffsetWithRange:function(t,e,n){return yn(t,e,n)},ellipse:function(t,e,n,r,o){const i=pa(n,r,o);return Mr(t,e,o,i).opset},doubleLineOps:function(t,e,n,r,o){return Rt(t,e,n,r,o,!0)}};function ua(t,e,n,r,o){return{type:"path",ops:Rt(t,e,n,r,o)}}function ln(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let i=0;i<r-1;i++)o.push(...Rt(t[i][0],t[i][1],t[i+1][0],t[i+1][1],n));return e&&o.push(...Rt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?ua(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function _d(t,e,n,r,o){return(function(i,a){return ln(i,!0,a)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function To(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=Je(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:Je(n[0],1.5*(1+.22*e.roughness),Po(e));for(let i=1;i<n.length;i++){const a=n[i];if(a.length){const s=Je(a,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:Je(a,1.5*(1+.22*e.roughness),Po(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function pa(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),i=2*Math.PI/o;let a=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return a+=w(a*c,n),s+=w(s*c,n),{increment:i,rx:a,ry:s}}function Mr(t,e,n,r){const[o,i]=Do(r.increment,t,e,r.rx,r.ry,1,r.increment*yn(.1,yn(.4,1,n),n),n);let a=xn(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=Do(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=xn(s,null,n);a=a.concat(c)}return{estimatedPoints:i,opset:{type:"path",ops:a}}}function Co(t,e,n,r,o,i,a,s,c){const l=t,d=e;let f=Math.abs(n/2),u=Math.abs(r/2);f+=w(.01*f,c),u+=w(.01*u,c);let p=o,h=i;for(;p<0;)p+=2*Math.PI,h+=2*Math.PI;h-p>2*Math.PI&&(p=0,h=2*Math.PI);const b=2*Math.PI/c.curveStepCount,g=Math.min(b/2,(h-p)/2),x=Ro(g,l,d,f,u,p,h,1,c);if(!c.disableMultiStroke){const y=Ro(g,l,d,f,u,p,h,1.5,c);x.push(...y)}return a&&(s?x.push(...Rt(l,d,l+f*Math.cos(p),d+u*Math.sin(p),c),...Rt(l,d,l+f*Math.cos(h),d+u*Math.sin(h),c)):x.push({op:"lineTo",data:[l,d]},{op:"lineTo",data:[l+f*Math.cos(p),d+u*Math.sin(p)]})),{type:"path",ops:x}}function Io(t,e){const n=la(ca(Kr(t))),r=[];let o=[0,0],i=[0,0];for(const{key:a,data:s}of n)switch(a){case"M":i=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...Rt(i[0],i[1],s[0],s[1],e)),i=[s[0],s[1]];break;case"C":{const[c,l,d,f,u,p]=s;r.push(...Bd(c,l,d,f,u,p,i,e)),i=[u,p];break}case"Z":r.push(...Rt(i[0],i[1],o[0],o[1],e)),i=[o[0],o[1]]}return{type:"path",ops:r}}function hr(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,i=r.length;if(i>2){n.push({op:"move",data:[r[0][0]+w(o,e),r[0][1]+w(o,e)]});for(let a=1;a<i;a++)n.push({op:"lineTo",data:[r[a][0]+w(o,e),r[a][1]+w(o,e)]})}}return{type:"fillPath",ops:n}}function Jt(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!K[o])switch(o){case"zigzag":K[o]||(K[o]=new Pd(r));break;case"cross-hatch":K[o]||(K[o]=new Dd(r));break;case"dots":K[o]||(K[o]=new Rd(r));break;case"dashed":K[o]||(K[o]=new Od(r));break;case"zigzag-line":K[o]||(K[o]=new Nd(r));break;default:o="hachure",K[o]||(K[o]=new Gr(r))}return K[o]})(e,zd).fillPolygons(t,e)}function Po(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function fa(t){return t.randomizer||(t.randomizer=new Fd(t.seed||0)),t.randomizer.next()}function yn(t,e,n,r=1){return n.roughness*r*(fa(n)*(e-t)+t)}function w(t,e,n=1){return yn(-t,t,e,n)}function Rt(t,e,n,r,o,i=!1){const a=i?o.disableMultiStrokeFill:o.disableMultiStroke,s=$r(t,e,n,r,o,!0,!1);if(a)return s;const c=$r(t,e,n,r,o,!0,!0);return s.concat(c)}function $r(t,e,n,r,o,i,a){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let d=o.maxRandomnessOffset||0;d*d*100>s&&(d=c/10);const f=d/2,u=.2+.2*fa(o);let p=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;p=w(p,o,l),h=w(h,o,l);const b=[],g=()=>w(f,o,l),x=()=>w(d,o,l),y=o.preserveVertices;return a?b.push({op:"move",data:[t+(y?0:g()),e+(y?0:g())]}):b.push({op:"move",data:[t+(y?0:w(d,o,l)),e+(y?0:w(d,o,l))]}),a?b.push({op:"bcurveTo",data:[p+t+(n-t)*u+g(),h+e+(r-e)*u+g(),p+t+2*(n-t)*u+g(),h+e+2*(r-e)*u+g(),n+(y?0:g()),r+(y?0:g())]}):b.push({op:"bcurveTo",data:[p+t+(n-t)*u+x(),h+e+(r-e)*u+x(),p+t+2*(n-t)*u+x(),h+e+2*(r-e)*u+x(),n+(y?0:x()),r+(y?0:x())]}),b}function Je(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]),r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]),o===t.length-1&&r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]);return xn(r,null,n)}function xn(t,e,n){const r=t.length,o=[];if(r>3){const i=[],a=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*t[s+1][0]-a*t[s-1][0])/6,c[1]+(a*t[s+1][1]-a*t[s-1][1])/6],i[2]=[t[s+1][0]+(a*t[s][0]-a*t[s+2][0])/6,t[s+1][1]+(a*t[s][1]-a*t[s+2][1])/6],i[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[i[1][0],i[1][1],i[2][0],i[2][1],i[3][0],i[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...$r(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function Do(t,e,n,r,o,i,a,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let d=0;d<=2*Math.PI;d+=t){const f=[e+r*Math.cos(d),n+o*Math.sin(d)];c.push(f),l.push(f)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const d=w(.5,s)-Math.PI/2;l.push([w(i,s)+e+.9*r*Math.cos(d-t),w(i,s)+n+.9*o*Math.sin(d-t)]);const f=2*Math.PI+d-.01;for(let u=d;u<f;u+=t){const p=[w(i,s)+e+r*Math.cos(u),w(i,s)+n+o*Math.sin(u)];c.push(p),l.push(p)}l.push([w(i,s)+e+r*Math.cos(d+2*Math.PI+.5*a),w(i,s)+n+o*Math.sin(d+2*Math.PI+.5*a)]),l.push([w(i,s)+e+.98*r*Math.cos(d+a),w(i,s)+n+.98*o*Math.sin(d+a)]),l.push([w(i,s)+e+.9*r*Math.cos(d+.5*a),w(i,s)+n+.9*o*Math.sin(d+.5*a)])}return[l,c]}function Ro(t,e,n,r,o,i,a,s,c){const l=i+w(.1,c),d=[];d.push([w(s,c)+e+.9*r*Math.cos(l-t),w(s,c)+n+.9*o*Math.sin(l-t)]);for(let f=l;f<=a;f+=t)d.push([w(s,c)+e+r*Math.cos(f),w(s,c)+n+o*Math.sin(f)]);return d.push([e+r*Math.cos(a),n+o*Math.sin(a)]),d.push([e+r*Math.cos(a),n+o*Math.sin(a)]),xn(d,null,c)}function Bd(t,e,n,r,o,i,a,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let d=[0,0];const f=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let p=0;p<f;p++)p===0?c.push({op:"move",data:[a[0],a[1]]}):c.push({op:"move",data:[a[0]+(u?0:w(l[0],s)),a[1]+(u?0:w(l[0],s))]}),d=u?[o,i]:[o+w(l[p],s),i+w(l[p],s)],c.push({op:"bcurveTo",data:[t+w(l[p],s),e+w(l[p],s),n+w(l[p],s),r+w(l[p],s),d[0],d[1]]});return c}function Se(t){return[...t]}function Oo(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(Se(t[0]),Se(t[1]),Se(t[2]),Se(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const i=[],a=1-e;r.push(Se(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*o[s+1][0]-a*o[s-1][0])/6,c[1]+(a*o[s+1][1]-a*o[s-1][1])/6],i[2]=[o[s+1][0]+(a*o[s][0]-a*o[s+2][0])/6,o[s+1][1]+(a*o[s][1]-a*o[s+2][1])/6],i[3]=[o[s+1][0],o[s+1][1]],r.push(i[1],i[2],i[3])}}return r}function dn(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function qd(t,e,n){const r=dn(e,n);if(r===0)return dn(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),dn(t,Ft(e,n,o))}function Ft(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function Lr(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],d=s[c+1],f=s[c+2],u=s[c+3];let p=3*d[0]-2*l[0]-u[0];p*=p;let h=3*d[1]-2*l[1]-u[1];h*=h;let b=3*f[0]-2*u[0]-l[0];b*=b;let g=3*f[1]-2*u[1]-l[1];return g*=g,p<b&&(p=b),h<g&&(h=g),p+h})(t,e)<n){const s=t[e+0];o.length?(i=o[o.length-1],a=s,Math.sqrt(dn(i,a))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],d=t[e+2],f=t[e+3],u=Ft(c,l,.5),p=Ft(l,d,.5),h=Ft(d,f,.5),b=Ft(u,p,.5),g=Ft(p,h,.5),x=Ft(b,g,.5);Lr([c,u,b,x],0,n,o),Lr([x,g,h,f],0,n,o)}var i,a;return o}function jd(t,e){return wn(t,0,t.length,e)}function wn(t,e,n,r,o){const i=o||[],a=t[e],s=t[n-1];let c=0,l=1;for(let d=e+1;d<n-1;++d){const f=qd(t[d],a,s);f>c&&(c=f,l=d)}return Math.sqrt(c)>r?(wn(t,e,l+1,r,i),wn(t,l,n,r,i)):(i.length||i.push(a),i.push(s)),i}function gr(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let i=0;i<o;i++)Lr(t,3*i,e,r);return n&&n>0?wn(r,0,r.length,n):r}const J="none";class kn{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,i){const a=this._o(i);return this._d("line",[ua(e,n,r,o,a)],a)}rectangle(e,n,r,o,i){const a=this._o(i),s=[],c=_d(e,n,r,o,a);if(a.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];a.fillStyle==="solid"?s.push(hr([l],a)):s.push(Jt([l],a))}return a.stroke!==J&&s.push(c),this._d("rectangle",s,a)}ellipse(e,n,r,o,i){const a=this._o(i),s=[],c=pa(r,o,a),l=Mr(e,n,a,c);if(a.fill)if(a.fillStyle==="solid"){const d=Mr(e,n,a,c).opset;d.type="fillPath",s.push(d)}else s.push(Jt([l.estimatedPoints],a));return a.stroke!==J&&s.push(l.opset),this._d("ellipse",s,a)}circle(e,n,r,o){const i=this.ellipse(e,n,r,r,o);return i.shape="circle",i}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[ln(e,!1,r)],r)}arc(e,n,r,o,i,a,s=!1,c){const l=this._o(c),d=[],f=Co(e,n,r,o,i,a,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const u=Object.assign({},l);u.disableMultiStroke=!0;const p=Co(e,n,r,o,i,a,!0,!1,u);p.type="fillPath",d.push(p)}else d.push((function(u,p,h,b,g,x,y){const E=u,B=p;let F=Math.abs(h/2),P=Math.abs(b/2);F+=w(.01*F,y),P+=w(.01*P,y);let tt=g,ht=x;for(;tt<0;)tt+=2*Math.PI,ht+=2*Math.PI;ht-tt>2*Math.PI&&(tt=0,ht=2*Math.PI);const Ye=(ht-tt)/y.curveStepCount,lt=[];for(let Nt=tt;Nt<=ht;Nt+=Ye)lt.push([E+F*Math.cos(Nt),B+P*Math.sin(Nt)]);return lt.push([E+F*Math.cos(ht),B+P*Math.sin(ht)]),lt.push([E,B]),Jt([lt],y)})(e,n,r,o,i,a,l));return l.stroke!==J&&d.push(f),this._d("arc",d,l)}curve(e,n){const r=this._o(n),o=[],i=To(e,r);if(r.fill&&r.fill!==J)if(r.fillStyle==="solid"){const a=To(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(a.ops)})}else{const a=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?a.push(...l):l.length===3?a.push(...gr(Oo([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):a.push(...gr(Oo(l),10,(1+r.roughness)/2))}a.length&&o.push(Jt([a],r))}return r.stroke!==J&&o.push(i),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],i=ln(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(hr([e],r)):o.push(Jt([e],r))),r.stroke!==J&&o.push(i),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const i=r.fill&&r.fill!=="transparent"&&r.fill!==J,a=r.stroke!==J,s=!!(r.simplification&&r.simplification<1),c=(function(d,f,u){const p=la(ca(Kr(d))),h=[];let b=[],g=[0,0],x=[];const y=()=>{x.length>=4&&b.push(...gr(x,f)),x=[]},E=()=>{y(),b.length&&(h.push(b),b=[])};for(const{key:F,data:P}of p)switch(F){case"M":E(),g=[P[0],P[1]],b.push(g);break;case"L":y(),b.push([P[0],P[1]]);break;case"C":if(!x.length){const tt=b.length?b[b.length-1]:g;x.push([tt[0],tt[1]])}x.push([P[0],P[1]]),x.push([P[2],P[3]]),x.push([P[4],P[5]]);break;case"Z":y(),b.push([g[0],g[1]])}if(E(),!u)return h;const B=[];for(const F of h){const P=jd(F,u);P.length&&B.push(P)}return B})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=Io(e,r);if(i)if(r.fillStyle==="solid")if(c.length===1){const d=Io(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(d.ops)})}else o.push(hr(c,r));else o.push(Jt(c,r));return a&&(s?c.forEach((d=>{o.push(ln(d,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const i=typeof n=="number"&&n>=0?o.data.map((a=>+a.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${i[0]} ${i[1]} `;break;case"bcurveTo":r+=`C${i[0]} ${i[1]}, ${i[2]} ${i[3]}, ${i[4]} ${i[5]} `;break;case"lineTo":r+=`L${i[0]} ${i[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const i of n){let a=null;switch(i.type){case"path":a={d:this.opsToPath(i),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:J};break;case"fillPath":a={d:this.opsToPath(i),stroke:J,strokeWidth:0,fill:r.fill||J};break;case"fillSketch":a=this.fillSketch(i,r)}a&&o.push(a)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||J,strokeWidth:r,fill:J}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class Wd{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new kn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,i=e.options.fixedDecimalPlaceDigits;for(const a of n)switch(a.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,a,i),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,a,i,s),o.restore();break}case"fillSketch":this.fillSketch(o,a,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const i of n.ops){const a=typeof r=="number"&&r>=0?i.data.map((s=>+s.toFixed(r))):i.data;switch(i.op){case"move":e.moveTo(a[0],a[1]);break;case"bcurveTo":e.bezierCurveTo(a[0],a[1],a[2],a[3],a[4],a[5]);break;case"lineTo":e.lineTo(a[0],a[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a),a}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a),a}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a),a}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i),i}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const tn="http://www.w3.org/2000/svg";class Ud{constructor(e,n){this.svg=e,this.gen=new kn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,i=o.createElementNS(tn,"g"),a=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(tn,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(tn,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&i.appendChild(c)}return i}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const i=e.createElementNS(tn,"path");return i.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),i.setAttribute("stroke",r.fill||""),i.setAttribute("stroke-width",o+""),i.setAttribute("fill","none"),r.fillLineDash&&i.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&i.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),i}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a)}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a)}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a)}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var ha={canvas:(t,e)=>new Wd(t,e),svg:(t,e)=>new Ud(t,e),generator:t=>new kn(t),newSeed:()=>kn.newSeed()};const Xd="http://www.w3.org/2000/svg",No=1,ga="#000000",Sn=3;let _=null;function Vd(){_||(_=document.createElementNS(Xd,"svg"),_.setAttribute("data-manuscript","ui"),_.setAttribute("width","100%"),_.setAttribute("height","100%"),_.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R+4}`,"overflow: visible"].join("; "),document.body.appendChild(_))}function Zr(){_==null||_.remove(),_=null}function ma(t,e,n,r){if(!_)return;for(;_.firstChild;)_.removeChild(_.firstChild);const o=ha.svg(_);Fo(p=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:No,...p}));const i=Math.atan2(r-e,n-t),a=14+Sn*2,s=Math.PI/7,c=n-a*Math.cos(i-s),l=r-a*Math.sin(i-s),d=n-a*Math.cos(i+s),f=r-a*Math.sin(i+s),u=`M ${c} ${l} L ${n} ${r} L ${d} ${f}`;Fo(p=>o.path(u,{roughness:1.5,bowing:1,seed:No+1,...p}))}function Fo(t){_&&(_.appendChild(t({stroke:"#ffffff",strokeWidth:Sn+4})),_.appendChild(t({stroke:ga,strokeWidth:Sn})))}const Yd=8;let En=!1,Ho=null,he=!1,Bt=0,qt=0;function Gd(){Ho||(Ho=at(({prev:t,next:e})=>{e==="arrow"?Kd():t==="arrow"&&Zd()}))}function Kd(){En||(En=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",ba,!0),document.addEventListener("mousemove",va,!0),document.addEventListener("mouseup",ya,!0),document.addEventListener("keydown",xa,!0))}function Zd(){En&&(En=!1,he=!1,document.body.style.cursor="",document.removeEventListener("mousedown",ba,!0),document.removeEventListener("mousemove",va,!0),document.removeEventListener("mouseup",ya,!0),document.removeEventListener("keydown",xa,!0),Zr())}function ba(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),he=!0,Bt=t.clientX,qt=t.clientY,Vd(),ma(Bt,qt,Bt,qt))}function va(t){he&&(t.preventDefault(),ma(Bt,qt,t.clientX,t.clientY))}function ya(t){if(!he)return;he=!1,Zr();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Bt,n-qt)<Yd){D("idle");return}t.preventDefault(),t.stopPropagation();const o=G(),i={kind:"arrow",id:Qd(),style:"excalidraw",from:{x:Bt,y:qt},to:{x:e,y:n},...o?{fromAnchorOffset:{x:Bt-o.left,y:qt-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:ga,strokeWidth:Sn};_e(i),D("idle")}function xa(t){t.key==="Escape"&&(t.preventDefault(),he=!1,Zr(),D("idle"))}function Qd(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const zo="http://www.w3.org/2000/svg",wa="#1a1a1a",ka=3,Jd=2,tu=2;let An=!1,_o=null,ge=!1,ft=[],ot=null,bt=null;function eu(){_o||(_o=at(({prev:t,next:e})=>{e==="freedraw"?nu():t==="freedraw"&&ru()}))}function nu(){An||(An=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Sa,!0),document.addEventListener("mousemove",Ea,!0),document.addEventListener("mouseup",Aa,!0),document.addEventListener("keydown",Ma,!0))}function ru(){An&&(An=!1,ge=!1,ft=[],document.body.style.cursor="",document.removeEventListener("mousedown",Sa,!0),document.removeEventListener("mousemove",Ea,!0),document.removeEventListener("mouseup",Aa,!0),document.removeEventListener("keydown",Ma,!0),Qr())}function Sa(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),ge=!0,ft=[{x:t.clientX,y:t.clientY}],ou(),$a())}function Ea(t){if(!ge)return;t.preventDefault();const e=ft[ft.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<tu||(ft.push({x:t.clientX,y:t.clientY}),$a())}function Aa(t){if(!ge)return;if(ge=!1,Qr(),ft.length<Jd){ft=[],D("idle");return}t.preventDefault(),t.stopPropagation();const e=ft.slice(),n=G(),r={kind:"freedraw",id:iu(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:wa,strokeWidth:ka};_e(r),ft=[],D("idle")}function Ma(t){t.key==="Escape"&&(t.preventDefault(),ge=!1,ft=[],Qr(),D("idle"))}function ou(){ot||(ot=document.createElementNS(zo,"svg"),ot.setAttribute("data-manuscript","ui"),ot.setAttribute("width","100%"),ot.setAttribute("height","100%"),ot.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R+4}`,"overflow: visible"].join("; "),bt=document.createElementNS(zo,"polyline"),bt.setAttribute("fill","none"),bt.setAttribute("stroke",wa),bt.setAttribute("stroke-width",String(ka)),bt.setAttribute("stroke-linecap","round"),bt.setAttribute("stroke-linejoin","round"),ot.appendChild(bt),document.body.appendChild(ot))}function Qr(){ot==null||ot.remove(),ot=null,bt=null}function $a(){bt&&bt.setAttribute("points",ft.map(t=>`${t.x},${t.y}`).join(" "))}function iu(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const je="manuscript:element-selected";let Mn=!1,nt=null,Bo=null;function au(){Bo||(Bo=at(({prev:t,next:e})=>{e==="picker"?su():t==="picker"&&cu()}))}function su(){Mn||(Mn=!0,document.addEventListener("mouseover",La,!0),document.addEventListener("mouseout",Ta,!0),document.addEventListener("click",Ca,!0),document.addEventListener("keydown",Ia,!0))}function cu(){Mn&&(Mn=!1,document.removeEventListener("mouseover",La,!0),document.removeEventListener("mouseout",Ta,!0),document.removeEventListener("click",Ca,!0),document.removeEventListener("keydown",Ia,!0),Pa())}function La(t){const e=t.target;!(e instanceof HTMLElement)||Da(e)||du(e)}function Ta(t){Pa()}function Ca(t){const e=t.target;if(!(e instanceof HTMLElement)||Da(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=Jc(e),r=e.ownerDocument??document;if(console.log("[manuscript/picker] selectorChain",{target:e,chain:n,resolve:{layer1:gn(n.layer1,r),layer2:mn(n.layer2,r),layer3:bn(n.layer3,r)},matchesTarget:{layer1:gn(n.layer1,r)===e,layer2:mn(n.layer2,r)===e,layer3:bn(n.layer3,r)===e}}),!tl(n,e)){lu();return}const o=e.getBoundingClientRect(),i={chain:n,rect:{x:o.x,y:o.y,width:o.width,height:o.height}};document.dispatchEvent(new CustomEvent(je,{detail:i})),D("idle")}let dt=null,en=null;function lu(){dt&&dt.remove(),dt=document.createElement("div"),dt.setAttribute("data-manuscript","ui"),dt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${R+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),dt.textContent=m("toast.ambiguous-selector"),document.body.appendChild(dt),en!==null&&window.clearTimeout(en),en=window.setTimeout(()=>{dt==null||dt.remove(),dt=null,en=null},3500)}function Ia(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function du(t){nt||(nt=document.createElement("div"),nt.setAttribute("data-manuscript","ui"),nt.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${R+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(nt));const e=t.getBoundingClientRect();nt.style.left=`${e.left}px`,nt.style.top=`${e.top}px`,nt.style.width=`${e.width}px`,nt.style.height=`${e.height}px`,nt.style.display="block"}function Pa(){nt&&(nt.style.display="none")}function Da(t){return t.closest('[data-manuscript="ui"]')!==null}const We="http://www.w3.org/2000/svg";function Jr(t,e){let n;switch(t){case"rectangle":n=uu(e);break;case"ellipse":n=pu(e);break;case"triangle":n=nn(gu(e),e);break;case"diamond":n=nn(mu(e),e);break;case"star":n=nn(bu(e),e);break;case"callout":n=hu(vu(e),e);break;case"line":n=fu(e);break;case"block-arrow":n=nn(yu(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function uu(t){const e=document.createElementNS(We,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),Gn(e,t),e}function pu(t){const e=document.createElementNS(We,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),Gn(e,t),e}function fu(t){const e=document.createElementNS(We,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function nn(t,e){const n=document.createElementNS(We,"polygon");return n.setAttribute("points",t),Gn(n,e),n.setAttribute("stroke-linejoin","round"),n}function hu(t,e){const n=document.createElementNS(We,"path");return n.setAttribute("d",t),Gn(n,e),n.setAttribute("stroke-linejoin","round"),n}function Gn(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function gu(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function mu(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function bu(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,i=[];for(let a=0;a<10;a++){const s=Math.PI/5*a-Math.PI/2,c=a%2===0?r:o;i.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return i.join(" ")}function vu(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,i=t.x+t.width*.5,a=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${i} ${r}`,`L ${a} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function yu(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const xu="http://www.w3.org/2000/svg",wu="#ffffff",ku="#1a1a1a",Su=2;let V=null,vt=null;function Ra(t){return{fill:t==="line"?"transparent":wu,stroke:ku,strokeWidth:Su}}function Eu(){vt||(vt=document.createElement("div"),vt.setAttribute("data-manuscript","ui"),vt.textContent="Click and drag to draw a shape · Esc to cancel",vt.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${R+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(vt))}function Oa(){vt==null||vt.remove(),vt=null}function Au(){V||(V=document.createElementNS(xu,"svg"),V.setAttribute("data-manuscript","ui"),V.setAttribute("width","100%"),V.setAttribute("height","100%"),V.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R+4}`,"overflow: visible"].join("; "),document.body.appendChild(V))}function to(){V==null||V.remove(),V=null}function Na(t,e,n,r,o){if(!V)return;for(;V.firstChild;)V.removeChild(V.firstChild);const i=t==="line"?r-e:Math.abs(r-e),a=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=Ra(t),d=Jr(t,{x:s,y:c,width:i,height:a,...l});d&&V.appendChild(d)}const Mu=6;let Mt="rectangle",$n=!1,qo=null,me=!1,$t=0,Lt=0;function $u(t){Mt=t}function Lu(){qo||(qo=at(({prev:t,next:e})=>{e==="shape"?Tu():t==="shape"&&Cu()}))}function Tu(){$n||($n=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Fa,!0),document.addEventListener("mousemove",Ha,!0),document.addEventListener("mouseup",za,!0),document.addEventListener("keydown",_a,!0),Eu())}function Cu(){$n&&($n=!1,me=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Fa,!0),document.removeEventListener("mousemove",Ha,!0),document.removeEventListener("mouseup",za,!0),document.removeEventListener("keydown",_a,!0),to(),Oa())}function Fa(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),me=!0,$t=t.clientX,Lt=t.clientY,Oa(),Au(),Na(Mt,$t,Lt,$t,Lt))}function Ha(t){me&&(t.preventDefault(),Na(Mt,$t,Lt,t.clientX,t.clientY))}function za(t){if(!me)return;me=!1,to();const e=t.clientX,n=t.clientY,r=Mt==="line"?e-$t:Math.abs(e-$t),o=Mt==="line"?n-Lt:Math.abs(n-Lt);if(Math.max(Math.abs(r),Math.abs(o))<Mu){D("idle");return}t.preventDefault(),t.stopPropagation();const i=Mt==="line"?{x:$t,y:Lt,width:r,height:o}:{x:Math.min($t,e),y:Math.min(Lt,n),width:r,height:o},a=Ra(Mt),s=G(),c={kind:"shape",id:Iu(),shapeKind:Mt,bounds:i,...s?{boundsAnchorOffset:{x:i.x-s.left,y:i.y-s.top}}:{},...a};_e(c),D("idle")}function _a(t){t.key==="Escape"&&(t.preventDefault(),me=!1,to(),D("idle"))}function Iu(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Pu={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},Du="Text";let Ln=!1,jo=null;function Ru(){jo||(jo=at(({prev:t,next:e})=>{e==="text"?Ou():t==="text"&&Nu()}))}function Ou(){Ln||(Ln=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Ba,!0),document.addEventListener("keydown",qa,!0))}function Nu(){Ln&&(Ln=!1,document.body.style.cursor="",document.removeEventListener("click",Ba,!0),document.removeEventListener("keydown",qa,!0))}function Ba(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=G(),o={kind:"text",id:Fu(),text:Du,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...Pu}};_e(o),requestAnimationFrame(()=>{const i=document.querySelector(`[data-annotation-text="${o.id}"]`);i&&i.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),D("idle")}function qa(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function Fu(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Hu="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",zu="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",Wo="Asta Sans",_u="fonts/AstaSans-VariableFont_wght.ttf";let Uo=!1;function Bu(){Uo||(Uo=!0,Xo(Hu),Xo(zu),qu())}function Xo(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function qu(){try{for(const t of document.fonts)if(t.family===Wo)return}catch{}try{const t=chrome.runtime.getURL(_u);new FontFace(Wo,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const ut="manuscript";function Kn(...t){}function mr(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function te(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function ja(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===ut&&typeof e.type=="string"}function ju(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const i=o.data;if(ja(i)){if(Kn("child received",i.type,"in",location.href),i.type==="set-mode"){D(i.mode),t=i.mode;return}if(i.type==="top-drag-start"){n=!0;return}if(i.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(je,(o=>{const i=o.detail;te({source:ut,type:"element-selected",detail:i})})),at(({prev:o,next:i})=>{o==="picker"&&i==="idle"&&te({source:ut,type:"exit-picker"})}),te({source:ut,type:"frame-ready"}),document.addEventListener("mousedown",o=>{te({source:ut,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&te({source:ut,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&te({source:ut,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function Wu(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const i=o.getBoundingClientRect();return{x:i.left,y:i.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function Uu(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Xu(){at(({next:t})=>{mr({source:ut,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>mr({source:ut,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>mr({source:ut,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(ja(e)){if(Kn("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){Vu(t.source,e.detail);return}if(e.type==="exit-picker"){D("idle");return}if(e.type==="iframe-mousedown"){Vo("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";Vo(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){Yu(t.source);return}}})}function Vu(t,e){const n=Uu(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};Kn("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(je,{detail:o})),D("idle")}function Vo(t,e,n,r){const o=Wu(e),i=n+o.x,a=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:i,clientY:a}))}function Yu(t){if(xt()==="picker")try{t==null||t.postMessage({source:ut,type:"set-mode",mode:"picker"},"*"),Kn("top → late child: set-mode picker")}catch{}}function Gu(){if(typeof window>"u")return;window===window.top?Xu():ju()}const Ku="iframe-tool-overlay",Yo=new Set(["text","shape","freedraw"]);let ce=[],br=!1,ne=null;function Zu(){typeof window>"u"||window===window.top&&(at(({next:t})=>{Yo.has(t)?Go():Wa()}),Yo.has(xt())&&Go())}function Go(){Wa(),Ko(),window.addEventListener("scroll",Tn,!0),window.addEventListener("resize",Tn),ne=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&Ko()}),ne.observe(document.body,{childList:!0,subtree:!0})}function Wa(){ce.forEach(t=>t.remove()),ce=[],window.removeEventListener("scroll",Tn,!0),window.removeEventListener("resize",Tn),ne==null||ne.disconnect(),ne=null}function Ko(){ce.forEach(e=>e.remove()),ce=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",Ku),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${R+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),ce.push(n),Ua(n,e)})}const rn=8;function Ua(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-rn}px`,t.style.top=`${n.top-rn}px`,t.style.width=`${n.width+rn*2}px`,t.style.height=`${n.height+rn*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function Tn(){br||(br=!0,requestAnimationFrame(()=>{br=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=ce[e];r&&Ua(r,n),e++})}))}let Dt=!1;function Zn(){return Dt}async function Qu(){try{if(typeof(await chrome.storage.local.get(X.prompterWindowId))[X.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(Dt=!0)}catch{}}async function Xa(){if(Dt){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}Dt=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(Dt=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Va(){if(Dt){Dt=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function Ya(t){try{await chrome.storage.local.set({[X.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function Ju(){Dt=!1}const tp="modulepreload",ep=function(t){return"/"+t},Zo={},np=function(e,n,r){let o=Promise.resolve();if(n&&n.length>0){let a=function(l){return Promise.all(l.map(d=>Promise.resolve(d).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));o=a(n.map(l=>{if(l=ep(l),l in Zo)return;Zo[l]=!0;const d=l.endsWith(".css"),f=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const u=document.createElement("link");if(u.rel=d?"stylesheet":tp,d||(u.as="script"),u.crossOrigin="",u.href=l,c&&u.setAttribute("nonce",c),document.head.appendChild(u),d)return new Promise((p,h)=>{u.addEventListener("load",p),u.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(a){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=a,window.dispatchEvent(s),!s.defaultPrevented)throw a}return o.then(a=>{for(const s of a||[])s.status==="rejected"&&i(s.reason);return e().catch(i)})},At="http://www.w3.org/2000/svg",Qo="manuscript-spotlight-mask",rp="oklch(0.42 0.09 250)",op=3,ip="rgb(0, 0, 0)",ap=.55,Ee=14;let le=null,Z=null,pt=null,Y=null,H=null,St=null,Tr=[],re=null;function Ga(t){le=t,Z||cp(),Jo(),Ne(),sp(t),re||(re=ye(Jo))}function be(){le=null,Ka(),re==null||re(),re=null,Z&&(Z.remove(),Z=null,pt=null,Y=null,H=null,St=null)}function sp(t){var n;Ka();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=Ne;r.addEventListener("scroll",o,!0),Tr.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",Ne)}function Ka(){for(const t of Tr)t.remove();Tr=[],window.removeEventListener("resize",Ne)}function cp(){Z=document.createElementNS(At,"svg"),Z.setAttribute("data-manuscript","ui"),Z.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R}`].join("; "),Z.setAttribute("width","100%"),Z.setAttribute("height","100%");const t=document.createElementNS(At,"defs"),e=document.createElementNS(At,"mask");e.setAttribute("id",Qo);const n=document.createElementNS(At,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),pt=document.createElementNS(At,"rect"),pt.setAttribute("fill","black"),pt.setAttribute("rx","4"),pt.setAttribute("ry","4"),e.appendChild(pt),t.appendChild(e),Z.appendChild(t),St=document.createElementNS(At,"rect"),St.setAttribute("width","100%"),St.setAttribute("height","100%"),St.setAttribute("mask",`url(#${Qo})`),Z.appendChild(St),Y=document.createElementNS(At,"rect"),Y.setAttribute("fill","none"),Y.setAttribute("rx","4"),Y.setAttribute("ry","4"),Y.style.pointerEvents="none",Z.appendChild(Y),H=document.createElementNS(At,"rect"),H.setAttribute("fill","none"),H.setAttribute("stroke","transparent"),H.setAttribute("stroke-width",String(Ee)),H.setAttribute("rx","4"),H.setAttribute("ry","4"),H.setAttribute("pointer-events","stroke"),H.style.cursor="pointer",H.addEventListener("click",lp),Z.appendChild(H),document.body.appendChild(Z)}function Jo(){var i;if(!Y||!St)return;const t=((i=st())==null?void 0:i.spotlight)??{},e=t.stroke??rp,n=t.strokeWidth??op,r=t.dimColor??ip,o=t.dimOpacity??ap;Y.setAttribute("stroke",e),Y.setAttribute("stroke-width",String(n)),St.setAttribute("fill",r),St.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),Ne()}function lp(t){xt()!=="replay"&&(!le||!H||(t.stopPropagation(),t.preventDefault(),np(()=>import("./chunk-BnwJaGsj.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{H&&e.openSpotlightEditor(H)})))}function Ne(){if(!le||!pt||!Y||!H)return;const t=le.getBoundingClientRect(),e=dp(le),n=4,r=t.left+e.x-n,o=t.top+e.y-n,i=t.width+n*2,a=t.height+n*2;pt.setAttribute("x",String(r)),pt.setAttribute("y",String(o)),pt.setAttribute("width",String(i)),pt.setAttribute("height",String(a));const s=Math.max(0,Number(Y.getAttribute("stroke-width")??0)),c=r-s/2,l=o-s/2,d=i+s,f=a+s;Y.setAttribute("x",String(c)),Y.setAttribute("y",String(l)),Y.setAttribute("width",String(d)),Y.setAttribute("height",String(f));const u=c-Ee/2,p=l-Ee/2,h=d+Ee,b=f+Ee;H.setAttribute("x",String(u)),H.setAttribute("y",String(p)),H.setAttribute("width",String(h)),H.setAttribute("height",String(b))}function dp(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const ti="data-wp-animations";function up(){if(document.head.querySelector(`[${ti}]`))return;const t=document.createElement("style");t.setAttribute(ti,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function Fe(t,e,n){if(!e||e.kind==="none"||xt()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const i=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",i),t.removeEventListener("animationcancel",i)};t.addEventListener("animationend",i),t.addEventListener("animationcancel",i)}const Cn="http://www.w3.org/2000/svg",Za="data-annotation-text",ei="data-annotation-arrow",Qa="data-annotation-shape",ni="data-annotation-freedraw",L={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function pp(t,e){const{svg:n,roughSvg:r}=L;if(!n||!r)return;const o=hp(t.id),{from:i,to:a}=ol(t,e);Ja(t,s=>r.line(i.x,i.y,a.x,a.y,{roughness:1.5,bowing:1,seed:o,...s})),fp(t,i,a,o+1)}function fp(t,e,n,r){const{roughSvg:o}=L;if(!o)return;const i=Math.atan2(n.y-e.y,n.x-e.x),a=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-a*Math.cos(i-s),l=n.y-a*Math.sin(i-s),d=n.x-a*Math.cos(i+s),f=n.y-a*Math.sin(i+s),u=`M ${c} ${l} L ${n.x} ${n.y} L ${d} ${f}`;Ja(t,p=>o.path(u,{roughness:1.5,bowing:1,seed:r,...p}))}function Ja(t,e){const{svg:n}=L;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(ei,t.id),Fe(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(ei,t.id),Fe(o,t.entryAnimation,0),n.appendChild(o)}function hp(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const M={state:null,unsubscribeStep:null};function it(){return M.state!==null}function Ue(){var t;return((t=M.state)==null?void 0:t.standalone)===!0}function gp(t,e){const{svg:n}=L;if(!n)return;const r=Wn(t,e),o=mp(t,r),i=r.map(c=>`${c.x},${c.y}`).join(" "),a=document.createElementNS(Cn,"polyline");if(a.setAttribute("points",i),a.setAttribute("fill","none"),a.setAttribute("stroke",t.stroke),a.setAttribute("stroke-width",String(t.strokeWidth)),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute(ni,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&a.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&a.setAttribute("transform",o),a.style.pointerEvents="none",Fe(a,t.entryAnimation,t.rotate??0),n.appendChild(a),Ue())return;const s=document.createElementNS(Cn,"polyline");s.setAttribute(ni,t.id),s.setAttribute("points",i),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),bp(t.id,c,s))}),n.appendChild(s)}function mp(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,i=-1/0,a=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>i&&(i=l.x),l.y>a&&(a=l.y);const s=(r+i)/2,c=(o+a)/2;return`rotate(${n} ${s} ${c})`}function bp(t,e,n){const r=C(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},i=G(),a=Wn(r,i).map(d=>({...d}));let s=!1;const c=d=>{const f=d.clientX-o.x,u=d.clientY-o.y;if(!s&&Math.hypot(f,u)<3)return;s=!0,d.preventDefault();const p=a.map(b=>({x:b.x+f,y:b.y+u})),h=i?{points:p,pointsAnchorOffset:p.map(b=>({x:b.x-i.left,y:b.y-i.top}))}:{points:p,pointsAnchorOffset:void 0};I(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const d=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),f=d[d.length-1]??n;gd(t,f)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function vp(t,e){const{svg:n}=L;if(!n)return;const r=jn(t,e),o=Jr(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(Qa,t.id),o.style.pointerEvents="none",Fe(o,t.entryAnimation,t.rotate??0),n.appendChild(o),Ue()||n.appendChild(yp(t,r)))}function yp(t,e){const n=document.createElementNS(Cn,"rect");if(n.setAttribute(Qa,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>xp(t.id,r,n)),n}function xp(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=C(t);if(!o||o.kind!=="shape")return;const i=G(),a=o.boundsAnchorOffset&&i?{x:i.left+o.boundsAnchorOffset.x,y:i.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:a.x,y:a.y};let c=!1;const l=f=>{const u=f.clientX-r.x,p=f.clientY-r.y;if(!c&&Math.hypot(u,p)<3)return;c=!0,f.preventDefault();const h=s.x+u,b=s.y+p,g=i?{bounds:{...s,x:h,y:b},boundsAnchorOffset:{x:h-i.left,y:b-i.top}}:{bounds:{...s,x:h,y:b},boundsAnchorOffset:void 0};I(t,g)},d=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const f=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=f[f.length-1]??n;hd(t,u)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)}function wp(t,e){const{host:n}=L;if(!n)return;const r=document.createElement("div");r.setAttribute(Za,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,i=t.style.backgroundColor??"#ffffff",a=t.style.backgroundOpacity??.96,s=i==="transparent"?"transparent":kp(i,a),c=t.rotate??0,l=t.style.borderColor??"#000000",d=l==="transparent"?"none":`2px solid ${l}`,f=rl(t,e),u=Ue();r.style.cssText=["position: absolute",`left: ${f.x}px`,`top: ${f.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${d}`,"border-radius: 8px",u?"pointer-events: none":"pointer-events: auto",u?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,u||Sp(r,t.id),Fe(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function kp(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,i=0,a=0;return r.length===4?(o=parseInt(r[1]+r[1],16),i=parseInt(r[2]+r[2],16),a=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),i=parseInt(r.slice(3,5),16),a=parseInt(r.slice(5,7),16)),`rgba(${o}, ${i}, ${a}, ${n})`}return t}function Sp(t,e){let n=!1,r=0,o=0,i=0,a=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();i=l.left,a=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,d=c.clientY-o;Math.abs(l)+Math.abs(d)>2&&(s=!0),t.style.left=`${i+l}px`,t.style.top=`${a+d}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),d=G(),f=d?{position:{x:c,y:l},anchorOffset:{x:c-d.left,y:l-d.top}}:{position:{x:c,y:l},anchorOffset:void 0};I(e,f)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),fd(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Ep(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",I(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Ep(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function ts(){if(L.host)return;up();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${R+3}`].join("; ");const e=document.createElementNS(Cn,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),L.host=t,L.svg=e,L.roughSvg=ha.svg(e),document.body.appendChild(t),L.unsubscribe=ye(un),L.unsubscribeMode=at(un),Ap(),un()}let de=null;function Ce(){de===null&&(de=requestAnimationFrame(()=>{de=null,un()}))}let jt=null,Cr=null;function Ap(){window.addEventListener("resize",Ce),window.addEventListener("scroll",Ce,!0),typeof ResizeObserver<"u"&&(jt=new ResizeObserver(Ce))}function Mp(){window.removeEventListener("resize",Ce),window.removeEventListener("scroll",Ce,!0),jt&&(jt.disconnect(),jt=null),Cr=null,de!==null&&(cancelAnimationFrame(de),de=null)}function es(){var t,e;(t=L.unsubscribe)==null||t.call(L),L.unsubscribe=null,(e=L.unsubscribeMode)==null||e.call(L),L.unsubscribeMode=null,Mp(),L.host&&(L.host.remove(),L.host=null,L.svg=null,L.roughSvg=null)}function $p(){return L.host!==null}function un(){const{host:t,svg:e}=L;if(!t||!e)return;for(t.querySelectorAll(`[${Za}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=G();if(jt){let o=null;try{o=Lp()}catch{o=null}o!==Cr&&(jt.disconnect(),o&&jt.observe(o),Cr=o)}const r=zi();for(const o of r)o.kind==="text"?wp(o,n):o.kind==="arrow"?pp(o,n):o.kind==="shape"?vp(o,n):o.kind==="freedraw"&&gp(o,n)}function Lp(){const t=st();if(!(t!=null&&t.selectors))return null;try{return Oe(t.selectors)}catch{return null}}const S={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function oe(t,e,n){return Math.max(e,Math.min(n,t))}function ns(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=Pp()),Tp()}function Tp(){const{host:t}=S;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),i=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${oe(o,0,n)}px`),Number.isFinite(i)&&(t.style.top=`${oe(i,0,r)}px`)}async function Cp(){try{return(await chrome.storage.local.get(X.replayControlsOrientation))[X.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Ip(t){try{await chrome.storage.local.set({[X.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function Pp(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function Dp(){try{const e=(await chrome.storage.local.get(X.replayControlsPosition))[X.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function ri(t){try{await chrome.storage.local.set({[X.replayControlsPosition]:t})}catch{}}function Rp(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function Op(){const{host:t,shadow:e}=S;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,i=0,a=0,s=0;const c=u=>{if(!S.host)return;u.preventDefault(),u.stopPropagation(),r=!0,n.classList.add("dragging");const p=S.host.getBoundingClientRect();S.host.style.left=`${p.left}px`,S.host.style.top=`${p.top}px`,S.host.style.bottom="auto",S.host.style.transform="none",o=u.clientX,i=u.clientY,a=p.left,s=p.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)},l=u=>{if(!r||!S.host)return;const p=S.host.getBoundingClientRect(),h=u.clientX-o,b=u.clientY-i,g=oe(a+h,0,window.innerWidth-p.width),x=oe(s+b,0,window.innerHeight-p.height);S.host.style.left=`${g}px`,S.host.style.top=`${x}px`},d=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const u=S.host;if(u){const p=parseFloat(u.style.left||"0"),h=parseFloat(u.style.top||"0");Number.isFinite(p)&&Number.isFinite(h)&&ri({left:p,top:h})}},f=()=>{if(S.host&&S.host.style.transform==="none"){const u=S.host.getBoundingClientRect(),p=oe(u.left,0,window.innerWidth-u.width),h=oe(u.top,0,window.innerHeight-u.height);S.host.style.left=`${p}px`,S.host.style.top=`${h}px`,ri({left:p,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",f),S.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",f),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0)}}function rs(){return`
    ${wt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function os(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Np(t){return os(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Fp(t,e){const{shadow:n}=S;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,i)=>{const a=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${i===e?" active":""}" role="option" data-action="step-jump" data-index="${i}" aria-selected="${i===e}" title="${Np(a)}">${i+1}. ${os(a)}</li>`}).join(""))}function Hp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function Ir(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function is(t){const{host:e,shadow:n}=S;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||Ir()}let pn=-1,fn=!1;function zp(){pn=-1,fn=!1}function _p(t,e,n){const{shadow:r}=S;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",pn=-1,fn=!1;return}o.classList.remove("hidden");const s=t!==pn||fn&&!n;pn=t,fn=n;let c=o.querySelector(".progress-fill");(!c||s)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function Bp(){return`
    ${wt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid color-mix(in oklch, currentColor, transparent 40%);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: color-mix(in oklch, currentColor, transparent 92%); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: color-mix(in oklch, currentColor, transparent 85%); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: color-mix(in oklch, currentColor, transparent 80%);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: color-mix(in oklch, currentColor, transparent 82%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: color-mix(in oklch, currentColor, transparent 45%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: color-mix(in oklch, currentColor, transparent 25%);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: color-mix(in oklch, currentColor, transparent 92%); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function qp(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function jp(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function Wp(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?qp(14):jp(14))}function Qn(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Et(t);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}let as=!1;function Up(t){if(S.host)return;const{host:e,shadow:n}=Qn();S.host=e,S.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${R+6}`,"pointer-events: auto",as?"display: none":""].filter(Boolean).join("; "),n.innerHTML=`<style>${Bp()}</style>${Xp()}`,n.addEventListener("click",r=>Vp(r,t)),document.body.appendChild(e),Op(),document.addEventListener("mousedown",is,!0),S.orientationApplied=!1,Cp().then(r=>{S.orientationApplied||(S.orientationApplied=!0,ns(r))}),Dp().then(r=>{S.host&&r&&S.host.style.transform!=="none"&&Rp(S.host,r)})}function Xp(){return`
    <div class="bar" role="toolbar" aria-label="${m("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${m("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${m("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${m("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${m("replay.prompter-aria")}" title="${m("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${m("replay.tts-aria")}" title="${m("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${m("replay.move-aria")}" title="${m("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${m("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${m("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Vp(t,e){var i;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){Hp();return}const r=n.closest('[data-action="step-jump"]');if(r){const a=Number(r.getAttribute("data-index"));Number.isFinite(a)&&(Ir(),e.onStepSelect(a));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(i=n.closest("[data-action]"))==null?void 0:i.getAttribute("data-action");switch(o&&Ir(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Yp();break}}function Yp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";S.orientationApplied=!0,ns(n),Ip(n)}function vr(t){as=t;const{host:e}=S;e&&(e.dataset.recordingHidden=t?"1":"",e.style.display=t?"none":"")}function Gp(){var t,e;(t=S.cleanupDrag)==null||t.call(S),S.cleanupDrag=null,document.removeEventListener("mousedown",is,!0),(e=S.host)==null||e.remove(),S.host=null,S.shadow=null,S.orientationApplied=!1,zp()}function oi(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const i=e.querySelector('[data-action="prev"]');i&&i.toggleAttribute("disabled",t.currentIndex<=0);const a=e.querySelector('[data-action="next"]');a&&(a.toggleAttribute("disabled",!1),a.setAttribute("aria-label",t.currentIndex>=t.total-1?m("replay.finish-aria"):m("replay.next-aria"))),_p(t.currentIndex,t.timerDurationMs??null,t.paused),Fp(t.steps??[],t.currentIndex),Wp(t.ttsEnabled===!0)}let Tt=null;function Kp(t){Xe();const{host:e,shadow:n}=Qn();Tt=e,Tt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${R+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${rs()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${m("replay.notfound.title")}</h2>
          <p>${m("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${m("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${m("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const i=o.target;if(!(i instanceof HTMLElement))return;const a=(s=i.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");a==="skip"?t.onSkip():a==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),Tt.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(Tt)}function Xe(){if(!Tt)return;const t=Tt.__cleanup;t==null||t(),Tt.remove(),Tt=null}let Ct=null;function Zp(t){In();const{host:e,shadow:n}=Qn();Ct=e,Ct.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${R+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${rs()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${m("replay.url-mismatch.title")}</h2>
          <p>${m("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${m("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${m("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${m("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",i=>{var c;const a=i.target;if(!(a instanceof HTMLElement))return;const s=(c=a.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=i=>{i.key==="Escape"?(i.preventDefault(),t.onCancel()):i.key==="Enter"&&(i.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),Ct.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(Ct)}function In(){if(!Ct)return;const t=Ct.__cleanup;t==null||t(),Ct.remove(),Ct=null}let zt=null;function Qp(t){Ve();const e=t.getBoundingClientRect(),n=Jp(t),r=e.left+n.x,o=e.top+n.y,i=e.bottom+n.y,a=36,s=8,c=o-s-a<8,l=c?Math.min(window.innerHeight-8-a,i+s):Math.max(8,o-s-a),d=Math.max(8,Math.min(r,window.innerWidth-200)),f=c?"up":"down",{host:u,shadow:p}=Qn();zt=u,zt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${d}px`,`z-index: ${R+6}`,"pointer-events: none"].join("; "),p.innerHTML=`
    <style>
      ${wt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${m("prompter.action-step")}</span>
      <span>${m("replay.action-prompt")}</span>
      <span class="tip ${f}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(zt)}function Ve(){zt==null||zt.remove(),zt=null}function Jp(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let ue=null;function tf(t){ue||(ue=e=>{if(M.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",ue,!0))}function ef(){ue&&(document.removeEventListener("keydown",ue,!0),ue=null)}function eo(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function ss(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function nf(t,e){var r,o,i;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||eo(n,location.href)||((o=M.state)==null?void 0:o.standalone)===!0)return!1;try{await Fr({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((i=M.state)==null?void 0:i.paused)??!1})}catch(a){console.warn("[manuscript] persist activeReplay before nav failed",a)}return location.href=n,!0}function cs(t){return new Promise(e=>{Zp({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{In(),e("force")},onCancel:()=>{In(),e("cancel")}})})}async function rf(t){try{const e=await wi();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function no(){const t=T();if(!(!t||!M.state)&&M.state.standalone!==!0)try{await Fr({scenarioId:t.id,stepIndex:U(),startedAt:Date.now(),paused:M.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function ls(t,e,n){const r=T();if(!r)return{ok:!1};if(n&&await rf(r.id))return{ok:!0};const o=ss(r);if(!o||eo(o,location.href))return{ok:!0};const i=await cs(o);return i==="cancel"?{ok:!1}:i==="navigate"?(await Fr({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class ds extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function of(t,e=Ns){const n=Oe(t);return n?Promise.resolve(n):new Promise((r,o)=>{let i=!1;const s=(Xi(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(i)return;const d=Oe(t);d&&(i=!0,c.disconnect(),clearTimeout(l),r(d))}),l=setTimeout(()=>{i||(i=!0,c.disconnect(),o(new ds(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function xe(){const{state:t}=M;if(!t)return;const e=T();if(!e)return;const n=e.steps[U()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(Si().then(o=>{oi({currentIndex:U(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:o})}),oi({currentIndex:U(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),Zn()){const o=U(),i=e.steps[o],a=e.steps[o+1];Ya({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(s=>({name:s.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:a?{name:a.name,description:a.description,autoAdvanceMs:a.autoAdvanceMs??null,waitForNavigation:a.waitForNavigation,thumbnailDataUrl:a.thumbnailDataUrl??null}:null})}}async function af(){if(Zn()){await Va(),Pn(!1);return}Pn(!0),await Xa(),xe()}function sf(){Pn(!1)}function Pn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function Jn(t){var i;const{state:e}=M;if(!e)return;const n=T();if(!n)return;const r=n.steps[U()];if(xe(),!r)return;if(Xe(),Ve(),qs()&&!e.paused&&js(r.description),!r.selectors){be(),r.waitForNavigation||ii(t);return}const o=new AbortController;e.pendingWait=o;try{const a=await of(r.selectors);if(o.signal.aborted)return;a.scrollIntoView({block:"center"}),Ga(a),r.waitForNavigation?(Qp(a),cf(a,o,t.onNext)):ii(t)}catch(a){if(o.signal.aborted)return;if(a instanceof ds){be(),Kp({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",a)}finally{((i=M.state)==null?void 0:i.pendingWait)===o&&(M.state.pendingWait=null)}}function cf(t,e,n){if(!M.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!M.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function ii(t){var a;const{state:e}=M;if(!e||e.paused)return;const n=T();if(!n)return;const r=U(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(a=e.autoAdvanceAbort)==null||a.abort();const i=new AbortController;e.autoAdvanceAbort=i,(async()=>{const s=[],c=Ws();c&&s.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&s.push(new Promise(l=>{const d=window.setTimeout(()=>{M.state&&M.state.autoAdvanceTimer===d&&(M.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);M.state&&(M.state.autoAdvanceTimer=d),i.signal.addEventListener("abort",()=>{window.clearTimeout(d),l()})})),s.length!==0&&(await Promise.race([Promise.all(s).then(()=>{}),new Promise(l=>{i.signal.aborted?l():i.signal.addEventListener("abort",()=>l(),{once:!0})})]),!i.signal.aborted&&(!M.state||M.state.paused||U()===r&&t.onNext()))})()}function tr(){var e,n;const{state:t}=M;t&&(t.autoAdvanceTimer!==null&&(window.clearTimeout(t.autoAdvanceTimer),t.autoAdvanceTimer=null),(e=t.autoAdvanceAbort)==null||e.abort(),t.autoAdvanceAbort=null,(n=t.pendingWait)==null||n.abort(),t.pendingWait=null,Ei())}const er={onNext:()=>void He(),onExit:()=>void ve()};async function we(t=0,e={}){if(M.state)return;const n=T();if(!n||n.steps.length===0||e.standalone!==!0&&!(await ls(n.id,t,!0)).ok)return;M.state={originalStepIndex:U(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,standalone:e.standalone===!0},D("replay"),Up({onPrev:Dn,onNext:He,onTogglePause:ze,onExit:ve,onStepSelect:o=>void oo(o),onTogglePrompter:()=>void af(),onToggleTts:()=>void lf()}),Zn()&&Pn(!0),tf({onNext:()=>void He(),onPrev:()=>void Dn(),onTogglePause:ze,onExit:()=>void ve()}),M.unsubscribeStep=ye(xe);const r=Math.min(Math.max(0,t),n.steps.length-1);Gt(r),await no(),await Jn(er)}async function ro(t){if(!M.state)return;const e=T();e&&(t<0||t>=e.steps.length||(tr(),Xe(),Ve(),!await nf(e,t)&&(Gt(t),await no(),await Jn(er))))}async function oo(t){t!==U()&&await ro(t)}async function He(){const{state:t}=M;if(!t)return;const e=T();if(!e)return;const n=U();if(n>=e.steps.length-1){tr(),Xe(),Ve(),t.paused=!0,xe(),document.dispatchEvent(new CustomEvent("manuscript:replay-end"));return}await ro(n+1)}async function Dn(){await ro(U()-1)}async function lf(){const t=!await Si();await Us(t),t||Ei(),xe()}function ze(){const{state:t}=M;if(!t)return;const e=T();if(e&&t.paused&&U()>=e.steps.length-1){df();return}t.paused=!t.paused,t.paused?tr():Jn(er),xe()}async function df(){if(!M.state)return;const t=T();!t||!(await ls(t.id,0,!1)).ok||M.state&&(M.state.paused=!1,Gt(0),await no(),await Jn(er))}async function ve(){var r;const{state:t}=M;if(!t)return;tr(),Xe(),Ve(),In(),be(),Gp(),Va(),ef(),(r=M.unsubscribeStep)==null||r.call(M),M.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;M.state=null,Gt(e),D("idle"),await zs(),n&&(es(),Fi())}const uf=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],kt=28,on=4,pf="http://www.w3.org/2000/svg";let j=null,Yt=null,Ie=null;function ff(t,e){nr(),Ie=e,j=document.createElement("div"),j.setAttribute("data-manuscript","ui"),Et(j),j.style.cssText=["position: fixed",`z-index: ${R+5}`,"pointer-events: auto"].join("; "),Yt=j.attachShadow({mode:"open"}),Yt.innerHTML=hf(),mf(),document.body.appendChild(j),ai(t),gf(),requestAnimationFrame(()=>{j&&ai(t)}),document.addEventListener("mousedown",us,!0),document.addEventListener("keydown",ps,!0)}function nr(){j&&(document.removeEventListener("mousedown",us,!0),document.removeEventListener("keydown",ps,!0),j.remove(),j=null,Yt=null,Ie=null)}function hf(){return`
    <style>
      ${wt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${kt+on*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${kt+on*2}px;
        height: ${kt+on*2}px;
        padding: ${on}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function gf(){if(!Yt)return;const t=Yt.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of uf){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(pf,"svg");o.setAttribute("width",String(kt)),o.setAttribute("height",String(kt)),o.setAttribute("viewBox",`0 0 ${kt} ${kt}`);const i=Jr(e,{x:3,y:3,width:kt-6,height:kt-6,fill:"transparent",stroke:"oklch(0.18 0.015 250)",strokeWidth:1.5});i&&o.appendChild(i),r.appendChild(o),t.appendChild(r)}}}function mf(){Yt&&Yt.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(Ie==null||Ie(r),nr())})}function ai(t){if(!j)return;const e=t.getBoundingClientRect();j.style.top="0px",j.style.left="0px";const n=j.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),j.style.top=`${Math.max(8,r)}px`,j.style.left=`${Math.max(8,o)}px`}function us(t){if(!j)return;const e=t.target;e instanceof Node&&j.contains(e)||nr()}function ps(t){t.key==="Escape"&&(t.preventDefault(),nr())}const bf=320,pe=32,vf=.8,Rn=200,k={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null};function On(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function rt(t){return On(t)}function Ot(t,e=!1,n=5e3){const{shadow:r}=k;if(!r)return;const o=r.querySelector('[data-region="toast"]');o&&(o.textContent=t,o.classList.add("visible"),o.classList.toggle("error",e),k.toastTimer!==null&&window.clearTimeout(k.toastTimer),k.toastTimer=window.setTimeout(()=>{o.classList.remove("visible"),k.toastTimer=null},n))}function Nn(t,e,n){return Math.max(e,Math.min(n,t))}let O=null;function yf(t){if(O!==null)return;const e=t.from??3,n=t.tickMs??1e3,r=t.scheduler??wf(),o=document.createElement("div");o.setAttribute("data-manuscript","ui"),o.setAttribute("data-region","countdown"),o.style.cssText=["position: fixed","inset: 0",`z-index: ${R+10}`,"pointer-events: auto"].join("; "),Et(o);const i=o.attachShadow({mode:"open"});i.innerHTML=kf(e),document.body.appendChild(o);const a=i.querySelector('[data-region="number"]'),s=i.querySelector('[data-action="cancel"]'),c=l=>{(l.key==="Escape"||l.key===" "||l.key==="Spacebar")&&(l.preventDefault(),si())};window.addEventListener("keydown",c),s==null||s.addEventListener("click",()=>si()),O={host:o,shadow:i,numberEl:a,scheduler:r,tickMs:n,timerId:null,remaining:e,onComplete:t.onComplete,onCancel:t.onCancel??null,keyListener:c},fs()}function io(){O&&(O.timerId!==null&&O.scheduler.cancel(O.timerId),window.removeEventListener("keydown",O.keyListener),O.host.remove(),O=null)}function fs(){O&&(O.timerId=O.scheduler.schedule(xf,O.tickMs))}function xf(){if(O){if(O.remaining-=1,O.remaining<=0){const t=O.onComplete;io(),t();return}O.numberEl.textContent=String(O.remaining),fs()}}function si(){if(!O)return;const t=O.onCancel;io(),t==null||t()}function wf(){return{schedule(t,e){return window.setTimeout(t,e)},cancel(t){window.clearTimeout(t)}}}function kf(t){return`
    <style>
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .ring {
        width: 220px;
        height: 220px;
        border-radius: 999px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #0a0a0a);
        box-shadow: 0 24px 60px rgb(0 0 0 / 0.35), 0 4px 12px rgb(0 0 0 / 0.20);
        display: grid;
        place-items: center;
        position: relative;
        animation: ring-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes ring-pop {
        from { transform: scale(0.85); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .number {
        font-size: 140px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        font-variant-numeric: tabular-nums;
        animation: digit-pop 200ms ease-out;
      }
      .number[data-changed] { animation: digit-pop 200ms ease-out; }
      @keyframes digit-pop {
        from { transform: scale(1.25); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .caption {
        position: absolute;
        bottom: -52px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 13px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.92);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint {
        position: absolute;
        bottom: -78px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 11px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.62);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid rgb(255 255 255 / 0.35);
        border-radius: 4px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        margin: 0 2px;
      }
      .cancel {
        appearance: none;
        background: rgb(255 255 255 / 0.10);
        color: rgb(255 255 255 / 0.92);
        border: 1px solid rgb(255 255 255 / 0.25);
        border-radius: 999px;
        padding: 6px 14px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        position: absolute;
        bottom: -120px;
        left: 50%;
        transform: translateX(-50%);
        transition: background 120ms ease, border-color 120ms ease;
      }
      .cancel:hover { background: rgb(255 255 255 / 0.20); border-color: rgb(255 255 255 / 0.45); }
    </style>
    <div class="scrim" role="dialog" aria-label="Recording starts soon">
      <div class="ring">
        <span class="number" data-region="number">${t}</span>
        <span class="caption">Recording starts in…</span>
        <span class="hint">During recording: <kbd>Space</kbd> pauses scenario · <kbd>Esc</kbd> stops &amp; saves</span>
        <button type="button" class="cancel" data-action="cancel">Cancel</button>
      </div>
    </div>
  `}let Pe=null;function Sf(t){if(Pe!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-paused-pill"),e.style.cssText=["position: fixed","top: 16px","right: 16px",`z-index: ${R+11}`,"pointer-events: auto"].join("; "),Et(e);const n=e.attachShadow({mode:"open"});n.innerHTML=Ef(),document.body.appendChild(e);const r=n.querySelector('[data-action="resume"]');r==null||r.addEventListener("click",()=>{const o=t.onResume;rr(),o()}),Pe={host:e}}function rr(){Pe&&(Pe.host.remove(),Pe=null)}function Ef(){const t=m("recording.paused-label"),e=m("recording.paused-aria");return`
    <style>
      ${wt()}
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .pill {
        appearance: none;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px 6px 10px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #111);
        border: 1px solid var(--c-border, #d9dee5);
        border-radius: 999px;
        box-shadow: 0 6px 18px rgb(0 0 0 / 0.18), 0 1px 4px rgb(0 0 0 / 0.10);
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 0.02em;
        opacity: 0.7;
        cursor: pointer;
        transition: opacity 120ms ease, filter 120ms ease;
      }
      .pill:hover {
        opacity: 1;
        filter: brightness(0.98);
      }
      .dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: var(--c-error, #c52a2a);
        flex-shrink: 0;
        animation: rec-blink 1s ease-in-out infinite;
      }
      @keyframes rec-blink {
        0%, 100% { opacity: 1; }
        50%      { opacity: 0.2; }
      }
      .label { line-height: 1.2; white-space: nowrap; }
    </style>
    <button type="button" class="pill" data-action="resume" aria-label="${e}" title="${e}">
      <span class="dot" aria-hidden="true"></span>
      <span class="label">${t}</span>
    </button>
  `}function Af(t,e=n=>MediaRecorder.isTypeSupported(n)){for(const n of t)if(e(n))return n;throw new Error(`No supported MIME type for screen recording (tried: ${t.join(", ")})`)}function Mf(t,e){const{factory:n,mimeType:r,timesliceMs:o}=e,i=n.create(t,{mimeType:r}),a=[];let s=!1,c=null;i.ondataavailable=f=>{f.data&&f.data.size>0&&a.push(f.data)};function l(){if(s)throw new Error("Recorder handle is single-use; create a new one.");s=!0,o!==void 0?i.start(o):i.start()}function d(){return c?Promise.reject(new Error("stop() already called")):(c=new Promise((f,u)=>{i.onstop=()=>{const p=new Blob(a,{type:r});f({blob:p,size:p.size,mimeType:r})},i.onerror=p=>{const h=p.error;u(new Error((h==null?void 0:h.message)??"MediaRecorder error"))},i.stop()}),c)}return{start:l,stop:d}}function $f(t){let e="idle";function n(){var o;e==="idle"&&(t.isStandalonePlayback()||(e="counting-down",(o=t.onRecordingStarting)==null||o.call(t),t.mountCountdown({onComplete:()=>{var i;e="recording",(i=t.onRecordingStarted)==null||i.call(t),t.sendMessage({type:"recording.fire"}).catch(()=>{var a;e="idle",(a=t.onRecordingStopped)==null||a.call(t)})},onCancel:()=>{var i;e="idle",(i=t.onRecordingStopped)==null||i.call(t),t.sendMessage({type:"recording.stop"}).catch(()=>{})}})))}async function r(){var o,i;if(e!=="idle"){if(e==="counting-down"){t.unmountCountdown(),e="idle",(o=t.onRecordingStopped)==null||o.call(t);return}try{await t.sendMessage({type:"recording.stop"})}finally{e="idle",(i=t.onRecordingStopped)==null||i.call(t)}}}return{startRecording:n,stopRecording:r,isRecording:()=>e==="recording",getPhase:()=>e}}const ci="Created with Manuscript",Lf=12,Tf=500,Pr=14,li=10,Cf=6,di=24,If=.7;function Pf(t,e,n,r){t.save(),t.globalAlpha=If,t.fillStyle="#fff",t.font=`${Tf} ${Lf}px "Pretendard Variable", Pretendard, system-ui, sans-serif`,t.textAlign="right",t.textBaseline="bottom",t.shadowColor="rgba(0, 0, 0, 0.85)",t.shadowBlur=3,t.shadowOffsetX=0,t.shadowOffsetY=1;const o=n-di,i=r-di;t.fillText(ci,o,i);const a=t.measureText(ci).width,s=o-a-Cf-li,c=i-Pr;t.drawImage(e,s,c,li,Pr),t.restore()}async function Df(){const t=ki({height:Pr,color:"#ffffff"}),e=`data:image/svg+xml;utf8,${encodeURIComponent(t)}`,n=new Image;return n.src=e,await n.decode(),n}const Rf=["video/webm;codecs=vp9,opus","video/webm;codecs=vp9","video/webm;codecs=vp8,opus","video/webm;codecs=vp8","video/webm"];let hn=null,De=!1,_t=null,Ae=null,Me=null,$e=null,Le=null,ee=null,Te=null,Dr=!1,Fn=null,ao=null,so=null,fe=null;async function Of(t={}){if(Ue()||_t)return!1;De=t.keepUiVisible===!0;let e;try{e=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,preferCurrentTab:!0,selfBrowserSurface:"include"})}catch(g){return console.warn("[manuscript/recording] tab share failed:",g),!1}let n=null;try{n=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,systemAudio:"include"}),n.getVideoTracks().forEach(g=>g.stop()),console.info("[manuscript/recording] step 2 OK — system audio acquired, video track dropped",{audioTracks:n.getAudioTracks().length})}catch(g){console.warn("[manuscript/recording] step 2 rejected:",g instanceof Error?`${g.name}: ${g.message}`:g),Ot("System audio not shared — TTS narration will be silent in the video.")}let r=null;if(t.withMicrophone)try{r=await navigator.mediaDevices.getUserMedia({audio:!0}),console.info("[manuscript/recording] microphone acquired",{audioTracks:r.getAudioTracks().length})}catch(g){console.warn("[manuscript/recording] microphone acquisition failed:",g instanceof Error?`${g.name}: ${g.message}`:g),Ot(m("recording.mic-failed"))}let o=null,i=null;const a=e.getAudioTracks().length>0,s=((n==null?void 0:n.getAudioTracks().length)??0)>0,c=((r==null?void 0:r.getAudioTracks().length)??0)>0;if(a||s||c){i=new AudioContext;const g=i.createMediaStreamDestination();a&&i.createMediaStreamSource(new MediaStream(e.getAudioTracks())).connect(g),s&&n&&i.createMediaStreamSource(new MediaStream(n.getAudioTracks())).connect(g),c&&r&&i.createMediaStreamSource(new MediaStream(r.getAudioTracks())).connect(g),o=g.stream.getAudioTracks()[0]??null}let l=null;try{const g=await Nf(e);ee=g.videoEl,Te=g.canvasStream,l=g.videoTrack}catch(g){console.warn("[manuscript/recording] watermark compositor failed; falling back to raw tab video:",g)}const d=l?[l]:[...e.getVideoTracks()];o&&d.push(o);const f=new MediaStream(d);Ae=e,Me=n,$e=r,Le=i,_t=f;const u=e.getVideoTracks()[0],p=u&&typeof u.getSettings=="function"?u.getSettings():null,h=(p==null?void 0:p.displaySurface)??"(unknown)";console.info("[manuscript/recording] capture stream info",{displaySurface:h,tabAudioTracks:e.getAudioTracks().length,systemAudioTracks:(n==null?void 0:n.getAudioTracks().length)??0,microphoneTracks:(r==null?void 0:r.getAudioTracks().length)??0,mergedAudioTrack:!!o});const b=()=>{const g=hn;g&&g.getPhase()!=="idle"&&g.stopRecording()};return u&&u.addEventListener("ended",b),n==null||n.getAudioTracks().forEach(g=>g.addEventListener("ended",b)),r==null||r.getAudioTracks().forEach(g=>g.addEventListener("ended",b)),qf().startRecording(),!0}async function Nf(t){const e=document.createElement("video");e.muted=!0,e.playsInline=!0,e.setAttribute("data-manuscript","ui"),e.style.cssText="position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;",document.body.appendChild(e),e.srcObject=new MediaStream(t.getVideoTracks()),await e.play();const n=t.getVideoTracks()[0],r=(n==null?void 0:n.getSettings())??{},o=(typeof r.width=="number"?r.width:void 0)??e.videoWidth??1280,i=(typeof r.height=="number"?r.height:void 0)??e.videoHeight??720,a=document.createElement("canvas");a.width=o,a.height=i;const s=a.getContext("2d");if(!s)throw new Error("2D canvas context unavailable");const c=await Df();Dr=!0;const l=()=>{if(!Dr)return;s.drawImage(e,0,0,a.width,a.height),Pf(s,c,a.width,a.height);const u=e.requestVideoFrameCallback;typeof u=="function"?u.call(e,l):requestAnimationFrame(l)};l();const d=a.captureStream(),f=d.getVideoTracks()[0];if(!f)throw new Error("canvas.captureStream produced no video track");return{videoEl:e,canvasStream:d,videoTrack:f}}function Ff(t){fe||(fe=e=>{const n=e.target;if(!(n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement||n instanceof HTMLElement&&n.isContentEditable)){if(e.key===" "||e.key==="Spacebar"){e.preventDefault(),e.stopPropagation(),hs();return}if(e.key==="Escape"){e.preventDefault(),e.stopPropagation(),rr(),t.stop();return}}},window.addEventListener("keydown",fe,!0))}function Hf(){fe&&(window.removeEventListener("keydown",fe,!0),fe=null)}function hs(){var e;if(!it())return;ze(),((e=M.state)==null?void 0:e.paused)===!0?Sf({onResume:hs}):rr()}function zf(t){let e;try{e=Af(Rf)}catch(n){return console.warn("[manuscript/recording] no supported mime:",n),null}return ao=e,console.info("[manuscript/recording] using mimeType",e,{streamAudioTracks:t.getAudioTracks().length,streamVideoTracks:t.getVideoTracks().length}),Mf(t,{factory:{create:(n,r)=>new MediaRecorder(n,r)},mimeType:e,timesliceMs:1e3})}function _f(t,e){const n=new Date(t),r=a=>String(a).padStart(2,"0"),o=`${n.getFullYear()}${r(n.getMonth()+1)}${r(n.getDate())}-${r(n.getHours())}${r(n.getMinutes())}`,i=e.includes("webm")?"webm":"video";return`manuscript-recording-${o}.${i}`}function Hn(){Dr=!1,_t==null||_t.getTracks().forEach(t=>t.stop()),Te==null||Te.getTracks().forEach(t=>t.stop()),Ae==null||Ae.getTracks().forEach(t=>t.stop()),Me==null||Me.getTracks().forEach(t=>t.stop()),$e==null||$e.getTracks().forEach(t=>t.stop()),Le==null||Le.close().catch(()=>{}),ee&&(ee.pause(),ee.srcObject=null,ee.remove()),_t=null,Ae=null,Me=null,$e=null,Le=null,ee=null,Te=null,Fn=null,ao=null,so=null,De=!1}async function Bf(){const t=Fn;if(!t){Hn();return}try{const e=await t.stop(),n=URL.createObjectURL(e.blob),r=_f(so??Date.now(),ao??"video/webm");try{await chrome.runtime.sendMessage({type:"recording.download",url:n,filename:r})}catch(o){console.warn("[manuscript/recording] download forward failed:",o)}}catch(e){console.warn("[manuscript/recording] recorder.stop failed:",e)}finally{Hn()}}function qf(){if(!hn){const t=$f({mountCountdown:yf,unmountCountdown:io,sendMessage:async()=>{},isStandalonePlayback:Ue,onRecordingStarting:()=>{if(De){sn()&&mi(!0);return}sn()&&gi(!0),vr(!0)},onRecordingStarted:()=>{Ff({stop:()=>void t.stopRecording()}),De||vr(!0);const e=_t;if(e){const n=zf(e);if(n){Fn=n,so=Date.now();try{n.start()}catch(r){console.warn("[manuscript/recording] recorder start failed:",r),Hn();return}}}!it()&&T()&&we(0)},onRecordingStopped:()=>{Hf(),rr(),De?sn()&&mi(!1):(vr(!1),sn()&&gi(!1)),it()&&ve(),Fn?Bf():Hn()}});hn=t,document.addEventListener("manuscript:replay-end",()=>{t.getPhase()==="recording"&&t.stopRecording()}),at(e=>{e.prev==="replay"&&e.next!=="replay"&&t.getPhase()==="recording"&&t.stopRecording()})}return hn}const jf="/assets/share-step-1-B4IYEXR4.png",Wf="/assets/share-step-2-B99Thpfo.png",Uf=chrome.runtime.getURL(jf.replace(/^\/+/,"")),Xf=chrome.runtime.getURL(Wf.replace(/^\/+/,""));let ie=null;function Vf(t){var a,s,c;if(ie!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-guide"),e.style.cssText=["position: fixed","inset: 0",`z-index: ${R+12}`,"pointer-events: auto"].join("; "),Et(e);const n=e.attachShadow({mode:"open"});n.innerHTML=Yf(),document.body.appendChild(e);function r(l){var d;ui(),(d=t.onCancel)==null||d.call(t)}function o(){var f,u;const l=((f=n.querySelector('[data-action="keep-ui"]'))==null?void 0:f.checked)===!0,d=((u=n.querySelector('[data-action="with-mic"]'))==null?void 0:u.checked)===!0;ui(),t.onStart({keepUiVisible:l,withMicrophone:d})}(a=n.querySelector('[data-action="start"]'))==null||a.addEventListener("click",o),(s=n.querySelector('[data-action="cancel"]'))==null||s.addEventListener("click",()=>r()),(c=n.querySelector('[data-action="scrim-close"]'))==null||c.addEventListener("click",l=>{l.target===l.currentTarget&&r()});const i=l=>{l.key==="Escape"&&(l.preventDefault(),r())};window.addEventListener("keydown",i),ie={host:e,keyListener:i}}function ui(){ie&&(window.removeEventListener("keydown",ie.keyListener),ie.host.remove(),ie=null)}function Yf(){return`
    <style>
      ${wt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .card {
        width: min(700px, calc(100vw - 48px));
        max-height: calc(100vh - 48px);
        overflow: auto;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        animation: card-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes card-pop {
        from { transform: scale(0.96); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .head {
        padding: 22px 28px 8px;
      }
      .title {
        font-size: 19px;
        font-weight: 600;
        margin: 0 0 8px;
      }
      .subtitle {
        font-size: 13px;
        color: var(--c-text-mute, #555);
        margin: 0;
        line-height: 1.5;
      }
      .steps {
        padding: 12px 28px 8px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      .step {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .step-head {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .step-badge {
        width: 26px;
        height: 26px;
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
        display: grid;
        place-items: center;
        flex-shrink: 0;
      }
      .step-title {
        font-size: 14px;
        font-weight: 600;
      }
      .step-img {
        width: 100%;
        height: auto;
        border: 1px solid var(--c-border, #ddd);
        border-radius: 8px;
        background: var(--c-surface-2, #f6f7f8);
        display: block;
      }
      .step-desc {
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
        margin: 0;
      }
      .step-desc ol {
        margin: 0 0 8px;
        padding-left: 18px;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .step-desc ol li {
        padding-left: 2px;
      }
      .step-desc p {
        margin: 6px 0 0;
      }
      .step-desc kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .options {
        padding: 4px 28px 0;
      }
      .opt-row {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.45;
        cursor: pointer;
        user-select: none;
        padding: 6px 8px;
        border-radius: 6px;
        transition: background 0.12s ease;
      }
      .opt-row + .opt-row { margin-top: 2px; }
      .opt-row:hover { background: var(--c-surface-2, #f6f7f8); }
      .opt-row input {
        margin: 2px 0 0;
        accent-color: var(--c-primary, #1a73e8);
      }
      .opt-row .opt-label { font-weight: 500; color: var(--c-text); }
      .opt-row .opt-hint { display: block; margin-top: 1px; }
      .keys-info {
        padding: 10px 28px 0;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
      }
      .keys-info kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .actions {
        padding: 12px 28px 22px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .btn {
        appearance: none;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 18px;
        border-radius: 999px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: filter 0.12s ease, background 0.12s ease;
      }
      .btn-ghost {
        background: transparent;
        color: var(--c-text-mute, #555);
        border-color: var(--c-border-strong, #d2d6dc);
      }
      .btn-ghost:hover { color: var(--c-text, #111); }
      .btn-primary {
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
      }
      .btn-primary:hover { filter: brightness(1.06); }
    </style>
    <div class="scrim" data-action="scrim-close" role="dialog" aria-modal="true" aria-labelledby="rec-guide-title">
      <div class="card">
        <div class="head">
          <h2 id="rec-guide-title" class="title">${m("recording.guide.title")}</h2>
          <p class="subtitle">${m("recording.guide.subtitle")}</p>
        </div>
        <div class="steps">
          <div class="step">
            <div class="step-head">
              <div class="step-badge">1</div>
              <div class="step-title">${m("recording.guide.step1-title")}</div>
            </div>
            <img src="${Uf}" alt="${m("recording.guide.step1-alt")}" class="step-img" />
            <div class="step-desc">${m("recording.guide.step1-desc-html")}</div>
          </div>
          <div class="step">
            <div class="step-head">
              <div class="step-badge">2</div>
              <div class="step-title">${m("recording.guide.step2-title")}</div>
            </div>
            <img src="${Xf}" alt="${m("recording.guide.step2-alt")}" class="step-img" />
            <div class="step-desc">${m("recording.guide.step2-desc-html")}</div>
          </div>
        </div>
        <div class="options">
          <label class="opt-row">
            <input type="checkbox" data-action="keep-ui" />
            <span>
              <span class="opt-label">${m("recording.guide.keep-ui-label")}</span>
              <span class="opt-hint">${m("recording.guide.keep-ui-hint")}</span>
            </span>
          </label>
          <label class="opt-row">
            <input type="checkbox" data-action="with-mic" />
            <span>
              <span class="opt-label">${m("recording.guide.mic-label")}</span>
              <span class="opt-hint">${m("recording.guide.mic-hint")}</span>
            </span>
          </label>
        </div>
        <div class="keys-info" data-region="keys-info">
          ${m("recording.guide.keys-info-html")}
        </div>
        <div class="actions">
          <button type="button" class="btn btn-ghost" data-action="cancel">
            ${m("recording.guide.cancel")} <kbd>Esc</kbd>
          </button>
          <button type="button" class="btn btn-primary" data-action="start">
            ${m("recording.guide.start")}
          </button>
        </div>
      </div>
    </div>
  `}function Gf(){const t=T();if(t)try{const e=_s(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Qf(t.name)}-${Jf(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),Ot(m("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),Ot(m("toast.export-failed"),!0)}}async function Kf(){const t=T();if(t){if(t.steps.length===0){Ot(m("toast.no-steps"),!0);return}sa(),await we(0,{paused:!0})}}function Zf(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Bs(r);Ni(o),Ot(m("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),Ot(m("toast.import-failed"),!0)}}),t.click()}function Qf(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Jf(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function or(t){const e=T(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!th(n.pickedAtUrl,location.href)?(gs(n.pickedAtUrl,t),!0):!1}function Re(){const t=T();if(!t)return;const e=U(),n=t.steps[e],r=t.steps[e+1];Ya({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function th(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function gs(t,e){const n=T();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let zn=!1,ms=0,bs=0,Rr=0,Or=0;function eh(){const{shadow:t}=k;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=k;if(!o)return;zn=!0,ms=n.clientX,bs=n.clientY;const i=o.getBoundingClientRect();Rr=i.left,Or=i.top,o.style.left=`${Rr}px`,o.style.top=`${Or}px`,o.style.right="auto",document.addEventListener("mousemove",vs,!0),document.addEventListener("mouseup",ys,!0),n.preventDefault()})}function vs(t){const{host:e}=k;if(!zn||!e)return;const n=t.clientX-ms,r=t.clientY-bs,o=e.offsetWidth,i=e.offsetHeight,a=Nn(Rr+n,0,window.innerWidth-o),s=Nn(Or+r,0,window.innerHeight-i);e.style.left=`${a}px`,e.style.top=`${s}px`}function ys(){zn&&(zn=!1,document.removeEventListener("mousemove",vs,!0),document.removeEventListener("mouseup",ys,!0))}let _n=!1,xs=0,ws=0;function nh(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=k;r&&(_n=!0,xs=n.clientY,ws=r.getBoundingClientRect().height,document.addEventListener("mousemove",ks,!0),document.addEventListener("mouseup",Ss,!0),n.preventDefault(),n.stopPropagation())})}function ks(t){const{host:e}=k;if(!_n||!e)return;const n=t.clientY-xs,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-pe,i=Nn(ws+n,Rn,o);e.style.height=`${i}px`,e.style.maxHeight=`${i}px`}function Ss(){_n&&(_n=!1,document.removeEventListener("mousemove",ks,!0),document.removeEventListener("mouseup",Ss,!0))}function rh(t){const e=window.innerHeight-pe*2;return Nn(t,Rn,Math.max(Rn,e))}function Es(){const{host:t}=k;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-pe;if(e.bottom>n){const o=Math.max(Rn,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),i=window.innerWidth-r.width;o>i&&(t.style.left=`${Math.max(0,i)}px`)}if(t.style.top){const o=parseFloat(t.style.top),i=window.innerHeight-r.height;o>i&&(t.style.top=`${Math.max(0,i)}px`)}}function co(){var t;return((t=k.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function As(){var t;return((t=k.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function oh(){const t=co();t&&(t.hidden?(ih(),t.hidden=!1):t.hidden=!0)}function Ms(){const t=co();t&&(t.hidden=!0)}async function ih(){const t=As();if(!t)return;await Vs();const e=Ys(),n=await Gs(),r=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const i of e){const a=i.name===n?" selected":"";o.push(`<option value="${r(i.name)}"${a}>${r(i.name)} (${r(i.lang)})</option>`)}t.innerHTML=o.join("")}function ah(){var n;const t=As();t&&t.addEventListener("change",()=>{const r=t.value;Xs(r.length>0?r:null)});const e=(n=k.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>Ms())}function sh(t){var o;const e=co();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=k.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Ms()}function Wt(t){const e=t===U();Gt(t),e&&$s()}function $s(){const t=st();if(!(t!=null&&t.selectors)){be();return}const e=Oe(t.selectors);e?(e.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),Ga(e)):be()}function pi(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function lo(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function ch(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function lh(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function dh(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function uh(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function ph(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function fh(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=T(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));Wt(l)}const i=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${i}" aria-label="Auto-advance seconds" />
    ${lo(10)}
  `;const a=t.querySelector("input");if(!a)return;a.focus(),a.select();const s=l=>{if(t.classList.remove("editing"),l){fi(t,i);return}const d=a.value.trim();let f=5;if(d===""||d==="0")se(r.id,{autoAdvanceMs:null});else{const u=Number(d);Number.isFinite(u)&&u>0?(se(r.id,{autoAdvanceMs:Math.round(u*1e3)}),f=u):se(r.id,{autoAdvanceMs:null})}fi(t,f)};a.addEventListener("blur",()=>s(!1)),a.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),a.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),a.addEventListener("mousedown",l=>l.stopPropagation())}function fi(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${lo(10)}
  `}function hh(t,e){const{shadow:n,host:r}=k;if(!n||!r)return;eh(),nh(),vh(),ah(),document.addEventListener("mousedown",sh,!0);const o=i=>i.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",i=>gh(i,t,e))}function gh(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="palette-toggle"]')){t.stopPropagation(),nc();return}if(o.closest('[data-action="recording-toggle"]')){t.stopPropagation(),mh();return}if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void Kf();if(o.closest('[data-action="prompter"]')){n(!0),Xa().then(()=>{Re()});return}if(o.closest('[data-action="export"]'))return Gf();if(o.closest('[data-action="import"]'))return Zf();if(o.closest('[data-action="settings-toggle"]'))return oh();const i=o.closest('[data-action="tool-set"]');if(i instanceof HTMLElement){t.stopPropagation();const s=i.getAttribute("data-tool");if(s==="shape"){ff(i,c=>{$u(c),D("shape")});return}D(xt()===s?"idle":s);return}if(bh(t,o))return;const a=o.closest("[data-step-card]");if(a&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(a.getAttribute("data-step-card"));if(or(s))return;Wt(s)}}async function mh(){const t=T(),e=t?ss(t):"";if(e&&!eo(e,location.href)){const n=await cs(e);if(n==="cancel")return;if(n==="navigate"){location.href=e;return}}Vf({onStart:({keepUiVisible:n,withMicrophone:r})=>{Of({keepUiVisible:n,withMicrophone:r}).then(o=>{o||Ot("Recording cancelled or unsupported.")})}})}function bh(t,e){var c;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const l=Number(n.getAttribute("data-insert-index"));return wo({insertIndex:l}),!0}if(e.closest('[data-action="step-add"]'))return wo(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const l=Number(r.getAttribute("data-step-index"));return or(l)||(Wt(l),D(xt()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),Tc(Number(o.getAttribute("data-step-index"))),!0;const i=e.closest('[data-action="step-link"]');if(i){t.stopPropagation();const l=i.getAttribute("data-url")??"",d=i.closest("[data-step-card]"),f=d?Number(d.getAttribute("data-step-card")):0;return l&&gs(l,Number.isFinite(f)?f:0),!0}const a=e.closest('[data-action="step-action-toggle"]');if(a instanceof HTMLElement){t.stopPropagation();const l=Number(a.getAttribute("data-step-index")),d=(c=T())==null?void 0:c.steps[l];return d&&(Wt(l),se(d.id,{waitForNavigation:!d.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');return s instanceof HTMLElement?(t.stopPropagation(),s.classList.contains("disabled")||fh(s),!0):!1}function vh(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>Nr(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=T();r&&(e.textContent=r.name),Nr(e),e.blur()}}),e.addEventListener("blur",()=>{$c(e.textContent??"")}))}function Nr(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const yh='[data-manuscript="ui"][data-region="permission-banner"]';function Ls(){return document.querySelector(yh)}function xh(t){const e=Ls();if(e){Cs(e,t);return}wh(t)}function Ts(){const t=Ls();t&&t.remove()}function Cs(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function wh(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),Et(e),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${R+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=kh(),Cs(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>Ts()),document.body.appendChild(e)}function kh(){return`
    <style>
      ${wt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const an=16,Sh=240,Eh=/permission|<all_urls>|activeTab/i;async function Ah(t){const e=Mh({x:t.x-an,y:t.y-an,width:t.width+an*2,height:t.height+an*2});if(e.width<=0||e.height<=0)return null;const n=await $h();if(!n.ok)return Eh.test(n.error)?xh(m("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await Ch(n.dataUrl,e,Sh)}catch(r){return console.error("[manuscript] crop failed",r),null}}function Mh(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function $h(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await Th();try{return{ok:!0,dataUrl:await Lh()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function Lh(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function Th(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function Ch(t,e,n){const r=await Ih(t),o=r.naturalWidth/window.innerWidth||1,i=e.x*o,a=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),d=Math.max(1,Math.round(e.width*l)),f=Math.max(1,Math.round(e.height*l)),u=document.createElement("canvas");u.width=d,u.height=f;const p=u.getContext("2d");if(!p)throw new Error("No 2d context");return p.drawImage(r,i,a,s,c,0,0,d,f),u.toDataURL("image/png")}function Ih(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function Is(t){const e=t.detail;Ic(e.chain);const n=Ph(e.rect,e.chain.framePath);Dh(n)}function Ph(t,e){if(!e||e.length===0)return t;const n=nl(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function Dh(t){try{const e=await Ah(t);Lc(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}function Rh(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Record button — same primary fill as play / prompter so the
         footer trio reads as one cluster (the design-system way of
         saying "these are the three CTAs"). The red dot icon is the
         only theme-independent piece — it carries the "record"
         affordance without making the whole button red at rest.
         Pressed flips to var(--c-error) + stop square + pulse halo so
         the recording state is unmistakable. Hidden during bridge
         standalone sessions; that branch is enforced at the controller
         layer. */
      .record-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        /* Record dot reads as an activity indicator, not an error
           state, so brighten --c-error locally with a 22% white mix.
           Stays palette-aware (light/dark both shift together) without
           touching the global error token or its other consumers. */
        color: color-mix(in oklch, var(--c-error), white 22%);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease, color 160ms ease;
      }
      .record-btn:hover { background: var(--c-primary-h); }
      .record-btn .record-stop { display: none; }
      .record-btn[aria-pressed="true"] {
        background: var(--c-error);
        color: var(--c-primary-fg);
        animation: record-pulse 1.6s ease-in-out infinite;
      }
      .record-btn[aria-pressed="true"] .record-dot { display: none; }
      .record-btn[aria-pressed="true"] .record-stop { display: inline-block; }
      @keyframes record-pulse {
        0%, 100% { box-shadow: 0 0 0 0 color-mix(in oklch, var(--c-error), transparent 60%); }
        50%      { box-shadow: 0 0 0 6px color-mix(in oklch, var(--c-error), transparent 100%); }
      }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
        /* Sit above the footer chrome (play-btn / record-btn / icon-btn
           / settings-popup at z-index 4) so the toast isn't clipped by
           those siblings. */
        z-index: 10;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Oh(){return`
      ${wt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .palette-toggle {
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        color: var(--c-text-mute);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: border-color 160ms ease, color 160ms ease;
      }
      .palette-toggle:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .palette-toggle:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
      }
      .palette-toggle .palette-sun { display: none; }
      .palette-toggle .palette-moon { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-sun { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-moon { display: none; }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Nh(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -1px;
        left: 3px;
        font-family: var(--ff-mono);
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 1px 3px;
        border-radius: 2px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

  `}function Fh(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Hh(){return[Oh(),Nh(),Fh(),Rh()].join(`
`)}function zh(){return`
    <style>${Hh()}</style>
    <div class="panel" role="region" aria-label="${m("panel.aria.region")}">
      ${_h()}
      ${Bh()}
      <div class="body" data-region="steps"></div>
      ${qh()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${m("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function _h(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${ki({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <div class="header-actions">
          <button type="button" class="palette-toggle" data-action="palette-toggle" data-region="palette-toggle" aria-label="${m("panel.palette-toggle-aria")}" aria-pressed="false" title="${m("panel.palette-toggle-aria")}">
            <svg class="palette-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <circle cx="8" cy="8" r="3"></circle>
              <path d="M8 1.2v1.6M8 13.2v1.6M14.8 8h-1.6M2.8 8H1.2M12.8 3.2l-1.13 1.13M4.33 11.67l-1.13 1.13M12.8 12.8l-1.13-1.13M4.33 4.33L3.2 3.2"></path>
            </svg>
            <svg class="palette-moon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path d="M6.5 1.5a6.5 6.5 0 1 0 8 8 5.4 5.4 0 0 1-8-8z"></path>
            </svg>
          </button>
          <button type="button" class="close-btn" data-action="close" aria-label="${m("panel.close-aria")}">×</button>
        </div>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${m("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Bh(){return`
    <div class="tool-bar" role="toolbar" aria-label="${m("panel.tool-label")}">
      <span class="eyebrow">${m("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${m("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${m("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${m("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function qh(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${m("panel.replay-aria")}" title="${m("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${m("panel.prompter-aria")}" title="${m("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
        <button type="button" class="record-btn" data-action="recording-toggle" data-region="record-btn" aria-pressed="false" aria-label="${m("panel.record-aria")}" title="${m("panel.record-aria")}">
          <svg class="record-dot" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="8" cy="8" r="5"/></svg>
          <svg class="record-stop" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="10" height="10" rx="1"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${m("panel.import-aria")}" title="${m("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${m("panel.export-aria")}" title="${m("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${m("panel.settings-aria")}" title="${m("panel.settings.title")}" data-region="settings-toggle">
          ${ph(16)}
        </button>
      </div>
      ${jh()}
    </div>
  `}function jh(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${m("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${m("panel.settings.close-aria")}" title="${m("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${m("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${m("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function Wh(t){const e=t.pickedAtUrl;return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${rt(e)}"
        aria-label="Open ${rt(e)}"
      >${uh(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${On(e)}</span>
    </div>
  `:""}function Uh(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,i=t.thumbnailDataUrl!==null,a=n&&xt()==="picker",s="step-thumb"+(o?" has-element":"")+(a?" is-picking":""),c=i?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,d=t.waitForNavigation;return r.innerHTML=`
    <button
      type="button"
      class="${s}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${rt(m("step.wand-aria",{n:e+1}))}"
      title="${rt(m("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!i?`<span class="step-thumb-icon">${dh(18)}</span>`:""}
      ${!o&&!i?'<span class="step-thumb-plus">+</span>':""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${rt(m("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${On(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${rt(m("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${On(t.description)}</div>
    </div>
    ${Wh(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${d}" aria-label="${rt(m("step.action-aria"))}" title="${rt(m("step.action-aria"))}">${lh(10)}</button>
      <div class="step-timer${d?" disabled":""}" data-action="step-timer" data-step-id="${rt(t.id)}" title="${rt(m("step.timer-aria"))}" ${d?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${lo(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${rt(m("step.delete-aria"))}" title="${rt(m("step.delete-aria"))}">${ch(12)}</button>
    </div>
  `,r}function Xh(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function Vh(t,e,n){hi(t,"step-name",n,r=>se(e.id,{name:r})),hi(t,"step-desc",n,r=>se(e.id,{description:r}),{escapeBlurs:!0}),Yh(t,n)}function hi(t,e,n,r,o={}){const i=t.querySelector(`[data-region="${e}"]`);i&&(i.addEventListener("input",()=>Xh(i)),i.addEventListener("focus",()=>{or(n)||Gt(n)}),i.addEventListener("mousedown",a=>a.stopPropagation()),i.addEventListener("blur",()=>r(i.textContent??"")),i.addEventListener("keydown",a=>{(a.key==="Enter"&&e==="step-name"||a.key==="Escape"&&o.escapeBlurs)&&(a.preventDefault(),i.blur())}))}function Yh(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}k.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),k.dragFromIndex=null,(n=k.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{k.dragFromIndex===null||k.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(k.dragFromIndex===null||k.dragFromIndex===e)&&(Cc(k.dragFromIndex,e),k.dragFromIndex=null)})}function Gh(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=T();if(e.innerHTML="",!n)return;const r=U();n.steps.forEach((i,a)=>{if(a>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(a)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${a+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${a}" aria-label="Insert step here">
          ${pi(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=Uh(i,a,r===a);e.appendChild(s),Vh(s,i,a)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${pi(10,1.8)}
    </button>
  `,e.appendChild(o)}function sn(){return k.host!==null}function Ps(t){const{host:e}=k;e&&(e.dataset.promptedHidden=t?"1":"",uo(e))}function gi(t){const{host:e}=k;e&&(e.dataset.recordingHidden=t?"1":"",uo(e))}function mi(t){const{host:e}=k;e&&(e.dataset.tutorialRecording=t?"1":"",uo(e))}function uo(t){const e=xt(),n=t.dataset.promptedHidden==="1",r=t.dataset.recordingHidden==="1",o=t.dataset.tutorialRecording==="1",i=e==="replay"&&!o;t.style.display=i||n||r?"none":""}async function Bn(t){if(k.host){t&&await xo(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),Et(e);const n=rh(window.innerHeight*vf);e.style.cssText=["position: fixed",`top: ${pe}px`,`right: ${pe}px`,`width: ${bf}px`,`height: ${n}px`,`max-height: calc(100vh - ${pe*2}px)`,`z-index: ${R+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=zh(),k.host=e,k.shadow=r,hh(Ds,Ps),document.body.appendChild(e),t&&await xo(t)||yo(),ts(),document.addEventListener(je,Is),window.addEventListener("resize",Es),k.unsubscribeMode=at(yr),k.unsubscribeScenario=ye(yr),yr();const o=T();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(i){console.warn("[manuscript] markActive failed",i)}}function Ds(){var e,n;const{host:t}=k;t&&(document.removeEventListener(je,Is),window.removeEventListener("resize",Es),(e=k.unsubscribeMode)==null||e.call(k),k.unsubscribeMode=null,(n=k.unsubscribeScenario)==null||n.call(k),k.unsubscribeScenario=null,D("idle"),be(),sa(),es(),Fi(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),k.host=null,k.shadow=null)}function yr(){const{host:t,shadow:e}=k;if(!e||!t)return;const n=xt(),r=t.dataset.promptedHidden==="1",o=t.dataset.recordingHidden==="1",i=t.dataset.tutorialRecording==="1",a=n==="replay"&&!i;t.style.display=a||r||o?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(l=>{const d=l.getAttribute("data-tool");l.setAttribute("aria-pressed",String(d===n))});const s=T(),c=e.querySelector('[data-region="title-edit"]');c&&s&&c!==e.activeElement&&(c.textContent!==s.name&&(c.textContent=s.name),Nr(c)),Gh(),$s(),Zn()&&!it()&&Re()}function Kh(t,e,n){switch(t.type){case"panel.open":return Bn(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return Ds(),n({ok:!0}),!1;case"scenario.replay":return Bn(t.scenarioId).then(()=>we(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return Zh(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return Ju(),it()&&ve(),sf(),Ps(!1),n({ok:!0}),!1}return!1}function Zh(t,e){if(it()){t==="prev"?Dn():t==="next"?He():t==="jump"&&typeof e=="number"?oo(e):t==="pause"&&ze();return}const n=T();if(!n)return;const r=U();if(t==="prev")r>0&&Wt(r-1),Re();else if(t==="next")r<n.steps.length-1&&Wt(r+1),Re();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(or(e))return;Wt(e)}Re()}else t==="pause"&&we(r)}async function Qh(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Jh(){try{const t=await wi();if(!t)return;if(tg()){await chrome.storage.local.remove(X.activeReplay);return}D("replay"),await Bn(t.scenarioId),await we(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function tg(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function eg(){try{const t=await Qh();if(!t)return;await Bn(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Gt(t.stepIndex)}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const ng="manuscript:host",rg="manuscript:ext",og="manuscript:ready";let bi=!1;function ig(){bi||(window.addEventListener("message",sg),bi=!0,at(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Ht("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(og)))}function ag(t){return typeof t=="object"&&t!==null&&t.source===ng&&typeof t.type=="string"}function Ht(t,e,n){const r={source:rg,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function sg(t){const e=t.data;if(ag(e))switch(e.type){case"ping":Ht("pong",e.requestId,{version:lg()});return;case"load":try{const n=cg(e.scenario);Ni(n),Ht("load-ack",e.requestId,{ok:!0})}catch(n){Ht("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!$p()&&ts(),Ht("play-ack",e.requestId,{ok:!0}),we(r,{paused:o,standalone:n}).catch(i=>{console.warn("[manuscript] startReplay failed",i)});return}case"pause":it()&&ze(),Ht("pause-ack",e.requestId,{ok:it()});return;case"next":it()&&He();return;case"prev":it()&&Dn();return;case"jump":it()&&typeof e.index=="number"&&oo(e.index);return;case"exit":(async()=>(it()&&await ve(),Ht("exit-ack",e.requestId,{ok:!0})))();return}}function cg(t){if(t==null)throw new ho("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new ho("Invalid JSON",n)}return go(e,{strict:!0})}return go(t,{strict:!0})}function lg(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const dg=window===window.top;Bu();Ks();au();Ru();Gd();Lu();eu();vd();Gu();Zu();var vi,yi;dg&&(Qu().then(()=>{Jh(),eg()}),chrome.runtime.onMessage.addListener(Kh),(yi=(vi=chrome.permissions)==null?void 0:vi.onAdded)==null||yi.addListener(()=>Ts()),ig());export{Ml as M,$l as V,wt as d,st as g,ye as o,Et as r,gg as u};
