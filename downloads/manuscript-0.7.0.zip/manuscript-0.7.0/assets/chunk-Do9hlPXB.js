import"./chunk-B5Qt9EMX.js";import{o as bt,p as wt,q as vt,m as G,r as $t,a as St,_ as At,n as K,s as Et}from"./chunk-b9UwEhlW.js";import{S as v}from"./chunk-C8iY6jtx.js";import{t as l}from"./chunk-ClheHCf9.js";const Lt="<all_urls>";function Bt(){return{origins:[Lt]}}function kt(){return typeof chrome>"u"?null:chrome.permissions??null}function Y(e){const t=kt();if(!t){e(!1);return}try{t.request(Bt(),r=>e(r??!1))}catch{e(!1)}}function L(e){const t=document.getElementById("error-message");t&&(t.textContent=e,t.hidden=!1)}function It(){const e=document.getElementById("error-message");e&&(e.textContent="",e.hidden=!0)}function Ct(e){const t=Date.parse(e);if(!t)return"";const r=Math.floor((Date.now()-t)/1e3);if(r<60)return"just now";const a=Math.floor(r/60);if(a<60)return`${a}m ago`;const n=Math.floor(a/60);if(n<24)return`${n}h ago`;const o=Math.floor(n/24);if(o<7)return`${o}d ago`;const s=new Date(t);return`${s.getFullYear()}-${Q(s.getMonth()+1)}-${Q(s.getDate())}`}function Q(e){return String(e).padStart(2,"0")}function B(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function D(e){return B(e)}function j(){return new URLSearchParams(window.location.search).has("detached")}async function Tt(){try{return(await chrome.storage.local.get(v.popupMode))[v.popupMode]==="detached"?"detached":"inline"}catch{return"inline"}}async function ot(e){try{await chrome.storage.local.set({[v.popupMode]:e})}catch(t){console.error("[manuscript] save popup mode failed",t)}}async function Pt(){if(j()){await ot("inline"),window.close();return}await it()}async function Mt(){if(j()){const[t]=await chrome.tabs.query({active:!0,windowType:"normal"});return t}const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e}async function it(){const e=chrome.runtime.getURL("src/popup/popup.html");try{await ot("detached");const t=await Rt();if(t!==void 0)try{await chrome.windows.update(t,{focused:!0}),window.close();return}catch{await X(void 0)}const r=await chrome.windows.create({url:e+"?detached=1",type:"popup",width:420,height:680});(r==null?void 0:r.id)!==void 0&&await X(r.id),window.close()}catch(t){console.error("[manuscript] open detached failed",t),L("Failed to open a separate window. Check the console.")}}async function Rt(){try{const t=(await chrome.storage.local.get(v.detachedWindowId))[v.detachedWindowId];return typeof t=="number"?t:void 0}catch{return}}async function X(e){try{e===void 0?await chrome.storage.local.remove(v.detachedWindowId):await chrome.storage.local.set({[v.detachedWindowId]:e})}catch(t){console.error("[manuscript] save detached window id failed",t)}}async function N(e,t){It();try{const r=await Mt();if(!(r!=null&&r.id)){L(l("popup.error.no-tab"));return}if(!Ut(r.url)){L(l("popup.error.bad-url"));return}if(await et(r.id,e)){tt(t);return}try{await jt(r.id)}catch(a){console.error("[manuscript] inject failed",a),L(l("popup.error.inject"));return}if(await et(r.id,e)){tt(t);return}L(l("popup.error.inject"))}catch(r){console.error("[manuscript] handleStart failed",r),L(l("popup.error.unknown"))}}function tt(e){if(j()){e==null||e();return}window.close()}async function et(e,t){try{return await chrome.tabs.sendMessage(e,{type:"panel.open",scenarioId:t}),!0}catch{return!1}}async function jt(e){var a,n;const r=(n=(a=chrome.runtime.getManifest().content_scripts)==null?void 0:a[0])==null?void 0:n.js;if(!r||r.length===0)throw new Error("no content_scripts.js in manifest");await chrome.scripting.executeScript({target:{tabId:e},files:r})}function Ut(e){return e?/^https?:/i.test(e):!1}async function R(){try{const[e,t]=await Promise.all([wt(),vt()]);_t(e,t==null?void 0:t.id)}catch(e){console.error("[manuscript] list load failed",e)}}function _t(e,t){const r=document.getElementById("scenarios");if(!r)return;if(e.length===0){r.hidden=!0,r.innerHTML="";return}r.hidden=!1;const a=e.map(n=>xt(n,n.id===t)).join("");r.innerHTML=`
    <div class="list-header">
      <h2 class="list-heading">${B(l("popup.list.heading"))}</h2>
      <span class="list-count">${e.length}</span>
    </div>
    <ul class="list" role="list">${a}</ul>
  `}function xt(e,t){const r=e.steps.length,a=Ct(e.updatedAt),n=t?`<span> · </span><span class="resume-tag">${B(l("popup.list.resume-tag"))}</span>`:"",o=G({height:14,color:"currentColor"}),s=l("popup.list.steps",{n:r});return`
    <li class="list-item${t?" list-item-recent":""}" role="listitem">
      <button class="list-resume" data-resume="${D(e.id)}" type="button">
        <span class="list-thumb" aria-hidden="true">${o}</span>
        <span class="list-text">
          <span class="list-name">${B(e.name)}</span>
          <span class="list-meta"><span>${B(s)} · ${a}</span>${n}</span>
        </span>
      </button>
      <button
        class="list-delete"
        data-delete="${D(e.id)}"
        data-delete-name="${D(e.name)}"
        type="button"
        aria-label="${D(l("popup.list.delete-aria",{name:e.name}))}"
      >×</button>
    </li>
  `}function Dt(e){return new Promise(t=>{var o;const r=document.createElement("div");r.className="confirm-overlay",r.setAttribute("role","dialog"),r.setAttribute("aria-modal","true"),r.innerHTML=`
      <div class="confirm-card">
        <p class="confirm-title">${B(l("common.delete-confirm",{name:e}))}</p>
        <div class="confirm-actions">
          <button type="button" class="confirm-btn confirm-cancel" data-confirm="cancel">${B(l("common.cancel"))}</button>
          <button type="button" class="confirm-btn confirm-delete" data-confirm="delete">${B(l("common.delete"))}</button>
        </div>
      </div>
    `;const a=s=>{document.removeEventListener("keydown",n,!0),r.remove(),t(s)},n=s=>{s.key==="Escape"&&(s.preventDefault(),a(!1))};r.addEventListener("click",s=>{var f;const u=s.target;if(u===r)return a(!1);const p=(f=u.closest("[data-confirm]"))==null?void 0:f.getAttribute("data-confirm");p==="cancel"?a(!1):p==="delete"&&a(!0)}),document.addEventListener("keydown",n,!0),document.body.appendChild(r),(o=r.querySelector(".confirm-cancel"))==null||o.focus()})}async function Ft(e){const t=e.target;if(!(t instanceof HTMLElement))return;const r=t.closest("[data-delete]");if(r){e.stopPropagation();const n=r.getAttribute("data-delete");if(!n)return;const o=r.getAttribute("data-delete-name")??"",s=o.length>0?o:l("common.untitled");if(!await Dt(s))return;try{await bt(n),await R()}catch(u){console.error("[manuscript] delete failed",u)}return}const a=t.closest("[data-resume]");if(a){const n=a.getAttribute("data-resume");if(!n)return;Y(()=>{N(n,R)})}}async function Ht(e,t){const r=$t(e);return await St(r),t&&await t(),{scenarioId:r.id}}function Nt(e,t={}){e.addEventListener("click",()=>{Ot(r=>{qt(r,t.reloadList)})})}async function qt(e,t){try{const{scenarioId:r}=await Ht(e,t);await N(r,t)}catch(r){console.error("[manuscript/popup] import failed",r),L(l("popup.import.failed"))}}function Ot(e){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var a;const r=(a=t.files)==null?void 0:a[0];if(t.remove(),!!r)try{const n=await r.text();e(n)}catch(n){console.error("[manuscript/popup] file read failed",n),L(l("popup.import.failed"))}}),t.click()}const O="manuscript.popupTab",Wt="local";async function Vt(e,t={}){const r=Array.from(e.querySelectorAll("[data-tab]")),a=new Set(r.map(u=>u.getAttribute("data-tab")).filter(u=>!!u)),n=await Gt(),o=n&&a.has(n)?n:t.defaultTab&&a.has(t.defaultTab)?t.defaultTab:Wt;rt(e,o);const s=u=>{var E;const f=u.currentTarget.getAttribute("data-tab");f&&f!==Jt(e)&&(rt(e,f),Kt(f),(E=t.onTabChange)==null||E.call(t,f))};for(const u of r)u.addEventListener("click",s);return()=>{for(const u of r)u.removeEventListener("click",s)}}function Jt(e){const t=e.querySelector('[data-tab][aria-pressed="true"]');return(t==null?void 0:t.getAttribute("data-tab"))??null}function rt(e,t){const r=e.querySelectorAll("[data-tab]");for(const n of r)n.setAttribute("aria-pressed",n.getAttribute("data-tab")===t?"true":"false");const a=e.querySelectorAll("[data-tab-panel]");for(const n of a)n.hidden=n.getAttribute("data-tab-panel")!==t}async function Gt(){try{const t=(await chrome.storage.local.get(O))[O];return typeof t=="string"?t:null}catch{return null}}async function Kt(e){try{await chrome.storage.local.set({[O]:e})}catch{}}const Yt={sources:[],catalogs:{}};async function U(){const t=(await chrome.storage.local.get(v.remoteLibrary))[v.remoteLibrary];if(!t||typeof t!="object")return zt(Yt);const r=t;return{sources:Array.isArray(r.sources)?r.sources:[],catalogs:r.catalogs&&typeof r.catalogs=="object"?r.catalogs:{}}}async function z(e){await chrome.storage.local.set({[v.remoteLibrary]:e})}function zt(e){return JSON.parse(JSON.stringify(e))}function nt(e){return`${e.owner}/${e.repo}@${e.branch}:${e.path}`}function Zt(){return`src-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`}async function F(){return(await U()).sources}async function st(e){const t=await U(),r=nt(e),a=t.sources.find(o=>nt(o)===r);if(a)return a;const n={...e,id:Zt(),label:`${e.owner}/${e.repo}`,addedAt:Date.now()};return t.sources.push(n),await z(t),n}async function ct(e){const t=await U();t.sources=t.sources.filter(r=>r.id!==e),delete t.catalogs[e],await z(t)}async function lt(e){return(await U()).catalogs[e]??null}async function dt(e,t){const r=await U();r.catalogs[e]=t,await z(r)}function ut(e,t){const r=t.filter(p=>p.type==="dir"||p.type==="file"&&p.name.toLowerCase().endsWith(".json")),a=new Map(e.map(p=>[p.name,p])),n=new Map(r.map(p=>[p.name,p])),o=[],s=[];for(const p of r){const f=a.get(p.name);f&&f.sha===p.sha?s.push(f):o.push(p)}const u=[];for(const p of e)n.has(p.name)||u.push(p);return{toFetch:o,toKeep:s,toRemove:u}}const Qt=Object.freeze(Object.defineProperty({__proto__:null,addRemoteSource:st,diffCatalog:ut,getCatalog:lt,listRemoteSources:F,removeRemoteSource:ct,setCatalog:dt},Symbol.toStringTag,{value:"Module"})),pt="main",Xt="",T=/^[A-Za-z0-9_.\-]+$/;function te(e){if(typeof e!="string")return null;const t=e.trim();return t.length===0||/(^|[\\/])\.\.([\\/]|$)/.test(t)||/(^|[\\/])\.([\\/]|$)/.test(t)?null:/^https?:\/\//i.test(t)?ee(t):re(t)}function ee(e){let t;try{t=new URL(e)}catch{return null}if(t.host.toLowerCase()!=="github.com")return null;const r=t.pathname.split("/").filter(p=>p.length>0);if(r.length<2)return null;const a=r[0];let n=r[1];if(n.endsWith(".git")&&(n=n.slice(0,-4)),!T.test(a)||!T.test(n))return null;if(r.length===2||r[2]!=="tree")return r.length>2?null:{owner:a,repo:n,branch:pt,path:Xt};const o=r[3];if(!o||!T.test(o))return null;const s=r.slice(4),u=mt(s);return u===null?null:{owner:a,repo:n,branch:o,path:u}}function re(e){const t=e.split("/").filter(s=>s.length>0);if(t.length<2)return null;const r=t[0];let a=t[1];if(a.endsWith(".git")&&(a=a.slice(0,-4)),!T.test(r)||!T.test(a))return null;const n=t.slice(2),o=mt(n);return o===null?null:{owner:r,repo:a,branch:pt,path:o}}function mt(e){if(e.length===0)return"";for(const t of e)if(t===".."||t==="."||!T.test(t))return null;return e.join("/")}const ne="https://api.github.com";async function ft(e){const t=`${ne}/repos/${W(e.owner)}/${W(e.repo)}/contents/${ae(e.path)}?ref=${encodeURIComponent(e.branch)}`,r=await fetch(t,{headers:{Accept:"application/vnd.github+json"}});if(!r.ok)throw r.status===404?new Error(`Folder not found (404): ${e.path}`):r.status===403?new Error("GitHub API rate limit reached (403). Try again in an hour or sign in via a future private-repo path."):new Error(`GitHub API error: ${r.status} ${r.statusText}`);const a=await r.json();if(!Array.isArray(a))throw new Error("Expected a folder listing — the path points to a file or unknown shape.");return a.map(oe)}async function ht(e){const t=await fetch(e);if(!t.ok)throw new Error(`Raw fetch failed: ${t.status} ${t.statusText}`);const r=await t.text();try{return JSON.parse(r)}catch(a){throw new Error(`Invalid JSON at ${e}: ${a.message}`)}}function W(e){return encodeURIComponent(e)}function ae(e){return e.split("/").filter(t=>t.length>0).map(W).join("/")}function oe(e){const t=e;return{name:typeof t.name=="string"?t.name:"",path:typeof t.path=="string"?t.path:"",sha:typeof t.sha=="string"?t.sha:"",type:typeof t.type=="string"?t.type:"file",downloadUrl:typeof t.download_url=="string"?t.download_url:null}}const ie=8;async function se(e,t={}){const r=await ft(e),{getCatalog:a}=await At(async()=>{const{getCatalog:g}=await Promise.resolve().then(()=>Qt);return{getCatalog:g}},void 0),n=await a(e.id),o=(n==null?void 0:n.items)??[],s=ut(o,r),u=t.fetchRaw??ht,p=Math.max(1,t.concurrency??ie);let f=0;const E=s.toFetch.length,k=new Array(s.toFetch.length);let I=0;async function q(){var g;for(;;){const C=I++;if(C>=s.toFetch.length)return;const i=s.toFetch[C];k[C]=await ce(i,u),f+=1,(g=t.onProgress)==null||g.call(t,f,E)}}await Promise.all(Array.from({length:Math.min(p,E)},()=>q()));const P=new Map;for(const g of s.toKeep)P.set(g.name,g);for(const g of k)g&&P.set(g.name,g);const _={items:r.filter(g=>g.type==="dir"||g.type==="file"&&g.name.toLowerCase().endsWith(".json")).map(g=>P.get(g.name)).filter(g=>!!g),lastRefreshed:Date.now()};return await dt(e.id,_),_}async function ce(e,t){if(e.type==="dir")return{name:e.name,type:"dir",sha:e.sha,downloadUrl:""};const r={name:e.name,type:"file",sha:e.sha,downloadUrl:e.downloadUrl??""};if(!e.downloadUrl)return{...r,error:"No download URL on folder listing"};let a;try{a=await t(e.downloadUrl)}catch(n){return{...r,error:`Fetch failed: ${n.message}`}}try{const n=K(a,{strict:!0});return{...r,scenarioName:n.name,scenarioId:n.id,stepCount:n.steps.length,scenarioJson:n}}catch(n){return{...r,error:`Invalid scenario: ${n.message}`}}}async function le(e,t,r={}){if(t.error)throw new Error(`Cannot play item with error: ${t.error}`);if(!t.scenarioJson)throw new Error("Cached item has no scenarioJson; refresh the catalog first.");const a=K(t.scenarioJson,{strict:!0}),n=`eph-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,o={...a,id:n};return await Et(o,{kind:"github",repo:`${e.owner}/${e.repo}`,path:e.path?`${e.path}/${t.name}`:t.name,sha:t.sha}),await(r.handleStart??N)(o.id),o.id}function de(e,t){if(t.sources.length===0){e.innerHTML=ue(t);return}e.innerHTML=pe(t)}function ue(e){return e.adding?`
      <div class="remote-empty" data-region="remote-empty">
        ${gt(e)}
      </div>
    `:`
    <div class="remote-empty" data-region="remote-empty">
      <div class="remote-empty-icon" aria-hidden="true">${H(32)}</div>
      <p class="remote-empty-copy">${d(l("popup.remote.empty.copy")||"Connect a public GitHub repo to load shared manuscripts.")}</p>
      <button
        type="button"
        class="remote-add-cta"
        data-action="remote-add-open"
      >
        <span class="remote-add-cta-icon" aria-hidden="true">${H(14)}</span>
        <span>${d(l("popup.remote.add-cta")||"+ Add a GitHub source")}</span>
      </button>
    </div>
  `}function pe(e){return`
    <div class="remote-header" data-region="remote-header">
      <div class="remote-header-actions">
        <button
          type="button"
          class="remote-icon-btn remote-icon-btn-add"
          data-action="remote-add-open"
          title="${d(l("popup.remote.add-cta-aria")||"Add source")}"
          aria-label="${d(l("popup.remote.add-cta-aria")||"Add source")}"
        ><span class="remote-icon-btn-plus" aria-hidden="true">+</span>${H(12)}</button>
        <button
          type="button"
          class="remote-icon-btn"
          data-action="remote-refresh-all"
          title="${d(l("popup.remote.refresh-all-aria")||"Refresh all")}"
          aria-label="${d(l("popup.remote.refresh-all-aria")||"Refresh all")}"
        >↻</button>
      </div>
    </div>
    ${e.adding?gt(e):""}
    <div class="remote-source-list" data-region="remote-source-list">
      ${e.sources.map(t=>me(t,e)).join("")}
    </div>
  `}function gt(e){return`
    <form class="remote-add-form" data-region="remote-add-form">
      <input
        type="text"
        class="remote-add-input"
        data-region="remote-add-input"
        placeholder="${d(l("popup.remote.add-placeholder")||"github.com/owner/repo or owner/repo/path")}"
        autocomplete="off"
        spellcheck="false"
      />
      <div class="remote-add-actions">
        <button
          type="submit"
          class="remote-add-submit"
          data-action="remote-add-submit"
        >${d(l("popup.remote.add-submit")||"Add")}</button>
        <button
          type="button"
          class="remote-add-cancel"
          data-action="remote-add-cancel"
        >${d(l("common.cancel")||"Cancel")}</button>
      </div>
      ${e.addError?`<p class="remote-add-error" data-region="remote-add-error">${d(e.addError)}</p>`:""}
    </form>
  `}function me(e,t){var p;const r=t.subPathBySourceId[e.id]??"",a=r.length>0,n=a?t.subViewBySourceId[e.id]??[]:((p=t.catalogs[e.id])==null?void 0:p.items)??null,o=t.loadingBySourceId[e.id],s=t.collapsedBySourceId[e.id]===!0,u=s?l("popup.remote.expand-aria")||"Expand source":l("popup.remote.collapse-aria")||"Collapse source";return`
    <section
      class="remote-source-card${s?" is-collapsed":""}"
      data-region="remote-source-card"
      data-source-id="${d(e.id)}"
    >
      <header class="remote-source-header">
        <div class="remote-source-label">
          <span class="remote-source-icon remote-source-icon-github" aria-hidden="true">${H(14)}</span>
          <span class="remote-source-title">${d(e.label)}</span>
          ${e.path?`<span class="remote-source-path">· ${d(e.path)}</span>`:""}
        </div>
        <div class="remote-source-actions">
          <button
            type="button"
            class="remote-source-toggle"
            data-action="remote-source-toggle"
            data-source-id="${d(e.id)}"
            aria-pressed="${s?"true":"false"}"
            aria-label="${d(u)}"
            title="${d(u)}"
          >${s?be():ye()}</button>
          <button
            type="button"
            class="remote-source-remove"
            data-action="remote-source-remove"
            data-source-id="${d(e.id)}"
            title="${d(l("popup.remote.remove-aria")||"Remove source")}"
            aria-label="${d(l("popup.remote.remove-aria")||"Remove source")}"
          >×</button>
        </div>
      </header>
      ${s?"":`
            ${a?fe(e,r):""}
            <div class="remote-source-body" data-region="remote-source-body">
              ${o?`<div class="remote-progress" data-region="remote-progress">${d(l("popup.remote.progress")||"Loading")} ${o.done} / ${o.total}</div>`:""}
              ${ge(e,n,a)}
            </div>
          `}
    </section>
  `}function fe(e,t){const r=t.split("/").filter(n=>n.length>0);if(r.length===0)return"";const a=r.map((n,o)=>{const s=o===r.length-1;return`${o===0?"":'<span class="remote-breadcrumb-sep" aria-hidden="true">/</span>'}<span class="remote-breadcrumb-seg${s?" is-current":""}">${d(n)}</span>`}).join("");return`
    <nav class="remote-breadcrumb" data-region="remote-breadcrumb">
      <button
        type="button"
        class="remote-breadcrumb-button"
        data-action="remote-folder-up"
        data-source-id="${d(e.id)}"
        aria-label="${d(l("popup.remote.back-aria")||"Back")}"
        title="${d(l("popup.remote.back-aria")||"Back")}"
      >
        <span class="remote-breadcrumb-chevron" aria-hidden="true">${he()}</span>
        <span class="remote-breadcrumb-folder" aria-hidden="true">📁</span>
        <span class="remote-breadcrumb-name">${a}</span>
      </button>
    </nav>
  `}function he(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M6 2 L3 5 L6 8"/></svg>'}function ge(e,t,r){if(t===null)return`<p class="remote-source-empty">${d(l("popup.remote.source-never-refreshed")||"Click ↻ refresh to load this source.")}</p>`;if(t.length===0)return`<p class="remote-source-empty">${d(r?l("popup.remote.folder-empty")||"This folder is empty.":l("popup.remote.source-empty")||"No manuscripts in this folder yet.")}</p>`;const a=t.filter(o=>o.type==="dir"),n=t.filter(o=>o.type!=="dir");return`
    <ul class="remote-catalog">
      ${a.map(o=>at(e,o)).join("")}
      ${n.map(o=>at(e,o)).join("")}
    </ul>
  `}function at(e,t){if(t.type==="dir")return`
      <li class="remote-catalog-item" data-region="remote-catalog-item">
        <button
          type="button"
          class="remote-catalog-row"
          data-action="remote-folder-into"
          data-source-id="${d(e.id)}"
          data-folder-name="${d(t.name)}"
          aria-label="${d(t.name)}"
        >
          <span class="remote-play-icon remote-folder-icon" aria-hidden="true">📁</span>
          <span class="remote-catalog-name">${d(t.name)}</span>
        </button>
      </li>
    `;const r=!!t.error,a=t.scenarioName||t.name,n=typeof t.stepCount=="number"?`<span class="remote-catalog-steps">${t.stepCount} ${d(l("popup.remote.steps-suffix")||"steps")}</span>`:"",o=r?` title="${d(t.error)}"`:"";return`
    <li class="remote-catalog-item" data-region="remote-catalog-item">
      <button
        type="button"
        class="remote-catalog-row"
        data-action="remote-play"
        data-source-id="${d(e.id)}"
        data-item-name="${d(t.name)}"
        ${r?"disabled":""}
        aria-label="${d(a)}"${o}
      >
        <span class="remote-play-icon" aria-hidden="true">${G({height:16})}</span>
        <span class="remote-catalog-name">${d(a)}</span>
        ${n}
        ${r?'<span class="remote-catalog-warn" aria-hidden="true">⚠</span>':""}
      </button>
    </li>
  `}function H(e=14){return`<svg width="${e}" height="${e}" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><path d="M8 0C3.58 0 0 3.58 0 8c0 3.54 2.29 6.53 5.47 7.59.4.07.55-.17.55-.38 0-.19-.01-.82-.01-1.49-2.01.37-2.53-.49-2.69-.94-.09-.23-.48-.94-.82-1.13-.28-.15-.68-.52-.01-.53.63-.01 1.08.58 1.23.82.72 1.21 1.87.87 2.33.66.07-.52.28-.87.51-1.07-1.78-.2-3.64-.89-3.64-3.95 0-.87.31-1.59.82-2.15-.08-.2-.36-1.02.08-2.12 0 0 .67-.21 2.2.82.64-.18 1.32-.27 2-.27.68 0 1.36.09 2 .27 1.53-1.04 2.2-.82 2.2-.82.44 1.1.16 1.92.08 2.12.51.56.82 1.27.82 2.15 0 3.07-1.87 3.75-3.65 3.95.29.25.54.73.54 1.48 0 1.07-.01 1.93-.01 2.2 0 .21.15.46.55.38A8.013 8.013 0 0 0 16 8c0-4.42-3.58-8-8-8z"/></svg>`}function ye(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M2 4 L5 7 L8 4"/></svg>'}function be(){return'<svg width="10" height="10" viewBox="0 0 10 10" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 2 L7 5 L4 8"/></svg>'}function d(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function we(e){const t={sources:[],catalogs:{},loadingBySourceId:{},subPathBySourceId:{},subViewBySourceId:{},collapsedBySourceId:{},adding:!1,addError:null};async function r(){t.sources=await F();for(const i of t.sources){const c=await lt(i.id);c&&(t.catalogs[i.id]=c)}try{const c=(await chrome.storage.local.get(v.remoteCollapsed))[v.remoteCollapsed];if(c&&typeof c=="object")for(const[m,h]of Object.entries(c))h===!0&&(t.collapsedBySourceId[m]=!0)}catch{}}async function a(){try{await chrome.storage.local.set({[v.remoteCollapsed]:t.collapsedBySourceId})}catch{}}async function n(i){t.collapsedBySourceId[i]?delete t.collapsedBySourceId[i]:t.collapsedBySourceId[i]=!0,o(),await a()}function o(){de(e,t)}async function s(i){t.loadingBySourceId[i.id]={done:0,total:0},o();try{const c=await se(i,{onProgress:(m,h)=>{t.loadingBySourceId[i.id]={done:m,total:h},o()}});t.catalogs[i.id]=c}catch(c){console.error("[manuscript/remote] refresh failed",c)}finally{delete t.loadingBySourceId[i.id],o()}}async function u(){await Promise.all(t.sources.map(i=>s(i)))}function p(){t.adding=!0,t.addError=null,o(),queueMicrotask(()=>{var i;(i=e.querySelector('[data-region="remote-add-input"]'))==null||i.focus()})}function f(){t.adding=!1,t.addError=null,o()}async function E(i){const c=te(i);if(!c){t.addError="Invalid URL. Expected github.com/owner/repo or owner/repo.",o();return}await new Promise(h=>{Y(()=>h())});const m=await st(c);t.sources=await F(),t.adding=!1,t.addError=null,o(),await s(m)}async function k(i){await ct(i),delete t.catalogs[i],delete t.loadingBySourceId[i],delete t.subPathBySourceId[i],delete t.subViewBySourceId[i],delete t.collapsedBySourceId[i],t.sources=await F(),o(),a()}async function I(i,c){const m=t.sources.find(y=>y.id===i);if(!m)return;const h=m.path?`${m.path}/${c}`:c;t.loadingBySourceId[i]={done:0,total:0},o();try{const S=(await ft({...m,path:h})).filter(b=>b.type==="dir"||b.type==="file"&&b.name.toLowerCase().endsWith(".json")),$=[],w=S.length;t.loadingBySourceId[i]={done:0,total:w},o();let A=0;for(const b of S){if(b.type==="dir")$.push({name:b.name,type:"dir",sha:b.sha,downloadUrl:""});else try{const x=b.downloadUrl?await ht(b.downloadUrl):null,M=x?K(x,{strict:!0}):null;$.push({name:b.name,type:"file",sha:b.sha,downloadUrl:b.downloadUrl??"",...M?{scenarioName:M.name,scenarioId:M.id,stepCount:M.steps.length,scenarioJson:M}:{error:"No download URL or unparseable JSON"}})}catch(x){$.push({name:b.name,type:"file",sha:b.sha,downloadUrl:b.downloadUrl??"",error:`Invalid scenario: ${x.message}`})}A+=1,t.loadingBySourceId[i]={done:A,total:w},o()}t.subViewBySourceId[i]=$}catch(y){console.error("[manuscript/remote] sub-folder fetch failed",y),t.subViewBySourceId[i]=[]}finally{delete t.loadingBySourceId[i],o()}}async function q(i,c){const m=t.subPathBySourceId[i]??"",h=m?`${m}/${c}`:c;t.subPathBySourceId[i]=h,t.subViewBySourceId[i]=[],o();const y=await P(i,h);if(y){t.subViewBySourceId[i]=y,o();return}await I(i,h)}async function P(i,c){var m;try{const y=(await chrome.storage.local.get("manuscript.remoteSubStubs"))["manuscript.remoteSubStubs"],S=(m=y==null?void 0:y[i])==null?void 0:m[c];return Array.isArray(S)?S:null}catch{return null}}async function Z(i){const c=t.subPathBySourceId[i]??"";if(!c)return;const m=c.split("/").filter(y=>y.length>0);m.pop();const h=m.join("/");if(h.length===0){delete t.subPathBySourceId[i],delete t.subViewBySourceId[i],o();return}t.subPathBySourceId[i]=h,t.subViewBySourceId[i]=[],o(),await I(i,h)}async function _(i,c){var A;const m=t.sources.find(b=>b.id===i);if(!m)return;const S=((t.subPathBySourceId[i]??"").length>0?t.subViewBySourceId[i]??[]:((A=t.catalogs[i])==null?void 0:A.items)??[]).find(b=>b.name===c);if(!S)return;const $=t.subPathBySourceId[i]??"",w=$?m.path?`${m.path}/${$}`:$:m.path;try{await le({...m,path:w},S)}catch(b){console.error("[manuscript/remote] play failed",b)}}const g=i=>{const c=i.target;if(!c)return;if(c.closest('[data-action="remote-add-open"]')){p();return}if(c.closest('[data-action="remote-add-cancel"]')){i.preventDefault(),f();return}if(c.closest('[data-action="remote-refresh-all"]')){u();return}const m=c.closest('[data-action="remote-source-toggle"]');if(m){const w=m.getAttribute("data-source-id");w&&n(w);return}const h=c.closest('[data-action="remote-source-remove"]');if(h){const w=h.getAttribute("data-source-id");w&&k(w);return}const y=c.closest('[data-action="remote-folder-into"]');if(y){const w=y.getAttribute("data-source-id"),A=y.getAttribute("data-folder-name");w&&A&&q(w,A);return}const S=c.closest('[data-action="remote-folder-up"]');if(S){const w=S.getAttribute("data-source-id");w&&Z(w);return}const $=c.closest('[data-action="remote-play"]');if($){const w=$.getAttribute("data-source-id"),A=$.getAttribute("data-item-name");w&&A&&_(w,A);return}},C=i=>{var y;const c=i.target;if(!c||!((y=c.matches)!=null&&y.call(c,'[data-region="remote-add-form"]')))return;i.preventDefault();const m=e.querySelector('[data-region="remote-add-input"]'),h=(m==null?void 0:m.value.trim())??"";if(h.length===0){t.addError="Enter a GitHub URL or owner/repo",o();return}E(h)};return e.addEventListener("click",g),e.addEventListener("submit",C),await r(),o(),u(),{refresh:u,destroy(){e.removeEventListener("click",g),e.removeEventListener("submit",C)}}}const V="studio",ve="studio-dark";function yt(e){return e.endsWith("-dark")}async function $e(){try{const t=(await chrome.storage.local.get(v.palette))[v.palette];if(typeof t=="string")return t}catch{}return V}function J(e){document.body.setAttribute("data-palette",e);const t=document.getElementById("palette-toggle");t==null||t.setAttribute("aria-pressed",yt(e)?"true":"false")}async function Se(){const e=document.body.getAttribute("data-palette")??V,t=yt(e)?V:ve;J(t);try{await chrome.storage.local.set({[v.palette]:t})}catch{}}document.addEventListener("DOMContentLoaded",()=>{Ae()});async function Ae(){if(Ee(),!j()&&await Tt()==="detached"){await it();return}const e=document.getElementById("start-cta"),t=document.getElementById("help-link"),r=document.getElementById("scenarios"),a=document.getElementById("detach-btn"),n=document.getElementById("palette-toggle"),o=document.getElementById("import-link");J(await $e()),chrome.storage.onChanged.addListener((f,E)=>{var I;if(E!=="local")return;const k=(I=f[v.palette])==null?void 0:I.newValue;typeof k=="string"&&J(k)}),n==null||n.addEventListener("click",()=>{Se()});const s=document.querySelector('[data-region="brand-logo"]');s&&(s.innerHTML=G({height:20})),j()&&a&&(a.textContent=l("popup.detach.detached"),a.setAttribute("title",l("popup.detach.inline-title")),a.setAttribute("aria-label",l("popup.detach.inline-title"))),e==null||e.addEventListener("click",()=>{Y(()=>{N(void 0,R)})}),o instanceof HTMLButtonElement&&Nt(o,{reloadList:R}),t==null||t.addEventListener("click",f=>{f.preventDefault(),chrome.tabs.create({url:"https://zendy00.github.io/manuscript-pages/"})}),r==null||r.addEventListener("click",f=>{Ft(f)}),a==null||a.addEventListener("click",()=>{Pt()});const u=document.querySelector(".empty-state");u&&await Vt(u);const p=document.querySelector('[data-tab-panel="remote"]');p&&(p.innerHTML="",we(p)),R()}function Ee(){for(const e of document.querySelectorAll("[data-i18n]")){const t=e.getAttribute("data-i18n");t&&(e.textContent=l(t))}for(const e of document.querySelectorAll("[data-i18n-aria]")){const t=e.getAttribute("data-i18n-aria");t&&e.setAttribute("aria-label",l(t))}for(const e of document.querySelectorAll("[data-i18n-title]")){const t=e.getAttribute("data-i18n-title");t&&e.setAttribute("title",l(t))}}
