import"./chunk-B5Qt9EMX.js";import{o as at,p as ot,q as it,m as W,r as ct,a as st,_ as lt,n as G,s as dt}from"./chunk-AEFpmvFC.js";import{S as y}from"./chunk-Bh4VowKL.js";import{t as c}from"./chunk-ClheHCf9.js";const ut="<all_urls>";function pt(){return{origins:[ut]}}function mt(){return typeof chrome>"u"?null:chrome.permissions??null}function H(e){const t=mt();if(!t){e(!1);return}try{t.request(pt(),r=>e(r??!1))}catch{e(!1)}}function $(e){const t=document.getElementById("error-message");t&&(t.textContent=e,t.hidden=!1)}function ft(){const e=document.getElementById("error-message");e&&(e.textContent="",e.hidden=!0)}function ht(e){const t=Date.parse(e);if(!t)return"";const r=Math.floor((Date.now()-t)/1e3);if(r<60)return"just now";const n=Math.floor(r/60);if(n<60)return`${n}m ago`;const a=Math.floor(n/60);if(a<24)return`${a}h ago`;const o=Math.floor(a/24);if(o<7)return`${o}d ago`;const i=new Date(t);return`${i.getFullYear()}-${B(i.getMonth()+1)}-${B(i.getDate())}`}function B(e){return String(e).padStart(2,"0")}function E(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function k(e){return E(e)}function T(){return new URLSearchParams(window.location.search).has("detached")}async function gt(){try{return(await chrome.storage.local.get(y.popupMode))[y.popupMode]==="detached"?"detached":"inline"}catch{return"inline"}}async function J(e){try{await chrome.storage.local.set({[y.popupMode]:e})}catch(t){console.error("[manuscript] save popup mode failed",t)}}async function yt(){if(T()){await J("inline"),window.close();return}await K()}async function wt(){if(T()){const[t]=await chrome.tabs.query({active:!0,windowType:"normal"});return t}const[e]=await chrome.tabs.query({active:!0,currentWindow:!0});return e}async function K(){const e=chrome.runtime.getURL("src/popup/popup.html");try{await J("detached");const t=await bt();if(t!==void 0)try{await chrome.windows.update(t,{focused:!0}),window.close();return}catch{await F(void 0)}const r=await chrome.windows.create({url:e+"?detached=1",type:"popup",width:420,height:680});(r==null?void 0:r.id)!==void 0&&await F(r.id),window.close()}catch(t){console.error("[manuscript] open detached failed",t),$("Failed to open a separate window. Check the console.")}}async function bt(){try{const t=(await chrome.storage.local.get(y.detachedWindowId))[y.detachedWindowId];return typeof t=="number"?t:void 0}catch{return}}async function F(e){try{e===void 0?await chrome.storage.local.remove(y.detachedWindowId):await chrome.storage.local.set({[y.detachedWindowId]:e})}catch(t){console.error("[manuscript] save detached window id failed",t)}}async function P(e,t){ft();try{const r=await wt();if(!(r!=null&&r.id)){$(c("popup.error.no-tab"));return}if(!$t(r.url)){$(c("popup.error.bad-url"));return}if(await N(r.id,e)){x(t);return}try{await vt(r.id)}catch(n){console.error("[manuscript] inject failed",n),$(c("popup.error.inject"));return}if(await N(r.id,e)){x(t);return}$(c("popup.error.inject"))}catch(r){console.error("[manuscript] handleStart failed",r),$(c("popup.error.unknown"))}}function x(e){if(T()){e==null||e();return}window.close()}async function N(e,t){try{return await chrome.tabs.sendMessage(e,{type:"panel.open",scenarioId:t}),!0}catch{return!1}}async function vt(e){var n,a;const r=(a=(n=chrome.runtime.getManifest().content_scripts)==null?void 0:n[0])==null?void 0:a.js;if(!r||r.length===0)throw new Error("no content_scripts.js in manifest");await chrome.scripting.executeScript({target:{tabId:e},files:r})}function $t(e){return e?/^https?:/i.test(e):!1}async function L(){try{const[e,t]=await Promise.all([ot(),it()]);Et(e,t==null?void 0:t.id)}catch(e){console.error("[manuscript] list load failed",e)}}function Et(e,t){const r=document.getElementById("scenarios");if(!r)return;if(e.length===0){r.hidden=!0,r.innerHTML="";return}r.hidden=!1;const n=e.map(a=>St(a,a.id===t)).join("");r.innerHTML=`
    <div class="list-header">
      <h2 class="list-heading">${E(c("popup.list.heading"))}</h2>
      <span class="list-count">${e.length}</span>
    </div>
    <ul class="list" role="list">${n}</ul>
  `}function St(e,t){const r=e.steps.length,n=ht(e.updatedAt),a=t?`<span> · </span><span class="resume-tag">${E(c("popup.list.resume-tag"))}</span>`:"",o=W({height:14,color:"currentColor"}),i=c("popup.list.steps",{n:r});return`
    <li class="list-item${t?" list-item-recent":""}" role="listitem">
      <button class="list-resume" data-resume="${k(e.id)}" type="button">
        <span class="list-thumb" aria-hidden="true">${o}</span>
        <span class="list-text">
          <span class="list-name">${E(e.name)}</span>
          <span class="list-meta"><span>${E(i)} · ${n}</span>${a}</span>
        </span>
      </button>
      <button
        class="list-delete"
        data-delete="${k(e.id)}"
        data-delete-name="${k(e.name)}"
        type="button"
        aria-label="${k(c("popup.list.delete-aria",{name:e.name}))}"
      >×</button>
    </li>
  `}function At(e){return new Promise(t=>{var o;const r=document.createElement("div");r.className="confirm-overlay",r.setAttribute("role","dialog"),r.setAttribute("aria-modal","true"),r.innerHTML=`
      <div class="confirm-card">
        <p class="confirm-title">${E(c("common.delete-confirm",{name:e}))}</p>
        <div class="confirm-actions">
          <button type="button" class="confirm-btn confirm-cancel" data-confirm="cancel">${E(c("common.cancel"))}</button>
          <button type="button" class="confirm-btn confirm-delete" data-confirm="delete">${E(c("common.delete"))}</button>
        </div>
      </div>
    `;const n=i=>{document.removeEventListener("keydown",a,!0),r.remove(),t(i)},a=i=>{i.key==="Escape"&&(i.preventDefault(),n(!1))};r.addEventListener("click",i=>{var f;const u=i.target;if(u===r)return n(!1);const d=(f=u.closest("[data-confirm]"))==null?void 0:f.getAttribute("data-confirm");d==="cancel"?n(!1):d==="delete"&&n(!0)}),document.addEventListener("keydown",a,!0),document.body.appendChild(r),(o=r.querySelector(".confirm-cancel"))==null||o.focus()})}async function Lt(e){const t=e.target;if(!(t instanceof HTMLElement))return;const r=t.closest("[data-delete]");if(r){e.stopPropagation();const a=r.getAttribute("data-delete");if(!a)return;const o=r.getAttribute("data-delete-name")??"",i=o.length>0?o:c("common.untitled");if(!await At(i))return;try{await at(a),await L()}catch(u){console.error("[manuscript] delete failed",u)}return}const n=t.closest("[data-resume]");if(n){const a=n.getAttribute("data-resume");if(!a)return;H(()=>{P(a,L)})}}async function Tt(e,t){const r=ct(e);return await st(r),t&&await t(),{scenarioId:r.id}}function It(e,t={}){e.addEventListener("click",()=>{Ct(r=>{kt(r,t.reloadList)})})}async function kt(e,t){try{const{scenarioId:r}=await Tt(e,t);await P(r,t)}catch(r){console.error("[manuscript/popup] import failed",r),$(c("popup.import.failed"))}}function Ct(e){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const r=(n=t.files)==null?void 0:n[0];if(t.remove(),!!r)try{const a=await r.text();e(a)}catch(a){console.error("[manuscript/popup] file read failed",a),$(c("popup.import.failed"))}}),t.click()}const M="manuscript.popupTab",Pt="local";async function Mt(e,t={}){const r=Array.from(e.querySelectorAll("[data-tab]")),n=new Set(r.map(u=>u.getAttribute("data-tab")).filter(u=>!!u)),a=await _t(),o=a&&n.has(a)?a:t.defaultTab&&n.has(t.defaultTab)?t.defaultTab:Pt;U(e,o);const i=u=>{var b;const f=u.currentTarget.getAttribute("data-tab");f&&f!==Rt(e)&&(U(e,f),Dt(f),(b=t.onTabChange)==null||b.call(t,f))};for(const u of r)u.addEventListener("click",i);return()=>{for(const u of r)u.removeEventListener("click",i)}}function Rt(e){const t=e.querySelector('[data-tab][aria-pressed="true"]');return(t==null?void 0:t.getAttribute("data-tab"))??null}function U(e,t){const r=e.querySelectorAll("[data-tab]");for(const a of r)a.setAttribute("aria-pressed",a.getAttribute("data-tab")===t?"true":"false");const n=e.querySelectorAll("[data-tab-panel]");for(const a of n)a.hidden=a.getAttribute("data-tab-panel")!==t}async function _t(){try{const t=(await chrome.storage.local.get(M))[M];return typeof t=="string"?t:null}catch{return null}}async function Dt(e){try{await chrome.storage.local.set({[M]:e})}catch{}}const jt={sources:[],catalogs:{}};async function I(){const t=(await chrome.storage.local.get(y.remoteLibrary))[y.remoteLibrary];if(!t||typeof t!="object")return Ht(jt);const r=t;return{sources:Array.isArray(r.sources)?r.sources:[],catalogs:r.catalogs&&typeof r.catalogs=="object"?r.catalogs:{}}}async function q(e){await chrome.storage.local.set({[y.remoteLibrary]:e})}function Ht(e){return JSON.parse(JSON.stringify(e))}function O(e){return`${e.owner}/${e.repo}@${e.branch}:${e.path}`}function qt(){return`src-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`}async function C(){return(await I()).sources}async function Y(e){const t=await I(),r=O(e),n=t.sources.find(o=>O(o)===r);if(n)return n;const a={...e,id:qt(),label:`${e.owner}/${e.repo}`,addedAt:Date.now()};return t.sources.push(a),await q(t),a}async function z(e){const t=await I();t.sources=t.sources.filter(r=>r.id!==e),delete t.catalogs[e],await q(t)}async function V(e){return(await I()).catalogs[e]??null}async function Z(e,t){const r=await I();r.catalogs[e]=t,await q(r)}function Q(e,t){const r=t.filter(d=>d.type==="file"&&d.name.toLowerCase().endsWith(".json")),n=new Map(e.map(d=>[d.name,d])),a=new Map(r.map(d=>[d.name,d])),o=[],i=[];for(const d of r){const f=n.get(d.name);f&&f.sha===d.sha?i.push(f):o.push(d)}const u=[];for(const d of e)a.has(d.name)||u.push(d);return{toFetch:o,toKeep:i,toRemove:u}}const Bt=Object.freeze(Object.defineProperty({__proto__:null,addRemoteSource:Y,diffCatalog:Q,getCatalog:V,listRemoteSources:C,removeRemoteSource:z,setCatalog:Z},Symbol.toStringTag,{value:"Module"})),X="main",R="manuscripts",A=/^[A-Za-z0-9_.\-]+$/;function Ft(e){if(typeof e!="string")return null;const t=e.trim();return t.length===0||/(^|[\\/])\.\.([\\/]|$)/.test(t)||/(^|[\\/])\.([\\/]|$)/.test(t)?null:/^https?:\/\//i.test(t)?xt(t):Nt(t)}function xt(e){let t;try{t=new URL(e)}catch{return null}if(t.host.toLowerCase()!=="github.com")return null;const r=t.pathname.split("/").filter(d=>d.length>0);if(r.length<2)return null;const n=r[0];let a=r[1];if(a.endsWith(".git")&&(a=a.slice(0,-4)),!A.test(n)||!A.test(a))return null;if(r.length===2||r[2]!=="tree")return r.length>2?null:{owner:n,repo:a,branch:X,path:R};const o=r[3];if(!o||!A.test(o))return null;const i=r.slice(4),u=tt(i);return u===null?null:{owner:n,repo:a,branch:o,path:u||R}}function Nt(e){const t=e.split("/").filter(i=>i.length>0);if(t.length<2)return null;const r=t[0];let n=t[1];if(n.endsWith(".git")&&(n=n.slice(0,-4)),!A.test(r)||!A.test(n))return null;const a=t.slice(2),o=tt(a);return o===null?null:{owner:r,repo:n,branch:X,path:o||R}}function tt(e){if(e.length===0)return"";for(const t of e)if(t===".."||t==="."||!A.test(t))return null;return e.join("/")}const Ut="https://api.github.com";async function Ot(e){const t=`${Ut}/repos/${_(e.owner)}/${_(e.repo)}/contents/${Gt(e.path)}?ref=${encodeURIComponent(e.branch)}`,r=await fetch(t,{headers:{Accept:"application/vnd.github+json"}});if(!r.ok)throw r.status===404?new Error(`Folder not found (404): ${e.path}`):r.status===403?new Error("GitHub API rate limit reached (403). Try again in an hour or sign in via a future private-repo path."):new Error(`GitHub API error: ${r.status} ${r.statusText}`);const n=await r.json();if(!Array.isArray(n))throw new Error("Expected a folder listing — the path points to a file or unknown shape.");return n.map(Jt)}async function Wt(e){const t=await fetch(e);if(!t.ok)throw new Error(`Raw fetch failed: ${t.status} ${t.statusText}`);const r=await t.text();try{return JSON.parse(r)}catch(n){throw new Error(`Invalid JSON at ${e}: ${n.message}`)}}function _(e){return encodeURIComponent(e)}function Gt(e){return e.split("/").filter(t=>t.length>0).map(_).join("/")}function Jt(e){const t=e;return{name:typeof t.name=="string"?t.name:"",path:typeof t.path=="string"?t.path:"",sha:typeof t.sha=="string"?t.sha:"",type:typeof t.type=="string"?t.type:"file",downloadUrl:typeof t.download_url=="string"?t.download_url:null}}const Kt=8;async function Yt(e,t={}){const r=await Ot(e),{getCatalog:n}=await lt(async()=>{const{getCatalog:l}=await Promise.resolve().then(()=>Bt);return{getCatalog:l}},void 0),a=await n(e.id),o=(a==null?void 0:a.items)??[],i=Q(o,r),u=t.fetchRaw??Wt,d=Math.max(1,t.concurrency??Kt);let f=0;const b=i.toFetch.length,v=new Array(i.toFetch.length);let S=0;async function s(){var l;for(;;){const w=S++;if(w>=i.toFetch.length)return;const nt=i.toFetch[w];v[w]=await zt(nt,u),f+=1,(l=t.onProgress)==null||l.call(t,f,b)}}await Promise.all(Array.from({length:Math.min(d,b)},()=>s()));const p=new Map;for(const l of i.toKeep)p.set(l.name,l);for(const l of v)l&&p.set(l.name,l);const h={items:r.filter(l=>l.type==="file"&&l.name.toLowerCase().endsWith(".json")).map(l=>p.get(l.name)).filter(l=>!!l),lastRefreshed:Date.now()};return await Z(e.id,h),h}async function zt(e,t){const r={name:e.name,sha:e.sha,downloadUrl:e.downloadUrl??""};if(!e.downloadUrl)return{...r,error:"No download URL on folder listing"};let n;try{n=await t(e.downloadUrl)}catch(a){return{...r,error:`Fetch failed: ${a.message}`}}try{const a=G(n,{strict:!0});return{...r,scenarioName:a.name,scenarioId:a.id,stepCount:a.steps.length,scenarioJson:a}}catch(a){return{...r,error:`Invalid scenario: ${a.message}`}}}async function Vt(e,t,r={}){if(t.error)throw new Error(`Cannot play item with error: ${t.error}`);if(!t.scenarioJson)throw new Error("Cached item has no scenarioJson; refresh the catalog first.");const n=G(t.scenarioJson,{strict:!0}),a=`eph-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,8)}`,o={...n,id:a};return await dt(o,{kind:"github",repo:`${e.owner}/${e.repo}`,path:`${e.path}/${t.name}`,sha:t.sha}),await(r.handleStart??P)(o.id),o.id}function Zt(e,t){if(t.sources.length===0){e.innerHTML=Qt(t);return}e.innerHTML=Xt(t)}function Qt(e){return e.adding?`
      <div class="remote-empty" data-region="remote-empty">
        ${et(e)}
      </div>
    `:`
    <div class="remote-empty" data-region="remote-empty">
      <div class="remote-empty-icon" aria-hidden="true">📂</div>
      <p class="remote-empty-copy">${m(c("popup.remote.empty.copy")||"Connect a public GitHub repo to load shared manuscripts.")}</p>
      <button
        type="button"
        class="remote-add-cta"
        data-action="remote-add-open"
      >${m(c("popup.remote.add-cta")||"+ Add a GitHub source")}</button>
    </div>
  `}function Xt(e){return`
    <div class="remote-header" data-region="remote-header">
      <div class="remote-header-actions">
        <button
          type="button"
          class="remote-icon-btn"
          data-action="remote-add-open"
          title="${m(c("popup.remote.add-cta-aria")||"Add source")}"
          aria-label="${m(c("popup.remote.add-cta-aria")||"Add source")}"
        >+</button>
        <button
          type="button"
          class="remote-icon-btn"
          data-action="remote-refresh-all"
          title="${m(c("popup.remote.refresh-all-aria")||"Refresh all")}"
          aria-label="${m(c("popup.remote.refresh-all-aria")||"Refresh all")}"
        >↻</button>
      </div>
    </div>
    ${e.adding?et(e):""}
    <div class="remote-source-list" data-region="remote-source-list">
      ${e.sources.map(t=>te(t,e)).join("")}
    </div>
  `}function et(e){return`
    <form class="remote-add-form" data-region="remote-add-form">
      <input
        type="text"
        class="remote-add-input"
        data-region="remote-add-input"
        placeholder="${m(c("popup.remote.add-placeholder")||"github.com/owner/repo or owner/repo/path")}"
        autocomplete="off"
        spellcheck="false"
      />
      <div class="remote-add-actions">
        <button
          type="submit"
          class="remote-add-submit"
          data-action="remote-add-submit"
        >${m(c("popup.remote.add-submit")||"Add")}</button>
        <button
          type="button"
          class="remote-add-cancel"
          data-action="remote-add-cancel"
        >${m(c("common.cancel")||"Cancel")}</button>
      </div>
      ${e.addError?`<p class="remote-add-error" data-region="remote-add-error">${m(e.addError)}</p>`:""}
    </form>
  `}function te(e,t){const r=t.catalogs[e.id],n=t.loadingBySourceId[e.id];return`
    <section
      class="remote-source-card"
      data-region="remote-source-card"
      data-source-id="${m(e.id)}"
    >
      <header class="remote-source-header">
        <div class="remote-source-label">
          <span class="remote-source-icon" aria-hidden="true">📂</span>
          <span class="remote-source-title">${m(e.label)}</span>
          <span class="remote-source-path">· ${m(e.path)}</span>
        </div>
        <button
          type="button"
          class="remote-source-remove"
          data-action="remote-source-remove"
          data-source-id="${m(e.id)}"
          title="${m(c("popup.remote.remove-aria")||"Remove source")}"
          aria-label="${m(c("popup.remote.remove-aria")||"Remove source")}"
        >×</button>
      </header>
      ${n?`<div class="remote-progress" data-region="remote-progress">${m(c("popup.remote.progress")||"Loading")} ${n.done} / ${n.total}</div>`:""}
      ${ee(e,r)}
    </section>
  `}function ee(e,t){return t?t.items.length===0?`<p class="remote-source-empty">${m(c("popup.remote.source-empty")||"No manuscripts in this folder yet.")}</p>`:`
    <ul class="remote-catalog">
      ${t.items.map(r=>re(e,r)).join("")}
    </ul>
  `:`<p class="remote-source-empty">${m(c("popup.remote.source-never-refreshed")||"Click ↻ refresh to load this source.")}</p>`}function re(e,t){const r=!!t.error,n=t.scenarioName||t.name,a=typeof t.stepCount=="number"?` <span class="remote-catalog-steps">${t.stepCount} ${m(c("popup.remote.steps-suffix")||"steps")}</span>`:"";return`
    <li class="remote-catalog-item" data-region="remote-catalog-item">
      <button
        type="button"
        class="remote-play"
        data-action="remote-play"
        data-source-id="${m(e.id)}"
        data-item-name="${m(t.name)}"
        ${r?"disabled":""}
        title="${m(n)}"
        aria-label="${m(n)}"
      >▶</button>
      <span class="remote-catalog-name">${m(n)}</span>
      ${a}
      ${r?`<span class="remote-catalog-warn" title="${m(t.error)}">⚠ ${m(t.error)}</span>`:""}
    </li>
  `}function m(e){return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}async function ne(e){const t={sources:[],catalogs:{},loadingBySourceId:{},adding:!1,addError:null};async function r(){t.sources=await C();for(const s of t.sources){const p=await V(s.id);p&&(t.catalogs[s.id]=p)}}function n(){Zt(e,t)}async function a(s){t.loadingBySourceId[s.id]={done:0,total:0},n();try{const p=await Yt(s,{onProgress:(g,h)=>{t.loadingBySourceId[s.id]={done:g,total:h},n()}});t.catalogs[s.id]=p}catch(p){console.error("[manuscript/remote] refresh failed",p)}finally{delete t.loadingBySourceId[s.id],n()}}async function o(){await Promise.all(t.sources.map(s=>a(s)))}function i(){t.adding=!0,t.addError=null,n(),queueMicrotask(()=>{var s;(s=e.querySelector('[data-region="remote-add-input"]'))==null||s.focus()})}function u(){t.adding=!1,t.addError=null,n()}async function d(s){const p=Ft(s);if(!p){t.addError="Invalid URL. Expected github.com/owner/repo or owner/repo.",n();return}await new Promise(h=>{H(()=>h())});const g=await Y(p);t.sources=await C(),t.adding=!1,t.addError=null,n(),await a(g)}async function f(s){await z(s),delete t.catalogs[s],delete t.loadingBySourceId[s],t.sources=await C(),n()}async function b(s,p){var l;const g=t.sources.find(w=>w.id===s),h=(l=t.catalogs[s])==null?void 0:l.items.find(w=>w.name===p);if(!(!g||!h))try{await Vt(g,h)}catch(w){console.error("[manuscript/remote] play failed",w)}}const v=s=>{const p=s.target;if(!p)return;if(p.closest('[data-action="remote-add-open"]')){i();return}if(p.closest('[data-action="remote-add-cancel"]')){s.preventDefault(),u();return}if(p.closest('[data-action="remote-refresh-all"]')){o();return}const g=p.closest('[data-action="remote-source-remove"]');if(g){const l=g.getAttribute("data-source-id");l&&f(l);return}const h=p.closest('[data-action="remote-play"]');if(h){const l=h.getAttribute("data-source-id"),w=h.getAttribute("data-item-name");l&&w&&b(l,w);return}},S=s=>{var l;const p=s.target;if(!p||!((l=p.matches)!=null&&l.call(p,'[data-region="remote-add-form"]')))return;s.preventDefault();const g=e.querySelector('[data-region="remote-add-input"]'),h=(g==null?void 0:g.value.trim())??"";if(h.length===0){t.addError="Enter a GitHub URL or owner/repo",n();return}d(h)};return e.addEventListener("click",v),e.addEventListener("submit",S),await r(),n(),{refresh:o,destroy(){e.removeEventListener("click",v),e.removeEventListener("submit",S)}}}const D="studio",ae="studio-dark";function rt(e){return e.endsWith("-dark")}async function oe(){try{const t=(await chrome.storage.local.get(y.palette))[y.palette];if(typeof t=="string")return t}catch{}return D}function j(e){document.body.setAttribute("data-palette",e);const t=document.getElementById("palette-toggle");t==null||t.setAttribute("aria-pressed",rt(e)?"true":"false")}async function ie(){const e=document.body.getAttribute("data-palette")??D,t=rt(e)?D:ae;j(t);try{await chrome.storage.local.set({[y.palette]:t})}catch{}}document.addEventListener("DOMContentLoaded",()=>{ce()});async function ce(){if(se(),!T()&&await gt()==="detached"){await K();return}const e=document.getElementById("start-cta"),t=document.getElementById("help-link"),r=document.getElementById("scenarios"),n=document.getElementById("detach-btn"),a=document.getElementById("palette-toggle"),o=document.getElementById("import-link");j(await oe()),chrome.storage.onChanged.addListener((f,b)=>{var S;if(b!=="local")return;const v=(S=f[y.palette])==null?void 0:S.newValue;typeof v=="string"&&j(v)}),a==null||a.addEventListener("click",()=>{ie()});const i=document.querySelector('[data-region="brand-logo"]');i&&(i.innerHTML=W({height:20})),T()&&n&&(n.textContent=c("popup.detach.detached"),n.setAttribute("title",c("popup.detach.inline-title")),n.setAttribute("aria-label",c("popup.detach.inline-title"))),e==null||e.addEventListener("click",()=>{H(()=>{P(void 0,L)})}),o instanceof HTMLButtonElement&&It(o,{reloadList:L}),t==null||t.addEventListener("click",f=>{f.preventDefault(),chrome.tabs.create({url:"https://zendy00.github.io/manuscript-pages/"})}),r==null||r.addEventListener("click",f=>{Lt(f)}),n==null||n.addEventListener("click",()=>{yt()});const u=document.querySelector(".empty-state");u&&await Mt(u);const d=document.querySelector('[data-tab-panel="remote"]');d&&(d.innerHTML="",ne(d)),L()}function se(){for(const e of document.querySelectorAll("[data-i18n]")){const t=e.getAttribute("data-i18n");t&&(e.textContent=c(t))}for(const e of document.querySelectorAll("[data-i18n-aria]")){const t=e.getAttribute("data-i18n-aria");t&&e.setAttribute("aria-label",c(t))}for(const e of document.querySelectorAll("[data-i18n-title]")){const t=e.getAttribute("data-i18n-title");t&&e.setAttribute("title",c(t))}}
