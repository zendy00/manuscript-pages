const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-67M_Tuok.js","assets/chunk-3M7yL2Iv.js","assets/chunk-DbUxhscj.js","assets/chunk-ClheHCf9.js","assets/chunk-CzgJdJy3.js"])))=>i.map(i=>d[i]);
import{S as G,O,E as pi}from"./chunk-3M7yL2Iv.js";import{s as fi,g as Gc,S as Yc,a as vo,b as hi,c as Kc,d as Zc,e as Qc,m as mi,f as Jc,h as tl,i as el,j as Zo,k as Qo}from"./chunk-DbUxhscj.js";import{t as m}from"./chunk-ClheHCf9.js";import{g as gi,i as nl,a as rl,b as bi,p as ol,c as vi,s as al,d as il,w as sl,l as cl,e as ll,f as dl}from"./chunk-CzgJdJy3.js";const Yr="manuscript:mode-changed";let An="idle";function st(){return An}function I(t){if(t===An)return;const e=An;An=t,document.dispatchEvent(new CustomEvent(Yr,{detail:{prev:e,next:t}}))}function mt(t){const e=n=>t(n.detail);return document.addEventListener(Yr,e),()=>document.removeEventListener(Yr,e)}function yi(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),a=n*(1-e),i=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,d=0;switch(r){case 0:c=n,l=s,d=a;break;case 1:c=i,l=n,d=a;break;case 2:c=a,l=n,d=s;break;case 3:c=a,l=i,d=n;break;case 4:c=s,l=a,d=n;break;case 5:c=n,l=a,d=i;break}return[Math.round(c*255),Math.round(l*255),Math.round(d*255)]}function xi(t,e,n){const r=t/255,o=e/255,a=n/255,i=Math.max(r,o,a),s=Math.min(r,o,a),c=i-s;let l=0;return c!==0&&(i===r?l=(o-a)/c%6:i===o?l=(a-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:i===0?0:c/i,v:i}}function wi(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function ki(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(a=>a+a).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(a=>!Number.isFinite(a))?{h:0,s:1,v:1}:xi(n,r,o)}function Cr(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function Jo(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function ul(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const pl=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── PALETTE E — STUDIO-DARK ─────
   Cool slate dark, mirrors PALETTE D STUDIO. See design/dark-mode-design.md §4.1.
   Chroma ≤ 0.09 doctrine maintained (focus only allowed slight excess at 0.13). */
[data-palette="studio-dark"] {
  --c-bg:        oklch(0.16  0.012 245);
  --c-surface:   oklch(0.22  0.014 245);
  --c-surface-2: oklch(0.19  0.012 245);
  --c-text:      oklch(0.97  0.003 245);
  --c-text-mute: oklch(0.78  0.006 245);
  --c-text-soft: oklch(0.62  0.008 245);
  --c-border:    oklch(0.32  0.012 245);
  --c-border-strong: oklch(0.42 0.014 245);
  --c-primary:   oklch(0.70  0.09  245);
  --c-primary-h: oklch(0.78  0.09  245);
  --c-primary-fg: oklch(0.14  0.020 245);
  --c-tint:      oklch(0.32  0.045 245);
  --c-focus:     oklch(0.74  0.13  245);
}

/* ───── PALETTE F — INK-DARK ─────
   Warm-on-cool dark, mirrors PALETTE A INK. design/dark-mode-design.md §4.2.
   Absorbs \`08.DARK-MODE-TOKENS.md\` §1 (spotlight-editor) and §2 (launcher pill) tones. */
[data-palette="ink-dark"] {
  --c-bg:        oklch(0.14  0.015 250);
  --c-surface:   oklch(0.20  0.018 250);
  --c-surface-2: oklch(0.17  0.016 250);
  --c-text:      oklch(0.98  0.003  80);
  --c-text-mute: oklch(0.76  0.006  80);
  --c-text-soft: oklch(0.60  0.008  80);
  --c-border:    oklch(0.30  0.014 250);
  --c-border-strong: oklch(0.40 0.016 250);
  --c-primary:   oklch(0.66  0.06  250);
  --c-primary-h: oklch(0.74  0.07  250);
  --c-primary-fg: oklch(0.14  0.018 250);
  --c-tint:      oklch(0.30  0.05  250);
  --c-focus:     oklch(0.70  0.10  250);
}

/* ───── Dark-palette shared overrides ─────
   Shadows: alpha ~4× because black-on-black shadow is weak; pair with
   surface-lightness steps (--c-bg < --c-surface-2 < --c-surface) for elevation.
   Functional accents: lightness ↑ for contrast on dark surface (L≈0.22). */
[data-palette$="-dark"] {
  --shadow-sm:   0 1px 2px  rgb(0 0 0 / 0.40);
  --shadow-md:   0 2px 6px  rgb(0 0 0 / 0.45), 0 1px 2px rgb(0 0 0 / 0.35);
  --shadow-lg:   0 12px 28px rgb(0 0 0 / 0.55), 0 4px 8px rgb(0 0 0 / 0.40);
  --shadow-card: 0 1px 2px  rgb(0 0 0 / 0.35),
                 0 4px 10px rgb(0 0 0 / 0.40),
                 0 12px 24px rgb(0 0 0 / 0.50);

  --c-success: oklch(0.66 0.10 150);
  --c-warning: oklch(0.78 0.11  75);
  --c-error:   oklch(0.66 0.15  27);
  --c-info:    oklch(0.66 0.09 245);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function yt(){return pl.replace(/:root\s*\{/g,":host {").replace(/\[data-palette([^\]]*)\]\s*\{/g,":host([data-palette$1]) {")}const Si="studio",fl=["studio","ink","graphite","sepia","studio-dark","ink-dark"];function Ei(t){return typeof t=="string"&&fl.includes(t)}function Ai(t){return t.endsWith("-dark")}let he=null;const Kr=new Set;let ta=!1;async function hl(){if(he)return he;try{const e=(await chrome.storage.local.get(G.palette))[G.palette];if(Ei(e))return he=e,e}catch{}return Si}function Mi(){return he??Si}async function ml(t){he=t,$i(t);try{await chrome.storage.local.set({[G.palette]:t})}catch{}}async function gl(){const t=Mi(),e=Ai(t)?"studio":"studio-dark";return await ml(e),e}function Ct(t){Kr.add(new WeakRef(t)),t.setAttribute("data-palette",Mi()),hl().then(e=>{t.isConnected&&t.setAttribute("data-palette",e)}),bl()}function bl(){if(!ta){ta=!0;try{chrome.storage.onChanged.addListener((t,e)=>{var r;if(e!=="local")return;const n=(r=t[G.palette])==null?void 0:r.newValue;Ei(n)&&(he=n,$i(n))})}catch{}}}function $i(t){for(const e of[...Kr]){const n=e.deref();n&&n.isConnected?(n.setAttribute("data-palette",t),vl(n,t)):Kr.delete(e)}}function vl(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="palette-toggle"]');n&&n.setAttribute("aria-pressed",Ai(e)?"true":"false")}const yl=140,xl=140;function wl(){return`
    ${yt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${yl}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${xl}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function kl(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function Sl(){return[wl(),kl()].join(`
`)}const Zr="manuscript:scenario-changed",El=500,Al=5e3,y={scenario:null,currentStepIndex:0,saveTimer:null};function L(){return y.scenario}function B(){return y.currentStepIndex}function dt(){return y.scenario?y.scenario.steps[y.currentStepIndex]??null:null}function Ce(t){return document.addEventListener(Zr,t),()=>document.removeEventListener(Zr,t)}function N(){document.dispatchEvent(new CustomEvent(Zr)),Ml()}function X(){y.scenario&&(y.scenario.updatedAt=new Date().toISOString())}function yo(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function xo(){return{id:yo("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:Al,waitForNavigation:!1}}function Ml(){if(!y.scenario)return;y.saveTimer!==null&&window.clearTimeout(y.saveTimer);const t=y.scenario;y.saveTimer=window.setTimeout(()=>{y.saveTimer=null,fi(t).catch(e=>{console.error("[manuscript] save failed",e)})},El)}function lr(){y.saveTimer!==null&&(window.clearTimeout(y.saveTimer),y.saveTimer=null,y.scenario&&fi(y.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const $l=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],Ll=8,Tl=5;function Il(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const i=Qr(e.getAttribute("content"));i&&t.add(i)}const n=getComputedStyle(document.documentElement);for(const i of $l){const s=Qr(n.getPropertyValue(i));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:i,prop:s}of r)ea(t,i,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let i=0;i<o.length&&i<Tl;i++)ea(t,o[i]??null,"background-color");const a=Array.from(t).filter(Cl).slice(0,Ll);return{text:a,background:a}}function ea(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Qr(r);o&&t.add(o)}function Qr(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],a=e[3];return`#${r}${r}${o}${o}${a}${a}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=Dr(n[1]),a=Dr(n[2]),i=Dr(n[3]);return`#${Pr(o)}${Pr(a)}${Pr(i)}`}return null}function Dr(t){return Math.max(0,Math.min(255,Number(t)|0))}function Pr(t){return t.toString(16).padStart(2,"0")}function Cl(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const a=Math.max(n,r,o),i=Math.min(n,r,o);return!(a-i<12)}const Dl="'Asta Sans', sans-serif",Pl=6,Rl=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function Nl(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const a=o.trim();if(!a)continue;const i=Li(a);if(!i)continue;const s=i.toLowerCase();if(!Rl.has(s)&&!e.has(s)&&(e.add(s),n.push(zl(a)),n.length>=Pl))break}return n}function Ol(t){const e=Hl(t)??t;return e.length>14?`${e.slice(0,13)}…`:e}function Hl(t){return Li(t)}function Li(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function zl(t){return/asta\s*sans/i.test(t)?t:`${t}, ${Dl}`}function na(){lr();const t=Fl(),e=ql();y.scenario={schemaVersion:Yc,id:yo("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[xo()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},y.currentStepIndex=0,N()}function Fl(){try{const t=Il();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function ql(){try{return Nl()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function ra(t){lr();const e=await Gc(t);return e?(y.scenario=e,y.currentStepIndex=0,N(),!0):!1}function Ti(t){lr(),y.scenario=t,y.currentStepIndex=0,N()}function _l(t){if(!y.scenario)return;const e=t.trim();!e||e===y.scenario.name||(y.scenario.name=e,y.scenario.updatedAt=new Date().toISOString(),N())}function Ii(){lr(),y.scenario=null,y.currentStepIndex=0,N()}function oa(t={}){if(!y.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>y.scenario.steps.length?y.scenario.steps.length:t.insertIndex;return y.scenario.steps.splice(e,0,xo()),X(),y.currentStepIndex=e,N(),y.currentStepIndex}function me(t,e){if(!y.scenario)return;const n=y.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(X(),N())}function Bl(t){const e=dt();!e||!y.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,X(),N())}function Ul(t){y.scenario&&(t<0||t>=y.scenario.steps.length||(y.scenario.steps.splice(t,1),y.scenario.steps.length===0?(y.scenario.steps.push(xo()),y.currentStepIndex=0):y.currentStepIndex>=y.scenario.steps.length?y.currentStepIndex=y.scenario.steps.length-1:t<y.currentStepIndex&&(y.currentStepIndex-=1),X(),N()))}function mb(t){const e=dt();if(!e||!y.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,X(),N()}function Dt(t){y.scenario&&(t<0||t>=y.scenario.steps.length||t!==y.currentStepIndex&&(y.currentStepIndex=t,N()))}function jl(t,e){if(!y.scenario||t===e||t<0||t>=y.scenario.steps.length||e<0||e>=y.scenario.steps.length)return;const[n]=y.scenario.steps.splice(t,1);n&&(y.scenario.steps.splice(e,0,n),y.currentStepIndex===t?y.currentStepIndex=e:t<y.currentStepIndex&&e>=y.currentStepIndex?y.currentStepIndex-=1:t>y.currentStepIndex&&e<=y.currentStepIndex&&(y.currentStepIndex+=1),X(),N())}function Wl(t){const e=dt();!e||!y.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),X(),N())}function tn(t){const e=dt();!e||!y.scenario||(e.annotations.push(t),X(),N())}function Ci(t){const e=dt();!e||!y.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),X(),N())}function R(t,e){const n=dt();!n||!y.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),X(),N())}function Di(){var t;return((t=dt())==null?void 0:t.annotations)??[]}function P(t){return Di().find(e=>e.id===t)}const Jr=100,Dn=2e3;function Pi(t,e){const n=t+1;if(e===null)return Array(n).fill(Dn);const r=Math.max(n*Jr,e),o=Math.floor(r/n),a=Array(n).fill(o);return a[n-1]=r-o*(n-1),a}const Vl=100;function Xl(t,e,n,r,o,a=Vl){const i=t.indexOf(n);if(i<0)return{dwells:[...e]};const s=new Set(r);let c=i,l=i;if(s.has(n)){for(;c>0;){const b=t[c-1];if(!b||!s.has(b))break;c--}for(;l<t.length-1;){const b=t[l+1];if(!b||!s.has(b))break;l++}}const d=c,p=l+1,u=[...e],f=u[d]??0,h=u[p]??0;if(o===-1){if(f-a<Jr)return{dwells:u};u[d]=f-a,u[p]=h+a}else{if(h-a<Jr)return{dwells:u};u[d]=f+a,u[p]=h-a}return{dwells:u}}function Gl(t,e,n,r){const o=new Set(n),a=e[0]??Dn,i=t.map((u,f)=>({sub:u,dwell:e[f+1]??Dn})),s=i.filter(u=>o.has(u.sub));if(s.length===0)return{subs:[...t],dwells:[...e]};const c=i.filter(u=>!o.has(u.sub)),l=Math.max(0,Math.min(t.length,r));let d=0;for(let u=0;u<l;u++){const f=t[u];f!==void 0&&!o.has(f)&&d++}const p=[...c.slice(0,d),...s,...c.slice(d)];return{subs:p.map(u=>u.sub),dwells:[a,...p.map(u=>u.dwell)]}}function Yl(t){const e=dt();if(!e||!y.scenario)return null;const n={id:yo("sub"),selectors:t.selectors,thumbnailDataUrl:t.thumbnailDataUrl,pickedAtUrl:t.pickedAtUrl},r=e.subElements??[];e.subElements=[...r,n];const o=e.subElements.length;return e.autoAdvanceMs===null&&(e.autoAdvanceMs=(o+1)*Dn),e.subDwellsMs=Pi(o,e.autoAdvanceMs),X(),N(),n}function Kl(t,e){var a;if(!y.scenario)return;const n=y.scenario.steps.find(i=>i.id===t);if(!n||!((a=n.subElements)!=null&&a.length))return;const r=new Set(e),o=n.subElements.filter(i=>!r.has(i.id));o.length!==n.subElements.length&&(o.length===0?(delete n.subElements,delete n.subDwellsMs):(n.subElements=o,n.subDwellsMs=Pi(o.length,n.autoAdvanceMs)),X(),N())}function Zl(t,e,n){if(!y.scenario)return;const r=y.scenario.steps.find(i=>i.id===t);if(!(r!=null&&r.subElements))return;const o=r.subElements.findIndex(i=>i.id===e);if(o<0)return;const a=r.subElements[o];a&&(r.subElements[o]={...a,...n},X(),N())}function Ql(t,e,n,r){if(!y.scenario)return;const o=y.scenario.steps.find(s=>s.id===t);if(!(o!=null&&o.subElements))return;const a=o.subElements.findIndex(s=>s.id===e);if(a<0)return;const i=o.subElements[a];i&&(o.subElements[a]={...i,selectors:n,pickedAtUrl:r,thumbnailDataUrl:null},X(),N())}function aa(t,e,n){if(!y.scenario)return;const r=y.scenario.steps.find(l=>l.id===t);if(!r||!r.subElements||!r.subDwellsMs||e.length===0)return;const o=r.subElements.map(l=>l.id),a=Gl(o,r.subDwellsMs,e,n),i=new Map(r.subElements.map(l=>[l.id,l])),s=[];for(const l of a.subs){const d=i.get(l);d&&s.push(d)}s.length===r.subElements.length&&s.every((l,d)=>{var p,u;return l.id===((u=(p=r.subElements)==null?void 0:p[d])==null?void 0:u.id)})||(r.subElements=s,r.subDwellsMs=a.dwells,X(),N())}function Ri(t,e,n,r){if(!y.scenario)return;const o=y.scenario.steps.find(s=>s.id===t);if(!(o!=null&&o.subElements)||!o.subDwellsMs)return;const a=o.subElements.map(s=>s.id),i=Xl(a,o.subDwellsMs,e,n,r);i.dwells.every((s,c)=>{var l;return s===((l=o.subDwellsMs)==null?void 0:l[c])})||(o.subDwellsMs=i.dwells,X(),N())}function Jl(t,e){if(!y.scenario)return;const n=e.trim();if(!n)return;const r=y.scenario.customColors??{},o=r[t]??[];o.includes(n)||(y.scenario.customColors={...r,[t]:[...o,n]},X(),N())}function td(t,e){if(!y.scenario||!y.scenario.customColors)return;const n=y.scenario.customColors[t];!n||!n.includes(e)||(y.scenario.customColors={...y.scenario.customColors,[t]:n.filter(r=>r!==e)},X(),N())}function ed(){return`
    <style>${Sl()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${nd()}
      ${rd()}
      ${od()}
      ${ad()}
    </div>
  `}function nd(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function rd(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function od(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function ad(){var a,i;const t=L(),e=((a=t==null?void 0:t.customColors)==null?void 0:a.text)??[],n=((i=t==null?void 0:t.customColors)==null?void 0:i.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${pn(s)}" style="background: ${pn(s)}" aria-label="Use ${pn(s)}" title="${pn(s)}"></button>`).join("")}</div>
    </div>
  `}function pn(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function id(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let a=n.left;a+r.width>window.innerWidth-8&&(a=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,a)}px`}let it=null,j=null,Ft=0,Qt=1,Jt=1,qt=null;function sd(t){te(),qt=t.onConfirm;const e=ki(t.initialColor);Ft=e.h,Qt=e.s,Jt=e.v,it=document.createElement("div"),it.setAttribute("data-manuscript","ui"),Ct(it),it.style.cssText=["position: fixed",`z-index: ${O+7}`,"pointer-events: auto"].join("; "),j=it.attachShadow({mode:"open"}),j.innerHTML=ed(),ld(),document.body.appendChild(it),id(it,t.anchor),en(),document.addEventListener("mousedown",Oi,!0),document.addEventListener("keydown",Hi,!0)}function te(){it&&(document.removeEventListener("mousedown",Oi,!0),document.removeEventListener("keydown",Hi,!0),it.remove(),it=null,j=null,qt=null)}function cd(){return it!==null}function en(){if(!j)return;const t=j.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${Ft}deg, 100%, 50%)`);const e=j.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Qt*100}%`,e.style.top=`${(1-Jt)*100}%`);const n=j.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${Ft/360*100}%`);const[r,o,a]=yi(Ft,Qt,Jt),i=wi(r,o,a),s=j.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${a})`);const c=j.querySelector('[data-region="hex"]');c&&(c.textContent=i),j.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===it&&j.activeElement===l)return;const d=l.dataset.channel;d==="r"?l.value=String(r):d==="g"?l.value=String(o):d==="b"&&(l.value=String(a))})}function Ni(){const[t,e,n]=yi(Ft,Qt,Jt);return wi(t,e,n)}function ld(){if(!j)return;const t=j.querySelector('[data-region="sv"]');t&&Jo(t,n=>dd(t,n));const e=j.querySelector('[data-region="hue"]');e&&Jo(e,n=>ud(e,n)),j.addEventListener("input",n=>{var c,l,d;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Cr((c=j.querySelector('[data-channel="r"]'))==null?void 0:c.value),a=Cr((l=j.querySelector('[data-channel="g"]'))==null?void 0:l.value),i=Cr((d=j.querySelector('[data-channel="b"]'))==null?void 0:d.value),s=xi(o,a,i);Ft=s.h,Qt=s.s,Jt=s.v,en()}),j.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),a=o==null?void 0:o.getAttribute("data-action");if(a==="confirm")qt==null||qt(Ni()),te();else if(a==="eyedrop")ul(ia);else if(a==="recent"){const i=o==null?void 0:o.getAttribute("data-color");i&&ia(i)}})}function ia(t){const e=ki(t);Ft=e.h,Qt=e.s,Jt=e.v,en()}function dd(t,e){const n=t.getBoundingClientRect();Qt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Jt=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),en()}function ud(t,e){const n=t.getBoundingClientRect();Ft=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,en()}function Oi(t){if(!it)return;const e=t.target;e instanceof HTMLElement&&it.contains(e)||te()}function Hi(t){t.key==="Escape"?(t.preventDefault(),te()):t.key==="Enter"&&(t.preventDefault(),qt==null||qt(Ni()),te())}const fn=8,ie=6,zi=32,sa=16,hn=4,Fi=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function ca(t,e,n,r){let{x:o,y:a,width:i,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,i-=n):(t==="ne"||t==="e"||t==="se")&&(i+=n),t==="nw"||t==="n"||t==="ne"?(a+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),i<ie&&(o=e.x+e.width-ie,i=ie),s<ie&&(a=e.y+e.height-ie,s=ie),{x:o,y:a,width:i,height:s}}function qi(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const a of t)a.x<e&&(e=a.x),a.y<n&&(n=a.y),a.x>r&&(r=a.x),a.y>o&&(o=a.y);return{x:e,y:n,width:r-e,height:o-n}}function pd(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const $={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},_="http://www.w3.org/2000/svg";function fd(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const a=r.tagName.toLowerCase(),i=r.parentElement,s=r.tagName;if(i){const c=Array.from(i.children).filter(l=>{var d;return l.tagName===s&&!((d=l.matches)!=null&&d.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${a}:nth-of-type(${l})`)}else n.unshift(a)}else n.unshift(a);r=i,o++}return n.join(" > ")}function hd(t,e=document,n=8){const r=[];let o=t,a=0;for(;o&&o!==document.body&&a<n;){const i=o.tagName.toLowerCase(),s=o.parentElement,c=o.tagName;if(s){const d=Array.from(s.children).filter(p=>{var u;return p.tagName===c&&!((u=p.matches)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length>1){const p=d.indexOf(o)+1;r.unshift(`${i}:nth-of-type(${p})`)}else r.unshift(i)}else r.unshift(i);const l=r.join(" > ");try{const d=Array.from(e.querySelectorAll(l)).filter(p=>{var u;return!((u=p.closest)!=null&&u.call(p,'[data-manuscript="ui"]'))});if(d.length===1&&d[0]===t)return l}catch{}o=s,a++}return r.join(" > ")}function wo(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function md(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const gd=["data-testid","data-test","id","aria-label"];function bd(t){for(const e of gd){const n=t.getAttribute(e);if(n&&n.length>0){const r=`[${e}="${md(n)}"]`;try{const o=Array.from(document.querySelectorAll(r)).filter(a=>{var i;return!((i=a.closest)!=null&&i.call(a,'[data-manuscript="ui"]'))});if(o.length===1&&o[0]===t)return{kind:"stable-attr",cssSelector:r}}catch{}}}return{kind:"stable-attr",cssSelector:hd(t)}}function Pn(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!wo(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function vd(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?fd(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Rn(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!wo(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function yd(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const a of Array.from(r.children)){if(a===t)continue;const i=(a.textContent??"").trim();if(i.length>0&&i.length<60&&n.push(i),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function Nn(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||wo(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const a=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>a.includes(c))?n:null}function xd(t){return{layer1:bd(t),layer2:vd(t),layer3:yd(t)}}function wd(t,e){const n=e.ownerDocument;return n?Pn(t.layer1,n)===e||Rn(t.layer2,n)===e||Nn(t.layer3,n)===e:!1}function Se(t){var e;return((e=to(t))==null?void 0:e.el)??null}function to(t){const e=_i(t.framePath);if(!e)return null;const n=Pn(t.layer1,e);if(n)return{el:n,layer:1};const r=Rn(t.layer2,e);if(r)return{el:r,layer:2};const o=Nn(t.layer3,e);return o?{el:o,layer:3}:null}function _i(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function kd(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function ot(){const t=dt();if(!t||!t.selectors)return null;try{const e=Se(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function Sd(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function dr(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function Ed(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function ur(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function Bi(t){if(!t.bounds)return t;const e=ot();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function Ad(t){if(!t.points)return t;const e=ot();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function Md(){document.removeEventListener("mousemove",ko,!0),document.removeEventListener("mouseup",So,!0),document.removeEventListener("keydown",ji,!0)}function $d(){document.addEventListener("keydown",ji,!0)}function Ld(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=P($.activeId);if(!n||n.kind!=="shape")return;const r=dr(n,ot());$.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},pr()}function Td(t){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const e=P($.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;$.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},pr()}function Ui(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=P($.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,a=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;$.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:a},pr()}function Id(t,e){if(!$.activeId)return;t.stopPropagation(),t.preventDefault();const n=P($.activeId);if(!n||n.kind!=="freedraw")return;const r=ur(n,ot()),o=qi(r);!o||o.width===0||o.height===0||($.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(a=>({...a}))},pr())}function pr(){document.addEventListener("mousemove",ko,!0),document.addEventListener("mouseup",So,!0)}function ko(t){const{activeId:e,dragState:n}=$;if(!e||!n)return;t.preventDefault();const r=P(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,a=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const i=ca(n.handle,n.startBounds,o,a);R(e,Bi({bounds:i}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const i=n.startBounds,s=ca(n.handle,i,o,a),c=i.width===0?1:s.width/i.width,l=i.height===0?1:s.height/i.height,d=n.startPoints.map(p=>({x:s.x+(p.x-i.x)*c,y:s.y+(p.y-i.y)*l}));R(e,Ad({points:d}))}else if(n.kind==="rotate"){const i=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(i-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?R(e,{rotate:s}):r.kind==="freedraw"?R(e,{rotate:s}):r.kind==="text"&&R(e,{rotate:s})}}function So(){document.removeEventListener("mousemove",ko,!0),document.removeEventListener("mouseup",So,!0),$.dragState=null}function ji(t){var o;const{activeId:e}=$;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Ci(e);return}if(t.key.startsWith("Arrow")){const a=P(e);if(!a||a.kind!=="shape")return;const i=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-i:t.key==="ArrowRight"?i:0,c=t.key==="ArrowUp"?-i:t.key==="ArrowDown"?i:0;if(s!==0||c!==0){t.preventDefault();const l=dr(a,ot());R(e,Bi({bounds:{...a.bounds,x:l.x+s,y:l.y+c}}))}}}}function Wi(t,e,n,r,o){const a=document.createElementNS(_,"rect");return a.setAttribute("x",String(t-fn/2)),a.setAttribute("y",String(e-fn/2)),a.setAttribute("width",String(fn)),a.setAttribute("height",String(fn)),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),a.style.cursor=r,a.style.pointerEvents="auto",a.setAttribute("pointer-events","all"),a.addEventListener("mousedown",i=>o(i,n)),a}function Vi(t,e,n){const r=document.createElementNS(_,"g"),o=e-18,a=e-zi,i=12,s=document.createElementNS(_,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(_,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(a+1)),c.setAttribute("r",String(i)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(_,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(a)),l.setAttribute("r",String(i)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const d=t-8,p=a-8,u=document.createElementNS(_,"path");u.setAttribute("d",`M ${d+4} ${p+11} A 5 5 0 1 1 ${d+11} ${p+4}`),u.setAttribute("fill","none"),u.setAttribute("stroke","oklch(0.48 0.085 245)"),u.setAttribute("stroke-width","1.5"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.style.pointerEvents="none",r.appendChild(u);const f=document.createElementNS(_,"path");return f.setAttribute("d",`M ${d+11} ${p+1.5} L ${d+14} ${p+4} L ${d+11} ${p+6.5} Z`),f.setAttribute("fill","oklch(0.48 0.085 245)"),f.setAttribute("stroke","oklch(0.48 0.085 245)"),f.setAttribute("stroke-width","1.5"),f.setAttribute("stroke-linejoin","round"),f.style.pointerEvents="none",r.appendChild(f),l.addEventListener("mousedown",h=>n(h)),r}function Eo(t,e){const n=document.createElementNS(_,"g"),r=t.x-sa,o=t.y-sa;return n.appendChild(Cd(r,o,e)),n}function Cd(t,e,n){const r=document.createElementNS(_,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(_,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const a=document.createElementNS(_,"circle");a.setAttribute("cx",String(t)),a.setAttribute("cy",String(e)),a.setAttribute("r","12"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.92 0.008 240)"),a.setAttribute("stroke-width","1"),r.appendChild(a);const i=t-6,s=e-6,c=document.createElementNS(_,"path");return c.setAttribute("d",[`M ${i+1.5} ${s+3.5} L ${i+10.5} ${s+3.5}`,`M ${i+4.5} ${s+3.5} L ${i+4.5} ${s+2} L ${i+7.5} ${s+2} L ${i+7.5} ${s+3.5}`,`M ${i+3} ${s+3.5} L ${i+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${i+4.3} ${s+11} L ${i+7.7} ${s+11} A 0.8 0.8 0 0 0 ${i+8.5} ${s+10.5} L ${i+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function Ao(t){const e=document.createElementNS(_,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function fr(){const{host:t,activeId:e,activeMode:n}=$;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=P(e);if(!r){eo();return}if(n==="freedraw"&&r.kind==="freedraw"){Nd(t,r);return}if(n==="text"&&r.kind==="text"){Rd(t,r);return}if(r.kind!=="shape"){eo();return}Dd(t,r)}function Dd(t,e){const n=dr(e,ot()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,a=r.x+r.width/2,i=r.y+r.height/2,s=document.createElementNS(_,"g");o&&s.setAttribute("transform",`rotate(${o} ${a} ${i})`),s.appendChild(Ao(r));for(const c of Fi){const{x:l,y:d}=c.offset(r);s.appendChild(Wi(l,d,c.name,c.cursor,Ld))}s.appendChild(Pd(r)),t.appendChild(s),t.appendChild(Eo(r,Mo))}function Pd(t){const e=t.x+t.width/2,n=t.y-zi,r=document.createElementNS(_,"g"),o=document.createElementNS(_,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const a=document.createElementNS(_,"g");a.style.cursor="grab",a.style.pointerEvents="auto",a.setAttribute("pointer-events","all");const i=document.createElementNS(_,"circle");i.setAttribute("cx",String(e)),i.setAttribute("cy",String(n)),i.setAttribute("r","9"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),a.appendChild(i);const s=document.createElementNS(_,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",a.appendChild(s),a.addEventListener("mousedown",c=>Td(c)),r.appendChild(a),r}function Rd(t,e){const n=pd(e.id);if(!n)return;const r=Xi(n),o=r.x+r.width/2,a=r.y+r.height/2;t.appendChild(Ao(r)),t.appendChild(Vi(o,r.y,i=>Ui(i,()=>({x:o,y:a})))),t.appendChild(Eo(r,Mo))}function Nd(t,e){const n=ur(e,ot()),r=qi(n);if(!r)return;const o=Xi(r),a=o.x+o.width/2,i=o.y+o.height/2;t.appendChild(Ao(o));for(const s of Fi){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(Wi(c,l,s.name,s.cursor,Id))}t.appendChild(Vi(a,o.y,s=>Ui(s,()=>({x:a,y:i})))),t.appendChild(Eo(o,Mo))}function Xi(t){return{x:t.x-hn,y:t.y-hn,width:t.width+hn*2,height:t.height+hn*2}}function Mo(){const t=$.activeId;t&&Ci(t)}function Od(t){const e=P(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const a=document.querySelectorAll(o);if(a.length===0)return;const i=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;a.forEach(s=>{s.style.animation=""}),a[0].getBoundingClientRect(),a.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${i}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function Hd(t){const e=P(t);!e||e.kind!=="shape"||($.activeId=t,$.activeMode="shape",$o(),fr())}function zd(t){const e=P(t);!e||e.kind!=="freedraw"||($.activeId=t,$.activeMode="freedraw",$o(),fr())}function Fd(t){const e=P(t);!e||e.kind!=="text"||($.activeId=t,$.activeMode="text",$o(),fr())}function eo(){var t;$.host&&(Md(),(t=$.unsubscribeScenario)==null||t.call($),$.unsubscribeScenario=null,$.host.remove(),$.host=null,$.activeId=null,$.activeMode="shape",$.dragState=null)}function qd(t){return $.host!==null&&t!==null&&$.host.contains(t)}function $o(){if($.host)return;const t=document.createElementNS(_,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),$.host=t,$d(),$.unsubscribeScenario=Ce(fr)}const _d=400,Bd=0;function Ud(t){return{kind:t,durationMs:_d,delayMs:Bd}}function jd(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const la=10,Wd=46,Gi=12,Yi=36,Ki=0,Zi=20,Vd=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],Xd=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],da=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}];function Gd(t){return!t||t.length===0?[...da]:[...t.map(e=>({label:Ol(e),value:e})),...da]}const Yd=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],M={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function wt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Qi(t){const e=M.activeId;if(!e)return;const n=P(e);n&&(n.kind==="text"?R(e,{style:{...n.style,color:t}}):n.kind==="shape"?R(e,{stroke:t}):n.kind==="freedraw"&&R(e,{stroke:t}))}function Ji(t){const e=M.activeId;if(!e)return;const n=P(e);n&&(n.kind==="text"?R(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&R(e,{fill:t}))}function ts(t){const e=M.activeId;if(!e)return;const n=P(e);!n||n.kind!=="text"||R(e,{style:{...n.style,borderColor:t}})}function Kd(t){const e=M.activeId;if(!e)return;const n=P(e);!n||n.kind!=="text"||R(e,{style:{...n.style,fontFamily:t}})}function Zd(t){const e=M.activeId;if(!e)return;const n=P(e);!n||n.kind!=="text"||R(e,{style:{...n.style,fontSize:t}})}function Qd(){const t=M.activeId;if(!t)return;const e=P(t);!e||e.kind!=="text"||R(t,{style:{...e.style,bold:!e.style.bold}})}function Jd(){const t=M.activeId;if(!t)return;const e=P(t);!e||e.kind!=="text"||R(t,{style:{...e.style,italic:e.style.italic!==!0}})}function tu(t){const e=M.activeId;e&&R(e,{entryAnimation:t==="none"?void 0:Ud(t)})}function eu(t){const e=M.activeId;if(!e)return;const n=P(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?R(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?R(e,{fillOpacity:r}):n.kind==="freedraw"&&R(e,{strokeOpacity:r})}function nu(t){const e=M.activeId;if(!e)return;const n=P(e);n&&(n.kind==="shape"?R(e,{strokeWidth:t}):n.kind==="freedraw"&&R(e,{strokeWidth:t}))}function ru(){const{shadow:t}=M;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=i=>{r&&Rr(e,i.clientX)},a=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",a,!0)};n.addEventListener("mousedown",i=>{r=!0,Rr(e,i.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0),i.preventDefault()}),e.addEventListener("mousedown",i=>{const s=i.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(Rr(e,i.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",a,!0))})}function Rr(t,e){const n=t.getBoundingClientRect();eu(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function no(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function ou(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function Nr(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function Or(t,e,n){var l,d,p;const r=M.swatchMode==="muted"?Vd:Xd,o=[];if(n&&(t==="bg"||t==="border")){const u=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${u}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let u=0;u<r.length;u++){const f=r[u];if(!f)continue;const h=u===1,b=Nr(e,f.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${f.resolved}" style="background:${f.resolved}" aria-pressed="${b}" title="${t} ${f.resolved}"></button>
    `)}const a=L(),i=(t==="text"||t==="border"?(l=a==null?void 0:a.siteColors)==null?void 0:l.text:(d=a==null?void 0:a.siteColors)==null?void 0:d.background)??[];for(const u of i){const f=Nr(e,u);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${wt(u)}" style="background:${wt(u)}" aria-pressed="${f}" title="Site color ${wt(u)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((p=a==null?void 0:a.customColors)==null?void 0:p[s])??[];for(const u of c){const f=Nr(e,u);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${wt(u)}" style="background:${wt(u)}" aria-pressed="${f}" title="Custom ${wt(u)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${wt(u)}" title="Remove" aria-label="Remove color ${wt(u)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function Lo(){const{shadow:t,activeId:e,activeKind:n}=M;if(!t||!e||!n)return;const r=P(e);if(!r||r.kind==="arrow")return;const o=r,a=t.querySelector('[data-region="caption"]');a&&(a.textContent=uu(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(i=>{const s=i.getAttribute("data-mode");i.setAttribute("aria-pressed",String(s===M.swatchMode))}),au(t,n),iu(t,n,o),su(t,n,o),cu(t,n,o),lu(t,o),du(t,o)}function au(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const a=t.querySelector('[data-region="width-row"]'),i=e==="shape"||e==="freedraw";a&&(a.hidden=!i);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const d=t.querySelector('[data-region="bg-label"]');d&&(d.textContent=e==="text"?"Bg":"Fill")}function iu(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const a=t.querySelector('[data-region="bold"]');a&&a.setAttribute("aria-pressed",String(n.style.bold));const i=t.querySelector('[data-region="italic"]');i&&i.setAttribute("aria-pressed",String(n.style.italic===!0))}function su(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),a=n.strokeWidth;r&&(r.value=String(a)),o&&(o.textContent=String(a))}function cu(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),a=t.querySelector('[data-region="border-swatches"]'),i=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=no(n,"text"),l=no(n,"bg");if(r&&(r.innerHTML=Or("text",c,!1)),o&&!(i!=null&&i.hidden)&&(o.innerHTML=Or("bg",l,e==="text")),a&&!(s!=null&&s.hidden)&&n.kind==="text"){const d=n.style.borderColor??"#000000";a.innerHTML=Or("border",d,!0)}}function lu(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=jd(e))}function du(t,e){const n=Math.round(ou(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),a=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),a&&(a.textContent=`${n}%`)}function uu(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function pu(t){const{shadow:e,host:n}=M;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>fu(o)),e.addEventListener("change",o=>hu(o)),e.addEventListener("input",o=>mu(o)),ru(),document.addEventListener("mousedown",o=>bu(o,t),!0),document.addEventListener("keydown",o=>vu(o,t),!0)}function fu(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(M.swatchMode=c,Lo());return}if(e.closest('[data-region="bold"]'))return Qd();if(e.closest('[data-region="italic"]'))return Jd();if(e.closest('[data-region="effect-play"]')){M.activeId&&Od(M.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return Qi(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return Ji(o.getAttribute("data-value")??"");const a=e.closest('[data-swatch="border"]');if(a)return ts(a.getAttribute("data-value")??"");const i=e.closest('[data-action="more-colors"]');if(i instanceof HTMLElement)return gu(i);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&td(c==="text"||c==="border"?"text":"background",l)}}function hu(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Kd(e.value):e.dataset.region==="effect"&&tu(e.value))}function mu(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(Gi,Math.min(Yi,Number(e.value)||16));Zd(n)}else if(e.dataset.region==="width"){const n=Math.max(Ki,Math.min(Zi,Number(e.value)||0));nu(n)}}}function gu(t){const{activeId:e,activeKind:n}=M;if(!e||!n)return;const r=P(e);if(!r||r.kind==="arrow")return;const o=r,a=t.getAttribute("data-slot");if(!a)return;const i=no(o,a)||"#ffffff";sd({anchor:t,initialColor:i,onConfirm:s=>{Jl(a==="text"||a==="border"?"text":"background",s),a==="text"?Qi(s):a==="border"?ts(s):Ji(s)}})}function bu(t,e){const{host:n,activeAnchorSelector:r}=M,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||qd(o)||cd()||r&&o instanceof Element&&o.closest(r)||(e(),te())}function vu(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function es(t){const{host:e}=M;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-la-Wd;o<8&&(o=r.bottom+la);const a=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${a}px`}function yu(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function xu(t,e){t==="text"?Fd(e):t==="shape"?Hd(e):zd(e)}function wu(){return`
    ${yt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function ku(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function Su(){return[wu(),ku()].join(`
`)}function Eu(){return`
    <style>${Su()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${Au()}
      ${Mu()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${$u()}
      <div class="divider"></div>
      ${Lu()}
      ${Tu()}
      ${Iu()}
      ${Cu()}
    </div>
  `}function Au(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function Mu(){var e;return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Gd((e=L())==null?void 0:e.siteFonts).map(n=>`<option value="${wt(n.value)}" style="font-family: ${wt(n.value)};">${n.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${Gi}" max="${Yi}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function $u(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function Lu(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${Ki}" max="${Zi}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function Tu(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Yd.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function Iu(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function Cu(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function To(t,e,n){P(t)&&(M.activeId=t,M.activeKind=n,M.activeAnchorSelector=yu(n,t),M.host||Ou(),Lo(),es(e),xu(n,t))}function Io(){var t;M.host&&((t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,te(),eo(),M.host.remove(),M.host=null,M.shadow=null,M.activeId=null,M.activeKind=null,M.activeAnchorSelector=null)}function Du(){return M.activeId}function Pu(t,e){To(t,e,"text")}function ns(){Io()}function Ru(t,e){To(t,e,"shape")}function Nu(t,e){To(t,e,"freedraw")}function Ou(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Ct(t),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=Eu(),M.host=t,M.shadow=e,document.body.appendChild(t),pu(Io),M.unsubscribeScenario=Ce(Hu)}function Hu(){const{activeId:t,host:e,activeAnchorSelector:n}=M;if(!t||!e)return;if(!P(t)){Io();return}if(Lo(),n){const o=document.querySelector(n);o&&es(o)}}const At=20;let On=null,ua=!1;function zu(){ua||(ua=!0,document.addEventListener("keydown",_u,!0)),Fu()}async function Fu(){try{const e=(await chrome.storage.local.get(G.annotationClipboard))[G.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(On=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function qu(t){try{await chrome.storage.local.set({[G.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function _u(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||st()!=="replay"&&(Bu()||(e==="c"?Uu(t):ju(t)))}function Bu(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function Uu(t){const e=Du();if(!e)return;const n=P(e);n&&(On=n,qu(n),t.preventDefault())}function ju(t){if(!On||!dt())return;const e=Wu(On);tn(e),t.preventDefault()}function Wu(t){switch(t.kind){case"text":return Vu(t);case"shape":return Xu(t);case"freedraw":return Gu(t);case"arrow":return Yu(t)}}function Vu(t){return{...t,id:hr("text"),position:{x:t.position.x+At,y:t.position.y+At},style:{...t.style}}}function Xu(t){return{...t,id:hr("shape"),bounds:{...t.bounds,x:t.bounds.x+At,y:t.bounds.y+At}}}function Gu(t){return{...t,id:hr("freedraw"),points:t.points.map(e=>({x:e.x+At,y:e.y+At}))}}function Yu(t){return{...t,id:hr("arrow"),from:{x:t.from.x+At,y:t.from.y+At},to:{x:t.to.x+At,y:t.to.y+At}}}function hr(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Hr(t,e,n){if(t&&t.length){const[r,o]=e,a=Math.PI/180*n,i=Math.cos(a),s=Math.sin(a);for(const c of t){const[l,d]=c;c[0]=(l-r)*i-(d-o)*s+r,c[1]=(l-r)*s+(d-o)*i+o}}}function Ku(t,e){return t[0]===e[0]&&t[1]===e[1]}function Zu(t,e,n,r=1){const o=n,a=Math.max(e,.1),i=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of i)Hr(l,s,o);const c=(function(l,d,p){const u=[];for(const x of l){const S=[...x];Ku(S[0],S[S.length-1])||S.push([S[0][0],S[0][1]]),S.length>2&&u.push(S)}const f=[];d=Math.max(d,.1);const h=[];for(const x of u)for(let S=0;S<x.length-1;S++){const z=x[S],H=x[S+1];if(z[1]!==H[1]){const C=Math.min(z[1],H[1]);h.push({ymin:C,ymax:Math.max(z[1],H[1]),x:C===z[1]?z[0]:H[0],islope:(H[0]-z[0])/(H[1]-z[1])})}}if(h.sort(((x,S)=>x.ymin<S.ymin?-1:x.ymin>S.ymin?1:x.x<S.x?-1:x.x>S.x?1:x.ymax===S.ymax?0:(x.ymax-S.ymax)/Math.abs(x.ymax-S.ymax))),!h.length)return f;let b=[],v=h[0].ymin,w=0;for(;b.length||h.length;){if(h.length){let x=-1;for(let S=0;S<h.length&&!(h[S].ymin>v);S++)x=S;h.splice(0,x+1).forEach((S=>{b.push({s:v,edge:S})}))}if(b=b.filter((x=>!(x.edge.ymax<=v))),b.sort(((x,S)=>x.edge.x===S.edge.x?0:(x.edge.x-S.edge.x)/Math.abs(x.edge.x-S.edge.x))),(p!==1||w%d==0)&&b.length>1)for(let x=0;x<b.length;x+=2){const S=x+1;if(S>=b.length)break;const z=b[x].edge,H=b[S].edge;f.push([[Math.round(z.x),v],[Math.round(H.x),v]])}v+=p,b.forEach((x=>{x.edge.x=x.edge.x+p*x.edge.islope})),w++}return f})(i,a,r);if(o){for(const l of i)Hr(l,s,-o);(function(l,d,p){const u=[];l.forEach((f=>u.push(...f))),Hr(u,d,p)})(c,s,-o)}return c}function nn(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let a=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(a=o),Zu(t,o,r,a||1)}class Co{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=nn(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function mr(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Qu extends Co{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=nn(e,Object.assign({},n,{hachureGap:r})),a=Math.PI/180*n.hachureAngle,i=[],s=.5*r*Math.cos(a),c=.5*r*Math.sin(a);for(const[l,d]of o)mr([l,d])&&i.push([[l[0]-s,l[1]+c],[...d]],[[l[0]+s,l[1]-c],[...d]]);return{type:"fillSketch",ops:this.renderLines(i,n)}}}class Ju extends Co{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),a=this._fillPolygons(e,o);return r.ops=r.ops.concat(a.ops),r}}class tp{constructor(e){this.helper=e}fillPolygons(e,n){const r=nn(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let a=n.fillWeight;a<0&&(a=n.strokeWidth/2);const i=o/4;for(const s of e){const c=mr(s),l=c/o,d=Math.ceil(l)-1,p=c-d*o,u=(s[0][0]+s[1][0])/2-o/4,f=Math.min(s[0][1],s[1][1]);for(let h=0;h<d;h++){const b=f+p+h*o,v=u-i+2*Math.random()*i,w=b-i+2*Math.random()*i,x=this.helper.ellipse(v,w,a,a,n);r.push(...x.ops)}}return{type:"fillSketch",ops:r}}}class ep{constructor(e){this.helper=e}fillPolygons(e,n){const r=nn(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,a=[];return e.forEach((i=>{const s=mr(i),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let d=i[0],p=i[1];d[0]>p[0]&&(d=i[1],p=i[0]);const u=Math.atan((p[1]-d[1])/(p[0]-d[0]));for(let f=0;f<c;f++){const h=f*(r+o),b=h+r,v=[d[0]+h*Math.cos(u)+l*Math.cos(u),d[1]+h*Math.sin(u)+l*Math.sin(u)],w=[d[0]+b*Math.cos(u)+l*Math.cos(u),d[1]+b*Math.sin(u)+l*Math.sin(u)];a.push(...this.helper.doubleLineOps(v[0],v[1],w[0],w[1],n))}})),a}}class np{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,a=nn(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(a,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((a=>{const i=mr(a),s=Math.round(i/(2*n));let c=a[0],l=a[1];c[0]>l[0]&&(c=a[1],l=a[0]);const d=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let p=0;p<s;p++){const u=2*p*n,f=2*(p+1)*n,h=Math.sqrt(2*Math.pow(n,2)),b=[c[0]+u*Math.cos(d),c[1]+u*Math.sin(d)],v=[c[0]+f*Math.cos(d),c[1]+f*Math.sin(d)],w=[b[0]+h*Math.cos(d+Math.PI/4),b[1]+h*Math.sin(d+Math.PI/4)];o.push(...this.helper.doubleLineOps(b[0],b[1],w[0],w[1],r),...this.helper.doubleLineOps(w[0],w[1],v[0],v[1],r))}})),o}}const at={};class rp{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const op=0,zr=1,pa=2,mn={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Fr(t,e){return t.type===e}function Do(t){const e=[],n=(function(i){const s=new Array;for(;i!=="";)if(i.match(/^([ \t\r\n,]+)/))i=i.substr(RegExp.$1.length);else if(i.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:op,text:RegExp.$1},i=i.substr(RegExp.$1.length);else{if(!i.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:zr,text:`${parseFloat(RegExp.$1)}`},i=i.substr(RegExp.$1.length)}return s[s.length]={type:pa,text:""},s})(t);let r="BOD",o=0,a=n[o];for(;!Fr(a,pa);){let i=0;const s=[];if(r==="BOD"){if(a.text!=="M"&&a.text!=="m")return Do("M0,0"+t);o++,i=mn[a.text],r=a.text}else Fr(a,zr)?i=mn[r]:(o++,i=mn[a.text],r=a.text);if(!(o+i<n.length))throw new Error("Path data ended short");for(let c=o;c<o+i;c++){const l=n[c];if(!Fr(l,zr))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof mn[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=i,a=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function rs(t){let e=0,n=0,r=0,o=0;const a=[];for(const{key:i,data:s}of t)switch(i){case"M":a.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],a.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":a.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],a.push({key:"L",data:[e,n]});break;case"C":a.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":a.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":a.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],a.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":a.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],a.push({key:"H",data:[e]});break;case"V":a.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],a.push({key:"V",data:[n]});break;case"S":a.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,d)=>d%2?l+n:l+e));a.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":a.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],a.push({key:"T",data:[e,n]});break;case"Z":case"z":a.push({key:"Z",data:[]}),e=r,n=o}return a}function os(t){const e=[];let n="",r=0,o=0,a=0,i=0,s=0,c=0;for(const{key:l,data:d}of t){switch(l){case"M":e.push({key:"M",data:[...d]}),[r,o]=d,[a,i]=d;break;case"C":e.push({key:"C",data:[...d]}),r=d[4],o=d[5],s=d[2],c=d[3];break;case"L":e.push({key:"L",data:[...d]}),[r,o]=d;break;case"H":r=d[0],e.push({key:"L",data:[r,o]});break;case"V":o=d[0],e.push({key:"L",data:[r,o]});break;case"S":{let p=0,u=0;n==="C"||n==="S"?(p=r+(r-s),u=o+(o-c)):(p=r,u=o),e.push({key:"C",data:[p,u,...d]}),s=d[0],c=d[1],r=d[2],o=d[3];break}case"T":{const[p,u]=d;let f=0,h=0;n==="Q"||n==="T"?(f=r+(r-s),h=o+(o-c)):(f=r,h=o);const b=r+2*(f-r)/3,v=o+2*(h-o)/3,w=p+2*(f-p)/3,x=u+2*(h-u)/3;e.push({key:"C",data:[b,v,w,x,p,u]}),s=f,c=h,r=p,o=u;break}case"Q":{const[p,u,f,h]=d,b=r+2*(p-r)/3,v=o+2*(u-o)/3,w=f+2*(p-f)/3,x=h+2*(u-h)/3;e.push({key:"C",data:[b,v,w,x,f,h]}),s=p,c=u,r=f,o=h;break}case"A":{const p=Math.abs(d[0]),u=Math.abs(d[1]),f=d[2],h=d[3],b=d[4],v=d[5],w=d[6];p===0||u===0?(e.push({key:"C",data:[r,o,v,w,v,w]}),r=v,o=w):(r!==v||o!==w)&&(as(r,o,v,w,p,u,f,h,b).forEach((function(x){e.push({key:"C",data:x})})),r=v,o=w);break}case"Z":e.push({key:"Z",data:[]}),r=a,o=i}n=l}return e}function Re(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function as(t,e,n,r,o,a,i,s,c,l){const d=(p=i,Math.PI*p/180);var p;let u=[],f=0,h=0,b=0,v=0;if(l)[f,h,b,v]=l;else{[t,e]=Re(t,e,-d),[n,r]=Re(n,r,-d);const tt=(t-n)/2,F=(e-r)/2;let xt=tt*tt/(o*o)+F*F/(a*a);xt>1&&(xt=Math.sqrt(xt),o*=xt,a*=xt);const oe=o*o,ae=a*a,Vc=oe*ae-oe*F*F-ae*tt*tt,Xc=oe*F*F+ae*tt*tt,Ko=(s===c?-1:1)*Math.sqrt(Math.abs(Vc/Xc));b=Ko*o*F/a+(t+n)/2,v=Ko*-a*tt/o+(e+r)/2,f=Math.asin(parseFloat(((e-v)/a).toFixed(9))),h=Math.asin(parseFloat(((r-v)/a).toFixed(9))),t<b&&(f=Math.PI-f),n<b&&(h=Math.PI-h),f<0&&(f=2*Math.PI+f),h<0&&(h=2*Math.PI+h),c&&f>h&&(f-=2*Math.PI),!c&&h>f&&(h-=2*Math.PI)}let w=h-f;if(Math.abs(w)>120*Math.PI/180){const tt=h,F=n,xt=r;h=c&&h>f?f+120*Math.PI/180*1:f+120*Math.PI/180*-1,u=as(n=b+o*Math.cos(h),r=v+a*Math.sin(h),F,xt,o,a,i,0,c,[h,tt,b,v])}w=h-f;const x=Math.cos(f),S=Math.sin(f),z=Math.cos(h),H=Math.sin(h),C=Math.tan(w/4),Y=4/3*o*C,J=4/3*a*C,re=[t,e],ct=[t+Y*S,e-J*x],Mt=[n+Y*H,r-J*z],un=[n,r];if(ct[0]=2*re[0]-ct[0],ct[1]=2*re[1]-ct[1],l)return[ct,Mt,un].concat(u);{u=[ct,Mt,un].concat(u);const tt=[];for(let F=0;F<u.length;F+=3){const xt=Re(u[F][0],u[F][1],d),oe=Re(u[F+1][0],u[F+1][1],d),ae=Re(u[F+2][0],u[F+2][1],d);tt.push([xt[0],xt[1],oe[0],oe[1],ae[0],ae[1]])}return tt}}const ap={randOffset:function(t,e){return E(t,e)},randOffsetWithRange:function(t,e,n){return Hn(t,e,n)},ellipse:function(t,e,n,r,o){const a=ss(n,r,o);return ro(t,e,o,a).opset},doubleLineOps:function(t,e,n,r,o){return Bt(t,e,n,r,o,!0)}};function is(t,e,n,r,o){return{type:"path",ops:Bt(t,e,n,r,o)}}function Mn(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let a=0;a<r-1;a++)o.push(...Bt(t[a][0],t[a][1],t[a+1][0],t[a+1][1],n));return e&&o.push(...Bt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?is(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function ip(t,e,n,r,o){return(function(a,i){return Mn(a,!0,i)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function fa(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=gn(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:gn(n[0],1.5*(1+.22*e.roughness),ga(e));for(let a=1;a<n.length;a++){const i=n[a];if(i.length){const s=gn(i,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:gn(i,1.5*(1+.22*e.roughness),ga(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function ss(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),a=2*Math.PI/o;let i=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return i+=E(i*c,n),s+=E(s*c,n),{increment:a,rx:i,ry:s}}function ro(t,e,n,r){const[o,a]=ba(r.increment,t,e,r.rx,r.ry,1,r.increment*Hn(.1,Hn(.4,1,n),n),n);let i=zn(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=ba(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=zn(s,null,n);i=i.concat(c)}return{estimatedPoints:a,opset:{type:"path",ops:i}}}function ha(t,e,n,r,o,a,i,s,c){const l=t,d=e;let p=Math.abs(n/2),u=Math.abs(r/2);p+=E(.01*p,c),u+=E(.01*u,c);let f=o,h=a;for(;f<0;)f+=2*Math.PI,h+=2*Math.PI;h-f>2*Math.PI&&(f=0,h=2*Math.PI);const b=2*Math.PI/c.curveStepCount,v=Math.min(b/2,(h-f)/2),w=va(v,l,d,p,u,f,h,1,c);if(!c.disableMultiStroke){const x=va(v,l,d,p,u,f,h,1.5,c);w.push(...x)}return i&&(s?w.push(...Bt(l,d,l+p*Math.cos(f),d+u*Math.sin(f),c),...Bt(l,d,l+p*Math.cos(h),d+u*Math.sin(h),c)):w.push({op:"lineTo",data:[l,d]},{op:"lineTo",data:[l+p*Math.cos(f),d+u*Math.sin(f)]})),{type:"path",ops:w}}function ma(t,e){const n=os(rs(Do(t))),r=[];let o=[0,0],a=[0,0];for(const{key:i,data:s}of n)switch(i){case"M":a=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...Bt(a[0],a[1],s[0],s[1],e)),a=[s[0],s[1]];break;case"C":{const[c,l,d,p,u,f]=s;r.push(...sp(c,l,d,p,u,f,a,e)),a=[u,f];break}case"Z":r.push(...Bt(a[0],a[1],o[0],o[1],e)),a=[o[0],o[1]]}return{type:"path",ops:r}}function qr(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,a=r.length;if(a>2){n.push({op:"move",data:[r[0][0]+E(o,e),r[0][1]+E(o,e)]});for(let i=1;i<a;i++)n.push({op:"lineTo",data:[r[i][0]+E(o,e),r[i][1]+E(o,e)]})}}return{type:"fillPath",ops:n}}function se(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!at[o])switch(o){case"zigzag":at[o]||(at[o]=new Qu(r));break;case"cross-hatch":at[o]||(at[o]=new Ju(r));break;case"dots":at[o]||(at[o]=new tp(r));break;case"dashed":at[o]||(at[o]=new ep(r));break;case"zigzag-line":at[o]||(at[o]=new np(r));break;default:o="hachure",at[o]||(at[o]=new Co(r))}return at[o]})(e,ap).fillPolygons(t,e)}function ga(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function cs(t){return t.randomizer||(t.randomizer=new rp(t.seed||0)),t.randomizer.next()}function Hn(t,e,n,r=1){return n.roughness*r*(cs(n)*(e-t)+t)}function E(t,e,n=1){return Hn(-t,t,e,n)}function Bt(t,e,n,r,o,a=!1){const i=a?o.disableMultiStrokeFill:o.disableMultiStroke,s=oo(t,e,n,r,o,!0,!1);if(i)return s;const c=oo(t,e,n,r,o,!0,!0);return s.concat(c)}function oo(t,e,n,r,o,a,i){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let d=o.maxRandomnessOffset||0;d*d*100>s&&(d=c/10);const p=d/2,u=.2+.2*cs(o);let f=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;f=E(f,o,l),h=E(h,o,l);const b=[],v=()=>E(p,o,l),w=()=>E(d,o,l),x=o.preserveVertices;return i?b.push({op:"move",data:[t+(x?0:v()),e+(x?0:v())]}):b.push({op:"move",data:[t+(x?0:E(d,o,l)),e+(x?0:E(d,o,l))]}),i?b.push({op:"bcurveTo",data:[f+t+(n-t)*u+v(),h+e+(r-e)*u+v(),f+t+2*(n-t)*u+v(),h+e+2*(r-e)*u+v(),n+(x?0:v()),r+(x?0:v())]}):b.push({op:"bcurveTo",data:[f+t+(n-t)*u+w(),h+e+(r-e)*u+w(),f+t+2*(n-t)*u+w(),h+e+2*(r-e)*u+w(),n+(x?0:w()),r+(x?0:w())]}),b}function gn(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+E(e,n),t[0][1]+E(e,n)]),r.push([t[0][0]+E(e,n),t[0][1]+E(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+E(e,n),t[o][1]+E(e,n)]),o===t.length-1&&r.push([t[o][0]+E(e,n),t[o][1]+E(e,n)]);return zn(r,null,n)}function zn(t,e,n){const r=t.length,o=[];if(r>3){const a=[],i=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*t[s+1][0]-i*t[s-1][0])/6,c[1]+(i*t[s+1][1]-i*t[s-1][1])/6],a[2]=[t[s+1][0]+(i*t[s][0]-i*t[s+2][0])/6,t[s+1][1]+(i*t[s][1]-i*t[s+2][1])/6],a[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[a[1][0],a[1][1],a[2][0],a[2][1],a[3][0],a[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...oo(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function ba(t,e,n,r,o,a,i,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let d=0;d<=2*Math.PI;d+=t){const p=[e+r*Math.cos(d),n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const d=E(.5,s)-Math.PI/2;l.push([E(a,s)+e+.9*r*Math.cos(d-t),E(a,s)+n+.9*o*Math.sin(d-t)]);const p=2*Math.PI+d-.01;for(let u=d;u<p;u+=t){const f=[E(a,s)+e+r*Math.cos(u),E(a,s)+n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([E(a,s)+e+r*Math.cos(d+2*Math.PI+.5*i),E(a,s)+n+o*Math.sin(d+2*Math.PI+.5*i)]),l.push([E(a,s)+e+.98*r*Math.cos(d+i),E(a,s)+n+.98*o*Math.sin(d+i)]),l.push([E(a,s)+e+.9*r*Math.cos(d+.5*i),E(a,s)+n+.9*o*Math.sin(d+.5*i)])}return[l,c]}function va(t,e,n,r,o,a,i,s,c){const l=a+E(.1,c),d=[];d.push([E(s,c)+e+.9*r*Math.cos(l-t),E(s,c)+n+.9*o*Math.sin(l-t)]);for(let p=l;p<=i;p+=t)d.push([E(s,c)+e+r*Math.cos(p),E(s,c)+n+o*Math.sin(p)]);return d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),d.push([e+r*Math.cos(i),n+o*Math.sin(i)]),zn(d,null,c)}function sp(t,e,n,r,o,a,i,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let d=[0,0];const p=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let f=0;f<p;f++)f===0?c.push({op:"move",data:[i[0],i[1]]}):c.push({op:"move",data:[i[0]+(u?0:E(l[0],s)),i[1]+(u?0:E(l[0],s))]}),d=u?[o,a]:[o+E(l[f],s),a+E(l[f],s)],c.push({op:"bcurveTo",data:[t+E(l[f],s),e+E(l[f],s),n+E(l[f],s),r+E(l[f],s),d[0],d[1]]});return c}function Ne(t){return[...t]}function ya(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(Ne(t[0]),Ne(t[1]),Ne(t[2]),Ne(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const a=[],i=1-e;r.push(Ne(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];a[0]=[c[0],c[1]],a[1]=[c[0]+(i*o[s+1][0]-i*o[s-1][0])/6,c[1]+(i*o[s+1][1]-i*o[s-1][1])/6],a[2]=[o[s+1][0]+(i*o[s][0]-i*o[s+2][0])/6,o[s+1][1]+(i*o[s][1]-i*o[s+2][1])/6],a[3]=[o[s+1][0],o[s+1][1]],r.push(a[1],a[2],a[3])}}return r}function $n(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function cp(t,e,n){const r=$n(e,n);if(r===0)return $n(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),$n(t,jt(e,n,o))}function jt(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function ao(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],d=s[c+1],p=s[c+2],u=s[c+3];let f=3*d[0]-2*l[0]-u[0];f*=f;let h=3*d[1]-2*l[1]-u[1];h*=h;let b=3*p[0]-2*u[0]-l[0];b*=b;let v=3*p[1]-2*u[1]-l[1];return v*=v,f<b&&(f=b),h<v&&(h=v),f+h})(t,e)<n){const s=t[e+0];o.length?(a=o[o.length-1],i=s,Math.sqrt($n(a,i))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],d=t[e+2],p=t[e+3],u=jt(c,l,.5),f=jt(l,d,.5),h=jt(d,p,.5),b=jt(u,f,.5),v=jt(f,h,.5),w=jt(b,v,.5);ao([c,u,b,w],0,n,o),ao([w,v,h,p],0,n,o)}var a,i;return o}function lp(t,e){return Fn(t,0,t.length,e)}function Fn(t,e,n,r,o){const a=o||[],i=t[e],s=t[n-1];let c=0,l=1;for(let d=e+1;d<n-1;++d){const p=cp(t[d],i,s);p>c&&(c=p,l=d)}return Math.sqrt(c)>r?(Fn(t,e,l+1,r,a),Fn(t,l,n,r,a)):(a.length||a.push(i),a.push(s)),a}function _r(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let a=0;a<o;a++)ao(t,3*a,e,r);return n&&n>0?Fn(r,0,r.length,n):r}const lt="none";class qn{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,a){const i=this._o(a);return this._d("line",[is(e,n,r,o,i)],i)}rectangle(e,n,r,o,a){const i=this._o(a),s=[],c=ip(e,n,r,o,i);if(i.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];i.fillStyle==="solid"?s.push(qr([l],i)):s.push(se([l],i))}return i.stroke!==lt&&s.push(c),this._d("rectangle",s,i)}ellipse(e,n,r,o,a){const i=this._o(a),s=[],c=ss(r,o,i),l=ro(e,n,i,c);if(i.fill)if(i.fillStyle==="solid"){const d=ro(e,n,i,c).opset;d.type="fillPath",s.push(d)}else s.push(se([l.estimatedPoints],i));return i.stroke!==lt&&s.push(l.opset),this._d("ellipse",s,i)}circle(e,n,r,o){const a=this.ellipse(e,n,r,r,o);return a.shape="circle",a}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[Mn(e,!1,r)],r)}arc(e,n,r,o,a,i,s=!1,c){const l=this._o(c),d=[],p=ha(e,n,r,o,a,i,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const u=Object.assign({},l);u.disableMultiStroke=!0;const f=ha(e,n,r,o,a,i,!0,!1,u);f.type="fillPath",d.push(f)}else d.push((function(u,f,h,b,v,w,x){const S=u,z=f;let H=Math.abs(h/2),C=Math.abs(b/2);H+=E(.01*H,x),C+=E(.01*C,x);let Y=v,J=w;for(;Y<0;)Y+=2*Math.PI,J+=2*Math.PI;J-Y>2*Math.PI&&(Y=0,J=2*Math.PI);const re=(J-Y)/x.curveStepCount,ct=[];for(let Mt=Y;Mt<=J;Mt+=re)ct.push([S+H*Math.cos(Mt),z+C*Math.sin(Mt)]);return ct.push([S+H*Math.cos(J),z+C*Math.sin(J)]),ct.push([S,z]),se([ct],x)})(e,n,r,o,a,i,l));return l.stroke!==lt&&d.push(p),this._d("arc",d,l)}curve(e,n){const r=this._o(n),o=[],a=fa(e,r);if(r.fill&&r.fill!==lt)if(r.fillStyle==="solid"){const i=fa(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(i.ops)})}else{const i=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?i.push(...l):l.length===3?i.push(..._r(ya([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):i.push(..._r(ya(l),10,(1+r.roughness)/2))}i.length&&o.push(se([i],r))}return r.stroke!==lt&&o.push(a),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],a=Mn(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(qr([e],r)):o.push(se([e],r))),r.stroke!==lt&&o.push(a),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const a=r.fill&&r.fill!=="transparent"&&r.fill!==lt,i=r.stroke!==lt,s=!!(r.simplification&&r.simplification<1),c=(function(d,p,u){const f=os(rs(Do(d))),h=[];let b=[],v=[0,0],w=[];const x=()=>{w.length>=4&&b.push(..._r(w,p)),w=[]},S=()=>{x(),b.length&&(h.push(b),b=[])};for(const{key:H,data:C}of f)switch(H){case"M":S(),v=[C[0],C[1]],b.push(v);break;case"L":x(),b.push([C[0],C[1]]);break;case"C":if(!w.length){const Y=b.length?b[b.length-1]:v;w.push([Y[0],Y[1]])}w.push([C[0],C[1]]),w.push([C[2],C[3]]),w.push([C[4],C[5]]);break;case"Z":x(),b.push([v[0],v[1]])}if(S(),!u)return h;const z=[];for(const H of h){const C=lp(H,u);C.length&&z.push(C)}return z})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=ma(e,r);if(a)if(r.fillStyle==="solid")if(c.length===1){const d=ma(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(d.ops)})}else o.push(qr(c,r));else o.push(se(c,r));return i&&(s?c.forEach((d=>{o.push(Mn(d,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const a=typeof n=="number"&&n>=0?o.data.map((i=>+i.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${a[0]} ${a[1]} `;break;case"bcurveTo":r+=`C${a[0]} ${a[1]}, ${a[2]} ${a[3]}, ${a[4]} ${a[5]} `;break;case"lineTo":r+=`L${a[0]} ${a[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const a of n){let i=null;switch(a.type){case"path":i={d:this.opsToPath(a),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:lt};break;case"fillPath":i={d:this.opsToPath(a),stroke:lt,strokeWidth:0,fill:r.fill||lt};break;case"fillSketch":i=this.fillSketch(a,r)}i&&o.push(i)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||lt,strokeWidth:r,fill:lt}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class dp{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new qn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,a=e.options.fixedDecimalPlaceDigits;for(const i of n)switch(i.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,i,a),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,i,a,s),o.restore();break}case"fillSketch":this.fillSketch(o,i,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const a of n.ops){const i=typeof r=="number"&&r>=0?a.data.map((s=>+s.toFixed(r))):a.data;switch(a.op){case"move":e.moveTo(i[0],i[1]);break;case"bcurveTo":e.bezierCurveTo(i[0],i[1],i[2],i[3],i[4],i[5]);break;case"lineTo":e.lineTo(i[0],i[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i),i}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i),i}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i),i}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a),a}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const bn="http://www.w3.org/2000/svg";class up{constructor(e,n){this.svg=e,this.gen=new qn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,a=o.createElementNS(bn,"g"),i=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(bn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(bn,"path"),c.setAttribute("d",this.opsToPath(s,i)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&a.appendChild(c)}return a}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const a=e.createElementNS(bn,"path");return a.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),a.setAttribute("stroke",r.fill||""),a.setAttribute("stroke-width",o+""),a.setAttribute("fill","none"),r.fillLineDash&&a.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&a.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),a}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,a){const i=this.gen.line(e,n,r,o,a);return this.draw(i)}rectangle(e,n,r,o,a){const i=this.gen.rectangle(e,n,r,o,a);return this.draw(i)}ellipse(e,n,r,o,a){const i=this.gen.ellipse(e,n,r,o,a);return this.draw(i)}circle(e,n,r,o){const a=this.gen.circle(e,n,r,o);return this.draw(a)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,a,i,s=!1,c){const l=this.gen.arc(e,n,r,o,a,i,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var ls={canvas:(t,e)=>new dp(t,e),svg:(t,e)=>new up(t,e),generator:t=>new qn(t),newSeed:()=>qn.newSeed()};const pp="http://www.w3.org/2000/svg",xa=1,ds="#000000",_n=3;let W=null;function fp(){W||(W=document.createElementNS(pp,"svg"),W.setAttribute("data-manuscript","ui"),W.setAttribute("width","100%"),W.setAttribute("height","100%"),W.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(W))}function Po(){W==null||W.remove(),W=null}function us(t,e,n,r){if(!W)return;for(;W.firstChild;)W.removeChild(W.firstChild);const o=ls.svg(W);wa(f=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:xa,...f}));const a=Math.atan2(r-e,n-t),i=14+_n*2,s=Math.PI/7,c=n-i*Math.cos(a-s),l=r-i*Math.sin(a-s),d=n-i*Math.cos(a+s),p=r-i*Math.sin(a+s),u=`M ${c} ${l} L ${n} ${r} L ${d} ${p}`;wa(f=>o.path(u,{roughness:1.5,bowing:1,seed:xa+1,...f}))}function wa(t){W&&(W.appendChild(t({stroke:"#ffffff",strokeWidth:_n+4})),W.appendChild(t({stroke:ds,strokeWidth:_n})))}const hp=8;let Bn=!1,ka=null,Ee=!1,Yt=0,Kt=0;function mp(){ka||(ka=mt(({prev:t,next:e})=>{e==="arrow"?gp():t==="arrow"&&bp()}))}function gp(){Bn||(Bn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",ps,!0),document.addEventListener("mousemove",fs,!0),document.addEventListener("mouseup",hs,!0),document.addEventListener("keydown",ms,!0))}function bp(){Bn&&(Bn=!1,Ee=!1,document.body.style.cursor="",document.removeEventListener("mousedown",ps,!0),document.removeEventListener("mousemove",fs,!0),document.removeEventListener("mouseup",hs,!0),document.removeEventListener("keydown",ms,!0),Po())}function ps(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Ee=!0,Yt=t.clientX,Kt=t.clientY,fp(),us(Yt,Kt,Yt,Kt))}function fs(t){Ee&&(t.preventDefault(),us(Yt,Kt,t.clientX,t.clientY))}function hs(t){if(!Ee)return;Ee=!1,Po();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Yt,n-Kt)<hp){I("idle");return}t.preventDefault(),t.stopPropagation();const o=ot(),a={kind:"arrow",id:vp(),style:"excalidraw",from:{x:Yt,y:Kt},to:{x:e,y:n},...o?{fromAnchorOffset:{x:Yt-o.left,y:Kt-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:ds,strokeWidth:_n};tn(a),I("idle")}function ms(t){t.key==="Escape"&&(t.preventDefault(),Ee=!1,Po(),I("idle"))}function vp(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Sa="http://www.w3.org/2000/svg",gs="#1a1a1a",bs=3,yp=2,xp=2;let Un=!1,Ea=null,Ae=!1,vt=[],pt=null,kt=null;function wp(){Ea||(Ea=mt(({prev:t,next:e})=>{e==="freedraw"?kp():t==="freedraw"&&Sp()}))}function kp(){Un||(Un=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",vs,!0),document.addEventListener("mousemove",ys,!0),document.addEventListener("mouseup",xs,!0),document.addEventListener("keydown",ws,!0))}function Sp(){Un&&(Un=!1,Ae=!1,vt=[],document.body.style.cursor="",document.removeEventListener("mousedown",vs,!0),document.removeEventListener("mousemove",ys,!0),document.removeEventListener("mouseup",xs,!0),document.removeEventListener("keydown",ws,!0),Ro())}function vs(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Ae=!0,vt=[{x:t.clientX,y:t.clientY}],Ep(),ks())}function ys(t){if(!Ae)return;t.preventDefault();const e=vt[vt.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<xp||(vt.push({x:t.clientX,y:t.clientY}),ks())}function xs(t){if(!Ae)return;if(Ae=!1,Ro(),vt.length<yp){vt=[],I("idle");return}t.preventDefault(),t.stopPropagation();const e=vt.slice(),n=ot(),r={kind:"freedraw",id:Ap(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:gs,strokeWidth:bs};tn(r),vt=[],I("idle")}function ws(t){t.key==="Escape"&&(t.preventDefault(),Ae=!1,vt=[],Ro(),I("idle"))}function Ep(){pt||(pt=document.createElementNS(Sa,"svg"),pt.setAttribute("data-manuscript","ui"),pt.setAttribute("width","100%"),pt.setAttribute("height","100%"),pt.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),kt=document.createElementNS(Sa,"polyline"),kt.setAttribute("fill","none"),kt.setAttribute("stroke",gs),kt.setAttribute("stroke-width",String(bs)),kt.setAttribute("stroke-linecap","round"),kt.setAttribute("stroke-linejoin","round"),pt.appendChild(kt),document.body.appendChild(pt))}function Ro(){pt==null||pt.remove(),pt=null,kt=null}function ks(){kt&&kt.setAttribute("points",vt.map(t=>`${t.x},${t.y}`).join(" "))}function Ap(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const rn="manuscript:element-selected";let jn=!1,ut=null,Aa=null;function Mp(){Aa||(Aa=mt(({prev:t,next:e})=>{e==="picker"?$p():t==="picker"&&Lp()}))}function $p(){jn||(jn=!0,document.addEventListener("mouseover",Ss,!0),document.addEventListener("mouseout",Es,!0),document.addEventListener("click",As,!0),document.addEventListener("keydown",Ms,!0))}function Lp(){jn&&(jn=!1,document.removeEventListener("mouseover",Ss,!0),document.removeEventListener("mouseout",Es,!0),document.removeEventListener("click",As,!0),document.removeEventListener("keydown",Ms,!0),$s())}function Ss(t){const e=t.target;!(e instanceof HTMLElement)||Ls(e)||Ip(e)}function Es(t){$s()}function As(t){const e=t.target;if(!(e instanceof HTMLElement)||Ls(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=xd(e),r=e.ownerDocument??document;if(console.log("[manuscript/picker] selectorChain",{target:e,chain:n,resolve:{layer1:Pn(n.layer1,r),layer2:Rn(n.layer2,r),layer3:Nn(n.layer3,r)},matchesTarget:{layer1:Pn(n.layer1,r)===e,layer2:Rn(n.layer2,r)===e,layer3:Nn(n.layer3,r)===e}}),!wd(n,e)){Tp();return}const o=e.getBoundingClientRect(),a={chain:n,rect:{x:o.x,y:o.y,width:o.width,height:o.height}};document.dispatchEvent(new CustomEvent(rn,{detail:a})),I("idle")}let gt=null,vn=null;function Tp(){gt&&gt.remove(),gt=document.createElement("div"),gt.setAttribute("data-manuscript","ui"),gt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),gt.textContent=m("toast.ambiguous-selector"),document.body.appendChild(gt),vn!==null&&window.clearTimeout(vn),vn=window.setTimeout(()=>{gt==null||gt.remove(),gt=null,vn=null},3500)}function Ms(t){t.key==="Escape"&&(t.preventDefault(),I("idle"))}function Ip(t){ut||(ut=document.createElement("div"),ut.setAttribute("data-manuscript","ui"),ut.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${O+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(ut));const e=t.getBoundingClientRect();ut.style.left=`${e.left}px`,ut.style.top=`${e.top}px`,ut.style.width=`${e.width}px`,ut.style.height=`${e.height}px`,ut.style.display="block"}function $s(){ut&&(ut.style.display="none")}function Ls(t){return t.closest('[data-manuscript="ui"]')!==null}const on="http://www.w3.org/2000/svg";function No(t,e){let n;switch(t){case"rectangle":n=Cp(e);break;case"ellipse":n=Dp(e);break;case"triangle":n=yn(Np(e),e);break;case"diamond":n=yn(Op(e),e);break;case"star":n=yn(Hp(e),e);break;case"callout":n=Rp(zp(e),e);break;case"line":n=Pp(e);break;case"block-arrow":n=yn(Fp(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function Cp(t){const e=document.createElementNS(on,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),gr(e,t),e}function Dp(t){const e=document.createElementNS(on,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),gr(e,t),e}function Pp(t){const e=document.createElementNS(on,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function yn(t,e){const n=document.createElementNS(on,"polygon");return n.setAttribute("points",t),gr(n,e),n.setAttribute("stroke-linejoin","round"),n}function Rp(t,e){const n=document.createElementNS(on,"path");return n.setAttribute("d",t),gr(n,e),n.setAttribute("stroke-linejoin","round"),n}function gr(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function Np(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function Op(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function Hp(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,a=[];for(let i=0;i<10;i++){const s=Math.PI/5*i-Math.PI/2,c=i%2===0?r:o;a.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return a.join(" ")}function zp(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,a=t.x+t.width*.5,i=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${a} ${r}`,`L ${i} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function Fp(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const qp="http://www.w3.org/2000/svg",_p="#ffffff",Bp="#1a1a1a",Up=2;let K=null,St=null;function Ts(t){return{fill:t==="line"?"transparent":_p,stroke:Bp,strokeWidth:Up}}function jp(){St||(St=document.createElement("div"),St.setAttribute("data-manuscript","ui"),St.textContent="Click and drag to draw a shape · Esc to cancel",St.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${O+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(St))}function Is(){St==null||St.remove(),St=null}function Wp(){K||(K=document.createElementNS(qp,"svg"),K.setAttribute("data-manuscript","ui"),K.setAttribute("width","100%"),K.setAttribute("height","100%"),K.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(K))}function Oo(){K==null||K.remove(),K=null}function Cs(t,e,n,r,o){if(!K)return;for(;K.firstChild;)K.removeChild(K.firstChild);const a=t==="line"?r-e:Math.abs(r-e),i=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=Ts(t),d=No(t,{x:s,y:c,width:a,height:i,...l});d&&K.appendChild(d)}const Vp=6;let Rt="rectangle",Wn=!1,Ma=null,Me=!1,Nt=0,Ot=0;function Xp(t){Rt=t}function Gp(){Ma||(Ma=mt(({prev:t,next:e})=>{e==="shape"?Yp():t==="shape"&&Kp()}))}function Yp(){Wn||(Wn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Ds,!0),document.addEventListener("mousemove",Ps,!0),document.addEventListener("mouseup",Rs,!0),document.addEventListener("keydown",Ns,!0),jp())}function Kp(){Wn&&(Wn=!1,Me=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Ds,!0),document.removeEventListener("mousemove",Ps,!0),document.removeEventListener("mouseup",Rs,!0),document.removeEventListener("keydown",Ns,!0),Oo(),Is())}function Ds(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),Me=!0,Nt=t.clientX,Ot=t.clientY,Is(),Wp(),Cs(Rt,Nt,Ot,Nt,Ot))}function Ps(t){Me&&(t.preventDefault(),Cs(Rt,Nt,Ot,t.clientX,t.clientY))}function Rs(t){if(!Me)return;Me=!1,Oo();const e=t.clientX,n=t.clientY,r=Rt==="line"?e-Nt:Math.abs(e-Nt),o=Rt==="line"?n-Ot:Math.abs(n-Ot);if(Math.max(Math.abs(r),Math.abs(o))<Vp){I("idle");return}t.preventDefault(),t.stopPropagation();const a=Rt==="line"?{x:Nt,y:Ot,width:r,height:o}:{x:Math.min(Nt,e),y:Math.min(Ot,n),width:r,height:o},i=Ts(Rt),s=ot(),c={kind:"shape",id:Zp(),shapeKind:Rt,bounds:a,...s?{boundsAnchorOffset:{x:a.x-s.left,y:a.y-s.top}}:{},...i};tn(c),I("idle")}function Ns(t){t.key==="Escape"&&(t.preventDefault(),Me=!1,Oo(),I("idle"))}function Zp(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Qp={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},Jp="Text";let Vn=!1,$a=null;function tf(){$a||($a=mt(({prev:t,next:e})=>{e==="text"?ef():t==="text"&&nf()}))}function ef(){Vn||(Vn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Os,!0),document.addEventListener("keydown",Hs,!0))}function nf(){Vn&&(Vn=!1,document.body.style.cursor="",document.removeEventListener("click",Os,!0),document.removeEventListener("keydown",Hs,!0))}function Os(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=ot(),o={kind:"text",id:rf(),text:Jp,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...Qp}};tn(o),requestAnimationFrame(()=>{const a=document.querySelector(`[data-annotation-text="${o.id}"]`);a&&a.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),I("idle")}function Hs(t){t.key==="Escape"&&(t.preventDefault(),I("idle"))}function rf(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const of="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",af="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",La="Asta Sans",sf="fonts/AstaSans-VariableFont_wght.ttf";let Ta=!1;function cf(){Ta||(Ta=!0,Ia(of),Ia(af),lf())}function Ia(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function lf(){try{for(const t of document.fonts)if(t.family===La)return}catch{}try{const t=chrome.runtime.getURL(sf);new FontFace(La,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const bt="manuscript";function br(...t){}function Br(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function ce(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function zs(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===bt&&typeof e.type=="string"}function df(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const a=o.data;if(zs(a)){if(br("child received",a.type,"in",location.href),a.type==="set-mode"){I(a.mode),t=a.mode;return}if(a.type==="top-drag-start"){n=!0;return}if(a.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(rn,(o=>{const a=o.detail;ce({source:bt,type:"element-selected",detail:a})})),mt(({prev:o,next:a})=>{o==="picker"&&a==="idle"&&ce({source:bt,type:"exit-picker"})}),ce({source:bt,type:"frame-ready"}),document.addEventListener("mousedown",o=>{ce({source:bt,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&ce({source:bt,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&ce({source:bt,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function uf(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const a=o.getBoundingClientRect();return{x:a.left,y:a.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function pf(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function ff(){mt(({next:t})=>{Br({source:bt,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Br({source:bt,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Br({source:bt,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(zs(e)){if(br("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){hf(t.source,e.detail);return}if(e.type==="exit-picker"){I("idle");return}if(e.type==="iframe-mousedown"){Ca("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";Ca(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){mf(t.source);return}}})}function hf(t,e){const n=pf(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};br("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(rn,{detail:o})),I("idle")}function Ca(t,e,n,r){const o=uf(e),a=n+o.x,i=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:a,clientY:i}))}function mf(t){if(st()==="picker")try{t==null||t.postMessage({source:bt,type:"set-mode",mode:"picker"},"*"),br("top → late child: set-mode picker")}catch{}}function gf(){if(typeof window>"u")return;window===window.top?ff():df()}const bf="iframe-tool-overlay",Da=new Set(["text","shape","freedraw"]);let ge=[],Ur=!1,de=null;function vf(){typeof window>"u"||window===window.top&&(mt(({next:t})=>{Da.has(t)?Pa():Fs()}),Da.has(st())&&Pa())}function Pa(){Fs(),Ra(),window.addEventListener("scroll",Xn,!0),window.addEventListener("resize",Xn),de=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&Ra()}),de.observe(document.body,{childList:!0,subtree:!0})}function Fs(){ge.forEach(t=>t.remove()),ge=[],window.removeEventListener("scroll",Xn,!0),window.removeEventListener("resize",Xn),de==null||de.disconnect(),de=null}function Ra(){ge.forEach(e=>e.remove()),ge=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",bf),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${O+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),ge.push(n),qs(n,e)})}const xn=8;function qs(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-xn}px`,t.style.top=`${n.top-xn}px`,t.style.width=`${n.width+xn*2}px`,t.style.height=`${n.height+xn*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function Xn(){Ur||(Ur=!0,requestAnimationFrame(()=>{Ur=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=ge[e];r&&qs(r,n),e++})}))}let _t=!1;function vr(){return _t}async function yf(){try{if(typeof(await chrome.storage.local.get(G.prompterWindowId))[G.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(_t=!0)}catch{}}async function _s(){if(_t){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}_t=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(_t=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Bs(){if(_t){_t=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function Us(t){try{await chrome.storage.local.set({[G.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function xf(){_t=!1}const wf="modulepreload",kf=function(t){return"/"+t},Na={},Sf=function(e,n,r){let o=Promise.resolve();if(n&&n.length>0){let i=function(l){return Promise.all(l.map(d=>Promise.resolve(d).then(p=>({status:"fulfilled",value:p}),p=>({status:"rejected",reason:p}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));o=i(n.map(l=>{if(l=kf(l),l in Na)return;Na[l]=!0;const d=l.endsWith(".css"),p=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${p}`))return;const u=document.createElement("link");if(u.rel=d?"stylesheet":wf,d||(u.as="script"),u.crossOrigin="",u.href=l,c&&u.setAttribute("nonce",c),document.head.appendChild(u),d)return new Promise((f,h)=>{u.addEventListener("load",f),u.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${l}`)))})}))}function a(i){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=i,window.dispatchEvent(s),!s.defaultPrevented)throw i}return o.then(i=>{for(const s of i||[])s.status==="rejected"&&a(s.reason);return e().catch(a)})},Pt="http://www.w3.org/2000/svg",Oa="manuscript-spotlight-mask",Ef="oklch(0.42 0.09 250)",Af=3,Mf="rgb(0, 0, 0)",$f=.55,Oe=14;let ee=null,et=null,Q=null,Z=null,U=null,Lt=null,Ue=0,io=[],ue=null;function Ho(t){Ue++,ee=t,et||If(),so(),Le(),js(t),ue||(ue=Ce(so))}function $e(){Ue++,ee=null,Ws(),ue==null||ue(),ue=null,et&&(et.remove(),et=null,Q=null,Z=null,U=null,Lt=null)}function zo(t,e={}){var s;const n=e.durationMs??300;if(!ee||!et||n<=0){Ho(t),(s=e.onDone)==null||s.call(e);return}const r=Lf();Ue++;const o=Ue;ee=t,so(),js(t);const a=performance.now();function i(c){var u;if(o!==Ue)return;const l=Math.min(1,(c-a)/n),d=Tf(l),p=Vs(t);Xs({x:wn(r.x,p.x,d),y:wn(r.y,p.y,d),width:wn(r.width,p.width,d),height:wn(r.height,p.height,d)}),l<1?requestAnimationFrame(i):(Le(),(u=e.onDone)==null||u.call(e))}requestAnimationFrame(i)}function Lf(){if(!Q)return{x:0,y:0,width:0,height:0};const t=4,e=Number(Q.getAttribute("x")??0)+t,n=Number(Q.getAttribute("y")??0)+t,r=Number(Q.getAttribute("width")??0)-t*2,o=Number(Q.getAttribute("height")??0)-t*2;return{x:e,y:n,width:r,height:o}}function wn(t,e,n){return t+(e-t)*n}function Tf(t){return t<.5?4*t*t*t:1-Math.pow(-2*t+2,3)/2}function js(t){var n;Ws();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=Le;r.addEventListener("scroll",o,!0),io.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",Le)}function Ws(){for(const t of io)t.remove();io=[],window.removeEventListener("resize",Le)}function If(){et=document.createElementNS(Pt,"svg"),et.setAttribute("data-manuscript","ui"),et.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O}`].join("; "),et.setAttribute("width","100%"),et.setAttribute("height","100%");const t=document.createElementNS(Pt,"defs"),e=document.createElementNS(Pt,"mask");e.setAttribute("id",Oa);const n=document.createElementNS(Pt,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),Q=document.createElementNS(Pt,"rect"),Q.setAttribute("fill","black"),Q.setAttribute("rx","4"),Q.setAttribute("ry","4"),e.appendChild(Q),t.appendChild(e),et.appendChild(t),Lt=document.createElementNS(Pt,"rect"),Lt.setAttribute("width","100%"),Lt.setAttribute("height","100%"),Lt.setAttribute("mask",`url(#${Oa})`),et.appendChild(Lt),Z=document.createElementNS(Pt,"rect"),Z.setAttribute("fill","none"),Z.setAttribute("rx","4"),Z.setAttribute("ry","4"),Z.style.pointerEvents="none",et.appendChild(Z),U=document.createElementNS(Pt,"rect"),U.setAttribute("fill","none"),U.setAttribute("stroke","transparent"),U.setAttribute("stroke-width",String(Oe)),U.setAttribute("rx","4"),U.setAttribute("ry","4"),U.setAttribute("pointer-events","stroke"),U.style.cursor="pointer",U.addEventListener("click",Cf),et.appendChild(U),document.body.appendChild(et)}function so(){var a;if(!Z||!Lt)return;const t=((a=dt())==null?void 0:a.spotlight)??{},e=t.stroke??Ef,n=t.strokeWidth??Af,r=t.dimColor??Mf,o=t.dimOpacity??$f;Z.setAttribute("stroke",e),Z.setAttribute("stroke-width",String(n)),Lt.setAttribute("fill",r),Lt.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),Le()}function Cf(t){st()!=="replay"&&(!ee||!U||(t.stopPropagation(),t.preventDefault(),Sf(()=>import("./chunk-67M_Tuok.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{U&&e.openSpotlightEditor(U)})))}function Le(){ee&&Xs(Vs(ee))}function Vs(t){const e=t.getBoundingClientRect(),n=Df(t);return{x:e.left+n.x,y:e.top+n.y,width:e.width,height:e.height}}function Xs(t){if(!Q||!Z||!U)return;const e=4,n=t.x-e,r=t.y-e,o=t.width+e*2,a=t.height+e*2;Q.setAttribute("x",String(n)),Q.setAttribute("y",String(r)),Q.setAttribute("width",String(o)),Q.setAttribute("height",String(a));const i=Math.max(0,Number(Z.getAttribute("stroke-width")??0)),s=n-i/2,c=r-i/2,l=o+i,d=a+i;Z.setAttribute("x",String(s)),Z.setAttribute("y",String(c)),Z.setAttribute("width",String(l)),Z.setAttribute("height",String(d));const p=s-Oe/2,u=c-Oe/2,f=l+Oe,h=d+Oe;U.setAttribute("x",String(p)),U.setAttribute("y",String(u)),U.setAttribute("width",String(f)),U.setAttribute("height",String(h))}function Df(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const Ha="data-wp-animations";function Pf(){if(document.head.querySelector(`[${Ha}]`))return;const t=document.createElement("style");t.setAttribute(Ha,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function Ze(t,e,n){if(!e||e.kind==="none"||st()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const a=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",a),t.removeEventListener("animationcancel",a)};t.addEventListener("animationend",a),t.addEventListener("animationcancel",a)}const Gn="http://www.w3.org/2000/svg",Gs="data-annotation-text",za="data-annotation-arrow",Ys="data-annotation-shape",Fa="data-annotation-freedraw",D={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function Rf(t,e){const{svg:n,roughSvg:r}=D;if(!n||!r)return;const o=Of(t.id),{from:a,to:i}=Ed(t,e);Ks(t,s=>r.line(a.x,a.y,i.x,i.y,{roughness:1.5,bowing:1,seed:o,...s})),Nf(t,a,i,o+1)}function Nf(t,e,n,r){const{roughSvg:o}=D;if(!o)return;const a=Math.atan2(n.y-e.y,n.x-e.x),i=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-i*Math.cos(a-s),l=n.y-i*Math.sin(a-s),d=n.x-i*Math.cos(a+s),p=n.y-i*Math.sin(a+s),u=`M ${c} ${l} L ${n.x} ${n.y} L ${d} ${p}`;Ks(t,f=>o.path(u,{roughness:1.5,bowing:1,seed:r,...f}))}function Ks(t,e){const{svg:n}=D;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(za,t.id),Ze(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(za,t.id),Ze(o,t.entryAnimation,0),n.appendChild(o)}function Of(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const k={state:null,unsubscribeStep:null};function ft(){return k.state!==null}function an(){var t;return((t=k.state)==null?void 0:t.standalone)===!0}function Hf(t,e){const{svg:n}=D;if(!n)return;const r=ur(t,e),o=zf(t,r),a=r.map(c=>`${c.x},${c.y}`).join(" "),i=document.createElementNS(Gn,"polyline");if(i.setAttribute("points",a),i.setAttribute("fill","none"),i.setAttribute("stroke",t.stroke),i.setAttribute("stroke-width",String(t.strokeWidth)),i.setAttribute("stroke-linecap","round"),i.setAttribute("stroke-linejoin","round"),i.setAttribute(Fa,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&i.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&i.setAttribute("transform",o),i.style.pointerEvents="none",Ze(i,t.entryAnimation,t.rotate??0),n.appendChild(i),an())return;const s=document.createElementNS(Gn,"polyline");s.setAttribute(Fa,t.id),s.setAttribute("points",a),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),Ff(t.id,c,s))}),n.appendChild(s)}function zf(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,a=-1/0,i=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>a&&(a=l.x),l.y>i&&(i=l.y);const s=(r+a)/2,c=(o+i)/2;return`rotate(${n} ${s} ${c})`}function Ff(t,e,n){const r=P(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},a=ot(),i=ur(r,a).map(d=>({...d}));let s=!1;const c=d=>{const p=d.clientX-o.x,u=d.clientY-o.y;if(!s&&Math.hypot(p,u)<3)return;s=!0,d.preventDefault();const f=i.map(b=>({x:b.x+p,y:b.y+u})),h=a?{points:f,pointsAnchorOffset:f.map(b=>({x:b.x-a.left,y:b.y-a.top}))}:{points:f,pointsAnchorOffset:void 0};R(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const d=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),p=d[d.length-1]??n;Nu(t,p)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function qf(t,e){const{svg:n}=D;if(!n)return;const r=dr(t,e),o=No(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(Ys,t.id),o.style.pointerEvents="none",Ze(o,t.entryAnimation,t.rotate??0),n.appendChild(o),an()||n.appendChild(_f(t,r)))}function _f(t,e){const n=document.createElementNS(Gn,"rect");if(n.setAttribute(Ys,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>Bf(t.id,r,n)),n}function Bf(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=P(t);if(!o||o.kind!=="shape")return;const a=ot(),i=o.boundsAnchorOffset&&a?{x:a.left+o.boundsAnchorOffset.x,y:a.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:i.x,y:i.y};let c=!1;const l=p=>{const u=p.clientX-r.x,f=p.clientY-r.y;if(!c&&Math.hypot(u,f)<3)return;c=!0,p.preventDefault();const h=s.x+u,b=s.y+f,v=a?{bounds:{...s,x:h,y:b},boundsAnchorOffset:{x:h-a.left,y:b-a.top}}:{bounds:{...s,x:h,y:b},boundsAnchorOffset:void 0};R(t,v)},d=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const p=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=p[p.length-1]??n;Ru(t,u)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)}function Uf(t,e){const{host:n}=D;if(!n)return;const r=document.createElement("div");r.setAttribute(Gs,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,a=t.style.backgroundColor??"#ffffff",i=t.style.backgroundOpacity??.96,s=a==="transparent"?"transparent":jf(a,i),c=t.rotate??0,l=t.style.borderColor??"#000000",d=l==="transparent"?"none":`2px solid ${l}`,p=Sd(t,e),u=an();r.style.cssText=["position: absolute",`left: ${p.x}px`,`top: ${p.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${d}`,"border-radius: 8px",u?"pointer-events: none":"pointer-events: auto",u?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,u||Wf(r,t.id),Ze(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function jf(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,a=0,i=0;return r.length===4?(o=parseInt(r[1]+r[1],16),a=parseInt(r[2]+r[2],16),i=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),a=parseInt(r.slice(3,5),16),i=parseInt(r.slice(5,7),16)),`rgba(${o}, ${a}, ${i}, ${n})`}return t}function Wf(t,e){let n=!1,r=0,o=0,a=0,i=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();a=l.left,i=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,d=c.clientY-o;Math.abs(l)+Math.abs(d)>2&&(s=!0),t.style.left=`${a+l}px`,t.style.top=`${i+d}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),d=ot(),p=d?{position:{x:c,y:l},anchorOffset:{x:c-d.left,y:l-d.top}}:{position:{x:c,y:l},anchorOffset:void 0};R(e,p)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),Pu(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Vf(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",R(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Vf(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function Zs(){if(D.host)return;Pf();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+3}`].join("; ");const e=document.createElementNS(Gn,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),D.host=t,D.svg=e,D.roughSvg=ls.svg(e),document.body.appendChild(t),D.unsubscribe=Ce(Ln),D.unsubscribeMode=mt(Ln),Xf(),Ln()}let be=null;function je(){be===null&&(be=requestAnimationFrame(()=>{be=null,Ln()}))}let Zt=null,co=null;function Xf(){window.addEventListener("resize",je),window.addEventListener("scroll",je,!0),typeof ResizeObserver<"u"&&(Zt=new ResizeObserver(je))}function Gf(){window.removeEventListener("resize",je),window.removeEventListener("scroll",je,!0),Zt&&(Zt.disconnect(),Zt=null),co=null,be!==null&&(cancelAnimationFrame(be),be=null)}function Qs(){var t,e;(t=D.unsubscribe)==null||t.call(D),D.unsubscribe=null,(e=D.unsubscribeMode)==null||e.call(D),D.unsubscribeMode=null,Gf(),D.host&&(D.host.remove(),D.host=null,D.svg=null,D.roughSvg=null)}function Yf(){return D.host!==null}function Ln(){const{host:t,svg:e}=D;if(!t||!e)return;for(t.querySelectorAll(`[${Gs}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=ot();if(Zt){let o=null;try{o=Kf()}catch{o=null}o!==co&&(Zt.disconnect(),o&&Zt.observe(o),co=o)}const r=Di();for(const o of r)o.kind==="text"?Uf(o,n):o.kind==="arrow"?Rf(o,n):o.kind==="shape"?qf(o,n):o.kind==="freedraw"&&Hf(o,n)}function Kf(){const t=dt();if(!(t!=null&&t.selectors))return null;try{return Se(t.selectors)}catch{return null}}const A={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function pe(t,e,n){return Math.max(e,Math.min(n,t))}function Js(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=th()),Zf()}function Zf(){const{host:t}=A;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),a=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${pe(o,0,n)}px`),Number.isFinite(a)&&(t.style.top=`${pe(a,0,r)}px`)}async function Qf(){try{return(await chrome.storage.local.get(G.replayControlsOrientation))[G.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Jf(t){try{await chrome.storage.local.set({[G.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function th(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function eh(){try{const e=(await chrome.storage.local.get(G.replayControlsPosition))[G.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function qa(t){try{await chrome.storage.local.set({[G.replayControlsPosition]:t})}catch{}}function nh(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function rh(){const{host:t,shadow:e}=A;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,a=0,i=0,s=0;const c=u=>{if(!A.host)return;u.preventDefault(),u.stopPropagation(),r=!0,n.classList.add("dragging");const f=A.host.getBoundingClientRect();A.host.style.left=`${f.left}px`,A.host.style.top=`${f.top}px`,A.host.style.bottom="auto",A.host.style.transform="none",o=u.clientX,a=u.clientY,i=f.left,s=f.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)},l=u=>{if(!r||!A.host)return;const f=A.host.getBoundingClientRect(),h=u.clientX-o,b=u.clientY-a,v=pe(i+h,0,window.innerWidth-f.width),w=pe(s+b,0,window.innerHeight-f.height);A.host.style.left=`${v}px`,A.host.style.top=`${w}px`},d=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const u=A.host;if(u){const f=parseFloat(u.style.left||"0"),h=parseFloat(u.style.top||"0");Number.isFinite(f)&&Number.isFinite(h)&&qa({left:f,top:h})}},p=()=>{if(A.host&&A.host.style.transform==="none"){const u=A.host.getBoundingClientRect(),f=pe(u.left,0,window.innerWidth-u.width),h=pe(u.top,0,window.innerHeight-u.height);A.host.style.left=`${f}px`,A.host.style.top=`${h}px`,qa({left:f,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",p),A.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",p),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0)}}function tc(){return`
    ${yt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function ec(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function oh(t){return ec(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function ah(t,e){const{shadow:n}=A;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,a)=>{const i=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${a===e?" active":""}" role="option" data-action="step-jump" data-index="${a}" aria-selected="${a===e}" title="${oh(i)}">${a+1}. ${ec(i)}</li>`}).join(""))}function ih(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function lo(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function nc(t){const{host:e,shadow:n}=A;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||lo()}let Tn=-1,In=!1;function sh(){Tn=-1,In=!1}function ch(t,e,n,r=0){const{shadow:o}=A;if(!o)return;const a=o.querySelector('[data-region="progress"]');if(!a)return;if(e===null||e<=0){a.classList.add("hidden"),a.innerHTML="",Tn=-1,In=!1;return}a.classList.remove("hidden");const c=t!==Tn||In&&!n;Tn=t,In=n;let l=a.querySelector(".progress-fill");if(!l||c){l==null||l.remove(),l=document.createElement("div"),l.className="progress-fill",l.style.animationDuration=`${e}ms`;const d=Math.max(0,Math.min(r,e-1));d>0&&(l.style.animationDelay=`-${d}ms`),a.appendChild(l)}l.classList.toggle("paused",n)}function lh(){return`
    ${yt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid color-mix(in oklch, currentColor, transparent 40%);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: color-mix(in oklch, currentColor, transparent 92%); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: color-mix(in oklch, currentColor, transparent 85%); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: color-mix(in oklch, currentColor, transparent 80%);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: color-mix(in oklch, currentColor, transparent 82%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: color-mix(in oklch, currentColor, transparent 45%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: color-mix(in oklch, currentColor, transparent 25%);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: color-mix(in oklch, currentColor, transparent 92%); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function dh(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function uh(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function ph(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?dh(14):uh(14))}function sn(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Ct(t);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}let rc=!1;function fh(t){if(A.host)return;const{host:e,shadow:n}=sn();A.host=e,A.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+6}`,"pointer-events: auto",rc?"display: none":""].filter(Boolean).join("; "),n.innerHTML=`<style>${lh()}</style>${hh()}`,n.addEventListener("click",r=>mh(r,t)),document.body.appendChild(e),rh(),document.addEventListener("mousedown",nc,!0),A.orientationApplied=!1,Qf().then(r=>{A.orientationApplied||(A.orientationApplied=!0,Js(r))}),eh().then(r=>{A.host&&r&&A.host.style.transform!=="none"&&nh(A.host,r)})}function hh(){return`
    <div class="bar" role="toolbar" aria-label="${m("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${m("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${m("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${m("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${m("replay.prompter-aria")}" title="${m("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${m("replay.tts-aria")}" title="${m("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${m("replay.move-aria")}" title="${m("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${m("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${m("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function mh(t,e){var a;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){ih();return}const r=n.closest('[data-action="step-jump"]');if(r){const i=Number(r.getAttribute("data-index"));Number.isFinite(i)&&(lo(),e.onStepSelect(i));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(a=n.closest("[data-action]"))==null?void 0:a.getAttribute("data-action");switch(o&&lo(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":gh();break}}function gh(){const{shadow:t}=A;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";A.orientationApplied=!0,Js(n),Jf(n)}function jr(t){rc=t;const{host:e}=A;e&&(e.dataset.recordingHidden=t?"1":"",e.style.display=t?"none":"")}function bh(){var t,e;(t=A.cleanupDrag)==null||t.call(A),A.cleanupDrag=null,document.removeEventListener("mousedown",nc,!0),(e=A.host)==null||e.remove(),A.host=null,A.shadow=null,A.orientationApplied=!1,sh()}function _a(t){const{shadow:e}=A;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const a=e.querySelector('[data-action="prev"]');a&&a.toggleAttribute("disabled",t.currentIndex<=0);const i=e.querySelector('[data-action="next"]');i&&(i.toggleAttribute("disabled",!1),i.setAttribute("aria-label",t.currentIndex>=t.total-1?m("replay.finish-aria"):m("replay.next-aria"))),ch(t.currentIndex,t.timerDurationMs??null,t.paused,t.timerElapsedMs??0),ah(t.steps??[],t.currentIndex),ph(t.ttsEnabled===!0)}let Ht=null;function vh(t){cn();const{host:e,shadow:n}=sn();Ht=e,Ht.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${tc()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${m("replay.notfound.title")}</h2>
          <p>${m("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${m("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${m("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const a=o.target;if(!(a instanceof HTMLElement))return;const i=(s=a.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");i==="skip"?t.onSkip():i==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),Ht.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(Ht)}function cn(){if(!Ht)return;const t=Ht.__cleanup;t==null||t(),Ht.remove(),Ht=null}let zt=null;function yh(t){Yn();const{host:e,shadow:n}=sn();zt=e,zt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${tc()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${m("replay.url-mismatch.title")}</h2>
          <p>${m("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${m("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${m("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${m("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",a=>{var c;const i=a.target;if(!(i instanceof HTMLElement))return;const s=(c=i.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=a=>{a.key==="Escape"?(a.preventDefault(),t.onCancel()):a.key==="Enter"&&(a.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),zt.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(zt)}function Yn(){if(!zt)return;const t=zt.__cleanup;t==null||t(),zt.remove(),zt=null}let Xt=null;function oc(t){ln();const e=t.getBoundingClientRect(),n=xh(t),r=e.left+n.x,o=e.top+n.y,a=e.bottom+n.y,i=36,s=8,c=o-s-i<8,l=c?Math.min(window.innerHeight-8-i,a+s):Math.max(8,o-s-i),d=Math.max(8,Math.min(r,window.innerWidth-200)),p=c?"up":"down",{host:u,shadow:f}=sn();Xt=u,Xt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${d}px`,`z-index: ${O+6}`,"pointer-events: none"].join("; "),f.innerHTML=`
    <style>
      ${yt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${m("prompter.action-step")}</span>
      <span>${m("replay.action-prompt")}</span>
      <span class="tip ${p}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Xt)}function ln(){Xt==null||Xt.remove(),Xt=null}function xh(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let ve=null;function wh(t){ve||(ve=e=>{if(k.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",ve,!0))}function kh(){ve&&(document.removeEventListener("keydown",ve,!0),ve=null)}function yr(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function ac(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function Sh(t,e){var r,o,a;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||yr(n,location.href)||((o=k.state)==null?void 0:o.standalone)===!0)return!1;try{await vo({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((a=k.state)==null?void 0:a.paused)??!1})}catch(i){console.warn("[manuscript] persist activeReplay before nav failed",i)}return location.href=n,!0}function ic(t){return new Promise(e=>{yh({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{Yn(),e("force")},onCancel:()=>{Yn(),e("cancel")}})})}async function Eh(t){try{const e=await hi();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Fo(){const t=L();if(!(!t||!k.state)&&k.state.standalone!==!0)try{await vo({scenarioId:t.id,stepIndex:B(),startedAt:Date.now(),paused:k.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function sc(t,e,n){const r=L();if(!r)return{ok:!1};if(n&&await Eh(r.id))return{ok:!0};const o=ac(r);if(!o||yr(o,location.href))return{ok:!0};const a=await ic(o);return a==="cancel"?{ok:!1}:a==="navigate"?(await vo({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class cc extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function lc(t,e=pi){return uo(t,e).then(n=>n.el)}function uo(t,e=pi){const n=to(t);return n?Promise.resolve(n):new Promise((r,o)=>{let a=!1;const s=(_i(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(a)return;const d=to(t);d&&(a=!0,c.disconnect(),clearTimeout(l),r(d))}),l=setTimeout(()=>{a||(a=!0,c.disconnect(),o(new cc(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function De(){const{state:t}=k;if(!t)return;const e=L();if(!e)return;const n=e.steps[B()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;let o=0;if(r!==null){if(t.autoAdvanceResumeMs!==null)o=Math.max(0,r-t.autoAdvanceResumeMs);else if(t.subSeqResume&&(n!=null&&n.subDwellsMs)){const{idx:a,elapsedMs:i}=t.subSeqResume,s=n.subDwellsMs;let c=0;const l=a+1;for(let d=0;d<l;d++)c+=s[d]??0;o=Math.max(0,Math.min(r,c+i))}}if(gi().then(a=>{_a({currentIndex:B(),total:e.steps.length,paused:t.paused,timerDurationMs:r,timerElapsedMs:o,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:a})}),_a({currentIndex:B(),total:e.steps.length,paused:t.paused,timerDurationMs:r,timerElapsedMs:o,steps:e.steps.map(a=>({name:a.name}))}),vr()){const a=B(),i=e.steps[a],s=e.steps[a+1];Us({scenarioId:e.id,scenarioName:e.name,currentIndex:a,total:e.steps.length,paused:t.paused,steps:e.steps.map(c=>({name:c.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:s?{name:s.name,description:s.description,autoAdvanceMs:s.autoAdvanceMs??null,waitForNavigation:s.waitForNavigation,thumbnailDataUrl:s.thumbnailDataUrl??null}:null})}}async function Ah(){if(vr()){await Bs(),Kn(!1);return}Kn(!0),await _s(),De()}function Mh(){Kn(!1)}function Kn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}const $h=.125;function dn(t,e={}){const{behavior:n}=e,r=window.innerHeight,o=t.getBoundingClientRect(),a=window.scrollY+o.top;let i;o.height>r?i=a-r*$h:i=a-(r-o.height)/2,i=Math.max(0,Math.round(i)),window.scrollTo(n?{top:i,behavior:n}:{top:i})}async function xr(t){var i,s;const{state:e}=k;if(!e)return;const n=L();if(!n)return;const r=n.steps[B()];if(De(),!r)return;cn(),ln();const o=B();if(nl()&&!e.paused&&e.narratedStepIndex!==o&&rl(r.description).then(c=>{c&&k.state&&B()===o&&(k.state.narratedStepIndex=o)}),!r.selectors){$e(),r.waitForNavigation||ja(t);return}const a=new AbortController;e.pendingWait=a;try{const c=await lc(r.selectors);if(a.signal.aborted)return;dn(c),Ho(c);const l=r.subElements??[];if(l.length>0){const d=new AbortController;(i=e.subSequenceAbort)==null||i.abort(),e.subSequenceAbort=d,Lh(c,r,l,d,t).finally(()=>{var p;((p=k.state)==null?void 0:p.subSequenceAbort)===d&&(k.state.subSequenceAbort=null)});return}r.waitForNavigation?(oc(c),dc(c,a,t.onNext)):ja(t)}catch(c){if(a.signal.aborted)return;if(c instanceof cc){$e(),vh({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",c)}finally{((s=k.state)==null?void 0:s.pendingWait)===a&&(k.state.pendingWait=null)}}async function Lh(t,e,n,r,o){var f;const a=e.subDwellsMs??[],i=a[0]??0;let s=t;const c=((f=k.state)==null?void 0:f.subSeqResume)??null,l=(c==null?void 0:c.idx)??-1,d=(c==null?void 0:c.elapsedMs)??0;if(k.state&&(k.state.subSeqResume=null),l===-1){Ba(-1);const h=Math.max(0,i-d);if(await Ua(h,r.signal),r.signal.aborted)return}const p=Math.max(0,l);for(let h=p;h<n.length;h++){const b=n[h];if(!b)continue;let v;try{v=await lc(b.selectors)}catch(S){console.warn("[manuscript] sub element not resolved, skipping",S);continue}if(r.signal.aborted)return;dn(v),zo(v,{durationMs:350}),s=v,Ba(h);const w=a[h+1]??0,x=h===l?Math.max(0,w-d):w;if(await Ua(x,r.signal),r.signal.aborted)return}if(k.state&&(k.state.subSeqNodeIdx=null,k.state.subSeqNodeStartMs=null),e.waitForNavigation){oc(s),dc(s,r,o.onNext);return}const u=bi();u&&(await Promise.race([u,new Promise(h=>{r.signal.aborted?h():r.signal.addEventListener("abort",()=>h(),{once:!0})})]),r.signal.aborted)||!k.state||k.state.paused||o.onNext()}function Ba(t){const{state:e}=k;e&&(e.subSeqNodeIdx=t,e.subSeqNodeStartMs=Date.now())}function Ua(t,e){return t<=0?Promise.resolve():new Promise(n=>{const r=window.setTimeout(()=>n(),t);e.addEventListener("abort",()=>{window.clearTimeout(r),n()},{once:!0})})}function dc(t,e,n){if(!k.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!k.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function ja(t){var c;const{state:e}=k;if(!e||e.paused)return;const n=L();if(!n)return;const r=B(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(c=e.autoAdvanceAbort)==null||c.abort();const a=new AbortController;e.autoAdvanceAbort=a;const i=e.autoAdvanceResumeMs;e.autoAdvanceResumeMs=null;const s=i??o.autoAdvanceMs;e.autoAdvanceDeadlineMs=s&&s>0?Date.now()+s:null,(async()=>{const l=[],d=bi();d&&l.push(d),s&&s>0&&l.push(new Promise(p=>{const u=window.setTimeout(()=>{k.state&&k.state.autoAdvanceTimer===u&&(k.state.autoAdvanceTimer=null),p()},s);k.state&&(k.state.autoAdvanceTimer=u),a.signal.addEventListener("abort",()=>{window.clearTimeout(u),p()})})),l.length!==0&&(await Promise.race([Promise.all(l).then(()=>{}),new Promise(p=>{a.signal.aborted?p():a.signal.addEventListener("abort",()=>p(),{once:!0})})]),!a.signal.aborted&&(!k.state||k.state.paused||B()===r&&t.onNext()))})()}function wr(t={}){var n,r,o;const{state:e}=k;if(e){if(t.pauseTts){if(e.subSeqNodeIdx!==null&&e.subSeqNodeStartMs!==null){const a=Math.max(0,Date.now()-e.subSeqNodeStartMs);e.subSeqResume={idx:e.subSeqNodeIdx,elapsedMs:a}}if(e.autoAdvanceDeadlineMs!==null){const a=Math.max(0,e.autoAdvanceDeadlineMs-Date.now());e.autoAdvanceResumeMs=a>0?a:null}}else e.subSeqResume=null,e.autoAdvanceResumeMs=null,e.narratedStepIndex=null;e.subSeqNodeIdx=null,e.subSeqNodeStartMs=null,e.autoAdvanceDeadlineMs=null,e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(n=e.autoAdvanceAbort)==null||n.abort(),e.autoAdvanceAbort=null,(r=e.pendingWait)==null||r.abort(),e.pendingWait=null,(o=e.subSequenceAbort)==null||o.abort(),e.subSequenceAbort=null,t.pauseTts?ol():vi()}}const kr={onNext:()=>void Qe(),onExit:()=>void Te()};async function Pe(t=0,e={}){if(k.state)return;const n=L();if(!n||n.steps.length===0||e.standalone!==!0&&!(await sc(n.id,t,!0)).ok)return;k.state={originalStepIndex:B(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,subSequenceAbort:null,subSeqNodeIdx:null,subSeqNodeStartMs:null,subSeqResume:null,autoAdvanceDeadlineMs:null,autoAdvanceResumeMs:null,narratedStepIndex:null,atEnd:!1,standalone:e.standalone===!0},I("replay"),fh({onPrev:Zn,onNext:Qe,onTogglePause:Je,onExit:Te,onStepSelect:o=>void _o(o),onTogglePrompter:()=>void Ah(),onToggleTts:()=>void Th()}),vr()&&Kn(!0),wh({onNext:()=>void Qe(),onPrev:()=>void Zn(),onTogglePause:Je,onExit:()=>void Te()}),k.unsubscribeStep=Ce(De);const r=Math.min(Math.max(0,t),n.steps.length-1);Dt(r),await Fo(),await xr(kr)}async function qo(t){if(!k.state)return;const e=L();e&&(t<0||t>=e.steps.length||(wr(),cn(),ln(),k.state.atEnd=!1,!await Sh(e,t)&&(Dt(t),await Fo(),await xr(kr))))}async function _o(t){t!==B()&&await qo(t)}async function Qe(){const{state:t}=k;if(!t)return;const e=L();if(!e)return;const n=B();if(n>=e.steps.length-1){wr(),cn(),ln(),t.paused=!0,t.atEnd=!0,De(),document.dispatchEvent(new CustomEvent("manuscript:replay-end"));return}await qo(n+1)}async function Zn(){await qo(B()-1)}async function Th(){const t=!await gi();await al(t),t||vi(),De()}function Je(){const{state:t}=k;if(t){if(t.atEnd&&t.paused){Ih();return}t.paused=!t.paused,t.paused?wr({pauseTts:!0}):xr(kr),De()}}async function Ih(){if(!k.state)return;const t=L();!t||!(await sc(t.id,0,!1)).ok||k.state&&(k.state.paused=!1,k.state.atEnd=!1,Dt(0),await Fo(),await xr(kr))}async function Te(){var r;const{state:t}=k;if(!t)return;wr(),cn(),ln(),Yn(),$e(),bh(),Bs(),kh(),(r=k.unsubscribeStep)==null||r.call(k),k.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;k.state=null,Dt(e),I("idle"),await Kc(),n&&(Qs(),Ii())}const Sr="manuscript:selector-health-changed",Qn=new Map,Jn=new Map;function uc(t,e){return`${t}::${e}`}function Er(t){return t===void 0?"none":t===null?"red":t===1?"green":t===2?"yellow":"orange"}function Ar(t,e){return e?Jn.get(uc(t,e)):Qn.get(t)}function Ch(t,e){return t===void 0?!0:t!==e}function Vt(t){const e=Ar(t.stepId,t.subId);Ch(e,t.layer)&&(t.subId?Jn.set(uc(t.stepId,t.subId),t.layer):Qn.set(t.stepId,t.layer),typeof document<"u"&&document.dispatchEvent(new CustomEvent(Sr,{detail:{stepId:t.stepId,subId:t.subId??null,layer:t.layer}})))}function Dh(){Qn.size===0&&Jn.size===0||(Qn.clear(),Jn.clear(),typeof document<"u"&&document.dispatchEvent(new CustomEvent(Sr,{detail:{stepId:"",subId:null,layer:null,cleared:!0}})))}function Ph(t){const e=[],n=new Map;for(const r of t.steps){const o=r.pickedAtUrl&&r.pickedAtUrl.length>0?r.pickedAtUrl:t.url,a=Rh(o);let i=n.get(a);i||(i={url:o??"",stepIds:[]},n.set(a,i),e.push(i)),i.stepIds.push(r.id)}return e}function Rh(t){if(!t)return"";try{const e=new URL(t);return`${e.origin}${e.pathname}`}catch{return t}}function Nh(t,e){return{scenarioId:t.id,startedAt:Date.now(),returnTo:e,groups:Ph(t),currentGroupIdx:0,stepResults:{},subResults:{}}}function Wa(t){return t===1?"green":t===2?"yellow":t===3?"orange":"red"}const Va=2e3;async function Oh(t,e,n){const r=e.groups[e.currentGroupIdx];r&&(await Promise.allSettled(r.stepIds.map(async o=>{const a=t.steps.find(i=>i.id===o);if(a){if(!a.selectors)e.stepResults[o]="no-element",Vt({stepId:o,layer:null}),n==null||n();else{try{const i=await uo(a.selectors,Va);e.stepResults[o]=Wa(i.layer),Vt({stepId:o,layer:i.layer})}catch{e.stepResults[o]="red",Vt({stepId:o,layer:null})}n==null||n()}await Promise.allSettled((a.subElements??[]).map(async i=>{try{const s=await uo(i.selectors,Va);e.subResults[`${o}::${i.id}`]=Wa(s.layer),Vt({stepId:o,subId:i.id,layer:s.layer})}catch{e.subResults[`${o}::${i.id}`]="red",Vt({stepId:o,subId:i.id,layer:null})}n==null||n()}))}})),e.currentGroupIdx+=1)}function pc(t){return t.currentGroupIdx>=t.groups.length}function Hh(t){const e=t.groups[t.currentGroupIdx];return e?e.url:null}async function zh(t){await Qc(t)}async function Tt(){await Zc()}function fc(t){for(const[e,n]of Object.entries(t.stepResults))Vt({stepId:e,layer:Xa(n)});for(const[e,n]of Object.entries(t.subResults)){const r=e.indexOf("::");if(r<0)continue;const o=e.slice(0,r),a=e.slice(r+2);Vt({stepId:o,subId:a,layer:Xa(n)})}}function Xa(t){return t==="green"?1:t==="yellow"?2:t==="orange"?3:null}const Ie={stepId:null,selectedIds:[],anchorId:null,primarySelected:!1};function hc(t,e,n){return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1}}function Fh(t,e,n){if(t.stepId!==e)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=t.selectedIds.includes(n)?t.selectedIds.filter(a=>a!==n):[...t.selectedIds,n];return{stepId:e,selectedIds:o,anchorId:n,primarySelected:!1}}function qh(t,e,n,r){if(t.stepId!==e||!t.anchorId)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const o=r.indexOf(t.anchorId),a=r.indexOf(n);if(o<0||a<0)return{stepId:e,selectedIds:[n],anchorId:n,primarySelected:!1};const i=Math.min(o,a),s=Math.max(o,a);return{stepId:e,selectedIds:r.slice(i,s+1),anchorId:t.anchorId,primarySelected:!1}}function _h(t,e){return{stepId:e,selectedIds:[],anchorId:null,primarySelected:!0}}function Mr(t,e){return t.stepId===e?t.selectedIds:[]}function mc(t,e){return t.stepId===e&&t.primarySelected}const Bh=320,ye=32,Uh=.8,tr=200,g={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null,pickerTarget:{type:"primary"},subSelection:Ie,subDragSet:null,subDragStepId:null};function rt(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function T(t){return rt(t)}function It(t,e=!1,n=5e3){const{shadow:r}=g;if(!r)return;const o=r.querySelector('[data-region="toast"]');o&&(o.textContent=t,o.classList.add("visible"),o.classList.toggle("error",e),g.toastTimer!==null&&window.clearTimeout(g.toastTimer),g.toastTimer=window.setTimeout(()=>{o.classList.remove("visible"),g.toastTimer=null},n))}function er(t,e,n){return Math.max(e,Math.min(n,t))}let We=null,nr=null,nt=null,Ve=null;function po(t){nt=t,We||jh(),gc(t)}function Ut(t){nt&&(nt={...nt,...t},gc(nt))}function xe(){Ve&&(document.removeEventListener("keydown",Ve,!0),Ve=null),We&&(We.remove(),We=null,nr=null,nt=null)}function jh(){const{host:t,shadow:e}=sn();We=t,nr=e,t.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),e.addEventListener("click",Wh),Ve=n=>{n.key==="Escape"&&nt&&nt.phase!=="validating"&&nt.phase!=="navigating"&&(n.preventDefault(),nt.onClose())},document.addEventListener("keydown",Ve,!0),document.body.appendChild(t)}function Wh(t){if(!nt)return;const e=t.target;if(!(e instanceof HTMLElement))return;if(e.closest('[data-action="close"]')){nt.onClose();return}if(e.closest('[data-action="start"]')){nt.onStart();return}const n=e.closest('[data-action="go-step"]');if(n!=null&&n.dataset.stepId){nt.onGoToStep(n.dataset.stepId);return}const r=e.closest('[data-action="repick"]');if(r!=null&&r.dataset.stepId){nt.onRepick(r.dataset.stepId);return}}function gc(t){nr&&(nr.innerHTML=`
    <style>${yt()}${Qh()}</style>
    ${Vh(t)}
  `)}function Vh(t){var i;const{scenario:e,session:n,phase:r}=t,o=Zh(e,n),a=typeof chrome<"u"&&((i=chrome.runtime)!=null&&i.getURL)?chrome.runtime.getURL("icons/manuscript.svg"):"";return`
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="vm-title">
      <div class="head">
        <div class="brand-row">
          <div class="brand">
            ${a?`<img class="brand-mark" src="${T(a)}" alt="" aria-hidden="true">`:""}
            <span class="brand-wordmark">Manuscript</span>
          </div>
          <div class="head-actions">
            ${Gh(r)}
            <button type="button" class="close-x" data-action="close" aria-label="${T(m("validate.close"))}" title="${T(m("validate.close"))}">×</button>
          </div>
        </div>
        <div class="title-row">
          <h2 id="vm-title">${rt(m("validate.modal-title"))}</h2>
          <div class="summary">${Xh(o)}</div>
        </div>
      </div>
      ${Yh(t)}
      <ul class="rows">${e.steps.map((s,c)=>Kh(s,c,n)).join("")}</ul>
    </div>
  `}function Xh(t){const e=(n,r,o)=>`<span class="sum-item"><span class="sum-dot" data-status="${n}"></span>${rt(m(r))} ${o}</span>`;return[e("green","validate.label-ok",t.ok),e("yellow","validate.label-fallback",t.fallback),e("red","validate.label-broken",t.broken),e("pending","validate.label-pending",t.pending)].join('<span class="sum-sep">·</span>')}function Gh(t){return t==="initial"?`<button class="primary" data-action="start">${rt(m("validate.start"))}</button>`:t==="complete"?`<span class="pill complete">${rt(m("validate.complete"))}</span>`:`<span class="pill">${rt(m("validate.in-progress"))}</span>`}function Yh(t){var e;if(t.phase==="navigating")return`<div class="banner">${rt(m("validate.navigating-to",{url:t.navigatingTo??""}))}</div>`;if(t.phase==="validating"){const n=(e=t.session.groups[t.session.currentGroupIdx])==null?void 0:e.url;return`<div class="banner">${rt(m("validate.checking",{url:n??""}))}</div>`}return""}function Kh(t,e,n){const r=n.stepResults[t.id],o=r??"pending",a=t.thumbnailDataUrl?` style="background-image: url('${T(t.thumbnailDataUrl)}')"`:"",i=Ga(r,t.selectors===null),s=(t.subElements??[]).map(c=>`<span class="sub-dot" data-status="${n.subResults[`${t.id}::${c.id}`]??"pending"}" title="${T(Ga(n.subResults[`${t.id}::${c.id}`],!1))}"></span>`).join("");return`
    <li class="row" data-status="${o}">
      <div class="thumb"${a}><span class="row-idx">${e+1}</span></div>
      <div class="meta">
        <div class="name">${rt(t.name)||'<span class="muted">(unnamed)</span>'}</div>
        <div class="status-line">
          <span class="dot" data-status="${o}"></span>
          <span class="status-text">${rt(i)}</span>
          ${s?`<span class="sub-dots">${s}</span>`:""}
        </div>
      </div>
      <div class="actions">
        <button class="action-btn" data-action="go-step" data-step-id="${T(t.id)}">${rt(m("validate.row-go"))}</button>
        ${r==="red"||r==="orange"?`<button class="action-btn primary" data-action="repick" data-step-id="${T(t.id)}">${rt(m("validate.row-repick"))}</button>`:""}
      </div>
    </li>
  `}function Ga(t,e){return e?m("validate.status-no-element"):t===void 0?m("validate.status-pending"):t==="green"?m("validate.status-green"):t==="yellow"?m("validate.status-yellow"):t==="orange"?m("validate.status-orange"):t==="red"?m("validate.status-red"):t==="no-element"?m("validate.status-no-element"):""}function Zh(t,e){let n=0,r=0,o=0,a=0;for(const i of t.steps){const s=e.stepResults[i.id];s==="green"?n++:s==="yellow"||s==="orange"?r++:s==="red"?o++:a++}return{ok:n,fallback:r,broken:o,pending:a}}function Qh(){return`
    :host { font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }
    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px;
      width: min(580px, calc(100vw - 32px));
      max-height: calc(100vh - 64px);
      display: flex;
      flex-direction: column;
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-primary);
    }
    .head {
      margin-bottom: 12px;
    }
    .brand-row {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      margin-bottom: 10px;
    }
    .brand {
      display: flex;
      align-items: center;
      gap: 8px;
      color: var(--c-text);
    }
    .brand-mark {
      width: 20px;
      height: 20px;
      display: block;
    }
    .brand-wordmark {
      font-family: var(--ff-serif);
      font-size: 18px;
      font-weight: 500;
      letter-spacing: -0.005em;
      line-height: 1;
    }
    .head-actions {
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .close-x {
      width: 24px;
      height: 24px;
      padding: 0;
      background: transparent;
      border: none;
      color: var(--c-text-mute);
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      border-radius: var(--r-xs);
      font-family: inherit;
    }
    .close-x:hover { color: var(--c-text); background: var(--c-surface-2); }

    /* Title row — H2 on the left, summary chips pinned right. Same line
       gives a tight, scannable header instead of the prior stacked
       title/summary block. */
    .title-row {
      display: flex;
      align-items: baseline;
      justify-content: space-between;
      gap: 12px;
      flex-wrap: wrap;
    }
    .title-row h2 { margin: 0; font-size: 15px; font-weight: 600; }
    .summary {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text-mute);
      font-family: inherit;
      font-variant-numeric: tabular-nums;
      flex-wrap: wrap;
    }
    .sum-item {
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .sum-sep { color: var(--c-text-soft); }
    .sum-dot {
      width: 7px;
      height: 7px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .sum-dot[data-status="green"]  { background: var(--c-success); }
    .sum-dot[data-status="yellow"] { background: var(--c-warning); }
    .sum-dot[data-status="red"]    { background: var(--c-error); }
    .sum-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .primary {
      flex-shrink: 0;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      font-size: 12px;
      font-weight: 500;
      cursor: pointer;
      white-space: nowrap;
      font-family: inherit;
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: 1px solid var(--c-primary);
    }
    .pill {
      flex-shrink: 0;
      padding: 5px 10px;
      border-radius: var(--r-pill);
      background: var(--c-tint);
      color: var(--c-primary);
      font-size: 11px;
      font-family: inherit;
      font-weight: 500;
    }
    .pill.complete {
      background: color-mix(in oklab, var(--c-success) 14%, transparent);
      color: var(--c-success);
    }
    .banner {
      padding: 8px 12px;
      border-radius: var(--r-sm);
      background: var(--c-tint);
      color: var(--c-text);
      font-size: 12px;
      font-weight: 500;
      margin-bottom: 8px;
      font-family: inherit;
      word-break: break-all;
    }
    .rows {
      list-style: none;
      margin: 0;
      padding: 0;
      overflow-y: auto;
      max-height: 60vh;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .row {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px;
      border-radius: var(--r-sm);
      background: var(--c-surface-2);
    }
    .row[data-status="red"]    { background: color-mix(in oklab, var(--c-error) 8%, var(--c-surface-2)); }
    .row[data-status="orange"] { background: color-mix(in oklab, var(--c-warning) 7%, var(--c-surface-2)); }
    .row[data-status="pending"] { opacity: 0.85; }
    .thumb {
      position: relative;
      width: 36px; height: 36px;
      border-radius: var(--r-xs);
      border: 1px solid var(--c-border);
      background-color: var(--c-surface);
      background-size: cover;
      background-position: center;
      background-repeat: no-repeat;
      flex-shrink: 0;
    }
    .row-idx {
      position: absolute;
      top: -2px; left: -2px;
      background: var(--c-surface);
      color: var(--c-text-mute);
      font-family: var(--ff-mono);
      font-size: 9px;
      font-weight: 600;
      padding: 1px 3px;
      border-radius: 2px;
    }
    .meta { flex: 1; min-width: 0; }
    .name {
      font-size: 13px;
      font-weight: 500;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .muted { color: var(--c-text-soft); font-style: italic; }
    .status-line {
      display: flex;
      align-items: center;
      gap: 6px;
      font-size: 11px;
      color: var(--c-text-mute);
      margin-top: 2px;
    }
    .dot, .sub-dot {
      width: 8px; height: 8px;
      border-radius: 999px;
      flex-shrink: 0;
      border: 1px solid var(--c-surface);
      box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
    }
    .dot[data-status="green"],  .sub-dot[data-status="green"]  { background: var(--c-success); }
    .dot[data-status="yellow"], .sub-dot[data-status="yellow"] { background: var(--c-warning); }
    .dot[data-status="orange"], .sub-dot[data-status="orange"] {
      background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%);
    }
    .dot[data-status="red"],    .sub-dot[data-status="red"]    { background: var(--c-error); }
    .dot[data-status="pending"], .sub-dot[data-status="pending"] {
      background: transparent;
      border-color: var(--c-text-soft);
    }
    .dot[data-status="no-element"] { background: transparent; border-color: var(--c-text-soft); }
    .sub-dots { display: inline-flex; gap: 3px; margin-left: 4px; }
    .actions { display: flex; gap: 6px; flex-shrink: 0; }
    .action-btn {
      padding: 4px 10px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      font-size: 11px;
      font-weight: 500;
      font-family: inherit;
      cursor: pointer;
    }
    .action-btn:hover { border-color: var(--c-border-strong); }
    .action-btn.primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border-color: var(--c-primary);
    }
  `}const Jh=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],$t=28,kn=4,tm="http://www.w3.org/2000/svg";let V=null,ne=null,Xe=null;function em(t,e){$r(),Xe=e,V=document.createElement("div"),V.setAttribute("data-manuscript","ui"),Ct(V),V.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; "),ne=V.attachShadow({mode:"open"}),ne.innerHTML=nm(),om(),document.body.appendChild(V),Ya(t),rm(),requestAnimationFrame(()=>{V&&Ya(t)}),document.addEventListener("mousedown",bc,!0),document.addEventListener("keydown",vc,!0)}function $r(){V&&(document.removeEventListener("mousedown",bc,!0),document.removeEventListener("keydown",vc,!0),V.remove(),V=null,ne=null,Xe=null)}function nm(){return`
    <style>
      ${yt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${$t+kn*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${$t+kn*2}px;
        height: ${$t+kn*2}px;
        padding: ${kn}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function rm(){if(!ne)return;const t=ne.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of Jh){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(tm,"svg");o.setAttribute("width",String($t)),o.setAttribute("height",String($t)),o.setAttribute("viewBox",`0 0 ${$t} ${$t}`);const a=No(e,{x:3,y:3,width:$t-6,height:$t-6,fill:"transparent",stroke:"oklch(0.18 0.015 250)",strokeWidth:1.5});a&&o.appendChild(a),r.appendChild(o),t.appendChild(r)}}}function om(){ne&&ne.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(Xe==null||Xe(r),$r())})}function Ya(t){if(!V)return;const e=t.getBoundingClientRect();V.style.top="0px",V.style.left="0px";const n=V.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),V.style.top=`${Math.max(8,r)}px`,V.style.left=`${Math.max(8,o)}px`}function bc(t){if(!V)return;const e=t.target;e instanceof Node&&V.contains(e)||$r()}function vc(t){t.key==="Escape"&&(t.preventDefault(),$r())}let q=null;function am(t){if(q!==null)return;const e=t.from??3,n=t.tickMs??1e3,r=t.scheduler??sm(),o=document.createElement("div");o.setAttribute("data-manuscript","ui"),o.setAttribute("data-region","countdown"),o.style.cssText=["position: fixed","inset: 0",`z-index: ${O+10}`,"pointer-events: auto"].join("; "),Ct(o);const a=o.attachShadow({mode:"open"});a.innerHTML=cm(e),document.body.appendChild(o);const i=a.querySelector('[data-region="number"]'),s=a.querySelector('[data-action="cancel"]'),c=l=>{(l.key==="Escape"||l.key===" "||l.key==="Spacebar")&&(l.preventDefault(),Ka())};window.addEventListener("keydown",c),s==null||s.addEventListener("click",()=>Ka()),q={host:o,shadow:a,numberEl:i,scheduler:r,tickMs:n,timerId:null,remaining:e,onComplete:t.onComplete,onCancel:t.onCancel??null,keyListener:c},yc()}function Bo(){q&&(q.timerId!==null&&q.scheduler.cancel(q.timerId),window.removeEventListener("keydown",q.keyListener),q.host.remove(),q=null)}function yc(){q&&(q.timerId=q.scheduler.schedule(im,q.tickMs))}function im(){if(q){if(q.remaining-=1,q.remaining<=0){const t=q.onComplete;Bo(),t();return}q.numberEl.textContent=String(q.remaining),yc()}}function Ka(){if(!q)return;const t=q.onCancel;Bo(),t==null||t()}function sm(){return{schedule(t,e){return window.setTimeout(t,e)},cancel(t){window.clearTimeout(t)}}}function cm(t){return`
    <style>
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .ring {
        width: 220px;
        height: 220px;
        border-radius: 999px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #0a0a0a);
        box-shadow: 0 24px 60px rgb(0 0 0 / 0.35), 0 4px 12px rgb(0 0 0 / 0.20);
        display: grid;
        place-items: center;
        position: relative;
        animation: ring-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes ring-pop {
        from { transform: scale(0.85); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .number {
        font-size: 140px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        font-variant-numeric: tabular-nums;
        animation: digit-pop 200ms ease-out;
      }
      .number[data-changed] { animation: digit-pop 200ms ease-out; }
      @keyframes digit-pop {
        from { transform: scale(1.25); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .caption {
        position: absolute;
        bottom: -52px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 13px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.92);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint {
        position: absolute;
        bottom: -78px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 11px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.62);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid rgb(255 255 255 / 0.35);
        border-radius: 4px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        margin: 0 2px;
      }
      .cancel {
        appearance: none;
        background: rgb(255 255 255 / 0.10);
        color: rgb(255 255 255 / 0.92);
        border: 1px solid rgb(255 255 255 / 0.25);
        border-radius: 999px;
        padding: 6px 14px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        position: absolute;
        bottom: -120px;
        left: 50%;
        transform: translateX(-50%);
        transition: background 120ms ease, border-color 120ms ease;
      }
      .cancel:hover { background: rgb(255 255 255 / 0.20); border-color: rgb(255 255 255 / 0.45); }
    </style>
    <div class="scrim" role="dialog" aria-label="Recording starts soon">
      <div class="ring">
        <span class="number" data-region="number">${t}</span>
        <span class="caption">Recording starts in…</span>
        <span class="hint">During recording: <kbd>Space</kbd> pauses scenario · <kbd>Esc</kbd> stops &amp; saves</span>
        <button type="button" class="cancel" data-action="cancel">Cancel</button>
      </div>
    </div>
  `}let Ge=null;function lm(t){if(Ge!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-paused-pill"),e.style.cssText=["position: fixed","top: 16px","right: 16px",`z-index: ${O+11}`,"pointer-events: auto"].join("; "),Ct(e);const n=e.attachShadow({mode:"open"});n.innerHTML=dm(),document.body.appendChild(e);const r=n.querySelector('[data-action="resume"]');r==null||r.addEventListener("click",()=>{const o=t.onResume;Lr(),o()}),Ge={host:e}}function Lr(){Ge&&(Ge.host.remove(),Ge=null)}function dm(){const t=m("recording.paused-label"),e=m("recording.paused-aria");return`
    <style>
      ${yt()}
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .pill {
        appearance: none;
        font-family: inherit;
        display: inline-flex;
        align-items: center;
        gap: 8px;
        padding: 6px 12px 6px 10px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #111);
        border: 1px solid var(--c-border, #d9dee5);
        border-radius: 999px;
        box-shadow: 0 6px 18px rgb(0 0 0 / 0.18), 0 1px 4px rgb(0 0 0 / 0.10);
        font-size: 12px;
        font-weight: 500;
        letter-spacing: 0.02em;
        opacity: 0.7;
        cursor: pointer;
        transition: opacity 120ms ease, filter 120ms ease;
      }
      .pill:hover {
        opacity: 1;
        filter: brightness(0.98);
      }
      .dot {
        width: 9px;
        height: 9px;
        border-radius: 999px;
        background: var(--c-error, #c52a2a);
        flex-shrink: 0;
        animation: rec-blink 1s ease-in-out infinite;
      }
      @keyframes rec-blink {
        0%, 100% { opacity: 1; }
        50%      { opacity: 0.2; }
      }
      .label { line-height: 1.2; white-space: nowrap; }
    </style>
    <button type="button" class="pill" data-action="resume" aria-label="${e}" title="${e}">
      <span class="dot" aria-hidden="true"></span>
      <span class="label">${t}</span>
    </button>
  `}function um(t,e=n=>MediaRecorder.isTypeSupported(n)){for(const n of t)if(e(n))return n;throw new Error(`No supported MIME type for screen recording (tried: ${t.join(", ")})`)}function pm(t,e){const{factory:n,mimeType:r,timesliceMs:o}=e,a=n.create(t,{mimeType:r}),i=[];let s=!1,c=null;a.ondataavailable=p=>{p.data&&p.data.size>0&&i.push(p.data)};function l(){if(s)throw new Error("Recorder handle is single-use; create a new one.");s=!0,o!==void 0?a.start(o):a.start()}function d(){return c?Promise.reject(new Error("stop() already called")):(c=new Promise((p,u)=>{a.onstop=()=>{const f=new Blob(i,{type:r});p({blob:f,size:f.size,mimeType:r})},a.onerror=f=>{const h=f.error;u(new Error((h==null?void 0:h.message)??"MediaRecorder error"))},a.stop()}),c)}return{start:l,stop:d}}function fm(t){let e="idle";function n(){var o;e==="idle"&&(t.isStandalonePlayback()||(e="counting-down",(o=t.onRecordingStarting)==null||o.call(t),t.mountCountdown({onComplete:()=>{var a;e="recording",(a=t.onRecordingStarted)==null||a.call(t),t.sendMessage({type:"recording.fire"}).catch(()=>{var i;e="idle",(i=t.onRecordingStopped)==null||i.call(t)})},onCancel:()=>{var a;e="idle",(a=t.onRecordingStopped)==null||a.call(t),t.sendMessage({type:"recording.stop"}).catch(()=>{})}})))}async function r(){var o,a;if(e!=="idle"){if(e==="counting-down"){t.unmountCountdown(),e="idle",(o=t.onRecordingStopped)==null||o.call(t);return}try{await t.sendMessage({type:"recording.stop"})}finally{e="idle",(a=t.onRecordingStopped)==null||a.call(t)}}}return{startRecording:n,stopRecording:r,isRecording:()=>e==="recording",getPhase:()=>e}}const Za="Created with Manuscript",hm=12,mm=500,fo=14,Qa=10,gm=6,Ja=24,bm=.7;function vm(t,e,n,r){t.save(),t.globalAlpha=bm,t.fillStyle="#fff",t.font=`${mm} ${hm}px "Pretendard Variable", Pretendard, system-ui, sans-serif`,t.textAlign="right",t.textBaseline="bottom",t.shadowColor="rgba(0, 0, 0, 0.85)",t.shadowBlur=3,t.shadowOffsetX=0,t.shadowOffsetY=1;const o=n-Ja,a=r-Ja;t.fillText(Za,o,a);const i=t.measureText(Za).width,s=o-i-gm-Qa,c=a-fo;t.drawImage(e,s,c,Qa,fo),t.restore()}async function ym(){const t=mi({height:fo,color:"#ffffff"}),e=`data:image/svg+xml;utf8,${encodeURIComponent(t)}`,n=new Image;return n.src=e,await n.decode(),n}const xm=["video/webm;codecs=vp9,opus","video/webm;codecs=vp9","video/webm;codecs=vp8,opus","video/webm;codecs=vp8","video/webm"];let Cn=null,Ye=!1,Gt=null,He=null,ze=null,Fe=null,qe=null,le=null,_e=null,ho=!1,rr=null,Uo=null,jo=null,we=null;async function wm(t={}){if(an()||Gt)return!1;Ye=t.keepUiVisible===!0;let e;try{e=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,preferCurrentTab:!0,selfBrowserSurface:"include"})}catch(v){return console.warn("[manuscript/recording] tab share failed:",v),!1}let n=null;try{n=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,systemAudio:"include"}),n.getVideoTracks().forEach(v=>v.stop()),console.info("[manuscript/recording] step 2 OK — system audio acquired, video track dropped",{audioTracks:n.getAudioTracks().length})}catch(v){console.warn("[manuscript/recording] step 2 rejected:",v instanceof Error?`${v.name}: ${v.message}`:v),It("System audio not shared — TTS narration will be silent in the video.")}let r=null;if(t.withMicrophone)try{r=await navigator.mediaDevices.getUserMedia({audio:!0}),console.info("[manuscript/recording] microphone acquired",{audioTracks:r.getAudioTracks().length})}catch(v){console.warn("[manuscript/recording] microphone acquisition failed:",v instanceof Error?`${v.name}: ${v.message}`:v),It(m("recording.mic-failed"))}let o=null,a=null;const i=e.getAudioTracks().length>0,s=((n==null?void 0:n.getAudioTracks().length)??0)>0,c=((r==null?void 0:r.getAudioTracks().length)??0)>0;if(i||s||c){a=new AudioContext;const v=a.createMediaStreamDestination();i&&a.createMediaStreamSource(new MediaStream(e.getAudioTracks())).connect(v),s&&n&&a.createMediaStreamSource(new MediaStream(n.getAudioTracks())).connect(v),c&&r&&a.createMediaStreamSource(new MediaStream(r.getAudioTracks())).connect(v),o=v.stream.getAudioTracks()[0]??null}let l=null;try{const v=await km(e);le=v.videoEl,_e=v.canvasStream,l=v.videoTrack}catch(v){console.warn("[manuscript/recording] watermark compositor failed; falling back to raw tab video:",v)}const d=l?[l]:[...e.getVideoTracks()];o&&d.push(o);const p=new MediaStream(d);He=e,ze=n,Fe=r,qe=a,Gt=p;const u=e.getVideoTracks()[0],f=u&&typeof u.getSettings=="function"?u.getSettings():null,h=(f==null?void 0:f.displaySurface)??"(unknown)";console.info("[manuscript/recording] capture stream info",{displaySurface:h,tabAudioTracks:e.getAudioTracks().length,systemAudioTracks:(n==null?void 0:n.getAudioTracks().length)??0,microphoneTracks:(r==null?void 0:r.getAudioTracks().length)??0,mergedAudioTrack:!!o});const b=()=>{const v=Cn;v&&v.getPhase()!=="idle"&&v.stopRecording()};return u&&u.addEventListener("ended",b),n==null||n.getAudioTracks().forEach(v=>v.addEventListener("ended",b)),r==null||r.getAudioTracks().forEach(v=>v.addEventListener("ended",b)),Lm().startRecording(),!0}async function km(t){const e=document.createElement("video");e.muted=!0,e.playsInline=!0,e.setAttribute("data-manuscript","ui"),e.style.cssText="position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;",document.body.appendChild(e),e.srcObject=new MediaStream(t.getVideoTracks()),await e.play();const n=t.getVideoTracks()[0],r=(n==null?void 0:n.getSettings())??{},o=(typeof r.width=="number"?r.width:void 0)??e.videoWidth??1280,a=(typeof r.height=="number"?r.height:void 0)??e.videoHeight??720,i=document.createElement("canvas");i.width=o,i.height=a;const s=i.getContext("2d");if(!s)throw new Error("2D canvas context unavailable");const c=await ym();ho=!0;const l=()=>{if(!ho)return;s.drawImage(e,0,0,i.width,i.height),vm(s,c,i.width,i.height);const u=e.requestVideoFrameCallback;typeof u=="function"?u.call(e,l):requestAnimationFrame(l)};l();const d=i.captureStream(),p=d.getVideoTracks()[0];if(!p)throw new Error("canvas.captureStream produced no video track");return{videoEl:e,canvasStream:d,videoTrack:p}}function Sm(t){we||(we=e=>{const n=e.target;if(!(n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement||n instanceof HTMLElement&&n.isContentEditable)){if(e.key===" "||e.key==="Spacebar"){e.preventDefault(),e.stopPropagation(),xc();return}if(e.key==="Escape"){e.preventDefault(),e.stopPropagation(),Lr(),t.stop();return}}},window.addEventListener("keydown",we,!0))}function Em(){we&&(window.removeEventListener("keydown",we,!0),we=null)}function xc(){var e;if(!ft())return;Je(),((e=k.state)==null?void 0:e.paused)===!0?lm({onResume:xc}):Lr()}function Am(t){let e;try{e=um(xm)}catch(n){return console.warn("[manuscript/recording] no supported mime:",n),null}return Uo=e,console.info("[manuscript/recording] using mimeType",e,{streamAudioTracks:t.getAudioTracks().length,streamVideoTracks:t.getVideoTracks().length}),pm(t,{factory:{create:(n,r)=>new MediaRecorder(n,r)},mimeType:e,timesliceMs:1e3})}function Mm(t,e){const n=new Date(t),r=i=>String(i).padStart(2,"0"),o=`${n.getFullYear()}${r(n.getMonth()+1)}${r(n.getDate())}-${r(n.getHours())}${r(n.getMinutes())}`,a=e.includes("webm")?"webm":"video";return`manuscript-recording-${o}.${a}`}function or(){ho=!1,Gt==null||Gt.getTracks().forEach(t=>t.stop()),_e==null||_e.getTracks().forEach(t=>t.stop()),He==null||He.getTracks().forEach(t=>t.stop()),ze==null||ze.getTracks().forEach(t=>t.stop()),Fe==null||Fe.getTracks().forEach(t=>t.stop()),qe==null||qe.close().catch(()=>{}),le&&(le.pause(),le.srcObject=null,le.remove()),Gt=null,He=null,ze=null,Fe=null,qe=null,le=null,_e=null,rr=null,Uo=null,jo=null,Ye=!1}async function $m(){const t=rr;if(!t){or();return}try{const e=await t.stop(),n=URL.createObjectURL(e.blob),r=Mm(jo??Date.now(),Uo??"video/webm");try{await chrome.runtime.sendMessage({type:"recording.download",url:n,filename:r})}catch(o){console.warn("[manuscript/recording] download forward failed:",o)}}catch(e){console.warn("[manuscript/recording] recorder.stop failed:",e)}finally{or()}}function Lm(){if(!Cn){const t=fm({mountCountdown:am,unmountCountdown:Bo,sendMessage:async()=>{},isStandalonePlayback:an,onRecordingStarting:()=>{if(Ye){En()&&ci(!0);return}En()&&si(!0),jr(!0)},onRecordingStarted:()=>{Sm({stop:()=>void t.stopRecording()}),Ye||jr(!0);const e=Gt;if(e){const n=Am(e);if(n){rr=n,jo=Date.now();try{n.start()}catch(r){console.warn("[manuscript/recording] recorder start failed:",r),or();return}}}!ft()&&L()&&Pe(0)},onRecordingStopped:()=>{Em(),Lr(),Ye?En()&&ci(!1):(jr(!1),En()&&si(!1)),ft()&&Te(),rr?$m():or()}});Cn=t,document.addEventListener("manuscript:replay-end",()=>{t.getPhase()==="recording"&&t.stopRecording()}),mt(e=>{e.prev==="replay"&&e.next!=="replay"&&t.getPhase()==="recording"&&t.stopRecording()})}return Cn}const Tm="/assets/share-step-1-B4IYEXR4.png",Im="/assets/share-step-2-B99Thpfo.png",Cm=chrome.runtime.getURL(Tm.replace(/^\/+/,"")),Dm=chrome.runtime.getURL(Im.replace(/^\/+/,""));let fe=null;function Pm(t){var i,s,c;if(fe!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-guide"),e.style.cssText=["position: fixed","inset: 0",`z-index: ${O+12}`,"pointer-events: auto"].join("; "),Ct(e);const n=e.attachShadow({mode:"open"});n.innerHTML=Rm(),document.body.appendChild(e);function r(l){var d;ti(),(d=t.onCancel)==null||d.call(t)}function o(){var p,u;const l=((p=n.querySelector('[data-action="keep-ui"]'))==null?void 0:p.checked)===!0,d=((u=n.querySelector('[data-action="with-mic"]'))==null?void 0:u.checked)===!0;ti(),t.onStart({keepUiVisible:l,withMicrophone:d})}(i=n.querySelector('[data-action="start"]'))==null||i.addEventListener("click",o),(s=n.querySelector('[data-action="cancel"]'))==null||s.addEventListener("click",()=>r()),(c=n.querySelector('[data-action="scrim-close"]'))==null||c.addEventListener("click",l=>{l.target===l.currentTarget&&r()});const a=l=>{l.key==="Escape"&&(l.preventDefault(),r())};window.addEventListener("keydown",a),fe={host:e,keyListener:a}}function ti(){fe&&(window.removeEventListener("keydown",fe.keyListener),fe.host.remove(),fe=null)}function Rm(){return`
    <style>
      ${yt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .card {
        width: min(700px, calc(100vw - 48px));
        max-height: calc(100vh - 48px);
        overflow: auto;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        animation: card-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes card-pop {
        from { transform: scale(0.96); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .head {
        padding: 22px 28px 8px;
      }
      .title {
        font-size: 19px;
        font-weight: 600;
        margin: 0 0 8px;
      }
      .subtitle {
        font-size: 13px;
        color: var(--c-text-mute, #555);
        margin: 0;
        line-height: 1.5;
      }
      .steps {
        padding: 12px 28px 8px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      .step {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .step-head {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .step-badge {
        width: 26px;
        height: 26px;
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
        display: grid;
        place-items: center;
        flex-shrink: 0;
      }
      .step-title {
        font-size: 14px;
        font-weight: 600;
      }
      .step-img {
        width: 100%;
        height: auto;
        border: 1px solid var(--c-border, #ddd);
        border-radius: 8px;
        background: var(--c-surface-2, #f6f7f8);
        display: block;
      }
      .step-desc {
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
        margin: 0;
      }
      .step-desc ol {
        margin: 0 0 8px;
        padding-left: 18px;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .step-desc ol li {
        padding-left: 2px;
      }
      .step-desc p {
        margin: 6px 0 0;
      }
      .step-desc kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .options {
        padding: 4px 28px 0;
      }
      .opt-row {
        display: flex;
        align-items: flex-start;
        gap: 8px;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.45;
        cursor: pointer;
        user-select: none;
        padding: 6px 8px;
        border-radius: 6px;
        transition: background 0.12s ease;
      }
      .opt-row + .opt-row { margin-top: 2px; }
      .opt-row:hover { background: var(--c-surface-2, #f6f7f8); }
      .opt-row input {
        margin: 2px 0 0;
        accent-color: var(--c-primary, #1a73e8);
      }
      .opt-row .opt-label { font-weight: 500; color: var(--c-text); }
      .opt-row .opt-hint { display: block; margin-top: 1px; }
      .keys-info {
        padding: 10px 28px 0;
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
      }
      .keys-info kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .actions {
        padding: 12px 28px 22px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .btn {
        appearance: none;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 18px;
        border-radius: 999px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: filter 0.12s ease, background 0.12s ease;
      }
      .btn-ghost {
        background: transparent;
        color: var(--c-text-mute, #555);
        border-color: var(--c-border-strong, #d2d6dc);
      }
      .btn-ghost:hover { color: var(--c-text, #111); }
      .btn-primary {
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
      }
      .btn-primary:hover { filter: brightness(1.06); }
    </style>
    <div class="scrim" data-action="scrim-close" role="dialog" aria-modal="true" aria-labelledby="rec-guide-title">
      <div class="card">
        <div class="head">
          <h2 id="rec-guide-title" class="title">${m("recording.guide.title")}</h2>
          <p class="subtitle">${m("recording.guide.subtitle")}</p>
        </div>
        <div class="steps">
          <div class="step">
            <div class="step-head">
              <div class="step-badge">1</div>
              <div class="step-title">${m("recording.guide.step1-title")}</div>
            </div>
            <img src="${Cm}" alt="${m("recording.guide.step1-alt")}" class="step-img" />
            <div class="step-desc">${m("recording.guide.step1-desc-html")}</div>
          </div>
          <div class="step">
            <div class="step-head">
              <div class="step-badge">2</div>
              <div class="step-title">${m("recording.guide.step2-title")}</div>
            </div>
            <img src="${Dm}" alt="${m("recording.guide.step2-alt")}" class="step-img" />
            <div class="step-desc">${m("recording.guide.step2-desc-html")}</div>
          </div>
        </div>
        <div class="options">
          <label class="opt-row">
            <input type="checkbox" data-action="keep-ui" />
            <span>
              <span class="opt-label">${m("recording.guide.keep-ui-label")}</span>
              <span class="opt-hint">${m("recording.guide.keep-ui-hint")}</span>
            </span>
          </label>
          <label class="opt-row">
            <input type="checkbox" data-action="with-mic" />
            <span>
              <span class="opt-label">${m("recording.guide.mic-label")}</span>
              <span class="opt-hint">${m("recording.guide.mic-hint")}</span>
            </span>
          </label>
        </div>
        <div class="keys-info" data-region="keys-info">
          ${m("recording.guide.keys-info-html")}
        </div>
        <div class="actions">
          <button type="button" class="btn btn-ghost" data-action="cancel">
            ${m("recording.guide.cancel")} <kbd>Esc</kbd>
          </button>
          <button type="button" class="btn btn-primary" data-action="start">
            ${m("recording.guide.start")}
          </button>
        </div>
      </div>
    </div>
  `}function Nm(){const t=L();if(t)try{const e=Jc(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${zm(t.name)}-${Fm(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),It(m("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),It(m("toast.export-failed"),!0)}}async function Om(){const t=L();if(t){if(t.steps.length===0){It(m("toast.no-steps"),!0);return}ns(),await Pe(0,{paused:!0})}}function Hm(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=tl(r);Ti(o),It(m("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),It(m("toast.import-failed"),!0)}}),t.click()}function zm(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Fm(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function Tr(t){const e=L(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!Ir(n.pickedAtUrl,location.href)?(Wo(n.pickedAtUrl,t),!0):!1}function Ke(){const t=L();if(!t)return;const e=B(),n=t.steps[e],r=t.steps[e+1];Us({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function Ir(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function Wo(t,e){const n=L();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let ar=!1,wc=0,kc=0,mo=0,go=0;function qm(){const{shadow:t}=g;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=g;if(!o)return;ar=!0,wc=n.clientX,kc=n.clientY;const a=o.getBoundingClientRect();mo=a.left,go=a.top,o.style.left=`${mo}px`,o.style.top=`${go}px`,o.style.right="auto",document.addEventListener("mousemove",Sc,!0),document.addEventListener("mouseup",Ec,!0),n.preventDefault()})}function Sc(t){const{host:e}=g;if(!ar||!e)return;const n=t.clientX-wc,r=t.clientY-kc,o=e.offsetWidth,a=e.offsetHeight,i=er(mo+n,0,window.innerWidth-o),s=er(go+r,0,window.innerHeight-a);e.style.left=`${i}px`,e.style.top=`${s}px`}function Ec(){ar&&(ar=!1,document.removeEventListener("mousemove",Sc,!0),document.removeEventListener("mouseup",Ec,!0))}let ir=!1,Ac=0,Mc=0;function _m(){const{shadow:t}=g;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=g;r&&(ir=!0,Ac=n.clientY,Mc=r.getBoundingClientRect().height,document.addEventListener("mousemove",$c,!0),document.addEventListener("mouseup",Lc,!0),n.preventDefault(),n.stopPropagation())})}function $c(t){const{host:e}=g;if(!ir||!e)return;const n=t.clientY-Ac,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-ye,a=er(Mc+n,tr,o);e.style.height=`${a}px`,e.style.maxHeight=`${a}px`}function Lc(){ir&&(ir=!1,document.removeEventListener("mousemove",$c,!0),document.removeEventListener("mouseup",Lc,!0))}function Bm(t){const e=window.innerHeight-ye*2;return er(t,tr,Math.max(tr,e))}function Tc(){const{host:t}=g;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-ye;if(e.bottom>n){const o=Math.max(tr,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),a=window.innerWidth-r.width;o>a&&(t.style.left=`${Math.max(0,a)}px`)}if(t.style.top){const o=parseFloat(t.style.top),a=window.innerHeight-r.height;o>a&&(t.style.top=`${Math.max(0,a)}px`)}}function Vo(){var t;return((t=g.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function Ic(){var t;return((t=g.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function Um(){const t=Vo();t&&(t.hidden?(jm(),t.hidden=!1):t.hidden=!0)}function Cc(){const t=Vo();t&&(t.hidden=!0)}async function jm(){const t=Ic();if(!t)return;await sl();const e=cl(),n=await ll(),r=a=>a.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const a of e){const i=a.name===n?" selected":"";o.push(`<option value="${r(a.name)}"${i}>${r(a.name)} (${r(a.lang)})</option>`)}t.innerHTML=o.join("")}function Wm(){var n;const t=Ic();t&&t.addEventListener("change",()=>{const r=t.value;il(r.length>0?r:null)});const e=(n=g.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>Cc())}function Dc(t){var o;const e=Vo();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=g.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Cc()}let Be=null;function Pc(t){Be=t}function ht(t){const e=t===B();Dt(t),e&&Xo()}function Xo(){var r;const t=dt();if(!(t!=null&&t.selectors)){Be=null,$e();return}let e=null;const n=g.subSelection;if(n.stepId===t.id&&n.anchorId){const o=(r=t.subElements)==null?void 0:r.find(a=>a.id===n.anchorId);o&&(e=Se(o.selectors))}if(e||(e=Se(t.selectors)),!e){Be=null,$e();return}e!==Be&&dn(e,{behavior:"smooth"}),Be=e,Ho(e)}function ei(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function Go(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function Vm(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function Xm(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function Gm(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function Ym(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function Km(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function Zm(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=L(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));ht(l)}const a=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${a}" aria-label="Auto-advance seconds" />
    ${Go(10)}
  `;const i=t.querySelector("input");if(!i)return;i.focus(),i.select();const s=l=>{if(t.classList.remove("editing"),l){ni(t,a);return}const d=i.value.trim();let p=5;if(d===""||d==="0")me(r.id,{autoAdvanceMs:null});else{const u=Number(d);Number.isFinite(u)&&u>0?(me(r.id,{autoAdvanceMs:Math.round(u*1e3)}),p=u):me(r.id,{autoAdvanceMs:null})}ni(t,p)};i.addEventListener("blur",()=>s(!1)),i.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),i.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),i.addEventListener("mousedown",l=>l.stopPropagation())}function ni(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${Go(10)}
  `}function Qm(t,e){const{shadow:n,host:r}=g;if(!n||!r)return;qm(),_m(),ug(),Wm(),document.addEventListener("mousedown",Dc,!0);const o=a=>a.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",a=>tg(a,t,e)),document.addEventListener("keydown",Rc,!0),document.addEventListener("mousedown",Nc,!0)}function Jm(){document.removeEventListener("mousedown",Dc,!0),document.removeEventListener("keydown",Rc,!0),document.removeEventListener("mousedown",Nc,!0)}function Rc(t){if(t.key==="Escape"){const r=g.subSelection;if(r.selectedIds.length===0&&!r.primarySelected)return;const o=Wr();if(o&&Vr(o)||st()==="picker")return;const a=r.stepId;g.subSelection=Ie,a&&ke(a);return}if(t.key==="ArrowLeft"||t.key==="ArrowRight"){const r=g.subSelection;if(!r.stepId||!r.anchorId)return;const o=Wr();if(o&&Vr(o))return;t.preventDefault(),Ri(r.stepId,r.anchorId,r.selectedIds,t.key==="ArrowLeft"?-1:1);return}if(t.key!=="Delete"&&t.key!=="Backspace")return;const e=g.subSelection;if(!e.stepId||e.selectedIds.length===0)return;const n=Wr();n&&Vr(n)||(t.preventDefault(),Kl(e.stepId,e.selectedIds),g.subSelection=Ie)}function Nc(t){const e=g.subSelection;if(e.selectedIds.length===0&&!e.primarySelected||st()==="picker")return;const n=t.composedPath();for(const o of n)if(o instanceof Element&&o.matches('.sub-node, .sub-add, .sub-gap, [data-action="step-wand"]'))return;const r=e.stepId;g.subSelection=Ie,r&&ke(r)}function Wr(){var e;let t=document.activeElement;for(;t&&((e=t.shadowRoot)!=null&&e.activeElement);)t=t.shadowRoot.activeElement;return t}function Vr(t){return!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLElement&&t.isContentEditable)}function tg(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="palette-toggle"]')){t.stopPropagation(),gl();return}if(o.closest('[data-action="recording-toggle"]')){t.stopPropagation(),eg();return}if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void Om();if(o.closest('[data-action="prompter"]')){n(!0),_s().then(()=>{Ke()});return}if(o.closest('[data-action="export"]'))return Nm();if(o.closest('[data-action="import"]'))return Hm();if(o.closest('[data-action="validate"]'))return ag();if(o.closest('[data-action="settings-toggle"]'))return Um();const a=o.closest('[data-action="tool-set"]');if(a instanceof HTMLElement){t.stopPropagation();const s=a.getAttribute("data-tool");if(s==="shape"){em(a,c=>{Xp(c),I("shape")});return}I(st()===s?"idle":s);return}if(ng(t,o))return;const i=o.closest("[data-step-card]");if(i&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(i.getAttribute("data-step-card"));if(Tr(s))return;ht(s)}}async function eg(){const t=L(),e=t?ac(t):"";if(e&&!yr(e,location.href)){const n=await ic(e);if(n==="cancel")return;if(n==="navigate"){location.href=e;return}}Pm({onStart:({keepUiVisible:n,withMicrophone:r})=>{wm({keepUiVisible:n,withMicrophone:r}).then(o=>{o||It("Recording cancelled or unsupported.")})}})}function ng(t,e){var u;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const f=Number(n.getAttribute("data-insert-index"));return oa({insertIndex:f}),!0}if(e.closest('[data-action="step-add"]'))return oa(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const f=Number(r.getAttribute("data-step-index"));return Tr(f)||og(f),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),Ul(Number(o.getAttribute("data-step-index"))),!0;const a=e.closest('[data-action="step-link"]');if(a){t.stopPropagation();const f=a.getAttribute("data-url")??"",h=a.closest("[data-step-card]"),b=h?Number(h.getAttribute("data-step-card")):0;return f?Ir(f,location.href)?(Number.isFinite(b)&&ht(b),!0):(Wo(f,Number.isFinite(b)?b:0),!0):!0}const i=e.closest('[data-action="step-action-toggle"]');if(i instanceof HTMLElement){t.stopPropagation();const f=Number(i.getAttribute("data-step-index")),h=(u=L())==null?void 0:u.steps[f];return h&&(ht(f),me(h.id,{waitForNavigation:!h.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');if(s instanceof HTMLElement)return t.stopPropagation(),s.classList.contains("disabled")||Zm(s),!0;const c=e.closest('[data-action="sub-add"]');if(c instanceof HTMLElement)return t.stopPropagation(),sg(c),!0;const l=e.closest('[data-action="sub-shift"]');if(l instanceof HTMLElement)return t.stopPropagation(),t.preventDefault(),rg(l),!0;const d=e.closest(".sub-node[data-sub-id]");if(d instanceof HTMLElement)return t.stopPropagation(),cg(d,t),!0;const p=e.closest(".sub-node.primary[data-primary]");return p instanceof HTMLElement?(t.stopPropagation(),lg(p),!0):!1}function rg(t){const e=t.dataset.subId??"",n=Number(t.dataset.direction??"0");if(!e||n!==-1&&n!==1)return;const r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!o)return;const a=Mr(g.subSelection,o);Ri(o,e,a,n)}function og(t){if(ht(t),st()==="picker"&&g.pickerTarget.type==="primary"){I("idle");return}g.subSelection=Ie,g.pickerTarget={type:"primary"},I("picker")}let Et=null;function sr(t){const{shadow:e}=g;e&&requestAnimationFrame(()=>{const n=e.querySelector(`[data-step-card="${t}"]`);n==null||n.scrollIntoView({behavior:"smooth",block:"center"})})}function ag(){const t=L();if(!t)return;const e=typeof location<"u"?location.href:"";Et=Nh(t,e),po({scenario:t,session:Et,phase:"initial",onStart:()=>{Oc(t)},onGoToStep:n=>{xe(),Et=null,Tt();const r=t.steps.findIndex(o=>o.id===n);r>=0&&(ht(r),sr(r))},onRepick:n=>{xe(),Et=null,Tt();const r=t.steps.findIndex(o=>o.id===n);r<0||(ht(r),sr(r),g.pickerTarget={type:"primary"},I("picker"))},onClose:()=>{xe(),Et=null,Tt()}})}async function ig(){const t=await el();if(!t)return;const e=L();if(!e||e.id!==t.scenarioId){await Tt();return}Et=t,fc(t);const n={onStart:()=>{},onGoToStep:r=>{xe(),Et=null,Tt();const o=e.steps.findIndex(a=>a.id===r);o>=0&&(ht(o),sr(o))},onRepick:r=>{xe(),Et=null,Tt();const o=e.steps.findIndex(a=>a.id===r);o<0||(ht(o),sr(o),g.pickerTarget={type:"primary"},I("picker"))},onClose:()=>{xe(),Et=null,Tt()}};if(pc(t)){po({scenario:e,session:t,phase:"complete",...n});return}po({scenario:e,session:t,phase:"validating",...n}),await Oc(e)}async function Oc(t){var r;if(!t)return;const e=Et;if(!e)return;if(Ut({phase:"validating"}),await new Promise(o=>setTimeout(o,30)),await Oh(t,e,()=>{Ut({session:e})}),await zh(e),Ut({session:e}),pc(e)){fc(e),Ut({phase:"complete"});const o=((r=t.steps[0])==null?void 0:r.pickedAtUrl)||t.url||"";if(o&&!Ir(o,location.href)){await new Promise(a=>setTimeout(a,700)),Ut({phase:"navigating",navigatingTo:o}),await new Promise(a=>setTimeout(a,600)),location.href=o;return}await Tt();return}const n=Hh(e);if(!n){Ut({phase:"complete"}),await Tt();return}Ut({phase:"navigating",navigatingTo:n}),await new Promise(o=>setTimeout(o,600)),location.href=n}function sg(t){const e=t.dataset.stepId??"";if(!e)return;const n=L(),r=n==null?void 0:n.steps.find(a=>a.id===e);if(!r||!r.selectors)return;const o=r.pickedAtUrl;if(o&&!yr(o,location.href)){It(m("sub.same-url-required"),!0);return}g.pickerTarget={type:"sub-add",stepId:e},I("picker")}function cg(t,e){var h;const n=t.dataset.subId??"",r=t.closest('[data-region="sub-track"]'),o=(r==null?void 0:r.dataset.stepId)??"";if(!n||!o)return;const a=L(),i=(a==null?void 0:a.steps.findIndex(b=>b.id===o))??-1;if(!a||i<0)return;const s=a.steps[i],c=(h=s==null?void 0:s.subElements)==null?void 0:h.find(b=>b.id===n);if(!s||!c)return;const l=e;if(l.shiftKey){const b=(s.subElements??[]).map(v=>v.id);g.subSelection=qh(g.subSelection,o,n,b),ke(o);return}if(l.ctrlKey||l.metaKey){g.subSelection=Fh(g.subSelection,o,n),ke(o);return}const d=g.subSelection,p=d.stepId===o&&d.anchorId===n,u=st()==="picker"&&g.pickerTarget.type==="sub-repick"&&g.pickerTarget.subId===n;if(p&&u){I("idle");return}if(p){g.pickerTarget={type:"sub-repick",stepId:o,subId:n},I("picker");return}g.subSelection=hc(g.subSelection,o,n),i!==B()&&Dt(i);const f=Se(c.selectors);f&&(dn(f,{behavior:"smooth"}),zo(f,{durationMs:350}),Pc(f)),st()==="picker"?I("idle"):ke(o)}function lg(t){const e=t.closest('[data-region="sub-track"]'),n=(e==null?void 0:e.dataset.stepId)??"";if(!n)return;const r=L(),o=(r==null?void 0:r.steps.findIndex(s=>s.id===n))??-1;if(o<0)return;const a=r==null?void 0:r.steps[o],i=(a==null?void 0:a.pickedAtUrl)||(r==null?void 0:r.url)||"";if(i&&!Ir(i,location.href)){Wo(i,o);return}if(g.subSelection=_h(g.subSelection,n),o!==B()&&Dt(o),ke(n),a!=null&&a.selectors){const s=Se(a.selectors);s&&(dn(s,{behavior:"smooth"}),zo(s,{durationMs:350}),Pc(s))}}function ke(t){const{shadow:e}=g;if(!e)return;const n=e.querySelector(`[data-region="sub-track"][data-step-id="${dg(t)}"]`);if(!n)return;const r=new Set(Mr(g.subSelection,t));n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{const i=a.dataset.subId;i&&a.classList.toggle("selected",r.has(i))});const o=n.querySelector(".sub-node.primary");o&&o.classList.toggle("selected",mc(g.subSelection,t))}function dg(t){return t.replace(/[^a-zA-Z0-9_-]/g,"\\$&")}function ug(){const{shadow:t}=g;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>bo(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=L();r&&(e.textContent=r.name),bo(e),e.blur()}}),e.addEventListener("blur",()=>{_l(e.textContent??"")}))}function bo(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const pg='[data-manuscript="ui"][data-region="permission-banner"]';function Hc(){return document.querySelector(pg)}function fg(t){const e=Hc();if(e){Fc(e,t);return}hg(t)}function zc(){const t=Hc();t&&t.remove()}function Fc(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function hg(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),Ct(e),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${O+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=mg(),Fc(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>zc()),document.body.appendChild(e)}function mg(){return`
    <style>
      ${yt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const Sn=16,gg=240,bg=/permission|<all_urls>|activeTab/i;async function qc(t){const e=vg({x:t.x-Sn,y:t.y-Sn,width:t.width+Sn*2,height:t.height+Sn*2});if(e.width<=0||e.height<=0)return null;const n=await yg();if(!n.ok)return bg.test(n.error)?fg(m("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await kg(n.dataUrl,e,gg)}catch(r){return console.error("[manuscript] crop failed",r),null}}function vg(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function yg(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await wg();try{return{ok:!0,dataUrl:await xg()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function xg(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function wg(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function kg(t,e,n){const r=await Sg(t),o=r.naturalWidth/window.innerWidth||1,a=e.x*o,i=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),d=Math.max(1,Math.round(e.width*l)),p=Math.max(1,Math.round(e.height*l)),u=document.createElement("canvas");u.width=d,u.height=p;const f=u.getContext("2d");if(!f)throw new Error("No 2d context");return f.drawImage(r,a,i,s,c,0,0,d,p),u.toDataURL("image/png")}function Sg(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function _c(t){const e=t.detail,n=g.pickerTarget;g.pickerTarget={type:"primary"};const r=Eg(e.rect,e.chain.framePath);if(n.type==="sub-add"){const o=Yl({selectors:e.chain,thumbnailDataUrl:null,pickedAtUrl:location.href});o&&(g.subSelection=hc(g.subSelection,n.stepId,o.id),Xo(),ri(n.stepId,o.id,r));return}if(n.type==="sub-repick"){Ql(n.stepId,n.subId,e.chain,location.href),ri(n.stepId,n.subId,r);return}Wl(e.chain),Ag(r)}function Eg(t,e){if(!e||e.length===0)return t;const n=kd(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function Ag(t){try{const e=await qc(t);Bl(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}async function ri(t,e,n){try{const r=await qc(n);Zl(t,e,{thumbnailDataUrl:r})}catch(r){console.warn("[manuscript] sub thumbnail capture skipped",r)}}function Mg(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Record button — same primary fill as play / prompter so the
         footer trio reads as one cluster (the design-system way of
         saying "these are the three CTAs"). The red dot icon is the
         only theme-independent piece — it carries the "record"
         affordance without making the whole button red at rest.
         Pressed flips to var(--c-error) + stop square + pulse halo so
         the recording state is unmistakable. Hidden during bridge
         standalone sessions; that branch is enforced at the controller
         layer. */
      .record-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        /* Record dot reads as an activity indicator, not an error
           state, so brighten --c-error locally with a 22% white mix.
           Stays palette-aware (light/dark both shift together) without
           touching the global error token or its other consumers. */
        color: color-mix(in oklch, var(--c-error), white 22%);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease, color 160ms ease;
      }
      .record-btn:hover { background: var(--c-primary-h); }
      .record-btn .record-stop { display: none; }
      .record-btn[aria-pressed="true"] {
        background: var(--c-error);
        color: var(--c-primary-fg);
        animation: record-pulse 1.6s ease-in-out infinite;
      }
      .record-btn[aria-pressed="true"] .record-dot { display: none; }
      .record-btn[aria-pressed="true"] .record-stop { display: inline-block; }
      @keyframes record-pulse {
        0%, 100% { box-shadow: 0 0 0 0 color-mix(in oklch, var(--c-error), transparent 60%); }
        50%      { box-shadow: 0 0 0 6px color-mix(in oklch, var(--c-error), transparent 100%); }
      }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
        /* Sit above the footer chrome (play-btn / record-btn / icon-btn
           / settings-popup at z-index 4) so the toast isn't clipped by
           those siblings. */
        z-index: 10;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function $g(){return`
      ${yt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .palette-toggle {
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        color: var(--c-text-mute);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: border-color 160ms ease, color 160ms ease;
      }
      .palette-toggle:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .palette-toggle:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
      }
      .palette-toggle .palette-sun { display: none; }
      .palette-toggle .palette-moon { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-sun { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-moon { display: none; }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Lg(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        flex-wrap: wrap;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -3px;
        left: 2px;
        font-family: var(--ff-mono);
        font-size: 13px;
        font-weight: 700;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 2px 5px;
        border-radius: 3px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* Selector health dot — Phase A telemetry. Hover shows which layer
         resolved the element on the last replay / sync; red = miss. */
      .health-dot {
        position: absolute;
        top: -3px;
        right: -3px;
        width: 9px;
        height: 9px;
        border-radius: 999px;
        border: 1.5px solid var(--c-surface);
        box-shadow: 0 0 0 0.5px rgba(0, 0, 0, 0.2);
        pointer-events: auto;
        z-index: 4;
      }
      .health-dot[data-health="green"]  { background: var(--c-success); }
      .health-dot[data-health="yellow"] { background: var(--c-warning); }
      .health-dot[data-health="orange"] { background: color-mix(in oklab, var(--c-warning) 50%, var(--c-error) 50%); }
      .health-dot[data-health="red"]    { background: var(--c-error); }
      .sub-node .health-dot { top: -2px; right: -2px; width: 7px; height: 7px; border-width: 1px; }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

      /* ---- Sub-element track (v0.1.2) ---- */
      .step-sub-track {
        position: relative;
        flex-basis: 100%;
        margin-top: 4px;
        padding: 6px 4px;
        border-top: 1px dashed var(--c-border);
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        gap: 6px;
        cursor: default;
        user-select: none;
      }
      .sub-rubber-band {
        position: absolute;
        pointer-events: none;
        border: 1px dashed var(--c-primary);
        background: var(--c-tint);
        opacity: 0.55;
        z-index: 5;
      }
      .sub-node {
        position: relative;
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        cursor: pointer;
      }
      /* Hover bridge — a transparent pseudo extends the sub-node's
         hover area outward so the cursor can move from the thumbnail to
         the outside-positioned shift buttons without losing :hover.
         pointer-events default off so the bridge doesn't intercept
         clicks in the gap area between sub-nodes (which would select
         the neighboring sub by mistake); it activates only while the
         node is already hovered/selected — i.e. once the cursor is on
         the body, the bridge takes over for the trip out to the buttons. */
      .sub-node::after {
        content: '';
        position: absolute;
        inset: -2px -10px -10px -10px;
        z-index: 1;
        pointer-events: none;
      }
      .sub-node:hover::after,
      .sub-node.selected::after {
        pointer-events: auto;
      }
      .sub-node.primary { border-color: var(--c-primary); }
      .sub-node.selected {
        outline: 2px solid var(--c-primary);
        outline-offset: 1px;
      }
      /* Picker-armed sub: same heartbeat as .step-thumb.is-picking so
         the user gets a consistent "now pick a replacement element" cue.
         Re-uses the thumb-pulse keyframes defined above. */
      .sub-node.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      /* Time-shift buttons sit just outside the thumbnail edges so they
         don't cover the picked image content. They're always in the
         DOM but hidden until either the user hovers the sub or the sub
         is selected — that way a click that flips .selected via direct
         DOM manipulation surfaces them immediately, no re-render needed.
         Arrow keys do the same job for keyboard users (anchor sub). */
      .sub-shift {
        position: absolute;
        width: 13px;
        height: 13px;
        padding: 0;
        border: 1px solid var(--c-primary);
        background: rgba(255, 255, 255, 0.92);
        color: var(--c-primary);
        border-radius: 3px;
        font-size: 11px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        z-index: 3;
        user-select: none;
        opacity: 0;
        pointer-events: none;
      }
      /* No opacity transition — each click rebuilds the step card and a
         fade-in on the fresh sub-node element would visibly flicker on
         every press. Snap to 1 once hover re-applies on the next paint. */
      /* Buttons sit fully inside the sub-node thumbnail so moving the
         mouse from thumb → button never leaves the .sub-node hover area
         (avoids the disappear-mid-move flicker). */
      .sub-node:hover .sub-shift {
        opacity: 1;
        pointer-events: auto;
      }
      .sub-shift:hover { background: var(--c-tint); color: var(--c-primary); }
      .sub-shift-left { left: -8px; bottom: -7px; z-index: 3; }
      .sub-shift-right { right: -8px; bottom: -7px; z-index: 3; }
      .sub-node[draggable="true"] { cursor: grab; }
      .sub-node.dragging { opacity: 0.4; cursor: grabbing; }
      /* Insert-before / insert-after drop indicators — a 2px vertical
         bar flush against the hovered sub-node on the matching side. */
      .sub-node.drop-before::before,
      .sub-node.drop-after::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-node.drop-before::before { left: -5px; }
      .sub-node.drop-after::after { right: -5px; }
      .sub-gap.drop-on {
        position: relative;
      }
      .sub-gap.drop-on::after {
        content: '';
        position: absolute;
        top: -3px;
        bottom: -3px;
        left: 50%;
        transform: translateX(-50%);
        width: 2px;
        background: var(--c-primary);
        border-radius: 2px;
      }
      .sub-badge {
        position: absolute;
        top: -4px;
        left: -4px;
        background: var(--c-surface);
        color: var(--c-primary);
        font-family: var(--ff-mono);
        font-size: 9px;
        font-weight: 700;
        padding: 1px 4px;
        border-radius: 999px;
        border: 1px solid var(--c-primary);
        line-height: 1;
      }
      .sub-gap {
        display: inline-flex;
        align-items: center;
        font-family: var(--ff-mono);
        font-size: 10px;
        color: var(--c-text-mute);
        white-space: nowrap;
        padding: 0 2px;
        user-select: none;
      }
      .sub-gap::before,
      .sub-gap::after {
        content: '';
        width: 6px;
        height: 1px;
        background: var(--c-border-strong);
        opacity: 0.6;
      }
      .sub-gap::before { margin-right: 4px; }
      .sub-gap::after  { margin-left: 4px; }
      .sub-add {
        width: 28px;
        height: 28px;
        flex-shrink: 0;
        border-radius: var(--r-xs);
        border: 1.5px dashed var(--c-border-strong);
        background: transparent;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .sub-add:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }

  `}function Tg(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Ig(){return[$g(),Lg(),Tg(),Mg()].join(`
`)}function Cg(){return`
    <style>${Ig()}</style>
    <div class="panel" role="region" aria-label="${m("panel.aria.region")}">
      ${Dg()}
      ${Pg()}
      <div class="body" data-region="steps"></div>
      ${Rg()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${m("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Dg(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${mi({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <div class="header-actions">
          <button type="button" class="palette-toggle" data-action="palette-toggle" data-region="palette-toggle" aria-label="${m("panel.palette-toggle-aria")}" aria-pressed="false" title="${m("panel.palette-toggle-aria")}">
            <svg class="palette-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <circle cx="8" cy="8" r="3"></circle>
              <path d="M8 1.2v1.6M8 13.2v1.6M14.8 8h-1.6M2.8 8H1.2M12.8 3.2l-1.13 1.13M4.33 11.67l-1.13 1.13M12.8 12.8l-1.13-1.13M4.33 4.33L3.2 3.2"></path>
            </svg>
            <svg class="palette-moon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path d="M6.5 1.5a6.5 6.5 0 1 0 8 8 5.4 5.4 0 0 1-8-8z"></path>
            </svg>
          </button>
          <button type="button" class="close-btn" data-action="close" aria-label="${m("panel.close-aria")}">×</button>
        </div>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${m("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Pg(){return`
    <div class="tool-bar" role="toolbar" aria-label="${m("panel.tool-label")}">
      <span class="eyebrow">${m("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${m("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${m("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${m("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Rg(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${m("panel.replay-aria")}" title="${m("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${m("panel.prompter-aria")}" title="${m("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
        <button type="button" class="record-btn" data-action="recording-toggle" data-region="record-btn" aria-pressed="false" aria-label="${m("panel.record-aria")}" title="${m("panel.record-aria")}">
          <svg class="record-dot" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="8" cy="8" r="5"/></svg>
          <svg class="record-stop" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="10" height="10" rx="1"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${m("panel.import-aria")}" title="${m("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${m("panel.export-aria")}" title="${m("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="validate" aria-label="${m("panel.validate-aria")}" title="${m("panel.validate-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 12l2 2 4-4"></path>
            <circle cx="12" cy="12" r="9"></circle>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${m("panel.settings-aria")}" title="${m("panel.settings.title")}" data-region="settings-toggle">
          ${Km(16)}
        </button>
      </div>
      ${Ng()}
    </div>
  `}function Ng(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${m("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${m("panel.settings.close-aria")}" title="${m("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${m("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${m("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function Og(t,e=[],n=!1,r=null){if(!t.selectors)return"";const o=t.subElements??[],a=t.subDwellsMs??[],i=new Set(e),s=[];return s.push(Hg(t,n)),o.forEach((c,l)=>{s.push(oi(l,a[l]??0)),s.push(zg(t.id,c,l,i.has(c.id),c.id===r))}),o.length>0&&s.push(oi(o.length,a[o.length]??0)),s.push(Fg(t.id)),`<div class="step-sub-track" data-region="sub-track" data-step-id="${T(t.id)}">${s.join("")}</div>`}function Hg(t,e){const n=t.thumbnailDataUrl?` style="background-image: url('${T(t.thumbnailDataUrl)}')"`:"",r=e?"sub-node primary selected":"sub-node primary",o=Ar(t.id),a=Er(o),i=a!=="none"?`<span class="health-dot" data-health="${a}" data-target="primary-mirror" title="${T(Bc(o))}"></span>`:"";return`<div class="${r}" data-primary="1"${n}><span class="sub-badge">1</span>${i}</div>`}function zg(t,e,n,r,o){const a=e.thumbnailDataUrl?` style="background-image: url('${T(e.thumbnailDataUrl)}')"`:"",i=["sub-node"];r&&i.push("selected"),o&&i.push("is-picking");const s=i.join(" "),c=`<span class="sub-badge">${n+2}</span>`,l=Ar(t,e.id),d=Er(l),p=d!=="none"?`<span class="health-dot" data-health="${d}" data-target="sub" title="${T(Bc(l))}"></span>`:"",u=T(m("sub.shift-left")),f=T(m("sub.shift-right")),h=T(e.id),b=`<button type="button" class="sub-shift sub-shift-left" data-action="sub-shift" data-sub-id="${h}" data-direction="-1" aria-label="${u}" title="${u}" tabindex="-1">‹</button><button type="button" class="sub-shift sub-shift-right" data-action="sub-shift" data-sub-id="${h}" data-direction="1" aria-label="${f}" title="${f}" tabindex="-1">›</button>`;return`<div class="${s}" data-sub-id="${h}" data-sub-idx="${n}" draggable="true"${a}>${c}${p}${b}</div>`}function Bc(t){return t===1?m("health.layer1"):t===2?m("health.layer2"):t===3?m("health.layer3"):t===null?m("health.broken"):""}function oi(t,e){return`<div class="sub-gap" data-gap-idx="${t}"><span>${qg(e)}</span></div>`}function Fg(t){const e=m("sub.add-aria")||"Add another element";return`<button type="button" class="sub-add" data-action="sub-add" data-step-id="${T(t)}" aria-label="${T(e)}" title="${T(e)}">+</button>`}function qg(t){const e=t/1e3;return Number.isInteger(e)?`${e}s`:`${e.toFixed(1)}s`}function _g(t){var n;const e=t.pickedAtUrl||((n=L())==null?void 0:n.url)||"";return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${T(e)}"
        aria-label="Open ${T(e)}"
      >${Ym(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${rt(e)}</span>
    </div>
  `:""}function Bg(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,a=t.thumbnailDataUrl!==null,i=n&&st()==="picker",s=i&&g.pickerTarget.type==="primary",c="step-thumb"+(o?" has-element":"")+(s?" is-picking":""),l=a?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",d=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,p=t.waitForNavigation,u=Ar(t.id),f=Er(u);return r.innerHTML=`
    <button
      type="button"
      class="${c}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${T(m("step.wand-aria",{n:e+1}))}"
      title="${T(m("step.wand-title"))}"${l}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!a?`<span class="step-thumb-icon">${Gm(18)}</span>`:""}
      ${!o&&!a?'<span class="step-thumb-plus">+</span>':""}
      ${f!=="none"?`<span class="health-dot" data-health="${f}" data-target="step" title="${T(Ug(u))}"></span>`:""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${T(m("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${rt(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${T(m("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${rt(t.description)}</div>
    </div>
    ${_g(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${p}" aria-label="${T(m("step.action-aria"))}" title="${T(m("step.action-aria"))}">${Xm(10)}</button>
      <div class="step-timer${p?" disabled":""}" data-action="step-timer" data-step-id="${T(t.id)}" title="${T(m("step.timer-aria"))}" ${p?'aria-disabled="true"':""}>
        <span class="step-timer-num">${d}</span>
        ${Go(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${T(m("step.delete-aria"))}" title="${T(m("step.delete-aria"))}">${Vm(12)}</button>
    </div>
    ${Og(t,Mr(g.subSelection,t.id),mc(g.subSelection,t.id),i&&g.subSelection.stepId===t.id?g.subSelection.anchorId:null)}
  `,r}function Ug(t){return t===1?m("health.layer1"):t===2?m("health.layer2"):t===3?m("health.layer3"):t===null?m("health.broken"):""}function jg(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function Wg(t,e,n){ii(t,"step-name",n,r=>me(e.id,{name:r})),ii(t,"step-desc",n,r=>me(e.id,{description:r}),{escapeBlurs:!0}),Gg(t,n),Xg(t,e),Vg(t,e)}function Vg(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id;n.addEventListener("mousedown",o=>{if(o.button!==0)return;const a=o.target;if(!a||a.closest(".sub-node, .sub-add"))return;const i=n.getBoundingClientRect(),s=o.clientX-i.left,c=o.clientY-i.top,l=document.createElement("div");l.className="sub-rubber-band",l.style.left=`${s}px`,l.style.top=`${c}px`,l.style.width="0px",l.style.height="0px",n.appendChild(l),o.preventDefault();const d=()=>{document.removeEventListener("mousemove",p),document.removeEventListener("mouseup",u),document.removeEventListener("keydown",f),l.remove()},p=h=>{const b=n.getBoundingClientRect(),v=h.clientX-b.left,w=h.clientY-b.top,x=Math.min(s,v),S=Math.min(c,w),z=Math.max(s,v),H=Math.max(c,w);l.style.left=`${x}px`,l.style.top=`${S}px`,l.style.width=`${z-x}px`,l.style.height=`${H-S}px`;const C=[];n.querySelectorAll(".sub-node[data-sub-id]").forEach(Y=>{const J=Y.getBoundingClientRect(),re=J.left-b.left,ct=J.top-b.top,Mt=J.right-b.left,un=J.bottom-b.top,tt=x<Mt&&z>re&&S<un&&H>ct;if(tt){const F=Y.dataset.subId;F&&C.push(F)}Y.classList.toggle("selected",tt)}),g.subSelection={stepId:r,selectedIds:C,anchorId:C[C.length-1]??null,primarySelected:!1}},u=()=>d(),f=h=>{h.key==="Escape"&&(d(),g.subSelection=Ie,n.querySelectorAll(".sub-node.selected").forEach(b=>b.classList.remove("selected")))};document.addEventListener("mousemove",p),document.addEventListener("mouseup",u,{once:!0}),document.addEventListener("keydown",f)})}function Xg(t,e){const n=t.querySelector('[data-region="sub-track"]');if(!n)return;const r=e.id,o=()=>{n.querySelectorAll(".sub-node.drop-before, .sub-node.drop-after, .sub-gap.drop-on").forEach(a=>a.classList.remove("drop-before","drop-after","drop-on"))};n.querySelectorAll(".sub-node[data-sub-id]").forEach(a=>{a.addEventListener("dragstart",i=>{i.stopPropagation();const s=a.dataset.subId??"";if(!s)return;const c=Mr(g.subSelection,r),l=c.includes(s)?[...c]:[s];g.subDragSet=l,g.subDragStepId=r,l.forEach(d=>{const p=n.querySelector(`.sub-node[data-sub-id="${d.replace(/"/g,'\\"')}"]`);p==null||p.classList.add("dragging")}),i.dataTransfer&&(i.dataTransfer.setData("text/plain",`sub:${l.join(",")}`),i.dataTransfer.effectAllowed="move")}),a.addEventListener("dragend",()=>{n.querySelectorAll(".sub-node.dragging").forEach(i=>i.classList.remove("dragging")),g.subDragSet=null,g.subDragStepId=null,o()}),a.addEventListener("dragover",i=>{if(!g.subDragSet||g.subDragStepId!==r)return;const s=Number(a.dataset.subIdx);if(!Number.isFinite(s))return;const c=a.getBoundingClientRect(),l=i.clientX<c.left+c.width/2,d=l?s:s+1;if(ai(e,g.subDragSet,d)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add(l?"drop-before":"drop-after")}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-before","drop-after")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.subIdx);if(!Number.isFinite(s)||!g.subDragSet||g.subDragStepId!==r){o();return}const c=a.getBoundingClientRect(),d=i.clientX<c.left+c.width/2?s:s+1,p=g.subDragSet;g.subDragSet=null,g.subDragStepId=null,o(),aa(r,p,d)})}),n.querySelectorAll(".sub-gap[data-gap-idx]").forEach(a=>{a.addEventListener("dragover",i=>{if(!g.subDragSet||g.subDragStepId!==r)return;const s=Number(a.dataset.gapIdx);if(Number.isFinite(s)){if(ai(e,g.subDragSet,s)){o();return}i.preventDefault(),i.stopPropagation(),i.dataTransfer&&(i.dataTransfer.dropEffect="move"),o(),a.classList.add("drop-on")}}),a.addEventListener("dragleave",()=>{a.classList.remove("drop-on")}),a.addEventListener("drop",i=>{i.preventDefault(),i.stopPropagation();const s=Number(a.dataset.gapIdx);if(!Number.isFinite(s)||!g.subDragSet||g.subDragStepId!==r){o();return}const c=g.subDragSet;g.subDragSet=null,g.subDragStepId=null,o(),aa(r,c,s)})})}function ai(t,e,n){const r=t.subElements??[];if(r.length===0||e.length===0)return!0;const o=new Set(e);let a=0;for(let s=0;s<n&&s<r.length;s++){const c=r[s];c&&!o.has(c.id)&&a++}let i=0;for(let s=0;s<r.length;s++){const c=r[s];if(c){if(o.has(c.id))break;i++}}return a===i}function ii(t,e,n,r,o={}){const a=t.querySelector(`[data-region="${e}"]`);a&&(a.addEventListener("input",()=>jg(a)),a.addEventListener("focus",()=>{Tr(n)||Dt(n)}),a.addEventListener("mousedown",i=>i.stopPropagation()),a.addEventListener("blur",()=>r(a.textContent??"")),a.addEventListener("keydown",i=>{(i.key==="Enter"&&e==="step-name"||i.key==="Escape"&&o.escapeBlurs)&&(i.preventDefault(),a.blur())}))}function Gg(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}g.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),g.dragFromIndex=null,(n=g.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{g.dragFromIndex===null||g.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(g.dragFromIndex===null||g.dragFromIndex===e)&&(jl(g.dragFromIndex,e),g.dragFromIndex=null)})}function Yg(){const{shadow:t}=g;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=L();if(e.innerHTML="",!n)return;const r=B();n.steps.forEach((a,i)=>{if(i>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(i)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${i+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${i}" aria-label="Insert step here">
          ${ei(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=Bg(a,i,r===i);e.appendChild(s),Wg(s,a,i)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${ei(10,1.8)}
    </button>
  `,e.appendChild(o)}function En(){return g.host!==null}function Uc(t){const{host:e}=g;e&&(e.dataset.promptedHidden=t?"1":"",Yo(e))}function si(t){const{host:e}=g;e&&(e.dataset.recordingHidden=t?"1":"",Yo(e))}function ci(t){const{host:e}=g;e&&(e.dataset.tutorialRecording=t?"1":"",Yo(e))}function Yo(t){const e=st(),n=t.dataset.promptedHidden==="1",r=t.dataset.recordingHidden==="1",o=t.dataset.tutorialRecording==="1",a=e==="replay"&&!o;t.style.display=a||n||r?"none":""}async function cr(t){if(g.host){t&&await ra(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),Ct(e);const n=Bm(window.innerHeight*Uh);e.style.cssText=["position: fixed",`top: ${ye}px`,`right: ${ye}px`,`width: ${Bh}px`,`height: ${n}px`,`max-height: calc(100vh - ${ye*2}px)`,`z-index: ${O+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=Cg(),g.host=e,g.shadow=r,Qm(jc,Uc),document.body.appendChild(e),t&&await ra(t)||na(),Zs(),document.addEventListener(rn,_c),document.addEventListener(Sr,Wc),window.addEventListener("resize",Tc),g.unsubscribeMode=mt(Gr),g.unsubscribeScenario=Ce(Gr),Gr();const o=L();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(a){console.warn("[manuscript] markActive failed",a)}}function jc(){var e,n;const{host:t}=g;t&&(document.removeEventListener(rn,_c),document.removeEventListener(Sr,Wc),window.removeEventListener("resize",Tc),Jm(),(e=g.unsubscribeMode)==null||e.call(g),g.unsubscribeMode=null,(n=g.unsubscribeScenario)==null||n.call(g),g.unsubscribeScenario=null,I("idle"),$e(),ns(),Qs(),Ii(),Dh(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),g.host=null,g.shadow=null)}function Wc(t){const e=t.detail,{shadow:n}=g;if(!n)return;if(e.cleared){n.querySelectorAll(".health-dot").forEach(o=>o.remove());return}const r=Er(e.layer);if(e.subId){const o=n.querySelector(`.sub-node[data-sub-id="${e.subId.replace(/"/g,'\\"')}"]`);o&&Xr(o,r,"sub")}else n.querySelectorAll("[data-step-card]").forEach(a=>{var p;const i=(p=a.querySelector("[data-step-id]"))==null?void 0:p.dataset.stepId,s=a.querySelector('[data-region="sub-track"]'),c=s==null?void 0:s.dataset.stepId;if(i!==e.stepId&&c!==e.stepId)return;const l=a.querySelector(".step-thumb");l&&Xr(l,r,"step");const d=a.querySelector(".sub-node.primary");d&&Xr(d,r,"primary-mirror")})}function Xr(t,e,n){const r=t.querySelector(`.health-dot[data-target="${n}"]`);if(e==="none"){r==null||r.remove();return}if(r)r.setAttribute("data-health",e);else{const o=document.createElement("span");o.className="health-dot",o.dataset.health=e,o.dataset.target=n,t.appendChild(o)}}function Gr(){const{host:t,shadow:e}=g;if(!e||!t)return;const n=st(),r=t.dataset.promptedHidden==="1",o=t.dataset.recordingHidden==="1",a=t.dataset.tutorialRecording==="1",i=n==="replay"&&!a;t.style.display=i||r||o?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(l=>{const d=l.getAttribute("data-tool");l.setAttribute("aria-pressed",String(d===n))});const s=L(),c=e.querySelector('[data-region="title-edit"]');c&&s&&c!==e.activeElement&&(c.textContent!==s.name&&(c.textContent=s.name),bo(c)),Yg(),Xo(),vr()&&!ft()&&Ke()}function Kg(t,e,n){switch(t.type){case"panel.open":return cr(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return jc(),n({ok:!0}),!1;case"scenario.replay":return cr(t.scenarioId).then(()=>Pe(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return Zg(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return xf(),ft()&&Te(),Mh(),Uc(!1),n({ok:!0}),!1}return!1}function Zg(t,e){if(ft()){t==="prev"?Zn():t==="next"?Qe():t==="jump"&&typeof e=="number"?_o(e):t==="pause"&&Je();return}const n=L();if(!n)return;const r=B();if(t==="prev")r>0&&ht(r-1),Ke();else if(t==="next")r<n.steps.length-1&&ht(r+1),Ke();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(Tr(e))return;ht(e)}Ke()}else t==="pause"&&Pe(r)}async function Qg(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Jg(){try{const t=await hi();if(!t)return;if(tb()){await chrome.storage.local.remove(G.activeReplay);return}I("replay"),await cr(t.scenarioId),await Pe(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function tb(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function eb(){try{const t=await Qg();if(!t)return;await cr(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Dt(t.stepIndex),await ig()}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const nb="manuscript:host",rb="manuscript:ext",ob="manuscript:ready";let li=!1;function ab(){li||(window.addEventListener("message",sb),li=!0,mt(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Wt("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(ob)))}function ib(t){return typeof t=="object"&&t!==null&&t.source===nb&&typeof t.type=="string"}function Wt(t,e,n){const r={source:rb,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function sb(t){const e=t.data;if(ib(e))switch(e.type){case"ping":Wt("pong",e.requestId,{version:lb()});return;case"load":try{const n=cb(e.scenario);Ti(n),Wt("load-ack",e.requestId,{ok:!0})}catch(n){Wt("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!Yf()&&Zs(),Wt("play-ack",e.requestId,{ok:!0}),Pe(r,{paused:o,standalone:n}).catch(a=>{console.warn("[manuscript] startReplay failed",a)});return}case"pause":ft()&&Je(),Wt("pause-ack",e.requestId,{ok:ft()});return;case"next":ft()&&Qe();return;case"prev":ft()&&Zn();return;case"jump":ft()&&typeof e.index=="number"&&_o(e.index);return;case"exit":(async()=>(ft()&&await Te(),Wt("exit-ack",e.requestId,{ok:!0})))();return}}function cb(t){if(t==null)throw new Zo("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new Zo("Invalid JSON",n)}return Qo(e,{strict:!0})}return Qo(t,{strict:!0})}function lb(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const db=window===window.top;cf();dl();Mp();tf();mp();Gp();wp();zu();gf();vf();var di,ui;db&&(yf().then(()=>{Jg(),eb()}),chrome.runtime.onMessage.addListener(Kg),(ui=(di=chrome.permissions)==null?void 0:di.onAdded)==null||ui.addListener(()=>zc()),ab());export{Vd as M,Xd as V,yt as d,dt as g,Ce as o,Ct as r,mb as u};
