import{O as C}from"./chunk-w63YPwpl.js";import{o as A,r as $,u as f,d as T,g as D,M as H,V as W}from"./chunk-6gTyBsVQ.js";import"./chunk-CPFEzpND.js";import"./chunk-CZWrsG4y.js";import"./chunk-qUkww72A.js";const _="oklch(0.42 0.09 250)",O=3,I="#000000",R=.55,m=0,M=12;let s=null,d=null,p=null,v=null,h=null,g=null,w="muted";function G(t){s||z(),g=t,x(),L(t),p||(p=A(()=>{x(),g&&L(g)}))}function b(){p==null||p(),p=null,v&&(document.removeEventListener("mousedown",v,!0),v=null),h&&(document.removeEventListener("keydown",h),h=null),g=null,s&&(s.remove(),s=null,d=null)}function Y(){return s!==null}function z(){s=document.createElement("div"),s.setAttribute("data-manuscript","ui"),$(s),s.setAttribute("data-popup","spotlight-editor"),s.style.cssText=["position: fixed",`z-index: ${C+5}`,"pointer-events: auto"].join("; "),d=s.attachShadow({mode:"open"}),d.innerHTML=q(),document.body.appendChild(s),B()}function q(){return`<style>${U()}</style>
    <div class="card">
      <div class="header">
        <span class="caption">Spotlight</span>
        <div class="toggle" role="tablist" aria-label="Swatch mode">
          <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
          <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
        </div>
      </div>

      <div class="row label-row">
        <span class="label">Ring</span>
        <div class="swatches" data-region="ring-swatches"></div>
      </div>
      <div class="row">
        <span class="label">Width</span>
        <div class="slider-wrap">
          <div class="slider-track" data-region="width-track">
            <div class="slider-fill" data-region="width-fill"></div>
            <div class="slider-thumb" data-region="width-thumb"></div>
          </div>
          <span class="slider-value" data-region="width-value">3</span>
        </div>
      </div>

      <div class="divider"></div>

      <div class="row label-row">
        <span class="label">Dim</span>
        <div class="swatches" data-region="dim-swatches"></div>
      </div>
      <div class="row">
        <span class="label">Opacity</span>
        <div class="slider-wrap">
          <div class="slider-track" data-region="opacity-track">
            <div class="slider-fill" data-region="opacity-fill"></div>
            <div class="slider-thumb" data-region="opacity-thumb"></div>
          </div>
          <span class="slider-value" data-region="opacity-value">55%</span>
        </div>
      </div>

      <div class="divider"></div>

      <div class="row footer-row">
        <button type="button" class="reset" data-action="reset">Reset to default</button>
        <button type="button" class="close" data-action="close" aria-label="Close">×</button>
      </div>
    </div>`}function U(){return`
    ${T()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }
    .card {
      width: 300px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      font-size: var(--fs-body);
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .header { display: flex; align-items: center; justify-content: space-between; }
    .caption {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: 0;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .row { display: flex; align-items: center; gap: 14px; }
    .row.label-row { gap: 14px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 60px;
      flex-shrink: 0;
    }

    .swatches { display: flex; gap: 4px; flex-wrap: wrap; flex: 1; }
    .sw {
      width: 22px;
      height: 22px;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      padding: 0;
      background: transparent;
      transition: transform 0.12s, box-shadow 0.12s;
      overflow: hidden;
      position: relative;
    }
    .sw:hover { transform: scale(1.08); }
    .sw[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .sw.transparent {
      background: var(--c-surface);
      border: 1px solid var(--c-border-strong);
    }
    .sw.transparent svg { position: absolute; inset: 0; display: block; }

    .slider-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .slider-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .slider-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .slider-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 2px solid var(--c-text);
      cursor: grab;
      box-shadow: var(--shadow-sm);
    }
    .slider-thumb:active { cursor: grabbing; }
    .slider-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 38px;
      text-align: right;
    }

    .divider { height: 1px; background: var(--c-border); margin: 2px -12px; }

    .footer-row { justify-content: space-between; gap: 8px; }
    .reset {
      appearance: none;
      background: var(--c-surface-2);
      border: 1px solid var(--c-border);
      color: var(--c-text-mute);
      font: inherit;
      font-size: 11px;
      padding: 5px 10px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .reset:hover { background: var(--c-tint); color: var(--c-text); }
    .close {
      appearance: none;
      background: transparent;
      border: 0;
      color: var(--c-text-mute);
      font-size: 18px;
      line-height: 1;
      cursor: pointer;
      padding: 0 4px;
    }
    .close:hover { color: var(--c-text); }
  `}function x(){var u;if(!d)return;const t=((u=D())==null?void 0:u.spotlight)??{},e=t.stroke??_,a=t.strokeWidth??O,n=t.dimColor??I,i=t.dimOpacity??R;d.querySelectorAll('[data-action="swatch-mode"]').forEach(y=>{y.setAttribute("aria-pressed",String(y.getAttribute("data-mode")===w))});const r=d.querySelector('[data-region="ring-swatches"]');r&&(r.innerHTML=k(e,"ring"));const o=d.querySelector('[data-region="dim-swatches"]');o&&(o.innerHTML=k(n,"dim",!0));const l=Math.max(0,Math.min(100,(a-m)/(M-m)*100));E("width",l,String(a));const c=Math.round(Math.max(0,Math.min(1,i))*100);E("opacity",c,`${c}%`)}function k(t,e,a=!1){const n=w==="muted"?H:W,i=[];if(a){const r=t==="transparent";i.push(`<button type="button" class="sw transparent" data-slot="${e}" data-color="transparent" aria-pressed="${r}" title="transparent">
        <svg viewBox="0 0 22 22" width="22" height="22" aria-hidden="true">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>`)}for(const{resolved:r}of n){const o=X(r,t);i.push(`<button type="button" class="sw" data-slot="${e}" data-color="${r}" aria-pressed="${o}" style="background:${r};"></button>`)}return i.join("")}function X(t,e){return!t||!e?!1:t.replace(/\s+/g,"").toLowerCase()===e.replace(/\s+/g,"").toLowerCase()}function E(t,e,a){if(!d)return;const n=d.querySelector(`[data-region="${t}-fill"]`),i=d.querySelector(`[data-region="${t}-thumb"]`),r=d.querySelector(`[data-region="${t}-value"]`),o=Math.max(0,Math.min(100,e));n&&(n.style.width=`${o}%`),i&&(i.style.left=`${o}%`),r&&(r.textContent=a)}function B(){d&&(d.addEventListener("click",t=>{var r;const e=t.target;if(!e)return;const a=e.closest('[data-action="swatch-mode"]');if(a){const o=a.getAttribute("data-mode");(o==="muted"||o==="vibrant")&&(w=o,x());return}const n=e.closest(".sw");if(n){const o=n.getAttribute("data-slot"),l=n.getAttribute("data-color")??"";o==="ring"?f({stroke:l}):o==="dim"&&f({dimColor:l});return}const i=(r=e.closest("[data-action]"))==null?void 0:r.getAttribute("data-action");i==="close"?b():i==="reset"&&f({stroke:void 0,strokeWidth:void 0,dimColor:void 0,dimOpacity:void 0})}),S("width",t=>{const e=Math.round((m+t*(M-m))*2)/2;f({strokeWidth:e})}),S("opacity",t=>{f({dimOpacity:Math.round(t*100)/100})}),v=t=>{if(!s||t.composedPath().includes(s))return;const a=t.target;a!=null&&a.closest('[data-manuscript="ui"]')||b()},document.addEventListener("mousedown",v,!0),h=t=>{t.key==="Escape"&&b()},document.addEventListener("keydown",h))}function S(t,e){if(!d)return;const a=d.querySelector(`[data-region="${t}-track"]`),n=d.querySelector(`[data-region="${t}-thumb"]`);if(!a||!n)return;let i=!1;const r=c=>{const u=a.getBoundingClientRect();return Math.max(0,Math.min(1,(c-u.left)/u.width))},o=c=>{i&&e(r(c.clientX))},l=()=>{i=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",l,!0)};n.addEventListener("mousedown",c=>{i=!0,e(r(c.clientX)),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",l,!0),c.preventDefault()}),a.addEventListener("mousedown",c=>{const u=c.target;u instanceof Element&&u.closest(`[data-region="${t}-thumb"]`)||(e(r(c.clientX)),i=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",l,!0))})}function L(t){if(!s)return;const e=t.getBoundingClientRect(),a=10,n=s.offsetWidth||300,i=s.offsetHeight||280;let r=e.right-n;r<8&&(r=8),r+n>window.innerWidth-8&&(r=window.innerWidth-n-8);let o=e.bottom+a;o+i>window.innerHeight-8&&(o=Math.max(8,e.top-i-a)),s.style.left=`${Math.round(r)}px`,s.style.top=`${Math.round(o)}px`}export{b as closeSpotlightEditor,Y as isSpotlightEditorOpen,G as openSpotlightEditor};
