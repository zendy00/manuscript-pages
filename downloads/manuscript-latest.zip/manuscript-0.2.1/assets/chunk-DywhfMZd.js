const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-qlGH_CZ3.js","assets/chunk-w63YPwpl.js","assets/chunk-CPFEzpND.js","assets/chunk-CZWrsG4y.js","assets/chunk-qUkww72A.js"])))=>i.map(i=>d[i]);
import{S as X,O,E as As}from"./chunk-w63YPwpl.js";import{s as li,g as Ms,S as $s,a as Tr,b as di,c as Ls,m as ui,d as Ts,e as Cs,f as ro,h as oo}from"./chunk-CPFEzpND.js";import{t as b,i as Is}from"./chunk-CZWrsG4y.js";import{g as pi,i as Ps,a as Ds,b as fi,c as Rs,s as Os,d as Ns,w as Fs,l as Hs,e as zs,f as _s}from"./chunk-qUkww72A.js";const pr="manuscript:mode-changed";let nn="idle";function yt(){return nn}function D(t){if(t===nn)return;const e=nn;nn=t,document.dispatchEvent(new CustomEvent(pr,{detail:{prev:e,next:t}}))}function it(t){const e=n=>t(n.detail);return document.addEventListener(pr,e),()=>document.removeEventListener(pr,e)}function hi(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),i=n*(1-e),a=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,d=0;switch(r){case 0:c=n,l=s,d=i;break;case 1:c=a,l=n,d=i;break;case 2:c=i,l=n,d=s;break;case 3:c=i,l=a,d=n;break;case 4:c=s,l=i,d=n;break;case 5:c=n,l=i,d=a;break}return[Math.round(c*255),Math.round(l*255),Math.round(d*255)]}function mi(t,e,n){const r=t/255,o=e/255,i=n/255,a=Math.max(r,o,i),s=Math.min(r,o,i),c=a-s;let l=0;return c!==0&&(a===r?l=(o-i)/c%6:a===o?l=(i-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:a===0?0:c/a,v:a}}function gi(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function bi(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(i=>i+i).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(i=>!Number.isFinite(i))?{h:0,s:1,v:1}:mi(n,r,o)}function Zn(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function io(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function Bs(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const qs=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── PALETTE E — STUDIO-DARK ─────
   Cool slate dark, mirrors PALETTE D STUDIO. See design/dark-mode-design.md §4.1.
   Chroma ≤ 0.09 doctrine maintained (focus only allowed slight excess at 0.13). */
[data-palette="studio-dark"] {
  --c-bg:        oklch(0.16  0.012 245);
  --c-surface:   oklch(0.22  0.014 245);
  --c-surface-2: oklch(0.19  0.012 245);
  --c-text:      oklch(0.97  0.003 245);
  --c-text-mute: oklch(0.78  0.006 245);
  --c-text-soft: oklch(0.62  0.008 245);
  --c-border:    oklch(0.32  0.012 245);
  --c-border-strong: oklch(0.42 0.014 245);
  --c-primary:   oklch(0.70  0.09  245);
  --c-primary-h: oklch(0.78  0.09  245);
  --c-primary-fg: oklch(0.14  0.020 245);
  --c-tint:      oklch(0.32  0.045 245);
  --c-focus:     oklch(0.74  0.13  245);
}

/* ───── PALETTE F — INK-DARK ─────
   Warm-on-cool dark, mirrors PALETTE A INK. design/dark-mode-design.md §4.2.
   Absorbs \`08.DARK-MODE-TOKENS.md\` §1 (spotlight-editor) and §2 (launcher pill) tones. */
[data-palette="ink-dark"] {
  --c-bg:        oklch(0.14  0.015 250);
  --c-surface:   oklch(0.20  0.018 250);
  --c-surface-2: oklch(0.17  0.016 250);
  --c-text:      oklch(0.98  0.003  80);
  --c-text-mute: oklch(0.76  0.006  80);
  --c-text-soft: oklch(0.60  0.008  80);
  --c-border:    oklch(0.30  0.014 250);
  --c-border-strong: oklch(0.40 0.016 250);
  --c-primary:   oklch(0.66  0.06  250);
  --c-primary-h: oklch(0.74  0.07  250);
  --c-primary-fg: oklch(0.14  0.018 250);
  --c-tint:      oklch(0.30  0.05  250);
  --c-focus:     oklch(0.70  0.10  250);
}

/* ───── Dark-palette shared overrides ─────
   Shadows: alpha ~4× because black-on-black shadow is weak; pair with
   surface-lightness steps (--c-bg < --c-surface-2 < --c-surface) for elevation.
   Functional accents: lightness ↑ for contrast on dark surface (L≈0.22). */
[data-palette$="-dark"] {
  --shadow-sm:   0 1px 2px  rgb(0 0 0 / 0.40);
  --shadow-md:   0 2px 6px  rgb(0 0 0 / 0.45), 0 1px 2px rgb(0 0 0 / 0.35);
  --shadow-lg:   0 12px 28px rgb(0 0 0 / 0.55), 0 4px 8px rgb(0 0 0 / 0.40);
  --shadow-card: 0 1px 2px  rgb(0 0 0 / 0.35),
                 0 4px 10px rgb(0 0 0 / 0.40),
                 0 12px 24px rgb(0 0 0 / 0.50);

  --c-success: oklch(0.66 0.10 150);
  --c-warning: oklch(0.78 0.11  75);
  --c-error:   oklch(0.66 0.15  27);
  --c-info:    oklch(0.66 0.09 245);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function kt(){return qs.replace(/:root\s*\{/g,":host {").replace(/\[data-palette([^\]]*)\]\s*\{/g,":host([data-palette$1]) {")}const vi="studio",js=["studio","ink","graphite","sepia","studio-dark","ink-dark"];function yi(t){return typeof t=="string"&&js.includes(t)}function xi(t){return t.endsWith("-dark")}let ae=null;const fr=new Set;let ao=!1;async function Ws(){if(ae)return ae;try{const e=(await chrome.storage.local.get(X.palette))[X.palette];if(yi(e))return ae=e,e}catch{}return vi}function wi(){return ae??vi}async function Us(t){ae=t,ki(t);try{await chrome.storage.local.set({[X.palette]:t})}catch{}}async function Xs(){const t=wi(),e=xi(t)?"studio":"studio-dark";return await Us(e),e}function Rt(t){fr.add(new WeakRef(t)),t.setAttribute("data-palette",wi()),Ws().then(e=>{t.isConnected&&t.setAttribute("data-palette",e)}),Vs()}function Vs(){if(!ao){ao=!0;try{chrome.storage.onChanged.addListener((t,e)=>{var r;if(e!=="local")return;const n=(r=t[X.palette])==null?void 0:r.newValue;yi(n)&&(ae=n,ki(n))})}catch{}}}function ki(t){for(const e of[...fr]){const n=e.deref();n&&n.isConnected?(n.setAttribute("data-palette",t),Ys(n,t)):fr.delete(e)}}function Ys(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="palette-toggle"]');n&&n.setAttribute("aria-pressed",xi(e)?"true":"false")}const Gs=140,Ks=140;function Zs(){return`
    ${kt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${Gs}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${Ks}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function Qs(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function Js(){return[Zs(),Qs()].join(`
`)}const hr="manuscript:scenario-changed",tc=500,ec=5e3,m={scenario:null,currentStepIndex:0,saveTimer:null};function I(){return m.scenario}function U(){return m.currentStepIndex}function at(){return m.scenario?m.scenario.steps[m.currentStepIndex]??null:null}function ye(t){return document.addEventListener(hr,t),()=>document.removeEventListener(hr,t)}function W(){document.dispatchEvent(new CustomEvent(hr)),nc()}function st(){m.scenario&&(m.scenario.updatedAt=new Date().toISOString())}function Si(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Cr(){return{id:Si("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:ec,waitForNavigation:!1}}function nc(){if(!m.scenario)return;m.saveTimer!==null&&window.clearTimeout(m.saveTimer);const t=m.scenario;m.saveTimer=window.setTimeout(()=>{m.saveTimer=null,li(t).catch(e=>{console.error("[manuscript] save failed",e)})},tc)}function On(){m.saveTimer!==null&&(window.clearTimeout(m.saveTimer),m.saveTimer=null,m.scenario&&li(m.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const rc=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],oc=8,ic=5;function ac(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const a=mr(e.getAttribute("content"));a&&t.add(a)}const n=getComputedStyle(document.documentElement);for(const a of rc){const s=mr(n.getPropertyValue(a));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:a,prop:s}of r)so(t,a,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let a=0;a<o.length&&a<ic;a++)so(t,o[a]??null,"background-color");const i=Array.from(t).filter(sc).slice(0,oc);return{text:i,background:i}}function so(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=mr(r);o&&t.add(o)}function mr(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],i=e[3];return`#${r}${r}${o}${o}${i}${i}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=Qn(n[1]),i=Qn(n[2]),a=Qn(n[3]);return`#${Jn(o)}${Jn(i)}${Jn(a)}`}return null}function Qn(t){return Math.max(0,Math.min(255,Number(t)|0))}function Jn(t){return t.toString(16).padStart(2,"0")}function sc(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const i=Math.max(n,r,o),a=Math.min(n,r,o);return!(i-a<12)}const cc="'Asta Sans', sans-serif",lc=6,dc=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function uc(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const i=o.trim();if(!i)continue;const a=pc(i);if(!a)continue;const s=a.toLowerCase();if(!dc.has(s)&&!e.has(s)&&(e.add(s),n.push(fc(i)),n.length>=lc))break}return n}function pc(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function fc(t){return/asta\s*sans/i.test(t)?t:`${t}, ${cc}`}function co(){On();const t=hc(),e=mc();m.scenario={schemaVersion:$s,id:Si("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[Cr()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},m.currentStepIndex=0,W()}function hc(){try{const t=ac();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function mc(){try{return uc()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function lo(t){On();const e=await Ms(t);return e?(m.scenario=e,m.currentStepIndex=0,W(),!0):!1}function Ei(t){On(),m.scenario=t,m.currentStepIndex=0,W()}function gc(t){if(!m.scenario)return;const e=t.trim();!e||e===m.scenario.name||(m.scenario.name=e,m.scenario.updatedAt=new Date().toISOString(),W())}function Ai(){On(),m.scenario=null,m.currentStepIndex=0,W()}function uo(t={}){if(!m.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>m.scenario.steps.length?m.scenario.steps.length:t.insertIndex;return m.scenario.steps.splice(e,0,Cr()),st(),m.currentStepIndex=e,W(),m.currentStepIndex}function se(t,e){if(!m.scenario)return;const n=m.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(st(),W())}function bc(t){const e=at();!e||!m.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,st(),W())}function vc(t){m.scenario&&(t<0||t>=m.scenario.steps.length||(m.scenario.steps.splice(t,1),m.scenario.steps.length===0?(m.scenario.steps.push(Cr()),m.currentStepIndex=0):m.currentStepIndex>=m.scenario.steps.length?m.currentStepIndex=m.scenario.steps.length-1:t<m.currentStepIndex&&(m.currentStepIndex-=1),st(),W()))}function rm(t){const e=at();if(!e||!m.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,st(),W()}function Gt(t){m.scenario&&(t<0||t>=m.scenario.steps.length||t!==m.currentStepIndex&&(m.currentStepIndex=t,W()))}function yc(t,e){if(!m.scenario||t===e||t<0||t>=m.scenario.steps.length||e<0||e>=m.scenario.steps.length)return;const[n]=m.scenario.steps.splice(t,1);n&&(m.scenario.steps.splice(e,0,n),m.currentStepIndex===t?m.currentStepIndex=e:t<m.currentStepIndex&&e>=m.currentStepIndex?m.currentStepIndex-=1:t>m.currentStepIndex&&e<=m.currentStepIndex&&(m.currentStepIndex+=1),st(),W())}function xc(t){const e=at();!e||!m.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),st(),W())}function Ne(t){const e=at();!e||!m.scenario||(e.annotations.push(t),st(),W())}function Mi(t){const e=at();!e||!m.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),st(),W())}function C(t,e){const n=at();!n||!m.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),st(),W())}function $i(){var t;return((t=at())==null?void 0:t.annotations)??[]}function T(t){return $i().find(e=>e.id===t)}function wc(t,e){if(!m.scenario)return;const n=e.trim();if(!n)return;const r=m.scenario.customColors??{},o=r[t]??[];o.includes(n)||(m.scenario.customColors={...r,[t]:[...o,n]},st(),W())}function kc(t,e){if(!m.scenario||!m.scenario.customColors)return;const n=m.scenario.customColors[t];!n||!n.includes(e)||(m.scenario.customColors={...m.scenario.customColors,[t]:n.filter(r=>r!==e)},st(),W())}function Sc(){return`
    <style>${Js()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Ec()}
      ${Ac()}
      ${Mc()}
      ${$c()}
    </div>
  `}function Ec(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Ac(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function Mc(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function $c(){var i,a;const t=I(),e=((i=t==null?void 0:t.customColors)==null?void 0:i.text)??[],n=((a=t==null?void 0:t.customColors)==null?void 0:a.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${Ue(s)}" style="background: ${Ue(s)}" aria-label="Use ${Ue(s)}" title="${Ue(s)}"></button>`).join("")}</div>
    </div>
  `}function Ue(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Lc(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let i=n.left;i+r.width>window.innerWidth-8&&(i=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,i)}px`}let Q=null,z=null,Ct=0,Wt=1,Ut=1,It=null;function Tc(t){Xt(),It=t.onConfirm;const e=bi(t.initialColor);Ct=e.h,Wt=e.s,Ut=e.v,Q=document.createElement("div"),Q.setAttribute("data-manuscript","ui"),Rt(Q),Q.style.cssText=["position: fixed",`z-index: ${O+7}`,"pointer-events: auto"].join("; "),z=Q.attachShadow({mode:"open"}),z.innerHTML=Sc(),Ic(),document.body.appendChild(Q),Lc(Q,t.anchor),Fe(),document.addEventListener("mousedown",Ti,!0),document.addEventListener("keydown",Ci,!0)}function Xt(){Q&&(document.removeEventListener("mousedown",Ti,!0),document.removeEventListener("keydown",Ci,!0),Q.remove(),Q=null,z=null,It=null)}function Cc(){return Q!==null}function Fe(){if(!z)return;const t=z.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${Ct}deg, 100%, 50%)`);const e=z.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Wt*100}%`,e.style.top=`${(1-Ut)*100}%`);const n=z.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${Ct/360*100}%`);const[r,o,i]=hi(Ct,Wt,Ut),a=gi(r,o,i),s=z.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${i})`);const c=z.querySelector('[data-region="hex"]');c&&(c.textContent=a),z.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===Q&&z.activeElement===l)return;const d=l.dataset.channel;d==="r"?l.value=String(r):d==="g"?l.value=String(o):d==="b"&&(l.value=String(i))})}function Li(){const[t,e,n]=hi(Ct,Wt,Ut);return gi(t,e,n)}function Ic(){if(!z)return;const t=z.querySelector('[data-region="sv"]');t&&io(t,n=>Pc(t,n));const e=z.querySelector('[data-region="hue"]');e&&io(e,n=>Dc(e,n)),z.addEventListener("input",n=>{var c,l,d;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Zn((c=z.querySelector('[data-channel="r"]'))==null?void 0:c.value),i=Zn((l=z.querySelector('[data-channel="g"]'))==null?void 0:l.value),a=Zn((d=z.querySelector('[data-channel="b"]'))==null?void 0:d.value),s=mi(o,i,a);Ct=s.h,Wt=s.s,Ut=s.v,Fe()}),z.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),i=o==null?void 0:o.getAttribute("data-action");if(i==="confirm")It==null||It(Li()),Xt();else if(i==="eyedrop")Bs(po);else if(i==="recent"){const a=o==null?void 0:o.getAttribute("data-color");a&&po(a)}})}function po(t){const e=bi(t);Ct=e.h,Wt=e.s,Ut=e.v,Fe()}function Pc(t,e){const n=t.getBoundingClientRect();Wt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Ut=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),Fe()}function Dc(t,e){const n=t.getBoundingClientRect();Ct=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,Fe()}function Ti(t){if(!Q)return;const e=t.target;e instanceof HTMLElement&&Q.contains(e)||Xt()}function Ci(t){t.key==="Escape"?(t.preventDefault(),Xt()):t.key==="Enter"&&(t.preventDefault(),It==null||It(Li()),Xt())}const Xe=8,Qt=6,Ii=32,fo=16,Ve=4,Pi=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function ho(t,e,n,r){let{x:o,y:i,width:a,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,a-=n):(t==="ne"||t==="e"||t==="se")&&(a+=n),t==="nw"||t==="n"||t==="ne"?(i+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),a<Qt&&(o=e.x+e.width-Qt,a=Qt),s<Qt&&(i=e.y+e.height-Qt,s=Qt),{x:o,y:i,width:a,height:s}}function Di(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of t)i.x<e&&(e=i.x),i.y<n&&(n=i.y),i.x>r&&(r=i.x),i.y>o&&(o=i.y);return{x:e,y:n,width:r-e,height:o-n}}function Rc(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const M={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},N="http://www.w3.org/2000/svg";function Ri(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const i=r.tagName.toLowerCase(),a=r.parentElement,s=r.tagName;if(a){const c=Array.from(a.children).filter(l=>{var d;return l.tagName===s&&!((d=l.matches)!=null&&d.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${i}:nth-of-type(${l})`)}else n.unshift(i)}else n.unshift(i);r=a,o++}return n.join(" > ")}function Ir(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function Oc(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const Nc=["data-testid","data-test","id","aria-label"];function Fc(t){for(const e of Nc){const n=t.getAttribute(e);if(n&&n.length>0)return{kind:"stable-attr",cssSelector:`[${e}="${Oc(n)}"]`}}return{kind:"stable-attr",cssSelector:Ri(t)}}function Hc(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!Ir(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function zc(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?Ri(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function _c(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!Ir(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function Bc(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const i of Array.from(r.children)){if(i===t)continue;const a=(i.textContent??"").trim();if(a.length>0&&a.length<60&&n.push(a),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function qc(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||Ir(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const i=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>i.includes(c))?n:null}function jc(t){return{layer1:Fc(t),layer2:zc(t),layer3:Bc(t)}}function Wc(t,e){const n=e.ownerDocument;return n?Oi(t,n)===e:!1}function Pe(t){const e=Ni(t.framePath);return e?Oi(t,e):null}function Oi(t,e){return Hc(t.layer1,e)??_c(t.layer2,e)??qc(t.layer3,e)}function Ni(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function Uc(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function G(){const t=at();if(!t||!t.selectors)return null;try{const e=Pe(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function Xc(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function Nn(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function Vc(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function Fn(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function Fi(t){if(!t.bounds)return t;const e=G();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function Yc(t){if(!t.points)return t;const e=G();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function Gc(){document.removeEventListener("mousemove",Pr,!0),document.removeEventListener("mouseup",Dr,!0),document.removeEventListener("keydown",zi,!0)}function Kc(){document.addEventListener("keydown",zi,!0)}function Zc(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="shape")return;const r=Nn(n,G());M.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},Hn()}function Qc(t){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const e=T(M.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;M.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},Hn()}function Hi(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,i=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;M.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:i},Hn()}function Jc(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="freedraw")return;const r=Fn(n,G()),o=Di(r);!o||o.width===0||o.height===0||(M.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(i=>({...i}))},Hn())}function Hn(){document.addEventListener("mousemove",Pr,!0),document.addEventListener("mouseup",Dr,!0)}function Pr(t){const{activeId:e,dragState:n}=M;if(!e||!n)return;t.preventDefault();const r=T(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,i=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const a=ho(n.handle,n.startBounds,o,i);C(e,Fi({bounds:a}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const a=n.startBounds,s=ho(n.handle,a,o,i),c=a.width===0?1:s.width/a.width,l=a.height===0?1:s.height/a.height,d=n.startPoints.map(f=>({x:s.x+(f.x-a.x)*c,y:s.y+(f.y-a.y)*l}));C(e,Yc({points:d}))}else if(n.kind==="rotate"){const a=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(a-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?C(e,{rotate:s}):r.kind==="freedraw"?C(e,{rotate:s}):r.kind==="text"&&C(e,{rotate:s})}}function Dr(){document.removeEventListener("mousemove",Pr,!0),document.removeEventListener("mouseup",Dr,!0),M.dragState=null}function zi(t){var o;const{activeId:e}=M;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Mi(e);return}if(t.key.startsWith("Arrow")){const i=T(e);if(!i||i.kind!=="shape")return;const a=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-a:t.key==="ArrowRight"?a:0,c=t.key==="ArrowUp"?-a:t.key==="ArrowDown"?a:0;if(s!==0||c!==0){t.preventDefault();const l=Nn(i,G());C(e,Fi({bounds:{...i.bounds,x:l.x+s,y:l.y+c}}))}}}}function _i(t,e,n,r,o){const i=document.createElementNS(N,"rect");return i.setAttribute("x",String(t-Xe/2)),i.setAttribute("y",String(e-Xe/2)),i.setAttribute("width",String(Xe)),i.setAttribute("height",String(Xe)),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),i.style.cursor=r,i.style.pointerEvents="auto",i.setAttribute("pointer-events","all"),i.addEventListener("mousedown",a=>o(a,n)),i}function Bi(t,e,n){const r=document.createElementNS(N,"g"),o=e-18,i=e-Ii,a=12,s=document.createElementNS(N,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(N,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(i+1)),c.setAttribute("r",String(a)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(N,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(i)),l.setAttribute("r",String(a)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const d=t-8,f=i-8,u=document.createElementNS(N,"path");u.setAttribute("d",`M ${d+4} ${f+11} A 5 5 0 1 1 ${d+11} ${f+4}`),u.setAttribute("fill","none"),u.setAttribute("stroke","oklch(0.48 0.085 245)"),u.setAttribute("stroke-width","1.5"),u.setAttribute("stroke-linecap","round"),u.setAttribute("stroke-linejoin","round"),u.style.pointerEvents="none",r.appendChild(u);const p=document.createElementNS(N,"path");return p.setAttribute("d",`M ${d+11} ${f+1.5} L ${d+14} ${f+4} L ${d+11} ${f+6.5} Z`),p.setAttribute("fill","oklch(0.48 0.085 245)"),p.setAttribute("stroke","oklch(0.48 0.085 245)"),p.setAttribute("stroke-width","1.5"),p.setAttribute("stroke-linejoin","round"),p.style.pointerEvents="none",r.appendChild(p),l.addEventListener("mousedown",h=>n(h)),r}function Rr(t,e){const n=document.createElementNS(N,"g"),r=t.x-fo,o=t.y-fo;return n.appendChild(tl(r,o,e)),n}function tl(t,e,n){const r=document.createElementNS(N,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(N,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const i=document.createElementNS(N,"circle");i.setAttribute("cx",String(t)),i.setAttribute("cy",String(e)),i.setAttribute("r","12"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.92 0.008 240)"),i.setAttribute("stroke-width","1"),r.appendChild(i);const a=t-6,s=e-6,c=document.createElementNS(N,"path");return c.setAttribute("d",[`M ${a+1.5} ${s+3.5} L ${a+10.5} ${s+3.5}`,`M ${a+4.5} ${s+3.5} L ${a+4.5} ${s+2} L ${a+7.5} ${s+2} L ${a+7.5} ${s+3.5}`,`M ${a+3} ${s+3.5} L ${a+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${a+4.3} ${s+11} L ${a+7.7} ${s+11} A 0.8 0.8 0 0 0 ${a+8.5} ${s+10.5} L ${a+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function Or(t){const e=document.createElementNS(N,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function zn(){const{host:t,activeId:e,activeMode:n}=M;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=T(e);if(!r){gr();return}if(n==="freedraw"&&r.kind==="freedraw"){ol(t,r);return}if(n==="text"&&r.kind==="text"){rl(t,r);return}if(r.kind!=="shape"){gr();return}el(t,r)}function el(t,e){const n=Nn(e,G()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,i=r.x+r.width/2,a=r.y+r.height/2,s=document.createElementNS(N,"g");o&&s.setAttribute("transform",`rotate(${o} ${i} ${a})`),s.appendChild(Or(r));for(const c of Pi){const{x:l,y:d}=c.offset(r);s.appendChild(_i(l,d,c.name,c.cursor,Zc))}s.appendChild(nl(r)),t.appendChild(s),t.appendChild(Rr(r,Nr))}function nl(t){const e=t.x+t.width/2,n=t.y-Ii,r=document.createElementNS(N,"g"),o=document.createElementNS(N,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const i=document.createElementNS(N,"g");i.style.cursor="grab",i.style.pointerEvents="auto",i.setAttribute("pointer-events","all");const a=document.createElementNS(N,"circle");a.setAttribute("cx",String(e)),a.setAttribute("cy",String(n)),a.setAttribute("r","9"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),i.appendChild(a);const s=document.createElementNS(N,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",i.appendChild(s),i.addEventListener("mousedown",c=>Qc(c)),r.appendChild(i),r}function rl(t,e){const n=Rc(e.id);if(!n)return;const r=qi(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(Or(r)),t.appendChild(Bi(o,r.y,a=>Hi(a,()=>({x:o,y:i})))),t.appendChild(Rr(r,Nr))}function ol(t,e){const n=Fn(e,G()),r=Di(n);if(!r)return;const o=qi(r),i=o.x+o.width/2,a=o.y+o.height/2;t.appendChild(Or(o));for(const s of Pi){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(_i(c,l,s.name,s.cursor,Jc))}t.appendChild(Bi(i,o.y,s=>Hi(s,()=>({x:i,y:a})))),t.appendChild(Rr(o,Nr))}function qi(t){return{x:t.x-Ve,y:t.y-Ve,width:t.width+Ve*2,height:t.height+Ve*2}}function Nr(){const t=M.activeId;t&&Mi(t)}function il(t){const e=T(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const i=document.querySelectorAll(o);if(i.length===0)return;const a=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;i.forEach(s=>{s.style.animation=""}),i[0].getBoundingClientRect(),i.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${a}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function al(t){const e=T(t);!e||e.kind!=="shape"||(M.activeId=t,M.activeMode="shape",Fr(),zn())}function sl(t){const e=T(t);!e||e.kind!=="freedraw"||(M.activeId=t,M.activeMode="freedraw",Fr(),zn())}function cl(t){const e=T(t);!e||e.kind!=="text"||(M.activeId=t,M.activeMode="text",Fr(),zn())}function gr(){var t;M.host&&(Gc(),(t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,M.host.remove(),M.host=null,M.activeId=null,M.activeMode="shape",M.dragState=null)}function ll(t){return M.host!==null&&t!==null&&M.host.contains(t)}function Fr(){if(M.host)return;const t=document.createElementNS(N,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),M.host=t,Kc(),M.unsubscribeScenario=ye(zn)}const dl=400,ul=0;function pl(t){return{kind:t,durationMs:dl,delayMs:ul}}function fl(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const mo=10,hl=46,ji=12,Wi=36,Ui=0,Xi=20,ml=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],gl=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],bl=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}],vl=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],A={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function St(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function Vi(t){const e=A.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,color:t}}):n.kind==="shape"?C(e,{stroke:t}):n.kind==="freedraw"&&C(e,{stroke:t}))}function Yi(t){const e=A.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&C(e,{fill:t}))}function Gi(t){const e=A.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,borderColor:t}})}function yl(t){const e=A.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontFamily:t}})}function xl(t){const e=A.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontSize:t}})}function wl(){const t=A.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,bold:!e.style.bold}})}function kl(){const t=A.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Sl(t){const e=A.activeId;e&&C(e,{entryAnimation:t==="none"?void 0:pl(t)})}function El(t){const e=A.activeId;if(!e)return;const n=T(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?C(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?C(e,{fillOpacity:r}):n.kind==="freedraw"&&C(e,{strokeOpacity:r})}function Al(t){const e=A.activeId;if(!e)return;const n=T(e);n&&(n.kind==="shape"?C(e,{strokeWidth:t}):n.kind==="freedraw"&&C(e,{strokeWidth:t}))}function Ml(){const{shadow:t}=A;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=a=>{r&&tr(e,a.clientX)},i=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",i,!0)};n.addEventListener("mousedown",a=>{r=!0,tr(e,a.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0),a.preventDefault()}),e.addEventListener("mousedown",a=>{const s=a.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(tr(e,a.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0))})}function tr(t,e){const n=t.getBoundingClientRect();El(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function br(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function $l(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function er(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function nr(t,e,n){var l,d,f;const r=A.swatchMode==="muted"?ml:gl,o=[];if(n&&(t==="bg"||t==="border")){const u=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${u}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let u=0;u<r.length;u++){const p=r[u];if(!p)continue;const h=u===1,g=er(e,p.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${p.resolved}" style="background:${p.resolved}" aria-pressed="${g}" title="${t} ${p.resolved}"></button>
    `)}const i=I(),a=(t==="text"||t==="border"?(l=i==null?void 0:i.siteColors)==null?void 0:l.text:(d=i==null?void 0:i.siteColors)==null?void 0:d.background)??[];for(const u of a){const p=er(e,u);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${St(u)}" style="background:${St(u)}" aria-pressed="${p}" title="Site color ${St(u)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((f=i==null?void 0:i.customColors)==null?void 0:f[s])??[];for(const u of c){const p=er(e,u);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${St(u)}" style="background:${St(u)}" aria-pressed="${p}" title="Custom ${St(u)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${St(u)}" title="Remove" aria-label="Remove color ${St(u)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function Hr(){const{shadow:t,activeId:e,activeKind:n}=A;if(!t||!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.querySelector('[data-region="caption"]');i&&(i.textContent=Rl(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(a=>{const s=a.getAttribute("data-mode");a.setAttribute("aria-pressed",String(s===A.swatchMode))}),Ll(t,n),Tl(t,n,o),Cl(t,n,o),Il(t,n,o),Pl(t,o),Dl(t,o)}function Ll(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const i=t.querySelector('[data-region="width-row"]'),a=e==="shape"||e==="freedraw";i&&(i.hidden=!a);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const d=t.querySelector('[data-region="bg-label"]');d&&(d.textContent=e==="text"?"Bg":"Fill")}function Tl(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const i=t.querySelector('[data-region="bold"]');i&&i.setAttribute("aria-pressed",String(n.style.bold));const a=t.querySelector('[data-region="italic"]');a&&a.setAttribute("aria-pressed",String(n.style.italic===!0))}function Cl(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),i=n.strokeWidth;r&&(r.value=String(i)),o&&(o.textContent=String(i))}function Il(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),i=t.querySelector('[data-region="border-swatches"]'),a=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=br(n,"text"),l=br(n,"bg");if(r&&(r.innerHTML=nr("text",c,!1)),o&&!(a!=null&&a.hidden)&&(o.innerHTML=nr("bg",l,e==="text")),i&&!(s!=null&&s.hidden)&&n.kind==="text"){const d=n.style.borderColor??"#000000";i.innerHTML=nr("border",d,!0)}}function Pl(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=fl(e))}function Dl(t,e){const n=Math.round($l(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),i=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),i&&(i.textContent=`${n}%`)}function Rl(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function Ol(t){const{shadow:e,host:n}=A;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>Nl(o)),e.addEventListener("change",o=>Fl(o)),e.addEventListener("input",o=>Hl(o)),Ml(),document.addEventListener("mousedown",o=>_l(o,t),!0),document.addEventListener("keydown",o=>Bl(o,t),!0)}function Nl(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(A.swatchMode=c,Hr());return}if(e.closest('[data-region="bold"]'))return wl();if(e.closest('[data-region="italic"]'))return kl();if(e.closest('[data-region="effect-play"]')){A.activeId&&il(A.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return Vi(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return Yi(o.getAttribute("data-value")??"");const i=e.closest('[data-swatch="border"]');if(i)return Gi(i.getAttribute("data-value")??"");const a=e.closest('[data-action="more-colors"]');if(a instanceof HTMLElement)return zl(a);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&kc(c==="text"||c==="border"?"text":"background",l)}}function Fl(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?yl(e.value):e.dataset.region==="effect"&&Sl(e.value))}function Hl(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(ji,Math.min(Wi,Number(e.value)||16));xl(n)}else if(e.dataset.region==="width"){const n=Math.max(Ui,Math.min(Xi,Number(e.value)||0));Al(n)}}}function zl(t){const{activeId:e,activeKind:n}=A;if(!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.getAttribute("data-slot");if(!i)return;const a=br(o,i)||"#ffffff";Tc({anchor:t,initialColor:a,onConfirm:s=>{wc(i==="text"||i==="border"?"text":"background",s),i==="text"?Vi(s):i==="border"?Gi(s):Yi(s)}})}function _l(t,e){const{host:n,activeAnchorSelector:r}=A,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||ll(o)||Cc()||r&&o instanceof Element&&o.closest(r)||(e(),Xt())}function Bl(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function Ki(t){const{host:e}=A;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-mo-hl;o<8&&(o=r.bottom+mo);const i=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${i}px`}function ql(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function jl(t,e){t==="text"?cl(e):t==="shape"?al(e):sl(e)}function Wl(){return`
    ${kt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function Ul(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function Xl(){return[Wl(),Ul()].join(`
`)}function Vl(){return`
    <style>${Xl()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${Yl()}
      ${Gl()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${Kl()}
      <div class="divider"></div>
      ${Zl()}
      ${Ql()}
      ${Jl()}
      ${td()}
    </div>
  `}function Yl(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function Gl(){return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${bl.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${ji}" max="${Wi}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function Kl(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function Zl(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${Ui}" max="${Xi}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function Ql(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${vl.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function Jl(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function td(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function zr(t,e,n){T(t)&&(A.activeId=t,A.activeKind=n,A.activeAnchorSelector=ql(n,t),A.host||id(),Hr(),Ki(e),jl(n,t))}function _r(){var t;A.host&&((t=A.unsubscribeScenario)==null||t.call(A),A.unsubscribeScenario=null,Xt(),gr(),A.host.remove(),A.host=null,A.shadow=null,A.activeId=null,A.activeKind=null,A.activeAnchorSelector=null)}function ed(){return A.activeId}function nd(t,e){zr(t,e,"text")}function Zi(){_r()}function rd(t,e){zr(t,e,"shape")}function od(t,e){zr(t,e,"freedraw")}function id(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Rt(t),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=Vl(),A.host=t,A.shadow=e,document.body.appendChild(t),Ol(_r),A.unsubscribeScenario=ye(ad)}function ad(){const{activeId:t,host:e,activeAnchorSelector:n}=A;if(!t||!e)return;if(!T(t)){_r();return}if(Hr(),n){const o=document.querySelector(n);o&&Ki(o)}}const vt=20;let dn=null,go=!1;function sd(){go||(go=!0,document.addEventListener("keydown",dd,!0)),cd()}async function cd(){try{const e=(await chrome.storage.local.get(X.annotationClipboard))[X.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(dn=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function ld(t){try{await chrome.storage.local.set({[X.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function dd(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||yt()!=="replay"&&(ud()||(e==="c"?pd(t):fd(t)))}function ud(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function pd(t){const e=ed();if(!e)return;const n=T(e);n&&(dn=n,ld(n),t.preventDefault())}function fd(t){if(!dn||!at())return;const e=hd(dn);Ne(e),t.preventDefault()}function hd(t){switch(t.kind){case"text":return md(t);case"shape":return gd(t);case"freedraw":return bd(t);case"arrow":return vd(t)}}function md(t){return{...t,id:_n("text"),position:{x:t.position.x+vt,y:t.position.y+vt},style:{...t.style}}}function gd(t){return{...t,id:_n("shape"),bounds:{...t.bounds,x:t.bounds.x+vt,y:t.bounds.y+vt}}}function bd(t){return{...t,id:_n("freedraw"),points:t.points.map(e=>({x:e.x+vt,y:e.y+vt}))}}function vd(t){return{...t,id:_n("arrow"),from:{x:t.from.x+vt,y:t.from.y+vt},to:{x:t.to.x+vt,y:t.to.y+vt}}}function _n(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function rr(t,e,n){if(t&&t.length){const[r,o]=e,i=Math.PI/180*n,a=Math.cos(i),s=Math.sin(i);for(const c of t){const[l,d]=c;c[0]=(l-r)*a-(d-o)*s+r,c[1]=(l-r)*s+(d-o)*a+o}}}function yd(t,e){return t[0]===e[0]&&t[1]===e[1]}function xd(t,e,n,r=1){const o=n,i=Math.max(e,.1),a=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of a)rr(l,s,o);const c=(function(l,d,f){const u=[];for(const y of l){const E=[...y];yd(E[0],E[E.length-1])||E.push([E[0][0],E[0][1]]),E.length>2&&u.push(E)}const p=[];d=Math.max(d,.1);const h=[];for(const y of u)for(let E=0;E<y.length-1;E++){const B=y[E],F=y[E+1];if(B[1]!==F[1]){const P=Math.min(B[1],F[1]);h.push({ymin:P,ymax:Math.max(B[1],F[1]),x:P===B[1]?B[0]:F[0],islope:(F[0]-B[0])/(F[1]-B[1])})}}if(h.sort(((y,E)=>y.ymin<E.ymin?-1:y.ymin>E.ymin?1:y.x<E.x?-1:y.x>E.x?1:y.ymax===E.ymax?0:(y.ymax-E.ymax)/Math.abs(y.ymax-E.ymax))),!h.length)return p;let g=[],v=h[0].ymin,x=0;for(;g.length||h.length;){if(h.length){let y=-1;for(let E=0;E<h.length&&!(h[E].ymin>v);E++)y=E;h.splice(0,y+1).forEach((E=>{g.push({s:v,edge:E})}))}if(g=g.filter((y=>!(y.edge.ymax<=v))),g.sort(((y,E)=>y.edge.x===E.edge.x?0:(y.edge.x-E.edge.x)/Math.abs(y.edge.x-E.edge.x))),(f!==1||x%d==0)&&g.length>1)for(let y=0;y<g.length;y+=2){const E=y+1;if(E>=g.length)break;const B=g[y].edge,F=g[E].edge;p.push([[Math.round(B.x),v],[Math.round(F.x),v]])}v+=f,g.forEach((y=>{y.edge.x=y.edge.x+f*y.edge.islope})),x++}return p})(a,i,r);if(o){for(const l of a)rr(l,s,-o);(function(l,d,f){const u=[];l.forEach((p=>u.push(...p))),rr(u,d,f)})(c,s,-o)}return c}function He(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let i=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(i=o),xd(t,o,r,i||1)}class Br{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=He(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function Bn(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class wd extends Br{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=He(e,Object.assign({},n,{hachureGap:r})),i=Math.PI/180*n.hachureAngle,a=[],s=.5*r*Math.cos(i),c=.5*r*Math.sin(i);for(const[l,d]of o)Bn([l,d])&&a.push([[l[0]-s,l[1]+c],[...d]],[[l[0]+s,l[1]-c],[...d]]);return{type:"fillSketch",ops:this.renderLines(a,n)}}}class kd extends Br{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),i=this._fillPolygons(e,o);return r.ops=r.ops.concat(i.ops),r}}class Sd{constructor(e){this.helper=e}fillPolygons(e,n){const r=He(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let i=n.fillWeight;i<0&&(i=n.strokeWidth/2);const a=o/4;for(const s of e){const c=Bn(s),l=c/o,d=Math.ceil(l)-1,f=c-d*o,u=(s[0][0]+s[1][0])/2-o/4,p=Math.min(s[0][1],s[1][1]);for(let h=0;h<d;h++){const g=p+f+h*o,v=u-a+2*Math.random()*a,x=g-a+2*Math.random()*a,y=this.helper.ellipse(v,x,i,i,n);r.push(...y.ops)}}return{type:"fillSketch",ops:r}}}class Ed{constructor(e){this.helper=e}fillPolygons(e,n){const r=He(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,i=[];return e.forEach((a=>{const s=Bn(a),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let d=a[0],f=a[1];d[0]>f[0]&&(d=a[1],f=a[0]);const u=Math.atan((f[1]-d[1])/(f[0]-d[0]));for(let p=0;p<c;p++){const h=p*(r+o),g=h+r,v=[d[0]+h*Math.cos(u)+l*Math.cos(u),d[1]+h*Math.sin(u)+l*Math.sin(u)],x=[d[0]+g*Math.cos(u)+l*Math.cos(u),d[1]+g*Math.sin(u)+l*Math.sin(u)];i.push(...this.helper.doubleLineOps(v[0],v[1],x[0],x[1],n))}})),i}}class Ad{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,i=He(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(i,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((i=>{const a=Bn(i),s=Math.round(a/(2*n));let c=i[0],l=i[1];c[0]>l[0]&&(c=i[1],l=i[0]);const d=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let f=0;f<s;f++){const u=2*f*n,p=2*(f+1)*n,h=Math.sqrt(2*Math.pow(n,2)),g=[c[0]+u*Math.cos(d),c[1]+u*Math.sin(d)],v=[c[0]+p*Math.cos(d),c[1]+p*Math.sin(d)],x=[g[0]+h*Math.cos(d+Math.PI/4),g[1]+h*Math.sin(d+Math.PI/4)];o.push(...this.helper.doubleLineOps(g[0],g[1],x[0],x[1],r),...this.helper.doubleLineOps(x[0],x[1],v[0],v[1],r))}})),o}}const K={};class Md{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const $d=0,or=1,bo=2,Ye={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function ir(t,e){return t.type===e}function qr(t){const e=[],n=(function(a){const s=new Array;for(;a!=="";)if(a.match(/^([ \t\r\n,]+)/))a=a.substr(RegExp.$1.length);else if(a.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:$d,text:RegExp.$1},a=a.substr(RegExp.$1.length);else{if(!a.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:or,text:`${parseFloat(RegExp.$1)}`},a=a.substr(RegExp.$1.length)}return s[s.length]={type:bo,text:""},s})(t);let r="BOD",o=0,i=n[o];for(;!ir(i,bo);){let a=0;const s=[];if(r==="BOD"){if(i.text!=="M"&&i.text!=="m")return qr("M0,0"+t);o++,a=Ye[i.text],r=i.text}else ir(i,or)?a=Ye[r]:(o++,a=Ye[i.text],r=i.text);if(!(o+a<n.length))throw new Error("Path data ended short");for(let c=o;c<o+a;c++){const l=n[c];if(!ir(l,or))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof Ye[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=a,i=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function Qi(t){let e=0,n=0,r=0,o=0;const i=[];for(const{key:a,data:s}of t)switch(a){case"M":i.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],i.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":i.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],i.push({key:"L",data:[e,n]});break;case"C":i.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":i.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":i.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],i.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":i.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],i.push({key:"H",data:[e]});break;case"V":i.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],i.push({key:"V",data:[n]});break;case"S":i.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,d)=>d%2?l+n:l+e));i.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":i.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],i.push({key:"T",data:[e,n]});break;case"Z":case"z":i.push({key:"Z",data:[]}),e=r,n=o}return i}function Ji(t){const e=[];let n="",r=0,o=0,i=0,a=0,s=0,c=0;for(const{key:l,data:d}of t){switch(l){case"M":e.push({key:"M",data:[...d]}),[r,o]=d,[i,a]=d;break;case"C":e.push({key:"C",data:[...d]}),r=d[4],o=d[5],s=d[2],c=d[3];break;case"L":e.push({key:"L",data:[...d]}),[r,o]=d;break;case"H":r=d[0],e.push({key:"L",data:[r,o]});break;case"V":o=d[0],e.push({key:"L",data:[r,o]});break;case"S":{let f=0,u=0;n==="C"||n==="S"?(f=r+(r-s),u=o+(o-c)):(f=r,u=o),e.push({key:"C",data:[f,u,...d]}),s=d[0],c=d[1],r=d[2],o=d[3];break}case"T":{const[f,u]=d;let p=0,h=0;n==="Q"||n==="T"?(p=r+(r-s),h=o+(o-c)):(p=r,h=o);const g=r+2*(p-r)/3,v=o+2*(h-o)/3,x=f+2*(p-f)/3,y=u+2*(h-u)/3;e.push({key:"C",data:[g,v,x,y,f,u]}),s=p,c=h,r=f,o=u;break}case"Q":{const[f,u,p,h]=d,g=r+2*(f-r)/3,v=o+2*(u-o)/3,x=p+2*(f-p)/3,y=h+2*(u-h)/3;e.push({key:"C",data:[g,v,x,y,p,h]}),s=f,c=u,r=p,o=h;break}case"A":{const f=Math.abs(d[0]),u=Math.abs(d[1]),p=d[2],h=d[3],g=d[4],v=d[5],x=d[6];f===0||u===0?(e.push({key:"C",data:[r,o,v,x,v,x]}),r=v,o=x):(r!==v||o!==x)&&(ta(r,o,v,x,f,u,p,h,g).forEach((function(y){e.push({key:"C",data:y})})),r=v,o=x);break}case"Z":e.push({key:"Z",data:[]}),r=i,o=a}n=l}return e}function ke(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function ta(t,e,n,r,o,i,a,s,c,l){const d=(f=a,Math.PI*f/180);var f;let u=[],p=0,h=0,g=0,v=0;if(l)[p,h,g,v]=l;else{[t,e]=ke(t,e,-d),[n,r]=ke(n,r,-d);const et=(t-n)/2,q=(e-r)/2;let mt=et*et/(o*o)+q*q/(i*i);mt>1&&(mt=Math.sqrt(mt),o*=mt,i*=mt);const Kt=o*o,Zt=i*i,Ss=Kt*Zt-Kt*q*q-Zt*et*et,Es=Kt*q*q+Zt*et*et,no=(s===c?-1:1)*Math.sqrt(Math.abs(Ss/Es));g=no*o*q/i+(t+n)/2,v=no*-i*et/o+(e+r)/2,p=Math.asin(parseFloat(((e-v)/i).toFixed(9))),h=Math.asin(parseFloat(((r-v)/i).toFixed(9))),t<g&&(p=Math.PI-p),n<g&&(h=Math.PI-h),p<0&&(p=2*Math.PI+p),h<0&&(h=2*Math.PI+h),c&&p>h&&(p-=2*Math.PI),!c&&h>p&&(h-=2*Math.PI)}let x=h-p;if(Math.abs(x)>120*Math.PI/180){const et=h,q=n,mt=r;h=c&&h>p?p+120*Math.PI/180*1:p+120*Math.PI/180*-1,u=ta(n=g+o*Math.cos(h),r=v+i*Math.sin(h),q,mt,o,i,a,0,c,[h,et,g,v])}x=h-p;const y=Math.cos(p),E=Math.sin(p),B=Math.cos(h),F=Math.sin(h),P=Math.tan(x/4),tt=4/3*o*P,ht=4/3*i*P,We=[t,e],ct=[t+tt*E,e-ht*y],Ot=[n+tt*F,r-ht*B],eo=[n,r];if(ct[0]=2*We[0]-ct[0],ct[1]=2*We[1]-ct[1],l)return[ct,Ot,eo].concat(u);{u=[ct,Ot,eo].concat(u);const et=[];for(let q=0;q<u.length;q+=3){const mt=ke(u[q][0],u[q][1],d),Kt=ke(u[q+1][0],u[q+1][1],d),Zt=ke(u[q+2][0],u[q+2][1],d);et.push([mt[0],mt[1],Kt[0],Kt[1],Zt[0],Zt[1]])}return et}}const Ld={randOffset:function(t,e){return w(t,e)},randOffsetWithRange:function(t,e,n){return un(t,e,n)},ellipse:function(t,e,n,r,o){const i=na(n,r,o);return vr(t,e,o,i).opset},doubleLineOps:function(t,e,n,r,o){return Dt(t,e,n,r,o,!0)}};function ea(t,e,n,r,o){return{type:"path",ops:Dt(t,e,n,r,o)}}function rn(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let i=0;i<r-1;i++)o.push(...Dt(t[i][0],t[i][1],t[i+1][0],t[i+1][1],n));return e&&o.push(...Dt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?ea(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function Td(t,e,n,r,o){return(function(i,a){return rn(i,!0,a)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function vo(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=Ge(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:Ge(n[0],1.5*(1+.22*e.roughness),wo(e));for(let i=1;i<n.length;i++){const a=n[i];if(a.length){const s=Ge(a,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:Ge(a,1.5*(1+.22*e.roughness),wo(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function na(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),i=2*Math.PI/o;let a=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return a+=w(a*c,n),s+=w(s*c,n),{increment:i,rx:a,ry:s}}function vr(t,e,n,r){const[o,i]=ko(r.increment,t,e,r.rx,r.ry,1,r.increment*un(.1,un(.4,1,n),n),n);let a=pn(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=ko(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=pn(s,null,n);a=a.concat(c)}return{estimatedPoints:i,opset:{type:"path",ops:a}}}function yo(t,e,n,r,o,i,a,s,c){const l=t,d=e;let f=Math.abs(n/2),u=Math.abs(r/2);f+=w(.01*f,c),u+=w(.01*u,c);let p=o,h=i;for(;p<0;)p+=2*Math.PI,h+=2*Math.PI;h-p>2*Math.PI&&(p=0,h=2*Math.PI);const g=2*Math.PI/c.curveStepCount,v=Math.min(g/2,(h-p)/2),x=So(v,l,d,f,u,p,h,1,c);if(!c.disableMultiStroke){const y=So(v,l,d,f,u,p,h,1.5,c);x.push(...y)}return a&&(s?x.push(...Dt(l,d,l+f*Math.cos(p),d+u*Math.sin(p),c),...Dt(l,d,l+f*Math.cos(h),d+u*Math.sin(h),c)):x.push({op:"lineTo",data:[l,d]},{op:"lineTo",data:[l+f*Math.cos(p),d+u*Math.sin(p)]})),{type:"path",ops:x}}function xo(t,e){const n=Ji(Qi(qr(t))),r=[];let o=[0,0],i=[0,0];for(const{key:a,data:s}of n)switch(a){case"M":i=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...Dt(i[0],i[1],s[0],s[1],e)),i=[s[0],s[1]];break;case"C":{const[c,l,d,f,u,p]=s;r.push(...Cd(c,l,d,f,u,p,i,e)),i=[u,p];break}case"Z":r.push(...Dt(i[0],i[1],o[0],o[1],e)),i=[o[0],o[1]]}return{type:"path",ops:r}}function ar(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,i=r.length;if(i>2){n.push({op:"move",data:[r[0][0]+w(o,e),r[0][1]+w(o,e)]});for(let a=1;a<i;a++)n.push({op:"lineTo",data:[r[a][0]+w(o,e),r[a][1]+w(o,e)]})}}return{type:"fillPath",ops:n}}function Jt(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!K[o])switch(o){case"zigzag":K[o]||(K[o]=new wd(r));break;case"cross-hatch":K[o]||(K[o]=new kd(r));break;case"dots":K[o]||(K[o]=new Sd(r));break;case"dashed":K[o]||(K[o]=new Ed(r));break;case"zigzag-line":K[o]||(K[o]=new Ad(r));break;default:o="hachure",K[o]||(K[o]=new Br(r))}return K[o]})(e,Ld).fillPolygons(t,e)}function wo(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function ra(t){return t.randomizer||(t.randomizer=new Md(t.seed||0)),t.randomizer.next()}function un(t,e,n,r=1){return n.roughness*r*(ra(n)*(e-t)+t)}function w(t,e,n=1){return un(-t,t,e,n)}function Dt(t,e,n,r,o,i=!1){const a=i?o.disableMultiStrokeFill:o.disableMultiStroke,s=yr(t,e,n,r,o,!0,!1);if(a)return s;const c=yr(t,e,n,r,o,!0,!0);return s.concat(c)}function yr(t,e,n,r,o,i,a){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let d=o.maxRandomnessOffset||0;d*d*100>s&&(d=c/10);const f=d/2,u=.2+.2*ra(o);let p=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;p=w(p,o,l),h=w(h,o,l);const g=[],v=()=>w(f,o,l),x=()=>w(d,o,l),y=o.preserveVertices;return a?g.push({op:"move",data:[t+(y?0:v()),e+(y?0:v())]}):g.push({op:"move",data:[t+(y?0:w(d,o,l)),e+(y?0:w(d,o,l))]}),a?g.push({op:"bcurveTo",data:[p+t+(n-t)*u+v(),h+e+(r-e)*u+v(),p+t+2*(n-t)*u+v(),h+e+2*(r-e)*u+v(),n+(y?0:v()),r+(y?0:v())]}):g.push({op:"bcurveTo",data:[p+t+(n-t)*u+x(),h+e+(r-e)*u+x(),p+t+2*(n-t)*u+x(),h+e+2*(r-e)*u+x(),n+(y?0:x()),r+(y?0:x())]}),g}function Ge(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]),r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]),o===t.length-1&&r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]);return pn(r,null,n)}function pn(t,e,n){const r=t.length,o=[];if(r>3){const i=[],a=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*t[s+1][0]-a*t[s-1][0])/6,c[1]+(a*t[s+1][1]-a*t[s-1][1])/6],i[2]=[t[s+1][0]+(a*t[s][0]-a*t[s+2][0])/6,t[s+1][1]+(a*t[s][1]-a*t[s+2][1])/6],i[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[i[1][0],i[1][1],i[2][0],i[2][1],i[3][0],i[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...yr(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function ko(t,e,n,r,o,i,a,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let d=0;d<=2*Math.PI;d+=t){const f=[e+r*Math.cos(d),n+o*Math.sin(d)];c.push(f),l.push(f)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const d=w(.5,s)-Math.PI/2;l.push([w(i,s)+e+.9*r*Math.cos(d-t),w(i,s)+n+.9*o*Math.sin(d-t)]);const f=2*Math.PI+d-.01;for(let u=d;u<f;u+=t){const p=[w(i,s)+e+r*Math.cos(u),w(i,s)+n+o*Math.sin(u)];c.push(p),l.push(p)}l.push([w(i,s)+e+r*Math.cos(d+2*Math.PI+.5*a),w(i,s)+n+o*Math.sin(d+2*Math.PI+.5*a)]),l.push([w(i,s)+e+.98*r*Math.cos(d+a),w(i,s)+n+.98*o*Math.sin(d+a)]),l.push([w(i,s)+e+.9*r*Math.cos(d+.5*a),w(i,s)+n+.9*o*Math.sin(d+.5*a)])}return[l,c]}function So(t,e,n,r,o,i,a,s,c){const l=i+w(.1,c),d=[];d.push([w(s,c)+e+.9*r*Math.cos(l-t),w(s,c)+n+.9*o*Math.sin(l-t)]);for(let f=l;f<=a;f+=t)d.push([w(s,c)+e+r*Math.cos(f),w(s,c)+n+o*Math.sin(f)]);return d.push([e+r*Math.cos(a),n+o*Math.sin(a)]),d.push([e+r*Math.cos(a),n+o*Math.sin(a)]),pn(d,null,c)}function Cd(t,e,n,r,o,i,a,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let d=[0,0];const f=s.disableMultiStroke?1:2,u=s.preserveVertices;for(let p=0;p<f;p++)p===0?c.push({op:"move",data:[a[0],a[1]]}):c.push({op:"move",data:[a[0]+(u?0:w(l[0],s)),a[1]+(u?0:w(l[0],s))]}),d=u?[o,i]:[o+w(l[p],s),i+w(l[p],s)],c.push({op:"bcurveTo",data:[t+w(l[p],s),e+w(l[p],s),n+w(l[p],s),r+w(l[p],s),d[0],d[1]]});return c}function Se(t){return[...t]}function Eo(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(Se(t[0]),Se(t[1]),Se(t[2]),Se(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const i=[],a=1-e;r.push(Se(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*o[s+1][0]-a*o[s-1][0])/6,c[1]+(a*o[s+1][1]-a*o[s-1][1])/6],i[2]=[o[s+1][0]+(a*o[s][0]-a*o[s+2][0])/6,o[s+1][1]+(a*o[s][1]-a*o[s+2][1])/6],i[3]=[o[s+1][0],o[s+1][1]],r.push(i[1],i[2],i[3])}}return r}function on(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function Id(t,e,n){const r=on(e,n);if(r===0)return on(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),on(t,Nt(e,n,o))}function Nt(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function xr(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],d=s[c+1],f=s[c+2],u=s[c+3];let p=3*d[0]-2*l[0]-u[0];p*=p;let h=3*d[1]-2*l[1]-u[1];h*=h;let g=3*f[0]-2*u[0]-l[0];g*=g;let v=3*f[1]-2*u[1]-l[1];return v*=v,p<g&&(p=g),h<v&&(h=v),p+h})(t,e)<n){const s=t[e+0];o.length?(i=o[o.length-1],a=s,Math.sqrt(on(i,a))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],d=t[e+2],f=t[e+3],u=Nt(c,l,.5),p=Nt(l,d,.5),h=Nt(d,f,.5),g=Nt(u,p,.5),v=Nt(p,h,.5),x=Nt(g,v,.5);xr([c,u,g,x],0,n,o),xr([x,v,h,f],0,n,o)}var i,a;return o}function Pd(t,e){return fn(t,0,t.length,e)}function fn(t,e,n,r,o){const i=o||[],a=t[e],s=t[n-1];let c=0,l=1;for(let d=e+1;d<n-1;++d){const f=Id(t[d],a,s);f>c&&(c=f,l=d)}return Math.sqrt(c)>r?(fn(t,e,l+1,r,i),fn(t,l,n,r,i)):(i.length||i.push(a),i.push(s)),i}function sr(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let i=0;i<o;i++)xr(t,3*i,e,r);return n&&n>0?fn(r,0,r.length,n):r}const J="none";class hn{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,i){const a=this._o(i);return this._d("line",[ea(e,n,r,o,a)],a)}rectangle(e,n,r,o,i){const a=this._o(i),s=[],c=Td(e,n,r,o,a);if(a.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];a.fillStyle==="solid"?s.push(ar([l],a)):s.push(Jt([l],a))}return a.stroke!==J&&s.push(c),this._d("rectangle",s,a)}ellipse(e,n,r,o,i){const a=this._o(i),s=[],c=na(r,o,a),l=vr(e,n,a,c);if(a.fill)if(a.fillStyle==="solid"){const d=vr(e,n,a,c).opset;d.type="fillPath",s.push(d)}else s.push(Jt([l.estimatedPoints],a));return a.stroke!==J&&s.push(l.opset),this._d("ellipse",s,a)}circle(e,n,r,o){const i=this.ellipse(e,n,r,r,o);return i.shape="circle",i}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[rn(e,!1,r)],r)}arc(e,n,r,o,i,a,s=!1,c){const l=this._o(c),d=[],f=yo(e,n,r,o,i,a,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const u=Object.assign({},l);u.disableMultiStroke=!0;const p=yo(e,n,r,o,i,a,!0,!1,u);p.type="fillPath",d.push(p)}else d.push((function(u,p,h,g,v,x,y){const E=u,B=p;let F=Math.abs(h/2),P=Math.abs(g/2);F+=w(.01*F,y),P+=w(.01*P,y);let tt=v,ht=x;for(;tt<0;)tt+=2*Math.PI,ht+=2*Math.PI;ht-tt>2*Math.PI&&(tt=0,ht=2*Math.PI);const We=(ht-tt)/y.curveStepCount,ct=[];for(let Ot=tt;Ot<=ht;Ot+=We)ct.push([E+F*Math.cos(Ot),B+P*Math.sin(Ot)]);return ct.push([E+F*Math.cos(ht),B+P*Math.sin(ht)]),ct.push([E,B]),Jt([ct],y)})(e,n,r,o,i,a,l));return l.stroke!==J&&d.push(f),this._d("arc",d,l)}curve(e,n){const r=this._o(n),o=[],i=vo(e,r);if(r.fill&&r.fill!==J)if(r.fillStyle==="solid"){const a=vo(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(a.ops)})}else{const a=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?a.push(...l):l.length===3?a.push(...sr(Eo([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):a.push(...sr(Eo(l),10,(1+r.roughness)/2))}a.length&&o.push(Jt([a],r))}return r.stroke!==J&&o.push(i),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],i=rn(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(ar([e],r)):o.push(Jt([e],r))),r.stroke!==J&&o.push(i),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const i=r.fill&&r.fill!=="transparent"&&r.fill!==J,a=r.stroke!==J,s=!!(r.simplification&&r.simplification<1),c=(function(d,f,u){const p=Ji(Qi(qr(d))),h=[];let g=[],v=[0,0],x=[];const y=()=>{x.length>=4&&g.push(...sr(x,f)),x=[]},E=()=>{y(),g.length&&(h.push(g),g=[])};for(const{key:F,data:P}of p)switch(F){case"M":E(),v=[P[0],P[1]],g.push(v);break;case"L":y(),g.push([P[0],P[1]]);break;case"C":if(!x.length){const tt=g.length?g[g.length-1]:v;x.push([tt[0],tt[1]])}x.push([P[0],P[1]]),x.push([P[2],P[3]]),x.push([P[4],P[5]]);break;case"Z":y(),g.push([v[0],v[1]])}if(E(),!u)return h;const B=[];for(const F of h){const P=Pd(F,u);P.length&&B.push(P)}return B})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=xo(e,r);if(i)if(r.fillStyle==="solid")if(c.length===1){const d=xo(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(d.ops)})}else o.push(ar(c,r));else o.push(Jt(c,r));return a&&(s?c.forEach((d=>{o.push(rn(d,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const i=typeof n=="number"&&n>=0?o.data.map((a=>+a.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${i[0]} ${i[1]} `;break;case"bcurveTo":r+=`C${i[0]} ${i[1]}, ${i[2]} ${i[3]}, ${i[4]} ${i[5]} `;break;case"lineTo":r+=`L${i[0]} ${i[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const i of n){let a=null;switch(i.type){case"path":a={d:this.opsToPath(i),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:J};break;case"fillPath":a={d:this.opsToPath(i),stroke:J,strokeWidth:0,fill:r.fill||J};break;case"fillSketch":a=this.fillSketch(i,r)}a&&o.push(a)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||J,strokeWidth:r,fill:J}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class Dd{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new hn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,i=e.options.fixedDecimalPlaceDigits;for(const a of n)switch(a.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,a,i),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,a,i,s),o.restore();break}case"fillSketch":this.fillSketch(o,a,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const i of n.ops){const a=typeof r=="number"&&r>=0?i.data.map((s=>+s.toFixed(r))):i.data;switch(i.op){case"move":e.moveTo(a[0],a[1]);break;case"bcurveTo":e.bezierCurveTo(a[0],a[1],a[2],a[3],a[4],a[5]);break;case"lineTo":e.lineTo(a[0],a[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a),a}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a),a}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a),a}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i),i}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const Ke="http://www.w3.org/2000/svg";class Rd{constructor(e,n){this.svg=e,this.gen=new hn(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,i=o.createElementNS(Ke,"g"),a=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(Ke,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(Ke,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&i.appendChild(c)}return i}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const i=e.createElementNS(Ke,"path");return i.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),i.setAttribute("stroke",r.fill||""),i.setAttribute("stroke-width",o+""),i.setAttribute("fill","none"),r.fillLineDash&&i.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&i.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),i}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a)}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a)}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a)}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var oa={canvas:(t,e)=>new Dd(t,e),svg:(t,e)=>new Rd(t,e),generator:t=>new hn(t),newSeed:()=>hn.newSeed()};const Od="http://www.w3.org/2000/svg",Ao=1,ia="#000000",mn=3;let _=null;function Nd(){_||(_=document.createElementNS(Od,"svg"),_.setAttribute("data-manuscript","ui"),_.setAttribute("width","100%"),_.setAttribute("height","100%"),_.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(_))}function jr(){_==null||_.remove(),_=null}function aa(t,e,n,r){if(!_)return;for(;_.firstChild;)_.removeChild(_.firstChild);const o=oa.svg(_);Mo(p=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:Ao,...p}));const i=Math.atan2(r-e,n-t),a=14+mn*2,s=Math.PI/7,c=n-a*Math.cos(i-s),l=r-a*Math.sin(i-s),d=n-a*Math.cos(i+s),f=r-a*Math.sin(i+s),u=`M ${c} ${l} L ${n} ${r} L ${d} ${f}`;Mo(p=>o.path(u,{roughness:1.5,bowing:1,seed:Ao+1,...p}))}function Mo(t){_&&(_.appendChild(t({stroke:"#ffffff",strokeWidth:mn+4})),_.appendChild(t({stroke:ia,strokeWidth:mn})))}const Fd=8;let gn=!1,$o=null,he=!1,_t=0,Bt=0;function Hd(){$o||($o=it(({prev:t,next:e})=>{e==="arrow"?zd():t==="arrow"&&_d()}))}function zd(){gn||(gn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",sa,!0),document.addEventListener("mousemove",ca,!0),document.addEventListener("mouseup",la,!0),document.addEventListener("keydown",da,!0))}function _d(){gn&&(gn=!1,he=!1,document.body.style.cursor="",document.removeEventListener("mousedown",sa,!0),document.removeEventListener("mousemove",ca,!0),document.removeEventListener("mouseup",la,!0),document.removeEventListener("keydown",da,!0),jr())}function sa(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),he=!0,_t=t.clientX,Bt=t.clientY,Nd(),aa(_t,Bt,_t,Bt))}function ca(t){he&&(t.preventDefault(),aa(_t,Bt,t.clientX,t.clientY))}function la(t){if(!he)return;he=!1,jr();const e=t.clientX,n=t.clientY;if(Math.hypot(e-_t,n-Bt)<Fd){D("idle");return}t.preventDefault(),t.stopPropagation();const o=G(),i={kind:"arrow",id:Bd(),style:"excalidraw",from:{x:_t,y:Bt},to:{x:e,y:n},...o?{fromAnchorOffset:{x:_t-o.left,y:Bt-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:ia,strokeWidth:mn};Ne(i),D("idle")}function da(t){t.key==="Escape"&&(t.preventDefault(),he=!1,jr(),D("idle"))}function Bd(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Lo="http://www.w3.org/2000/svg",ua="#1a1a1a",pa=3,qd=2,jd=2;let bn=!1,To=null,me=!1,ft=[],ot=null,gt=null;function Wd(){To||(To=it(({prev:t,next:e})=>{e==="freedraw"?Ud():t==="freedraw"&&Xd()}))}function Ud(){bn||(bn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",fa,!0),document.addEventListener("mousemove",ha,!0),document.addEventListener("mouseup",ma,!0),document.addEventListener("keydown",ga,!0))}function Xd(){bn&&(bn=!1,me=!1,ft=[],document.body.style.cursor="",document.removeEventListener("mousedown",fa,!0),document.removeEventListener("mousemove",ha,!0),document.removeEventListener("mouseup",ma,!0),document.removeEventListener("keydown",ga,!0),Wr())}function fa(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),me=!0,ft=[{x:t.clientX,y:t.clientY}],Vd(),ba())}function ha(t){if(!me)return;t.preventDefault();const e=ft[ft.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<jd||(ft.push({x:t.clientX,y:t.clientY}),ba())}function ma(t){if(!me)return;if(me=!1,Wr(),ft.length<qd){ft=[],D("idle");return}t.preventDefault(),t.stopPropagation();const e=ft.slice(),n=G(),r={kind:"freedraw",id:Yd(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:ua,strokeWidth:pa};Ne(r),ft=[],D("idle")}function ga(t){t.key==="Escape"&&(t.preventDefault(),me=!1,ft=[],Wr(),D("idle"))}function Vd(){ot||(ot=document.createElementNS(Lo,"svg"),ot.setAttribute("data-manuscript","ui"),ot.setAttribute("width","100%"),ot.setAttribute("height","100%"),ot.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),gt=document.createElementNS(Lo,"polyline"),gt.setAttribute("fill","none"),gt.setAttribute("stroke",ua),gt.setAttribute("stroke-width",String(pa)),gt.setAttribute("stroke-linecap","round"),gt.setAttribute("stroke-linejoin","round"),ot.appendChild(gt),document.body.appendChild(ot))}function Wr(){ot==null||ot.remove(),ot=null,gt=null}function ba(){gt&&gt.setAttribute("points",ft.map(t=>`${t.x},${t.y}`).join(" "))}function Yd(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const ze="manuscript:element-selected";let vn=!1,nt=null,Co=null;function Gd(){Co||(Co=it(({prev:t,next:e})=>{e==="picker"?Kd():t==="picker"&&Zd()}))}function Kd(){vn||(vn=!0,document.addEventListener("mouseover",va,!0),document.addEventListener("mouseout",ya,!0),document.addEventListener("click",xa,!0),document.addEventListener("keydown",wa,!0))}function Zd(){vn&&(vn=!1,document.removeEventListener("mouseover",va,!0),document.removeEventListener("mouseout",ya,!0),document.removeEventListener("click",xa,!0),document.removeEventListener("keydown",wa,!0),ka())}function va(t){const e=t.target;!(e instanceof HTMLElement)||Sa(e)||Jd(e)}function ya(t){ka()}function xa(t){const e=t.target;if(!(e instanceof HTMLElement)||Sa(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=jc(e);if(!Wc(n,e)){Qd();return}const r=e.getBoundingClientRect(),o={chain:n,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};document.dispatchEvent(new CustomEvent(ze,{detail:o})),D("idle")}let lt=null,Ze=null;function Qd(){lt&&lt.remove(),lt=document.createElement("div"),lt.setAttribute("data-manuscript","ui"),lt.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),lt.textContent=b("toast.ambiguous-selector"),document.body.appendChild(lt),Ze!==null&&window.clearTimeout(Ze),Ze=window.setTimeout(()=>{lt==null||lt.remove(),lt=null,Ze=null},3500)}function wa(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function Jd(t){nt||(nt=document.createElement("div"),nt.setAttribute("data-manuscript","ui"),nt.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${O+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(nt));const e=t.getBoundingClientRect();nt.style.left=`${e.left}px`,nt.style.top=`${e.top}px`,nt.style.width=`${e.width}px`,nt.style.height=`${e.height}px`,nt.style.display="block"}function ka(){nt&&(nt.style.display="none")}function Sa(t){return t.closest('[data-manuscript="ui"]')!==null}const _e="http://www.w3.org/2000/svg";function Ur(t,e){let n;switch(t){case"rectangle":n=tu(e);break;case"ellipse":n=eu(e);break;case"triangle":n=Qe(ou(e),e);break;case"diamond":n=Qe(iu(e),e);break;case"star":n=Qe(au(e),e);break;case"callout":n=ru(su(e),e);break;case"line":n=nu(e);break;case"block-arrow":n=Qe(cu(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function tu(t){const e=document.createElementNS(_e,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),qn(e,t),e}function eu(t){const e=document.createElementNS(_e,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),qn(e,t),e}function nu(t){const e=document.createElementNS(_e,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function Qe(t,e){const n=document.createElementNS(_e,"polygon");return n.setAttribute("points",t),qn(n,e),n.setAttribute("stroke-linejoin","round"),n}function ru(t,e){const n=document.createElementNS(_e,"path");return n.setAttribute("d",t),qn(n,e),n.setAttribute("stroke-linejoin","round"),n}function qn(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function ou(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function iu(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function au(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,i=[];for(let a=0;a<10;a++){const s=Math.PI/5*a-Math.PI/2,c=a%2===0?r:o;i.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return i.join(" ")}function su(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,i=t.x+t.width*.5,a=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${i} ${r}`,`L ${a} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function cu(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const lu="http://www.w3.org/2000/svg",du="#ffffff",uu="#1a1a1a",pu=2;let V=null,bt=null;function Ea(t){return{fill:t==="line"?"transparent":du,stroke:uu,strokeWidth:pu}}function fu(){bt||(bt=document.createElement("div"),bt.setAttribute("data-manuscript","ui"),bt.textContent="Click and drag to draw a shape · Esc to cancel",bt.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${O+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(bt))}function Aa(){bt==null||bt.remove(),bt=null}function hu(){V||(V=document.createElementNS(lu,"svg"),V.setAttribute("data-manuscript","ui"),V.setAttribute("width","100%"),V.setAttribute("height","100%"),V.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+4}`,"overflow: visible"].join("; "),document.body.appendChild(V))}function Xr(){V==null||V.remove(),V=null}function Ma(t,e,n,r,o){if(!V)return;for(;V.firstChild;)V.removeChild(V.firstChild);const i=t==="line"?r-e:Math.abs(r-e),a=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=Ea(t),d=Ur(t,{x:s,y:c,width:i,height:a,...l});d&&V.appendChild(d)}const mu=6;let At="rectangle",yn=!1,Io=null,ge=!1,Mt=0,$t=0;function gu(t){At=t}function bu(){Io||(Io=it(({prev:t,next:e})=>{e==="shape"?vu():t==="shape"&&yu()}))}function vu(){yn||(yn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",$a,!0),document.addEventListener("mousemove",La,!0),document.addEventListener("mouseup",Ta,!0),document.addEventListener("keydown",Ca,!0),fu())}function yu(){yn&&(yn=!1,ge=!1,document.body.style.cursor="",document.removeEventListener("mousedown",$a,!0),document.removeEventListener("mousemove",La,!0),document.removeEventListener("mouseup",Ta,!0),document.removeEventListener("keydown",Ca,!0),Xr(),Aa())}function $a(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),ge=!0,Mt=t.clientX,$t=t.clientY,Aa(),hu(),Ma(At,Mt,$t,Mt,$t))}function La(t){ge&&(t.preventDefault(),Ma(At,Mt,$t,t.clientX,t.clientY))}function Ta(t){if(!ge)return;ge=!1,Xr();const e=t.clientX,n=t.clientY,r=At==="line"?e-Mt:Math.abs(e-Mt),o=At==="line"?n-$t:Math.abs(n-$t);if(Math.max(Math.abs(r),Math.abs(o))<mu){D("idle");return}t.preventDefault(),t.stopPropagation();const i=At==="line"?{x:Mt,y:$t,width:r,height:o}:{x:Math.min(Mt,e),y:Math.min($t,n),width:r,height:o},a=Ea(At),s=G(),c={kind:"shape",id:xu(),shapeKind:At,bounds:i,...s?{boundsAnchorOffset:{x:i.x-s.left,y:i.y-s.top}}:{},...a};Ne(c),D("idle")}function Ca(t){t.key==="Escape"&&(t.preventDefault(),ge=!1,Xr(),D("idle"))}function xu(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const wu={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},ku="Text";let xn=!1,Po=null;function Su(){Po||(Po=it(({prev:t,next:e})=>{e==="text"?Eu():t==="text"&&Au()}))}function Eu(){xn||(xn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Ia,!0),document.addEventListener("keydown",Pa,!0))}function Au(){xn&&(xn=!1,document.body.style.cursor="",document.removeEventListener("click",Ia,!0),document.removeEventListener("keydown",Pa,!0))}function Ia(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=G(),o={kind:"text",id:Mu(),text:ku,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...wu}};Ne(o),requestAnimationFrame(()=>{const i=document.querySelector(`[data-annotation-text="${o.id}"]`);i&&i.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),D("idle")}function Pa(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function Mu(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const $u="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",Lu="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",Do="Asta Sans",Tu="fonts/AstaSans-VariableFont_wght.ttf";let Ro=!1;function Cu(){Ro||(Ro=!0,Oo($u),Oo(Lu),Iu())}function Oo(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function Iu(){try{for(const t of document.fonts)if(t.family===Do)return}catch{}try{const t=chrome.runtime.getURL(Tu);new FontFace(Do,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const dt="manuscript";function jn(...t){}function cr(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function te(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function Da(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===dt&&typeof e.type=="string"}function Pu(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const i=o.data;if(Da(i)){if(jn("child received",i.type,"in",location.href),i.type==="set-mode"){D(i.mode),t=i.mode;return}if(i.type==="top-drag-start"){n=!0;return}if(i.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(ze,(o=>{const i=o.detail;te({source:dt,type:"element-selected",detail:i})})),it(({prev:o,next:i})=>{o==="picker"&&i==="idle"&&te({source:dt,type:"exit-picker"})}),te({source:dt,type:"frame-ready"}),document.addEventListener("mousedown",o=>{te({source:dt,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&te({source:dt,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&te({source:dt,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function Du(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const i=o.getBoundingClientRect();return{x:i.left,y:i.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function Ru(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Ou(){it(({next:t})=>{cr({source:dt,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>cr({source:dt,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>cr({source:dt,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(Da(e)){if(jn("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){Nu(t.source,e.detail);return}if(e.type==="exit-picker"){D("idle");return}if(e.type==="iframe-mousedown"){No("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";No(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){Fu(t.source);return}}})}function Nu(t,e){const n=Ru(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};jn("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(ze,{detail:o})),D("idle")}function No(t,e,n,r){const o=Du(e),i=n+o.x,a=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:i,clientY:a}))}function Fu(t){if(yt()==="picker")try{t==null||t.postMessage({source:dt,type:"set-mode",mode:"picker"},"*"),jn("top → late child: set-mode picker")}catch{}}function Hu(){if(typeof window>"u")return;window===window.top?Ou():Pu()}const zu="iframe-tool-overlay",Fo=new Set(["text","shape","freedraw"]);let ce=[],lr=!1,ne=null;function _u(){typeof window>"u"||window===window.top&&(it(({next:t})=>{Fo.has(t)?Ho():Ra()}),Fo.has(yt())&&Ho())}function Ho(){Ra(),zo(),window.addEventListener("scroll",wn,!0),window.addEventListener("resize",wn),ne=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&zo()}),ne.observe(document.body,{childList:!0,subtree:!0})}function Ra(){ce.forEach(t=>t.remove()),ce=[],window.removeEventListener("scroll",wn,!0),window.removeEventListener("resize",wn),ne==null||ne.disconnect(),ne=null}function zo(){ce.forEach(e=>e.remove()),ce=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",zu),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${O+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),ce.push(n),Oa(n,e)})}const Je=8;function Oa(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-Je}px`,t.style.top=`${n.top-Je}px`,t.style.width=`${n.width+Je*2}px`,t.style.height=`${n.height+Je*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function wn(){lr||(lr=!0,requestAnimationFrame(()=>{lr=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=ce[e];r&&Oa(r,n),e++})}))}let Pt=!1;function Wn(){return Pt}async function Bu(){try{if(typeof(await chrome.storage.local.get(X.prompterWindowId))[X.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(Pt=!0)}catch{}}async function Na(){if(Pt){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}Pt=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(Pt=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Fa(){if(Pt){Pt=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function Ha(t){try{await chrome.storage.local.set({[X.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function qu(){Pt=!1}const ju="modulepreload",Wu=function(t){return"/"+t},_o={},Uu=function(e,n,r){let o=Promise.resolve();if(n&&n.length>0){let a=function(l){return Promise.all(l.map(d=>Promise.resolve(d).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const s=document.querySelector("meta[property=csp-nonce]"),c=(s==null?void 0:s.nonce)||(s==null?void 0:s.getAttribute("nonce"));o=a(n.map(l=>{if(l=Wu(l),l in _o)return;_o[l]=!0;const d=l.endsWith(".css"),f=d?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const u=document.createElement("link");if(u.rel=d?"stylesheet":ju,d||(u.as="script"),u.crossOrigin="",u.href=l,c&&u.setAttribute("nonce",c),document.head.appendChild(u),d)return new Promise((p,h)=>{u.addEventListener("load",p),u.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(a){const s=new Event("vite:preloadError",{cancelable:!0});if(s.payload=a,window.dispatchEvent(s),!s.defaultPrevented)throw a}return o.then(a=>{for(const s of a||[])s.status==="rejected"&&i(s.reason);return e().catch(i)})},Et="http://www.w3.org/2000/svg",Bo="manuscript-spotlight-mask",Xu="oklch(0.42 0.09 250)",Vu=3,Yu="rgb(0, 0, 0)",Gu=.55,Ee=14;let le=null,Z=null,pt=null,Y=null,H=null,wt=null,wr=[],re=null;function za(t){le=t,Z||Zu(),qo(),De(),Ku(t),re||(re=ye(qo))}function be(){le=null,_a(),re==null||re(),re=null,Z&&(Z.remove(),Z=null,pt=null,Y=null,H=null,wt=null)}function Ku(t){var n;_a();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=De;r.addEventListener("scroll",o,!0),wr.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",De)}function _a(){for(const t of wr)t.remove();wr=[],window.removeEventListener("resize",De)}function Zu(){Z=document.createElementNS(Et,"svg"),Z.setAttribute("data-manuscript","ui"),Z.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O}`].join("; "),Z.setAttribute("width","100%"),Z.setAttribute("height","100%");const t=document.createElementNS(Et,"defs"),e=document.createElementNS(Et,"mask");e.setAttribute("id",Bo);const n=document.createElementNS(Et,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),pt=document.createElementNS(Et,"rect"),pt.setAttribute("fill","black"),pt.setAttribute("rx","4"),pt.setAttribute("ry","4"),e.appendChild(pt),t.appendChild(e),Z.appendChild(t),wt=document.createElementNS(Et,"rect"),wt.setAttribute("width","100%"),wt.setAttribute("height","100%"),wt.setAttribute("mask",`url(#${Bo})`),Z.appendChild(wt),Y=document.createElementNS(Et,"rect"),Y.setAttribute("fill","none"),Y.setAttribute("rx","4"),Y.setAttribute("ry","4"),Y.style.pointerEvents="none",Z.appendChild(Y),H=document.createElementNS(Et,"rect"),H.setAttribute("fill","none"),H.setAttribute("stroke","transparent"),H.setAttribute("stroke-width",String(Ee)),H.setAttribute("rx","4"),H.setAttribute("ry","4"),H.setAttribute("pointer-events","stroke"),H.style.cursor="pointer",H.addEventListener("click",Qu),Z.appendChild(H),document.body.appendChild(Z)}function qo(){var i;if(!Y||!wt)return;const t=((i=at())==null?void 0:i.spotlight)??{},e=t.stroke??Xu,n=t.strokeWidth??Vu,r=t.dimColor??Yu,o=t.dimOpacity??Gu;Y.setAttribute("stroke",e),Y.setAttribute("stroke-width",String(n)),wt.setAttribute("fill",r),wt.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),De()}function Qu(t){yt()!=="replay"&&(!le||!H||(t.stopPropagation(),t.preventDefault(),Uu(()=>import("./chunk-qlGH_CZ3.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{H&&e.openSpotlightEditor(H)})))}function De(){if(!le||!pt||!Y||!H)return;const t=le.getBoundingClientRect(),e=Ju(le),n=4,r=t.left+e.x-n,o=t.top+e.y-n,i=t.width+n*2,a=t.height+n*2;pt.setAttribute("x",String(r)),pt.setAttribute("y",String(o)),pt.setAttribute("width",String(i)),pt.setAttribute("height",String(a));const s=Math.max(0,Number(Y.getAttribute("stroke-width")??0)),c=r-s/2,l=o-s/2,d=i+s,f=a+s;Y.setAttribute("x",String(c)),Y.setAttribute("y",String(l)),Y.setAttribute("width",String(d)),Y.setAttribute("height",String(f));const u=c-Ee/2,p=l-Ee/2,h=d+Ee,g=f+Ee;H.setAttribute("x",String(u)),H.setAttribute("y",String(p)),H.setAttribute("width",String(h)),H.setAttribute("height",String(g))}function Ju(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const jo="data-wp-animations";function tp(){if(document.head.querySelector(`[${jo}]`))return;const t=document.createElement("style");t.setAttribute(jo,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function Re(t,e,n){if(!e||e.kind==="none"||yt()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const i=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",i),t.removeEventListener("animationcancel",i)};t.addEventListener("animationend",i),t.addEventListener("animationcancel",i)}const kn="http://www.w3.org/2000/svg",Ba="data-annotation-text",Wo="data-annotation-arrow",qa="data-annotation-shape",Uo="data-annotation-freedraw",L={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function ep(t,e){const{svg:n,roughSvg:r}=L;if(!n||!r)return;const o=rp(t.id),{from:i,to:a}=Vc(t,e);ja(t,s=>r.line(i.x,i.y,a.x,a.y,{roughness:1.5,bowing:1,seed:o,...s})),np(t,i,a,o+1)}function np(t,e,n,r){const{roughSvg:o}=L;if(!o)return;const i=Math.atan2(n.y-e.y,n.x-e.x),a=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-a*Math.cos(i-s),l=n.y-a*Math.sin(i-s),d=n.x-a*Math.cos(i+s),f=n.y-a*Math.sin(i+s),u=`M ${c} ${l} L ${n.x} ${n.y} L ${d} ${f}`;ja(t,p=>o.path(u,{roughness:1.5,bowing:1,seed:r,...p}))}function ja(t,e){const{svg:n}=L;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(Wo,t.id),Re(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(Wo,t.id),Re(o,t.entryAnimation,0),n.appendChild(o)}function rp(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const $={state:null,unsubscribeStep:null};function ut(){return $.state!==null}function Be(){var t;return((t=$.state)==null?void 0:t.standalone)===!0}function op(t,e){const{svg:n}=L;if(!n)return;const r=Fn(t,e),o=ip(t,r),i=r.map(c=>`${c.x},${c.y}`).join(" "),a=document.createElementNS(kn,"polyline");if(a.setAttribute("points",i),a.setAttribute("fill","none"),a.setAttribute("stroke",t.stroke),a.setAttribute("stroke-width",String(t.strokeWidth)),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute(Uo,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&a.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&a.setAttribute("transform",o),a.style.pointerEvents="none",Re(a,t.entryAnimation,t.rotate??0),n.appendChild(a),Be())return;const s=document.createElementNS(kn,"polyline");s.setAttribute(Uo,t.id),s.setAttribute("points",i),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),ap(t.id,c,s))}),n.appendChild(s)}function ip(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,i=-1/0,a=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>i&&(i=l.x),l.y>a&&(a=l.y);const s=(r+i)/2,c=(o+a)/2;return`rotate(${n} ${s} ${c})`}function ap(t,e,n){const r=T(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},i=G(),a=Fn(r,i).map(d=>({...d}));let s=!1;const c=d=>{const f=d.clientX-o.x,u=d.clientY-o.y;if(!s&&Math.hypot(f,u)<3)return;s=!0,d.preventDefault();const p=a.map(g=>({x:g.x+f,y:g.y+u})),h=i?{points:p,pointsAnchorOffset:p.map(g=>({x:g.x-i.left,y:g.y-i.top}))}:{points:p,pointsAnchorOffset:void 0};C(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const d=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),f=d[d.length-1]??n;od(t,f)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function sp(t,e){const{svg:n}=L;if(!n)return;const r=Nn(t,e),o=Ur(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(qa,t.id),o.style.pointerEvents="none",Re(o,t.entryAnimation,t.rotate??0),n.appendChild(o),Be()||n.appendChild(cp(t,r)))}function cp(t,e){const n=document.createElementNS(kn,"rect");if(n.setAttribute(qa,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>lp(t.id,r,n)),n}function lp(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=T(t);if(!o||o.kind!=="shape")return;const i=G(),a=o.boundsAnchorOffset&&i?{x:i.left+o.boundsAnchorOffset.x,y:i.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:a.x,y:a.y};let c=!1;const l=f=>{const u=f.clientX-r.x,p=f.clientY-r.y;if(!c&&Math.hypot(u,p)<3)return;c=!0,f.preventDefault();const h=s.x+u,g=s.y+p,v=i?{bounds:{...s,x:h,y:g},boundsAnchorOffset:{x:h-i.left,y:g-i.top}}:{bounds:{...s,x:h,y:g},boundsAnchorOffset:void 0};C(t,v)},d=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const f=document.querySelectorAll(`[data-annotation-shape="${t}"]`),u=f[f.length-1]??n;rd(t,u)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)}function dp(t,e){const{host:n}=L;if(!n)return;const r=document.createElement("div");r.setAttribute(Ba,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,i=t.style.backgroundColor??"#ffffff",a=t.style.backgroundOpacity??.96,s=i==="transparent"?"transparent":up(i,a),c=t.rotate??0,l=t.style.borderColor??"#000000",d=l==="transparent"?"none":`2px solid ${l}`,f=Xc(t,e),u=Be();r.style.cssText=["position: absolute",`left: ${f.x}px`,`top: ${f.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${d}`,"border-radius: 8px",u?"pointer-events: none":"pointer-events: auto",u?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,u||pp(r,t.id),Re(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function up(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,i=0,a=0;return r.length===4?(o=parseInt(r[1]+r[1],16),i=parseInt(r[2]+r[2],16),a=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),i=parseInt(r.slice(3,5),16),a=parseInt(r.slice(5,7),16)),`rgba(${o}, ${i}, ${a}, ${n})`}return t}function pp(t,e){let n=!1,r=0,o=0,i=0,a=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();i=l.left,a=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,d=c.clientY-o;Math.abs(l)+Math.abs(d)>2&&(s=!0),t.style.left=`${i+l}px`,t.style.top=`${a+d}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),d=G(),f=d?{position:{x:c,y:l},anchorOffset:{x:c-d.left,y:l-d.top}}:{position:{x:c,y:l},anchorOffset:void 0};C(e,f)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),nd(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),fp(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",C(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function fp(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function Wa(){if(L.host)return;tp();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${O+3}`].join("; ");const e=document.createElementNS(kn,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),L.host=t,L.svg=e,L.roughSvg=oa.svg(e),document.body.appendChild(t),L.unsubscribe=ye(an),L.unsubscribeMode=it(an),hp(),an()}let de=null;function Te(){de===null&&(de=requestAnimationFrame(()=>{de=null,an()}))}let qt=null,kr=null;function hp(){window.addEventListener("resize",Te),window.addEventListener("scroll",Te,!0),typeof ResizeObserver<"u"&&(qt=new ResizeObserver(Te))}function mp(){window.removeEventListener("resize",Te),window.removeEventListener("scroll",Te,!0),qt&&(qt.disconnect(),qt=null),kr=null,de!==null&&(cancelAnimationFrame(de),de=null)}function Ua(){var t,e;(t=L.unsubscribe)==null||t.call(L),L.unsubscribe=null,(e=L.unsubscribeMode)==null||e.call(L),L.unsubscribeMode=null,mp(),L.host&&(L.host.remove(),L.host=null,L.svg=null,L.roughSvg=null)}function gp(){return L.host!==null}function an(){const{host:t,svg:e}=L;if(!t||!e)return;for(t.querySelectorAll(`[${Ba}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=G();if(qt){let o=null;try{o=bp()}catch{o=null}o!==kr&&(qt.disconnect(),o&&qt.observe(o),kr=o)}const r=$i();for(const o of r)o.kind==="text"?dp(o,n):o.kind==="arrow"?ep(o,n):o.kind==="shape"?sp(o,n):o.kind==="freedraw"&&op(o,n)}function bp(){const t=at();if(!(t!=null&&t.selectors))return null;try{return Pe(t.selectors)}catch{return null}}const S={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function oe(t,e,n){return Math.max(e,Math.min(n,t))}function Xa(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=wp()),vp()}function vp(){const{host:t}=S;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),i=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${oe(o,0,n)}px`),Number.isFinite(i)&&(t.style.top=`${oe(i,0,r)}px`)}async function yp(){try{return(await chrome.storage.local.get(X.replayControlsOrientation))[X.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function xp(t){try{await chrome.storage.local.set({[X.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function wp(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function kp(){try{const e=(await chrome.storage.local.get(X.replayControlsPosition))[X.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function Xo(t){try{await chrome.storage.local.set({[X.replayControlsPosition]:t})}catch{}}function Sp(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function Ep(){const{host:t,shadow:e}=S;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,i=0,a=0,s=0;const c=u=>{if(!S.host)return;u.preventDefault(),u.stopPropagation(),r=!0,n.classList.add("dragging");const p=S.host.getBoundingClientRect();S.host.style.left=`${p.left}px`,S.host.style.top=`${p.top}px`,S.host.style.bottom="auto",S.host.style.transform="none",o=u.clientX,i=u.clientY,a=p.left,s=p.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",d,!0)},l=u=>{if(!r||!S.host)return;const p=S.host.getBoundingClientRect(),h=u.clientX-o,g=u.clientY-i,v=oe(a+h,0,window.innerWidth-p.width),x=oe(s+g,0,window.innerHeight-p.height);S.host.style.left=`${v}px`,S.host.style.top=`${x}px`},d=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0);const u=S.host;if(u){const p=parseFloat(u.style.left||"0"),h=parseFloat(u.style.top||"0");Number.isFinite(p)&&Number.isFinite(h)&&Xo({left:p,top:h})}},f=()=>{if(S.host&&S.host.style.transform==="none"){const u=S.host.getBoundingClientRect(),p=oe(u.left,0,window.innerWidth-u.width),h=oe(u.top,0,window.innerHeight-u.height);S.host.style.left=`${p}px`,S.host.style.top=`${h}px`,Xo({left:p,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",f),S.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",f),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",d,!0)}}function Va(){return`
    ${kt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function Ya(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Ap(t){return Ya(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Mp(t,e){const{shadow:n}=S;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,i)=>{const a=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${i===e?" active":""}" role="option" data-action="step-jump" data-index="${i}" aria-selected="${i===e}" title="${Ap(a)}">${i+1}. ${Ya(a)}</li>`}).join(""))}function $p(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function Sr(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function Ga(t){const{host:e,shadow:n}=S;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||Sr()}let sn=-1,cn=!1;function Lp(){sn=-1,cn=!1}function Tp(t,e,n){const{shadow:r}=S;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",sn=-1,cn=!1;return}o.classList.remove("hidden");const s=t!==sn||cn&&!n;sn=t,cn=n;let c=o.querySelector(".progress-fill");(!c||s)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function Cp(){return`
    ${kt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid color-mix(in oklch, currentColor, transparent 40%);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: color-mix(in oklch, currentColor, transparent 92%); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: color-mix(in oklch, currentColor, transparent 85%); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: color-mix(in oklch, currentColor, transparent 80%);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: color-mix(in oklch, currentColor, transparent 82%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: color-mix(in oklch, currentColor, transparent 45%);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: color-mix(in oklch, currentColor, transparent 25%);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: color-mix(in oklch, currentColor, transparent 92%); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function Ip(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function Pp(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function Dp(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?Ip(14):Pp(14))}function Un(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),Rt(t);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}let Ka=!1;function Rp(t){if(S.host)return;const{host:e,shadow:n}=Un();S.host=e,S.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${O+6}`,"pointer-events: auto",Ka?"display: none":""].filter(Boolean).join("; "),n.innerHTML=`<style>${Cp()}</style>${Op()}`,n.addEventListener("click",r=>Np(r,t)),document.body.appendChild(e),Ep(),document.addEventListener("mousedown",Ga,!0),S.orientationApplied=!1,yp().then(r=>{S.orientationApplied||(S.orientationApplied=!0,Xa(r))}),kp().then(r=>{S.host&&r&&S.host.style.transform!=="none"&&Sp(S.host,r)})}function Op(){return`
    <div class="bar" role="toolbar" aria-label="${b("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${b("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${b("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${b("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${b("replay.prompter-aria")}" title="${b("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${b("replay.tts-aria")}" title="${b("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${b("replay.move-aria")}" title="${b("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${b("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${b("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Np(t,e){var i;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){$p();return}const r=n.closest('[data-action="step-jump"]');if(r){const a=Number(r.getAttribute("data-index"));Number.isFinite(a)&&(Sr(),e.onStepSelect(a));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(i=n.closest("[data-action]"))==null?void 0:i.getAttribute("data-action");switch(o&&Sr(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Fp();break}}function Fp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";S.orientationApplied=!0,Xa(n),xp(n)}function dr(t){Ka=t;const{host:e}=S;e&&(e.dataset.recordingHidden=t?"1":"",e.style.display=t?"none":"")}function Hp(){var t,e;(t=S.cleanupDrag)==null||t.call(S),S.cleanupDrag=null,document.removeEventListener("mousedown",Ga,!0),(e=S.host)==null||e.remove(),S.host=null,S.shadow=null,S.orientationApplied=!1,Lp()}function Vo(t){const{shadow:e}=S;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const i=e.querySelector('[data-action="prev"]');i&&i.toggleAttribute("disabled",t.currentIndex<=0);const a=e.querySelector('[data-action="next"]');a&&(a.toggleAttribute("disabled",!1),a.setAttribute("aria-label",t.currentIndex>=t.total-1?b("replay.finish-aria"):b("replay.next-aria"))),Tp(t.currentIndex,t.timerDurationMs??null,t.paused),Mp(t.steps??[],t.currentIndex),Dp(t.ttsEnabled===!0)}let Lt=null;function zp(t){qe();const{host:e,shadow:n}=Un();Lt=e,Lt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${Va()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${b("replay.notfound.title")}</h2>
          <p>${b("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${b("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${b("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const i=o.target;if(!(i instanceof HTMLElement))return;const a=(s=i.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");a==="skip"?t.onSkip():a==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),Lt.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(Lt)}function qe(){if(!Lt)return;const t=Lt.__cleanup;t==null||t(),Lt.remove(),Lt=null}let Tt=null;function _p(t){Sn();const{host:e,shadow:n}=Un();Tt=e,Tt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${O+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${Va()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${b("replay.url-mismatch.title")}</h2>
          <p>${b("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${b("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${b("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${b("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",i=>{var c;const a=i.target;if(!(a instanceof HTMLElement))return;const s=(c=a.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=i=>{i.key==="Escape"?(i.preventDefault(),t.onCancel()):i.key==="Enter"&&(i.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),Tt.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(Tt)}function Sn(){if(!Tt)return;const t=Tt.__cleanup;t==null||t(),Tt.remove(),Tt=null}let Ht=null;function Bp(t){je();const e=t.getBoundingClientRect(),n=qp(t),r=e.left+n.x,o=e.top+n.y,i=e.bottom+n.y,a=36,s=8,c=o-s-a<8,l=c?Math.min(window.innerHeight-8-a,i+s):Math.max(8,o-s-a),d=Math.max(8,Math.min(r,window.innerWidth-200)),f=c?"up":"down",{host:u,shadow:p}=Un();Ht=u,Ht.style.cssText=["position: fixed",`top: ${l}px`,`left: ${d}px`,`z-index: ${O+6}`,"pointer-events: none"].join("; "),p.innerHTML=`
    <style>
      ${kt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${b("prompter.action-step")}</span>
      <span>${b("replay.action-prompt")}</span>
      <span class="tip ${f}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Ht)}function je(){Ht==null||Ht.remove(),Ht=null}function qp(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let ue=null;function jp(t){ue||(ue=e=>{if($.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",ue,!0))}function Wp(){ue&&(document.removeEventListener("keydown",ue,!0),ue=null)}function Za(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function Up(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function Xp(t,e){var r,o,i;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||Za(n,location.href)||((o=$.state)==null?void 0:o.standalone)===!0)return!1;try{await Tr({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((i=$.state)==null?void 0:i.paused)??!1})}catch(a){console.warn("[manuscript] persist activeReplay before nav failed",a)}return location.href=n,!0}function Vp(t){return new Promise(e=>{_p({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{Sn(),e("force")},onCancel:()=>{Sn(),e("cancel")}})})}async function Yp(t){try{const e=await di();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Vr(){const t=I();if(!(!t||!$.state)&&$.state.standalone!==!0)try{await Tr({scenarioId:t.id,stepIndex:U(),startedAt:Date.now(),paused:$.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function Qa(t,e,n){const r=I();if(!r)return{ok:!1};if(n&&await Yp(r.id))return{ok:!0};const o=Up(r);if(!o||Za(o,location.href))return{ok:!0};const i=await Vp(o);return i==="cancel"?{ok:!1}:i==="navigate"?(await Tr({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class Ja extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function Gp(t,e=As){const n=Pe(t);return n?Promise.resolve(n):new Promise((r,o)=>{let i=!1;const s=(Ni(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(i)return;const d=Pe(t);d&&(i=!0,c.disconnect(),clearTimeout(l),r(d))}),l=setTimeout(()=>{i||(i=!0,c.disconnect(),o(new Ja(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function xe(){const{state:t}=$;if(!t)return;const e=I();if(!e)return;const n=e.steps[U()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(pi().then(o=>{Vo({currentIndex:U(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:o})}),Vo({currentIndex:U(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),Wn()){const o=U(),i=e.steps[o],a=e.steps[o+1];Ha({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(s=>({name:s.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:a?{name:a.name,description:a.description,autoAdvanceMs:a.autoAdvanceMs??null,waitForNavigation:a.waitForNavigation,thumbnailDataUrl:a.thumbnailDataUrl??null}:null})}}async function Kp(){if(Wn()){await Fa(),En(!1);return}En(!0),await Na(),xe()}function Zp(){En(!1)}function En(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function Xn(t){var i;const{state:e}=$;if(!e)return;const n=I();if(!n)return;const r=n.steps[U()];if(xe(),!r)return;if(qe(),je(),Ps()&&!e.paused&&Ds(r.description),!r.selectors){be(),r.waitForNavigation||Yo(t);return}const o=new AbortController;e.pendingWait=o;try{const a=await Gp(r.selectors);if(o.signal.aborted)return;a.scrollIntoView({block:"center"}),za(a),r.waitForNavigation?(Bp(a),Qp(a,o,t.onNext)):Yo(t)}catch(a){if(o.signal.aborted)return;if(a instanceof Ja){be(),zp({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",a)}finally{((i=$.state)==null?void 0:i.pendingWait)===o&&($.state.pendingWait=null)}}function Qp(t,e,n){if(!$.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!$.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function Yo(t){var a;const{state:e}=$;if(!e||e.paused)return;const n=I();if(!n)return;const r=U(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(a=e.autoAdvanceAbort)==null||a.abort();const i=new AbortController;e.autoAdvanceAbort=i,(async()=>{const s=[],c=Rs();c&&s.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&s.push(new Promise(l=>{const d=window.setTimeout(()=>{$.state&&$.state.autoAdvanceTimer===d&&($.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);$.state&&($.state.autoAdvanceTimer=d),i.signal.addEventListener("abort",()=>{window.clearTimeout(d),l()})})),s.length!==0&&(await Promise.race([Promise.all(s).then(()=>{}),new Promise(l=>{i.signal.aborted?l():i.signal.addEventListener("abort",()=>l(),{once:!0})})]),!i.signal.aborted&&(!$.state||$.state.paused||U()===r&&t.onNext()))})()}function Vn(){var e,n;const{state:t}=$;t&&(t.autoAdvanceTimer!==null&&(window.clearTimeout(t.autoAdvanceTimer),t.autoAdvanceTimer=null),(e=t.autoAdvanceAbort)==null||e.abort(),t.autoAdvanceAbort=null,(n=t.pendingWait)==null||n.abort(),t.pendingWait=null,fi())}const Yn={onNext:()=>void Oe(),onExit:()=>void ve()};async function we(t=0,e={}){if($.state)return;const n=I();if(!n||n.steps.length===0||e.standalone!==!0&&!(await Qa(n.id,t,!0)).ok)return;$.state={originalStepIndex:U(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,standalone:e.standalone===!0},D("replay"),Rp({onPrev:An,onNext:Oe,onTogglePause:Mn,onExit:ve,onStepSelect:o=>void Gr(o),onTogglePrompter:()=>void Kp(),onToggleTts:()=>void Jp()}),Wn()&&En(!0),jp({onNext:()=>void Oe(),onPrev:()=>void An(),onTogglePause:Mn,onExit:()=>void ve()}),$.unsubscribeStep=ye(xe);const r=Math.min(Math.max(0,t),n.steps.length-1);Gt(r),await Vr(),await Xn(Yn)}async function Yr(t){if(!$.state)return;const e=I();e&&(t<0||t>=e.steps.length||(Vn(),qe(),je(),!await Xp(e,t)&&(Gt(t),await Vr(),await Xn(Yn))))}async function Gr(t){t!==U()&&await Yr(t)}async function Oe(){const{state:t}=$;if(!t)return;const e=I();if(!e)return;const n=U();if(n>=e.steps.length-1){Vn(),qe(),je(),t.paused=!0,xe(),document.dispatchEvent(new CustomEvent("manuscript:replay-end"));return}await Yr(n+1)}async function An(){await Yr(U()-1)}async function Jp(){const t=!await pi();await Os(t),t||fi(),xe()}function Mn(){const{state:t}=$;if(!t)return;const e=I();if(e&&t.paused&&U()>=e.steps.length-1){tf();return}t.paused=!t.paused,t.paused?Vn():Xn(Yn),xe()}async function tf(){if(!$.state)return;const t=I();!t||!(await Qa(t.id,0,!1)).ok||$.state&&($.state.paused=!1,Gt(0),await Vr(),await Xn(Yn))}async function ve(){var r;const{state:t}=$;if(!t)return;Vn(),qe(),je(),Sn(),be(),Hp(),Fa(),Wp(),(r=$.unsubscribeStep)==null||r.call($),$.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;$.state=null,Gt(e),D("idle"),await Ls(),n&&(Ua(),Ai())}const ef=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],xt=28,tn=4,nf="http://www.w3.org/2000/svg";let j=null,Vt=null,Ce=null;function rf(t,e){Gn(),Ce=e,j=document.createElement("div"),j.setAttribute("data-manuscript","ui"),Rt(j),j.style.cssText=["position: fixed",`z-index: ${O+5}`,"pointer-events: auto"].join("; "),Vt=j.attachShadow({mode:"open"}),Vt.innerHTML=of(),sf(),document.body.appendChild(j),Go(t),af(),requestAnimationFrame(()=>{j&&Go(t)}),document.addEventListener("mousedown",ts,!0),document.addEventListener("keydown",es,!0)}function Gn(){j&&(document.removeEventListener("mousedown",ts,!0),document.removeEventListener("keydown",es,!0),j.remove(),j=null,Vt=null,Ce=null)}function of(){return`
    <style>
      ${kt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${xt+tn*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${xt+tn*2}px;
        height: ${xt+tn*2}px;
        padding: ${tn}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function af(){if(!Vt)return;const t=Vt.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of ef){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(nf,"svg");o.setAttribute("width",String(xt)),o.setAttribute("height",String(xt)),o.setAttribute("viewBox",`0 0 ${xt} ${xt}`);const i=Ur(e,{x:3,y:3,width:xt-6,height:xt-6,fill:"transparent",stroke:"oklch(0.18 0.015 250)",strokeWidth:1.5});i&&o.appendChild(i),r.appendChild(o),t.appendChild(r)}}}function sf(){Vt&&Vt.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(Ce==null||Ce(r),Gn())})}function Go(t){if(!j)return;const e=t.getBoundingClientRect();j.style.top="0px",j.style.left="0px";const n=j.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),j.style.top=`${Math.max(8,r)}px`,j.style.left=`${Math.max(8,o)}px`}function ts(t){if(!j)return;const e=t.target;e instanceof Node&&j.contains(e)||Gn()}function es(t){t.key==="Escape"&&(t.preventDefault(),Gn())}const cf=320,pe=32,lf=.8,$n=200,k={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null};function Ln(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function rt(t){return Ln(t)}function Yt(t,e=!1,n=5e3){const{shadow:r}=k;if(!r)return;const o=r.querySelector('[data-region="toast"]');o&&(o.textContent=t,o.classList.add("visible"),o.classList.toggle("error",e),k.toastTimer!==null&&window.clearTimeout(k.toastTimer),k.toastTimer=window.setTimeout(()=>{o.classList.remove("visible"),k.toastTimer=null},n))}function Tn(t,e,n){return Math.max(e,Math.min(n,t))}let R=null;function df(t){if(R!==null)return;const e=t.from??3,n=t.tickMs??1e3,r=t.scheduler??pf(),o=document.createElement("div");o.setAttribute("data-manuscript","ui"),o.setAttribute("data-region","countdown"),o.style.cssText=["position: fixed","inset: 0",`z-index: ${O+10}`,"pointer-events: auto"].join("; "),Rt(o);const i=o.attachShadow({mode:"open"});i.innerHTML=ff(e),document.body.appendChild(o);const a=i.querySelector('[data-region="number"]'),s=i.querySelector('[data-action="cancel"]'),c=l=>{(l.key==="Escape"||l.key===" "||l.key==="Spacebar")&&(l.preventDefault(),Ko())};window.addEventListener("keydown",c),s==null||s.addEventListener("click",()=>Ko()),R={host:o,shadow:i,numberEl:a,scheduler:r,tickMs:n,timerId:null,remaining:e,onComplete:t.onComplete,onCancel:t.onCancel??null,keyListener:c},ns()}function Kr(){R&&(R.timerId!==null&&R.scheduler.cancel(R.timerId),window.removeEventListener("keydown",R.keyListener),R.host.remove(),R=null)}function ns(){R&&(R.timerId=R.scheduler.schedule(uf,R.tickMs))}function uf(){if(R){if(R.remaining-=1,R.remaining<=0){const t=R.onComplete;Kr(),t();return}R.numberEl.textContent=String(R.remaining),ns()}}function Ko(){if(!R)return;const t=R.onCancel;Kr(),t==null||t()}function pf(){return{schedule(t,e){return window.setTimeout(t,e)},cancel(t){window.clearTimeout(t)}}}function ff(t){return`
    <style>
      :host { display: block; font-family: var(--ff-sans, system-ui, sans-serif); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .ring {
        width: 220px;
        height: 220px;
        border-radius: 999px;
        background: var(--c-surface, #fff);
        color: var(--c-text, #0a0a0a);
        box-shadow: 0 24px 60px rgb(0 0 0 / 0.35), 0 4px 12px rgb(0 0 0 / 0.20);
        display: grid;
        place-items: center;
        position: relative;
        animation: ring-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes ring-pop {
        from { transform: scale(0.85); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .number {
        font-size: 140px;
        font-weight: 700;
        line-height: 1;
        letter-spacing: -0.02em;
        font-variant-numeric: tabular-nums;
        animation: digit-pop 200ms ease-out;
      }
      .number[data-changed] { animation: digit-pop 200ms ease-out; }
      @keyframes digit-pop {
        from { transform: scale(1.25); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .caption {
        position: absolute;
        bottom: -52px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 13px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.92);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint {
        position: absolute;
        bottom: -78px;
        left: 50%;
        transform: translateX(-50%);
        font-size: 11px;
        font-weight: 500;
        color: rgb(255 255 255 / 0.62);
        letter-spacing: 0.02em;
        white-space: nowrap;
      }
      .hint kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid rgb(255 255 255 / 0.35);
        border-radius: 4px;
        font-family: ui-monospace, monospace;
        font-size: 10px;
        margin: 0 2px;
      }
      .cancel {
        appearance: none;
        background: rgb(255 255 255 / 0.10);
        color: rgb(255 255 255 / 0.92);
        border: 1px solid rgb(255 255 255 / 0.25);
        border-radius: 999px;
        padding: 6px 14px;
        font-family: inherit;
        font-size: 12px;
        font-weight: 600;
        letter-spacing: 0.02em;
        cursor: pointer;
        position: absolute;
        bottom: -120px;
        left: 50%;
        transform: translateX(-50%);
        transition: background 120ms ease, border-color 120ms ease;
      }
      .cancel:hover { background: rgb(255 255 255 / 0.20); border-color: rgb(255 255 255 / 0.45); }
    </style>
    <div class="scrim" role="dialog" aria-label="Recording starts soon">
      <div class="ring">
        <span class="number" data-region="number">${t}</span>
        <span class="caption">Recording starts in…</span>
        <span class="hint">Press <kbd>Space</kbd> or <kbd>Esc</kbd> to stop</span>
        <button type="button" class="cancel" data-action="cancel">Cancel</button>
      </div>
    </div>
  `}function hf(t,e=n=>MediaRecorder.isTypeSupported(n)){for(const n of t)if(e(n))return n;throw new Error(`No supported MIME type for screen recording (tried: ${t.join(", ")})`)}function mf(t,e){const{factory:n,mimeType:r,timesliceMs:o}=e,i=n.create(t,{mimeType:r}),a=[];let s=!1,c=null;i.ondataavailable=f=>{f.data&&f.data.size>0&&a.push(f.data)};function l(){if(s)throw new Error("Recorder handle is single-use; create a new one.");s=!0,o!==void 0?i.start(o):i.start()}function d(){return c?Promise.reject(new Error("stop() already called")):(c=new Promise((f,u)=>{i.onstop=()=>{const p=new Blob(a,{type:r});f({blob:p,size:p.size,mimeType:r})},i.onerror=p=>{const h=p.error;u(new Error((h==null?void 0:h.message)??"MediaRecorder error"))},i.stop()}),c)}return{start:l,stop:d}}function gf(t){let e="idle";function n(){var o;e==="idle"&&(t.isStandalonePlayback()||(e="counting-down",(o=t.onRecordingStarting)==null||o.call(t),t.mountCountdown({onComplete:()=>{var i;e="recording",(i=t.onRecordingStarted)==null||i.call(t),t.sendMessage({type:"recording.fire"}).catch(()=>{var a;e="idle",(a=t.onRecordingStopped)==null||a.call(t)})},onCancel:()=>{var i;e="idle",(i=t.onRecordingStopped)==null||i.call(t),t.sendMessage({type:"recording.stop"}).catch(()=>{})}})))}async function r(){var o,i;if(e!=="idle"){if(e==="counting-down"){t.unmountCountdown(),e="idle",(o=t.onRecordingStopped)==null||o.call(t);return}try{await t.sendMessage({type:"recording.stop"})}finally{e="idle",(i=t.onRecordingStopped)==null||i.call(t)}}}return{startRecording:n,stopRecording:r,isRecording:()=>e==="recording",getPhase:()=>e}}const Zo="Created with Manuscript",bf=12,vf=500,Er=14,Qo=10,yf=6,Jo=24,xf=.7;function wf(t,e,n,r){t.save(),t.globalAlpha=xf,t.fillStyle="#fff",t.font=`${vf} ${bf}px "Pretendard Variable", Pretendard, system-ui, sans-serif`,t.textAlign="right",t.textBaseline="bottom",t.shadowColor="rgba(0, 0, 0, 0.85)",t.shadowBlur=3,t.shadowOffsetX=0,t.shadowOffsetY=1;const o=n-Jo,i=r-Jo;t.fillText(Zo,o,i);const a=t.measureText(Zo).width,s=o-a-yf-Qo,c=i-Er;t.drawImage(e,s,c,Qo,Er),t.restore()}async function kf(){const t=ui({height:Er,color:"#ffffff"}),e=`data:image/svg+xml;utf8,${encodeURIComponent(t)}`,n=new Image;return n.src=e,await n.decode(),n}const Sf=["video/webm;codecs=vp9,opus","video/webm;codecs=vp9","video/webm;codecs=vp8,opus","video/webm;codecs=vp8","video/webm"];let ln=null,zt=null,Ae=null,Me=null,$e=null,ee=null,Le=null,Ar=!1,Cn=null,Zr=null,Qr=null,fe=null;async function Ef(){if(Be()||zt)return!1;let t;try{t=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,preferCurrentTab:!0,selfBrowserSurface:"include"})}catch(p){return console.warn("[manuscript/recording] tab share failed:",p),!1}let e=null;try{e=await navigator.mediaDevices.getDisplayMedia({video:!0,audio:!0,systemAudio:"include"}),e.getVideoTracks().forEach(p=>p.stop()),console.info("[manuscript/recording] step 2 OK — system audio acquired, video track dropped",{audioTracks:e.getAudioTracks().length})}catch(p){console.warn("[manuscript/recording] step 2 rejected:",p instanceof Error?`${p.name}: ${p.message}`:p),Yt("System audio not shared — TTS narration will be silent in the video.")}let n=null,r=null;const o=t.getAudioTracks().length>0,i=((e==null?void 0:e.getAudioTracks().length)??0)>0;if(o||i){r=new AudioContext;const p=r.createMediaStreamDestination();o&&r.createMediaStreamSource(new MediaStream(t.getAudioTracks())).connect(p),i&&e&&r.createMediaStreamSource(new MediaStream(e.getAudioTracks())).connect(p),n=p.stream.getAudioTracks()[0]??null}let a=null;try{const p=await Af(t);ee=p.videoEl,Le=p.canvasStream,a=p.videoTrack}catch(p){console.warn("[manuscript/recording] watermark compositor failed; falling back to raw tab video:",p)}const s=a?[a]:[...t.getVideoTracks()];n&&s.push(n);const c=new MediaStream(s);Ae=t,Me=e,$e=r,zt=c;const l=t.getVideoTracks()[0],d=l&&typeof l.getSettings=="function"?l.getSettings():null,f=(d==null?void 0:d.displaySurface)??"(unknown)";console.info("[manuscript/recording] capture stream info",{displaySurface:f,tabAudioTracks:t.getAudioTracks().length,systemAudioTracks:(e==null?void 0:e.getAudioTracks().length)??0,mergedAudioTrack:!!n});const u=()=>{const p=ln;p&&p.getPhase()!=="idle"&&p.stopRecording()};return l&&l.addEventListener("ended",u),e==null||e.getAudioTracks().forEach(p=>p.addEventListener("ended",u)),If().startRecording(),!0}async function Af(t){const e=document.createElement("video");e.muted=!0,e.playsInline=!0,e.setAttribute("data-manuscript","ui"),e.style.cssText="position:fixed;left:-9999px;top:-9999px;width:1px;height:1px;opacity:0;pointer-events:none;",document.body.appendChild(e),e.srcObject=new MediaStream(t.getVideoTracks()),await e.play();const n=t.getVideoTracks()[0],r=(n==null?void 0:n.getSettings())??{},o=(typeof r.width=="number"?r.width:void 0)??e.videoWidth??1280,i=(typeof r.height=="number"?r.height:void 0)??e.videoHeight??720,a=document.createElement("canvas");a.width=o,a.height=i;const s=a.getContext("2d");if(!s)throw new Error("2D canvas context unavailable");const c=await kf();Ar=!0;const l=()=>{if(!Ar)return;s.drawImage(e,0,0,a.width,a.height),wf(s,c,a.width,a.height);const u=e.requestVideoFrameCallback;typeof u=="function"?u.call(e,l):requestAnimationFrame(l)};l();const d=a.captureStream(),f=d.getVideoTracks()[0];if(!f)throw new Error("canvas.captureStream produced no video track");return{videoEl:e,canvasStream:d,videoTrack:f}}function Mf(t){fe||(fe=e=>{if(e.key!==" "&&e.key!=="Spacebar")return;const n=e.target;n instanceof HTMLInputElement||n instanceof HTMLTextAreaElement||n instanceof HTMLElement&&n.isContentEditable||(e.preventDefault(),e.stopPropagation(),t())},window.addEventListener("keydown",fe,!0))}function $f(){fe&&(window.removeEventListener("keydown",fe,!0),fe=null)}function Lf(t){let e;try{e=hf(Sf)}catch(n){return console.warn("[manuscript/recording] no supported mime:",n),null}return Zr=e,console.info("[manuscript/recording] using mimeType",e,{streamAudioTracks:t.getAudioTracks().length,streamVideoTracks:t.getVideoTracks().length}),mf(t,{factory:{create:(n,r)=>new MediaRecorder(n,r)},mimeType:e,timesliceMs:1e3})}function Tf(t,e){const n=new Date(t),r=a=>String(a).padStart(2,"0"),o=`${n.getFullYear()}${r(n.getMonth()+1)}${r(n.getDate())}-${r(n.getHours())}${r(n.getMinutes())}`,i=e.includes("webm")?"webm":"video";return`manuscript-recording-${o}.${i}`}function In(){Ar=!1,zt==null||zt.getTracks().forEach(t=>t.stop()),Le==null||Le.getTracks().forEach(t=>t.stop()),Ae==null||Ae.getTracks().forEach(t=>t.stop()),Me==null||Me.getTracks().forEach(t=>t.stop()),$e==null||$e.close().catch(()=>{}),ee&&(ee.pause(),ee.srcObject=null,ee.remove()),zt=null,Ae=null,Me=null,$e=null,ee=null,Le=null,Cn=null,Zr=null,Qr=null}async function Cf(){const t=Cn;if(!t){In();return}try{const e=await t.stop(),n=URL.createObjectURL(e.blob),r=Tf(Qr??Date.now(),Zr??"video/webm");try{await chrome.runtime.sendMessage({type:"recording.download",url:n,filename:r})}catch(o){console.warn("[manuscript/recording] download forward failed:",o)}}catch(e){console.warn("[manuscript/recording] recorder.stop failed:",e)}finally{In()}}function If(){if(!ln){const t=gf({mountCountdown:df,unmountCountdown:Kr,sendMessage:async()=>{},isStandalonePlayback:Be,onRecordingStarting:()=>{oi()&&ii(!0),dr(!0)},onRecordingStarted:()=>{Mf(()=>void t.stopRecording()),dr(!0);const e=zt;if(e){const n=Lf(e);if(n){Cn=n,Qr=Date.now();try{n.start()}catch(r){console.warn("[manuscript/recording] recorder start failed:",r),In();return}}}!ut()&&I()&&we(0)},onRecordingStopped:()=>{$f(),dr(!1),oi()&&ii(!1),ut()&&ve(),Cn?Cf():In()}});ln=t,document.addEventListener("manuscript:replay-end",()=>{t.getPhase()==="recording"&&t.stopRecording()}),it(e=>{e.prev==="replay"&&e.next!=="replay"&&t.getPhase()==="recording"&&t.stopRecording()})}return ln}const Pf="/assets/share-step-1-B4IYEXR4.png",Df="/assets/share-step-2-B99Thpfo.png",Rf=chrome.runtime.getURL(Pf.replace(/^\/+/,"")),Of=chrome.runtime.getURL(Df.replace(/^\/+/,""));let ie=null;function Nf(t){var a,s,c;if(ie!==null)return;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","recording-guide"),e.style.cssText=["position: fixed","inset: 0",`z-index: ${O+12}`,"pointer-events: auto"].join("; "),Rt(e);const n=e.attachShadow({mode:"open"});n.innerHTML=Ff(),document.body.appendChild(e);function r(l){var d;ti(),(d=t.onCancel)==null||d.call(t)}function o(){ti(),t.onStart()}(a=n.querySelector('[data-action="start"]'))==null||a.addEventListener("click",o),(s=n.querySelector('[data-action="cancel"]'))==null||s.addEventListener("click",()=>r()),(c=n.querySelector('[data-action="scrim-close"]'))==null||c.addEventListener("click",l=>{l.target===l.currentTarget&&r()});const i=l=>{l.key==="Escape"&&(l.preventDefault(),r())};window.addEventListener("keydown",i),ie={host:e,keyListener:i}}function ti(){ie&&(window.removeEventListener("keydown",ie.keyListener),ie.host.remove(),ie=null)}function Ff(){return`
    <style>
      ${kt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .scrim {
        position: fixed;
        inset: 0;
        background: rgb(0 0 0 / 0.55);
        display: grid;
        place-items: center;
        animation: scrim-fade 160ms ease-out;
      }
      @keyframes scrim-fade {
        from { opacity: 0; } to { opacity: 1; }
      }
      .card {
        width: min(700px, calc(100vw - 48px));
        max-height: calc(100vh - 48px);
        overflow: auto;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        animation: card-pop 240ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      @keyframes card-pop {
        from { transform: scale(0.96); opacity: 0; }
        to   { transform: scale(1);    opacity: 1; }
      }
      .head {
        padding: 22px 28px 8px;
      }
      .title {
        font-size: 19px;
        font-weight: 600;
        margin: 0 0 8px;
      }
      .subtitle {
        font-size: 13px;
        color: var(--c-text-mute, #555);
        margin: 0;
        line-height: 1.5;
      }
      .steps {
        padding: 12px 28px 8px;
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 20px;
      }
      .step {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }
      .step-head {
        display: flex;
        align-items: center;
        gap: 10px;
      }
      .step-badge {
        width: 26px;
        height: 26px;
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
        border-radius: 999px;
        font-size: 13px;
        font-weight: 700;
        display: grid;
        place-items: center;
        flex-shrink: 0;
      }
      .step-title {
        font-size: 14px;
        font-weight: 600;
      }
      .step-img {
        width: 100%;
        height: auto;
        border: 1px solid var(--c-border, #ddd);
        border-radius: 8px;
        background: var(--c-surface-2, #f6f7f8);
        display: block;
      }
      .step-desc {
        font-size: 12px;
        color: var(--c-text-mute, #555);
        line-height: 1.5;
        margin: 0;
      }
      .step-desc ol {
        margin: 0 0 8px;
        padding-left: 18px;
        display: flex;
        flex-direction: column;
        gap: 2px;
      }
      .step-desc ol li {
        padding-left: 2px;
      }
      .step-desc p {
        margin: 6px 0 0;
      }
      .step-desc kbd {
        display: inline-block;
        padding: 1px 6px;
        border: 1px solid var(--c-border, #ccc);
        border-radius: 4px;
        background: var(--c-surface-2, #f1f3f4);
        font-family: var(--ff-mono, ui-monospace, monospace);
        font-size: 11px;
      }
      .actions {
        padding: 16px 28px 22px;
        display: flex;
        justify-content: flex-end;
        gap: 8px;
      }
      .btn {
        appearance: none;
        font-family: inherit;
        font-size: 14px;
        font-weight: 500;
        padding: 8px 18px;
        border-radius: 999px;
        cursor: pointer;
        border: 1px solid transparent;
        transition: filter 0.12s ease, background 0.12s ease;
      }
      .btn-ghost {
        background: transparent;
        color: var(--c-text-mute, #555);
        border-color: var(--c-border-strong, #d2d6dc);
      }
      .btn-ghost:hover { color: var(--c-text, #111); }
      .btn-primary {
        background: var(--c-primary, #1a73e8);
        color: var(--c-primary-fg, #fff);
      }
      .btn-primary:hover { filter: brightness(1.06); }
    </style>
    <div class="scrim" data-action="scrim-close" role="dialog" aria-modal="true" aria-labelledby="rec-guide-title">
      <div class="card">
        <div class="head">
          <h2 id="rec-guide-title" class="title">${b("recording.guide.title")}</h2>
          <p class="subtitle">${b("recording.guide.subtitle")}</p>
        </div>
        <div class="steps">
          <div class="step">
            <div class="step-head">
              <div class="step-badge">1</div>
              <div class="step-title">${b("recording.guide.step1-title")}</div>
            </div>
            <img src="${Rf}" alt="${b("recording.guide.step1-alt")}" class="step-img" />
            <div class="step-desc">${b("recording.guide.step1-desc-html")}</div>
          </div>
          <div class="step">
            <div class="step-head">
              <div class="step-badge">2</div>
              <div class="step-title">${b("recording.guide.step2-title")}</div>
            </div>
            <img src="${Of}" alt="${b("recording.guide.step2-alt")}" class="step-img" />
            <div class="step-desc">${b("recording.guide.step2-desc-html")}</div>
          </div>
        </div>
        <div class="actions">
          <button type="button" class="btn btn-ghost" data-action="cancel">
            ${b("recording.guide.cancel")} <kbd>Esc</kbd>
          </button>
          <button type="button" class="btn btn-primary" data-action="start">
            ${b("recording.guide.start")}
          </button>
        </div>
      </div>
    </div>
  `}function Hf(){const t=I();if(t)try{const e=Ts(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Bf(t.name)}-${qf(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),Yt(b("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),Yt(b("toast.export-failed"),!0)}}async function zf(){const t=I();if(t){if(t.steps.length===0){Yt(b("toast.no-steps"),!0);return}Zi(),await we(0,{paused:!0})}}function _f(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Cs(r);Ei(o),Yt(b("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),Yt(b("toast.import-failed"),!0)}}),t.click()}function Bf(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function qf(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function Kn(t){const e=I(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!jf(n.pickedAtUrl,location.href)?(rs(n.pickedAtUrl,t),!0):!1}function Ie(){const t=I();if(!t)return;const e=U(),n=t.steps[e],r=t.steps[e+1];Ha({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function jf(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function rs(t,e){const n=I();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let Pn=!1,os=0,is=0,Mr=0,$r=0;function Wf(){const{shadow:t}=k;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=k;if(!o)return;Pn=!0,os=n.clientX,is=n.clientY;const i=o.getBoundingClientRect();Mr=i.left,$r=i.top,o.style.left=`${Mr}px`,o.style.top=`${$r}px`,o.style.right="auto",document.addEventListener("mousemove",as,!0),document.addEventListener("mouseup",ss,!0),n.preventDefault()})}function as(t){const{host:e}=k;if(!Pn||!e)return;const n=t.clientX-os,r=t.clientY-is,o=e.offsetWidth,i=e.offsetHeight,a=Tn(Mr+n,0,window.innerWidth-o),s=Tn($r+r,0,window.innerHeight-i);e.style.left=`${a}px`,e.style.top=`${s}px`}function ss(){Pn&&(Pn=!1,document.removeEventListener("mousemove",as,!0),document.removeEventListener("mouseup",ss,!0))}let Dn=!1,cs=0,ls=0;function Uf(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=k;r&&(Dn=!0,cs=n.clientY,ls=r.getBoundingClientRect().height,document.addEventListener("mousemove",ds,!0),document.addEventListener("mouseup",us,!0),n.preventDefault(),n.stopPropagation())})}function ds(t){const{host:e}=k;if(!Dn||!e)return;const n=t.clientY-cs,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-pe,i=Tn(ls+n,$n,o);e.style.height=`${i}px`,e.style.maxHeight=`${i}px`}function us(){Dn&&(Dn=!1,document.removeEventListener("mousemove",ds,!0),document.removeEventListener("mouseup",us,!0))}function Xf(t){const e=window.innerHeight-pe*2;return Tn(t,$n,Math.max($n,e))}function ps(){const{host:t}=k;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-pe;if(e.bottom>n){const o=Math.max($n,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),i=window.innerWidth-r.width;o>i&&(t.style.left=`${Math.max(0,i)}px`)}if(t.style.top){const o=parseFloat(t.style.top),i=window.innerHeight-r.height;o>i&&(t.style.top=`${Math.max(0,i)}px`)}}function Jr(){var t;return((t=k.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function fs(){var t;return((t=k.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function Vf(){const t=Jr();t&&(t.hidden?(Yf(),t.hidden=!1):t.hidden=!0)}function hs(){const t=Jr();t&&(t.hidden=!0)}async function Yf(){const t=fs();if(!t)return;await Fs();const e=Hs(),n=await zs(),r=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const i of e){const a=i.name===n?" selected":"";o.push(`<option value="${r(i.name)}"${a}>${r(i.name)} (${r(i.lang)})</option>`)}t.innerHTML=o.join("")}function Gf(){var n;const t=fs();t&&t.addEventListener("change",()=>{const r=t.value;Ns(r.length>0?r:null)});const e=(n=k.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>hs())}function Kf(t){var o;const e=Jr();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=k.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||hs()}function jt(t){const e=t===U();Gt(t),e&&ms()}function ms(){const t=at();if(!(t!=null&&t.selectors)){be();return}const e=Pe(t.selectors);e?(e.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),za(e)):be()}function ei(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function to(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function Zf(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function Qf(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function Jf(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function th(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function eh(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function nh(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=I(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));jt(l)}const i=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${i}" aria-label="Auto-advance seconds" />
    ${to(10)}
  `;const a=t.querySelector("input");if(!a)return;a.focus(),a.select();const s=l=>{if(t.classList.remove("editing"),l){ni(t,i);return}const d=a.value.trim();let f=5;if(d===""||d==="0")se(r.id,{autoAdvanceMs:null});else{const u=Number(d);Number.isFinite(u)&&u>0?(se(r.id,{autoAdvanceMs:Math.round(u*1e3)}),f=u):se(r.id,{autoAdvanceMs:null})}ni(t,f)};a.addEventListener("blur",()=>s(!1)),a.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),a.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),a.addEventListener("mousedown",l=>l.stopPropagation())}function ni(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${to(10)}
  `}function rh(t,e){const{shadow:n,host:r}=k;if(!n||!r)return;Wf(),Uf(),ah(),Gf(),document.addEventListener("mousedown",Kf,!0);const o=i=>i.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",i=>oh(i,t,e))}function oh(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="palette-toggle"]')){t.stopPropagation(),Xs();return}if(o.closest('[data-action="recording-toggle"]')){t.stopPropagation(),Nf({onStart:()=>{Ef().then(s=>{s||Yt("Recording cancelled or unsupported.")})}});return}if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void zf();if(o.closest('[data-action="prompter"]')){n(!0),Na().then(()=>{Ie()});return}if(o.closest('[data-action="export"]'))return Hf();if(o.closest('[data-action="import"]'))return _f();if(o.closest('[data-action="settings-toggle"]'))return Vf();const i=o.closest('[data-action="tool-set"]');if(i instanceof HTMLElement){t.stopPropagation();const s=i.getAttribute("data-tool");if(s==="shape"){rf(i,c=>{gu(c),D("shape")});return}D(yt()===s?"idle":s);return}if(ih(t,o))return;const a=o.closest("[data-step-card]");if(a&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(a.getAttribute("data-step-card"));if(Kn(s))return;jt(s)}}function ih(t,e){var c;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const l=Number(n.getAttribute("data-insert-index"));return uo({insertIndex:l}),!0}if(e.closest('[data-action="step-add"]'))return uo(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const l=Number(r.getAttribute("data-step-index"));return Kn(l)||(jt(l),D(yt()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),vc(Number(o.getAttribute("data-step-index"))),!0;const i=e.closest('[data-action="step-link"]');if(i){t.stopPropagation();const l=i.getAttribute("data-url")??"",d=i.closest("[data-step-card]"),f=d?Number(d.getAttribute("data-step-card")):0;return l&&rs(l,Number.isFinite(f)?f:0),!0}const a=e.closest('[data-action="step-action-toggle"]');if(a instanceof HTMLElement){t.stopPropagation();const l=Number(a.getAttribute("data-step-index")),d=(c=I())==null?void 0:c.steps[l];return d&&(jt(l),se(d.id,{waitForNavigation:!d.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');return s instanceof HTMLElement?(t.stopPropagation(),s.classList.contains("disabled")||nh(s),!0):!1}function ah(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>Lr(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=I();r&&(e.textContent=r.name),Lr(e),e.blur()}}),e.addEventListener("blur",()=>{gc(e.textContent??"")}))}function Lr(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const sh='[data-manuscript="ui"][data-region="permission-banner"]';function gs(){return document.querySelector(sh)}function ch(t){const e=gs();if(e){vs(e,t);return}lh(t)}function bs(){const t=gs();t&&t.remove()}function vs(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function lh(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),Rt(e),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${O+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=dh(),vs(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>bs()),document.body.appendChild(e)}function dh(){return`
    <style>
      ${kt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const en=16,uh=240,ph=/permission|<all_urls>|activeTab/i;async function fh(t){const e=hh({x:t.x-en,y:t.y-en,width:t.width+en*2,height:t.height+en*2});if(e.width<=0||e.height<=0)return null;const n=await mh();if(!n.ok)return ph.test(n.error)?ch(b("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await vh(n.dataUrl,e,uh)}catch(r){return console.error("[manuscript] crop failed",r),null}}function hh(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function mh(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await bh();try{return{ok:!0,dataUrl:await gh()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function gh(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function bh(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function vh(t,e,n){const r=await yh(t),o=r.naturalWidth/window.innerWidth||1,i=e.x*o,a=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),d=Math.max(1,Math.round(e.width*l)),f=Math.max(1,Math.round(e.height*l)),u=document.createElement("canvas");u.width=d,u.height=f;const p=u.getContext("2d");if(!p)throw new Error("No 2d context");return p.drawImage(r,i,a,s,c,0,0,d,f),u.toDataURL("image/png")}function yh(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function ys(t){const e=t.detail;xc(e.chain);const n=xh(e.rect,e.chain.framePath);wh(n)}function xh(t,e){if(!e||e.length===0)return t;const n=Uc(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function wh(t){try{const e=await fh(t);bc(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}function kh(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Record button — toggles between a red record dot (idle) and a
         square stop icon (recording). Hidden during bridge standalone
         sessions; that branch is enforced at the controller layer. */
      .record-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-error);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .record-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-error);
      }
      .record-btn .record-stop { display: none; }
      .record-btn[aria-pressed="true"] {
        background: var(--c-error);
        color: var(--c-primary-fg);
        border-color: var(--c-error);
        animation: record-pulse 1.6s ease-in-out infinite;
      }
      .record-btn[aria-pressed="true"] .record-dot { display: none; }
      .record-btn[aria-pressed="true"] .record-stop { display: inline-block; }
      @keyframes record-pulse {
        0%, 100% { box-shadow: 0 0 0 0 color-mix(in oklch, var(--c-error), transparent 60%); }
        50%      { box-shadow: 0 0 0 6px color-mix(in oklch, var(--c-error), transparent 100%); }
      }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
        /* Sit above the footer chrome (play-btn / record-btn / icon-btn
           / settings-popup at z-index 4) so the toast isn't clipped by
           those siblings. */
        z-index: 10;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Sh(){return`
      ${kt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .header-actions {
        display: flex;
        align-items: center;
        gap: 6px;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .palette-toggle {
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        color: var(--c-text-mute);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: border-color 160ms ease, color 160ms ease;
      }
      .palette-toggle:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .palette-toggle:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
      }
      .palette-toggle .palette-sun { display: none; }
      .palette-toggle .palette-moon { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-sun { display: inline-block; }
      .palette-toggle[aria-pressed="true"] .palette-moon { display: none; }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Eh(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -1px;
        left: 3px;
        font-family: var(--ff-mono);
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 1px 3px;
        border-radius: 2px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

  `}function Ah(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Mh(){return[Sh(),Eh(),Ah(),kh()].join(`
`)}function $h(){return`
    <style>${Mh()}</style>
    <div class="panel" role="region" aria-label="${b("panel.aria.region")}">
      ${Lh()}
      ${Th()}
      <div class="body" data-region="steps"></div>
      ${Ch()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${b("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Lh(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${ui({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <div class="header-actions">
          <button type="button" class="palette-toggle" data-action="palette-toggle" data-region="palette-toggle" aria-label="${b("panel.palette-toggle-aria")}" aria-pressed="false" title="${b("panel.palette-toggle-aria")}">
            <svg class="palette-sun" width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
              <circle cx="8" cy="8" r="3"></circle>
              <path d="M8 1.2v1.6M8 13.2v1.6M14.8 8h-1.6M2.8 8H1.2M12.8 3.2l-1.13 1.13M4.33 11.67l-1.13 1.13M12.8 12.8l-1.13-1.13M4.33 4.33L3.2 3.2"></path>
            </svg>
            <svg class="palette-moon" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true">
              <path d="M6.5 1.5a6.5 6.5 0 1 0 8 8 5.4 5.4 0 0 1-8-8z"></path>
            </svg>
          </button>
          <button type="button" class="close-btn" data-action="close" aria-label="${b("panel.close-aria")}">×</button>
        </div>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${b("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Th(){return`
    <div class="tool-bar" role="toolbar" aria-label="${b("panel.tool-label")}">
      <span class="eyebrow">${b("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${b("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${b("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${b("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Ch(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${b("panel.replay-aria")}" title="${b("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${b("panel.prompter-aria")}" title="${b("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
        <button type="button" class="record-btn" data-action="recording-toggle" data-region="record-btn" aria-pressed="false" aria-label="${b("panel.record-aria")}" title="${b("panel.record-aria")}">
          <svg class="record-dot" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><circle cx="8" cy="8" r="5"/></svg>
          <svg class="record-stop" width="14" height="14" viewBox="0 0 16 16" fill="currentColor" aria-hidden="true"><rect x="3" y="3" width="10" height="10" rx="1"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${b("panel.import-aria")}" title="${b("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${b("panel.export-aria")}" title="${b("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${b("panel.settings-aria")}" title="${b("panel.settings.title")}" data-region="settings-toggle">
          ${eh(16)}
        </button>
      </div>
      ${Ih()}
    </div>
  `}function Ih(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${b("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${b("panel.settings.close-aria")}" title="${b("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${b("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${b("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function Ph(t){const e=t.pickedAtUrl;return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${rt(e)}"
        aria-label="Open ${rt(e)}"
      >${th(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${Ln(e)}</span>
    </div>
  `:""}function Dh(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,i=t.thumbnailDataUrl!==null,a=n&&yt()==="picker",s="step-thumb"+(o?" has-element":"")+(a?" is-picking":""),c=i?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,d=t.waitForNavigation;return r.innerHTML=`
    <button
      type="button"
      class="${s}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${rt(b("step.wand-aria",{n:e+1}))}"
      title="${rt(b("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!i?`<span class="step-thumb-icon">${Jf(18)}</span>`:""}
      ${!o&&!i?'<span class="step-thumb-plus">+</span>':""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${rt(b("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${Ln(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${rt(b("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${Ln(t.description)}</div>
    </div>
    ${Ph(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${d}" aria-label="${rt(b("step.action-aria"))}" title="${rt(b("step.action-aria"))}">${Qf(10)}</button>
      <div class="step-timer${d?" disabled":""}" data-action="step-timer" data-step-id="${rt(t.id)}" title="${rt(b("step.timer-aria"))}" ${d?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${to(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${rt(b("step.delete-aria"))}" title="${rt(b("step.delete-aria"))}">${Zf(12)}</button>
    </div>
  `,r}function Rh(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function Oh(t,e,n){ri(t,"step-name",n,r=>se(e.id,{name:r})),ri(t,"step-desc",n,r=>se(e.id,{description:r}),{escapeBlurs:!0}),Nh(t,n)}function ri(t,e,n,r,o={}){const i=t.querySelector(`[data-region="${e}"]`);i&&(i.addEventListener("input",()=>Rh(i)),i.addEventListener("focus",()=>{Kn(n)||Gt(n)}),i.addEventListener("mousedown",a=>a.stopPropagation()),i.addEventListener("blur",()=>r(i.textContent??"")),i.addEventListener("keydown",a=>{(a.key==="Enter"&&e==="step-name"||a.key==="Escape"&&o.escapeBlurs)&&(a.preventDefault(),i.blur())}))}function Nh(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}k.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),k.dragFromIndex=null,(n=k.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{k.dragFromIndex===null||k.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(k.dragFromIndex===null||k.dragFromIndex===e)&&(yc(k.dragFromIndex,e),k.dragFromIndex=null)})}function Fh(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=I();if(e.innerHTML="",!n)return;const r=U();n.steps.forEach((i,a)=>{if(a>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(a)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${a+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${a}" aria-label="Insert step here">
          ${ei(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=Dh(i,a,r===a);e.appendChild(s),Oh(s,i,a)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${ei(10,1.8)}
    </button>
  `,e.appendChild(o)}function oi(){return k.host!==null}function xs(t){const{host:e}=k;e&&(e.dataset.promptedHidden=t?"1":"",ws(e))}function ii(t){const{host:e}=k;e&&(e.dataset.recordingHidden=t?"1":"",ws(e))}function ws(t){if(yt()==="replay")return;const e=t.dataset.promptedHidden==="1",n=t.dataset.recordingHidden==="1";t.style.display=e||n?"none":""}async function Rn(t){if(k.host){t&&await lo(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),Rt(e);const n=Xf(window.innerHeight*lf);e.style.cssText=["position: fixed",`top: ${pe}px`,`right: ${pe}px`,`width: ${cf}px`,`height: ${n}px`,`max-height: calc(100vh - ${pe*2}px)`,`z-index: ${O+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=$h(),k.host=e,k.shadow=r,rh(ks,xs),document.body.appendChild(e),t&&await lo(t)||co(),Wa(),document.addEventListener(ze,ys),window.addEventListener("resize",ps),k.unsubscribeMode=it(ur),k.unsubscribeScenario=ye(ur),ur();const o=I();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(i){console.warn("[manuscript] markActive failed",i)}}function ks(){var e,n;const{host:t}=k;t&&(document.removeEventListener(ze,ys),window.removeEventListener("resize",ps),(e=k.unsubscribeMode)==null||e.call(k),k.unsubscribeMode=null,(n=k.unsubscribeScenario)==null||n.call(k),k.unsubscribeScenario=null,D("idle"),be(),Zi(),Ua(),Ai(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),k.host=null,k.shadow=null)}function ur(){const{host:t,shadow:e}=k;if(!e||!t)return;const n=yt(),r=t.dataset.promptedHidden==="1";t.style.display=n==="replay"||r?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(a=>{const s=a.getAttribute("data-tool");a.setAttribute("aria-pressed",String(s===n))});const o=I(),i=e.querySelector('[data-region="title-edit"]');i&&o&&i!==e.activeElement&&(i.textContent!==o.name&&(i.textContent=o.name),Lr(i)),Fh(),ms(),Wn()&&!ut()&&Ie()}function Hh(t,e,n){switch(t.type){case"panel.open":return Rn(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return ks(),n({ok:!0}),!1;case"scenario.replay":return Rn(t.scenarioId).then(()=>we(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return zh(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return qu(),ut()&&ve(),Zp(),xs(!1),n({ok:!0}),!1}return!1}function zh(t,e){if(ut()){t==="prev"?An():t==="next"?Oe():t==="jump"&&typeof e=="number"?Gr(e):t==="pause"&&Mn();return}const n=I();if(!n)return;const r=U();if(t==="prev")r>0&&jt(r-1),Ie();else if(t==="next")r<n.steps.length-1&&jt(r+1),Ie();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(Kn(e))return;jt(e)}Ie()}else t==="pause"&&we(r)}async function _h(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Bh(){try{const t=await di();if(!t)return;if(qh()){await chrome.storage.local.remove(X.activeReplay);return}D("replay"),await Rn(t.scenarioId),await we(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function qh(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function jh(){try{const t=await _h();if(!t)return;await Rn(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Gt(t.stepIndex)}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const Wh="manuscript:host",Uh="manuscript:ext",Xh="manuscript:ready";let ai=!1;function Vh(){ai||(window.addEventListener("message",Gh),ai=!0,it(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Ft("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(Xh)))}function Yh(t){return typeof t=="object"&&t!==null&&t.source===Wh&&typeof t.type=="string"}function Ft(t,e,n){const r={source:Uh,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function Gh(t){const e=t.data;if(Yh(e))switch(e.type){case"ping":Ft("pong",e.requestId,{version:Zh()});return;case"load":try{const n=Kh(e.scenario);Ei(n),Ft("load-ack",e.requestId,{ok:!0})}catch(n){Ft("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!gp()&&Wa(),Ft("play-ack",e.requestId,{ok:!0}),we(r,{paused:o,standalone:n}).catch(i=>{console.warn("[manuscript] startReplay failed",i)});return}case"pause":ut()&&Mn(),Ft("pause-ack",e.requestId,{ok:ut()});return;case"next":ut()&&Oe();return;case"prev":ut()&&An();return;case"jump":ut()&&typeof e.index=="number"&&Gr(e.index);return;case"exit":(async()=>(ut()&&await ve(),Ft("exit-ack",e.requestId,{ok:!0})))();return}}function Kh(t){if(t==null)throw new ro("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new ro("Invalid JSON",n)}return oo(e,{strict:!0})}return oo(t,{strict:!0})}function Zh(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const Qh=window===window.top;Cu();_s();Is();Gd();Su();Hd();bu();Wd();sd();Hu();_u();var si,ci;Qh&&(Bu().then(()=>{Bh(),jh()}),chrome.runtime.onMessage.addListener(Hh),(ci=(si=chrome.permissions)==null?void 0:si.onAdded)==null||ci.addListener(()=>bs()),Vh());export{ml as M,gl as V,kt as d,at as g,ye as o,Rt as r,rm as u};
