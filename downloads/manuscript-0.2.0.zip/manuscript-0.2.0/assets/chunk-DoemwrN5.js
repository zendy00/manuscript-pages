function t(e){return typeof e=="object"&&e!==null&&e.target==="manuscript-offscreen"}function n(e){return typeof e=="object"&&e!==null&&e.target==="manuscript-background"}export{n as a,t as i};
