import{O as z,S as Z,E as Ra}from"./chunk-aRRa0OE6.js";import{s as To,g as Fa,S as za,a as sr,b as Co,c as Ha,d as _a,e as Ba,m as qa,f as Dr,h as Or}from"./chunk-_P7E0VjS.js";import{t as b,i as ja}from"./chunk-DAwYOt8I.js";import{g as Io,i as Wa,a as Ua,b as Po,c as Xa,s as Ya,d as Ga,w as Va,l as Ka,e as Za,f as Qa}from"./chunk-Cr8au9ne.js";const Yn="manuscript:mode-changed";let _e="idle";function vt(){return _e}function D(t){if(t===_e)return;const e=_e;_e=t,document.dispatchEvent(new CustomEvent(Yn,{detail:{prev:e,next:t}}))}function ct(t){const e=n=>t(n.detail);return document.addEventListener(Yn,e),()=>document.removeEventListener(Yn,e)}function Do(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),i=n*(1-e),a=n*(1-o*e),s=n*(1-(1-o)*e);let c=0,l=0,u=0;switch(r){case 0:c=n,l=s,u=i;break;case 1:c=a,l=n,u=i;break;case 2:c=i,l=n,u=s;break;case 3:c=i,l=a,u=n;break;case 4:c=s,l=i,u=n;break;case 5:c=n,l=i,u=a;break}return[Math.round(c*255),Math.round(l*255),Math.round(u*255)]}function Oo(t,e,n){const r=t/255,o=e/255,i=n/255,a=Math.max(r,o,i),s=Math.min(r,o,i),c=a-s;let l=0;return c!==0&&(a===r?l=(o-i)/c%6:a===o?l=(i-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:a===0?0:c/a,v:a}}function No(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function Ro(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(i=>i+i).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(i=>!Number.isFinite(i))?{h:0,s:1,v:1}:Oo(n,r,o)}function Dn(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function Nr(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function Ja(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const ts=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function qt(){return ts.replace(/:root\s*\{/g,":host {")}const ve="studio",es=140,ns=140;function rs(){return`
    ${qt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${es}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${ns}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function os(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function is(){return[rs(),os()].join(`
`)}const Gn="manuscript:scenario-changed",as=500,ss=5e3,m={scenario:null,currentStepIndex:0,saveTimer:null};function P(){return m.scenario}function q(){return m.currentStepIndex}function mt(){return m.scenario?m.scenario.steps[m.currentStepIndex]??null:null}function ye(t){return document.addEventListener(Gn,t),()=>document.removeEventListener(Gn,t)}function j(){document.dispatchEvent(new CustomEvent(Gn)),cs()}function lt(){m.scenario&&(m.scenario.updatedAt=new Date().toISOString())}function Fo(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function cr(){return{id:Fo("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:ss,waitForNavigation:!1}}function cs(){if(!m.scenario)return;m.saveTimer!==null&&window.clearTimeout(m.saveTimer);const t=m.scenario;m.saveTimer=window.setTimeout(()=>{m.saveTimer=null,To(t).catch(e=>{console.error("[manuscript] save failed",e)})},as)}function bn(){m.saveTimer!==null&&(window.clearTimeout(m.saveTimer),m.saveTimer=null,m.scenario&&To(m.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const ls=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],us=8,ds=5;function ps(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const a=Vn(e.getAttribute("content"));a&&t.add(a)}const n=getComputedStyle(document.documentElement);for(const a of ls){const s=Vn(n.getPropertyValue(a));s&&t.add(s)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:a,prop:s}of r)Rr(t,a,s);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let a=0;a<o.length&&a<ds;a++)Rr(t,o[a]??null,"background-color");const i=Array.from(t).filter(fs).slice(0,us);return{text:i,background:i}}function Rr(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Vn(r);o&&t.add(o)}function Vn(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],i=e[3];return`#${r}${r}${o}${o}${i}${i}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=On(n[1]),i=On(n[2]),a=On(n[3]);return`#${Nn(o)}${Nn(i)}${Nn(a)}`}return null}function On(t){return Math.max(0,Math.min(255,Number(t)|0))}function Nn(t){return t.toString(16).padStart(2,"0")}function fs(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const i=Math.max(n,r,o),a=Math.min(n,r,o);return!(i-a<12)}const hs="'Asta Sans', sans-serif",ms=6,gs=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function bs(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const i=o.trim();if(!i)continue;const a=vs(i);if(!a)continue;const s=a.toLowerCase();if(!gs.has(s)&&!e.has(s)&&(e.add(s),n.push(ys(i)),n.length>=ms))break}return n}function vs(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function ys(t){return/asta\s*sans/i.test(t)?t:`${t}, ${hs}`}function Fr(){bn();const t=xs(),e=ws();m.scenario={schemaVersion:za,id:Fo("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[cr()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},m.currentStepIndex=0,j()}function xs(){try{const t=ps();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function ws(){try{return bs()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function zr(t){bn();const e=await Fa(t);return e?(m.scenario=e,m.currentStepIndex=0,j(),!0):!1}function zo(t){bn(),m.scenario=t,m.currentStepIndex=0,j()}function ks(t){if(!m.scenario)return;const e=t.trim();!e||e===m.scenario.name||(m.scenario.name=e,m.scenario.updatedAt=new Date().toISOString(),j())}function Ho(){bn(),m.scenario=null,m.currentStepIndex=0,j()}function Hr(t={}){if(!m.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>m.scenario.steps.length?m.scenario.steps.length:t.insertIndex;return m.scenario.steps.splice(e,0,cr()),lt(),m.currentStepIndex=e,j(),m.currentStepIndex}function Zt(t,e){if(!m.scenario)return;const n=m.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(lt(),j())}function Ss(t){const e=mt();!e||!m.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,lt(),j())}function As(t){m.scenario&&(t<0||t>=m.scenario.steps.length||(m.scenario.steps.splice(t,1),m.scenario.steps.length===0?(m.scenario.steps.push(cr()),m.currentStepIndex=0):m.currentStepIndex>=m.scenario.steps.length?m.currentStepIndex=m.scenario.steps.length-1:t<m.currentStepIndex&&(m.currentStepIndex-=1),lt(),j()))}function jt(t){m.scenario&&(t<0||t>=m.scenario.steps.length||t!==m.currentStepIndex&&(m.currentStepIndex=t,j()))}function Es(t,e){if(!m.scenario||t===e||t<0||t>=m.scenario.steps.length||e<0||e>=m.scenario.steps.length)return;const[n]=m.scenario.steps.splice(t,1);n&&(m.scenario.steps.splice(e,0,n),m.currentStepIndex===t?m.currentStepIndex=e:t<m.currentStepIndex&&e>=m.currentStepIndex?m.currentStepIndex-=1:t>m.currentStepIndex&&e<=m.currentStepIndex&&(m.currentStepIndex+=1),lt(),j())}function Ms(t){const e=mt();!e||!m.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),lt(),j())}function xe(t){const e=mt();!e||!m.scenario||(e.annotations.push(t),lt(),j())}function _o(t){const e=mt();!e||!m.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),lt(),j())}function C(t,e){const n=mt();!n||!m.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),lt(),j())}function Bo(){var t;return((t=mt())==null?void 0:t.annotations)??[]}function T(t){return Bo().find(e=>e.id===t)}function $s(t,e){if(!m.scenario)return;const n=e.trim();if(!n)return;const r=m.scenario.customColors??{},o=r[t]??[];o.includes(n)||(m.scenario.customColors={...r,[t]:[...o,n]},lt(),j())}function Ls(t,e){if(!m.scenario||!m.scenario.customColors)return;const n=m.scenario.customColors[t];!n||!n.includes(e)||(m.scenario.customColors={...m.scenario.customColors,[t]:n.filter(r=>r!==e)},lt(),j())}function Ts(){return`
    <style>${is()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Cs()}
      ${Is()}
      ${Ps()}
      ${Ds()}
    </div>
  `}function Cs(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Is(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function Ps(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function Ds(){var i,a;const t=P(),e=((i=t==null?void 0:t.customColors)==null?void 0:i.text)??[],n=((a=t==null?void 0:t.customColors)==null?void 0:a.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(s=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${Te(s)}" style="background: ${Te(s)}" aria-label="Use ${Te(s)}" title="${Te(s)}"></button>`).join("")}</div>
    </div>
  `}function Te(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Os(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let i=n.left;i+r.width>window.innerWidth-8&&(i=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,i)}px`}let Y=null,R=null,Et=0,zt=1,Ht=1,Mt=null;function Ns(t){_t(),Mt=t.onConfirm;const e=Ro(t.initialColor);Et=e.h,zt=e.s,Ht=e.v,Y=document.createElement("div"),Y.setAttribute("data-manuscript","ui"),Y.setAttribute("data-palette",ve),Y.style.cssText=["position: fixed",`z-index: ${z+7}`,"pointer-events: auto"].join("; "),R=Y.attachShadow({mode:"open"}),R.innerHTML=Ts(),Fs(),document.body.appendChild(Y),Os(Y,t.anchor),we(),document.addEventListener("mousedown",jo,!0),document.addEventListener("keydown",Wo,!0)}function _t(){Y&&(document.removeEventListener("mousedown",jo,!0),document.removeEventListener("keydown",Wo,!0),Y.remove(),Y=null,R=null,Mt=null)}function Rs(){return Y!==null}function we(){if(!R)return;const t=R.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${Et}deg, 100%, 50%)`);const e=R.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${zt*100}%`,e.style.top=`${(1-Ht)*100}%`);const n=R.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${Et/360*100}%`);const[r,o,i]=Do(Et,zt,Ht),a=No(r,o,i),s=R.querySelector('[data-region="preview"]');s&&(s.style.background=`rgb(${r}, ${o}, ${i})`);const c=R.querySelector('[data-region="hex"]');c&&(c.textContent=a),R.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===Y&&R.activeElement===l)return;const u=l.dataset.channel;u==="r"?l.value=String(r):u==="g"?l.value=String(o):u==="b"&&(l.value=String(i))})}function qo(){const[t,e,n]=Do(Et,zt,Ht);return No(t,e,n)}function Fs(){if(!R)return;const t=R.querySelector('[data-region="sv"]');t&&Nr(t,n=>zs(t,n));const e=R.querySelector('[data-region="hue"]');e&&Nr(e,n=>Hs(e,n)),R.addEventListener("input",n=>{var c,l,u;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Dn((c=R.querySelector('[data-channel="r"]'))==null?void 0:c.value),i=Dn((l=R.querySelector('[data-channel="g"]'))==null?void 0:l.value),a=Dn((u=R.querySelector('[data-channel="b"]'))==null?void 0:u.value),s=Oo(o,i,a);Et=s.h,zt=s.s,Ht=s.v,we()}),R.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),i=o==null?void 0:o.getAttribute("data-action");if(i==="confirm")Mt==null||Mt(qo()),_t();else if(i==="eyedrop")Ja(_r);else if(i==="recent"){const a=o==null?void 0:o.getAttribute("data-color");a&&_r(a)}})}function _r(t){const e=Ro(t);Et=e.h,zt=e.s,Ht=e.v,we()}function zs(t,e){const n=t.getBoundingClientRect();zt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),Ht=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),we()}function Hs(t,e){const n=t.getBoundingClientRect();Et=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,we()}function jo(t){if(!Y)return;const e=t.target;e instanceof HTMLElement&&Y.contains(e)||_t()}function Wo(t){t.key==="Escape"?(t.preventDefault(),_t()):t.key==="Enter"&&(t.preventDefault(),Mt==null||Mt(qo()),_t())}const Ce=8,Xt=6,Uo=32,Br=16,Ie=4,Xo=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function qr(t,e,n,r){let{x:o,y:i,width:a,height:s}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,a-=n):(t==="ne"||t==="e"||t==="se")&&(a+=n),t==="nw"||t==="n"||t==="ne"?(i+=r,s-=r):(t==="sw"||t==="s"||t==="se")&&(s+=r),a<Xt&&(o=e.x+e.width-Xt,a=Xt),s<Xt&&(i=e.y+e.height-Xt,s=Xt),{x:o,y:i,width:a,height:s}}function Yo(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of t)i.x<e&&(e=i.x),i.y<n&&(n=i.y),i.x>r&&(r=i.x),i.y>o&&(o=i.y);return{x:e,y:n,width:r-e,height:o-n}}function _s(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const M={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},O="http://www.w3.org/2000/svg";function Go(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const i=r.tagName.toLowerCase(),a=r.parentElement,s=r.tagName;if(a){const c=Array.from(a.children).filter(l=>{var u;return l.tagName===s&&!((u=l.matches)!=null&&u.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${i}:nth-of-type(${l})`)}else n.unshift(i)}else n.unshift(i);r=a,o++}return n.join(" > ")}function lr(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function Bs(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const qs=["data-testid","data-test","id","aria-label"];function js(t){for(const e of qs){const n=t.getAttribute(e);if(n&&n.length>0)return{kind:"stable-attr",cssSelector:`[${e}="${Bs(n)}"]`}}return{kind:"stable-attr",cssSelector:Go(t)}}function Ws(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!lr(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function Us(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?Go(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Xs(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!lr(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function Ys(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const i of Array.from(r.children)){if(i===t)continue;const a=(i.textContent??"").trim();if(a.length>0&&a.length<60&&n.push(a),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function Gs(t,e){var s;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||lr(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const i=(((s=n.parentElement)==null?void 0:s.textContent)??"").trim();return t.nearbyText.some(c=>i.includes(c))?n:null}function Vs(t){return{layer1:js(t),layer2:Us(t),layer3:Ys(t)}}function Ks(t,e){const n=e.ownerDocument;return n?Vo(t,n)===e:!1}function fe(t){const e=Ko(t.framePath);return e?Vo(t,e):null}function Vo(t,e){return Ws(t.layer1,e)??Xs(t.layer2,e)??Gs(t.layer3,e)}function Ko(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function Zs(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function U(){const t=mt();if(!t||!t.selectors)return null;try{const e=fe(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function Qs(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function vn(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function Js(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function yn(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function Zo(t){if(!t.bounds)return t;const e=U();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function tc(t){if(!t.points)return t;const e=U();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function ec(){document.removeEventListener("mousemove",ur,!0),document.removeEventListener("mouseup",dr,!0),document.removeEventListener("keydown",Jo,!0)}function nc(){document.addEventListener("keydown",Jo,!0)}function rc(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="shape")return;const r=vn(n,U());M.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},xn()}function oc(t){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const e=T(M.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;M.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},xn()}function Qo(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,i=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;M.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:i},xn()}function ic(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="freedraw")return;const r=yn(n,U()),o=Yo(r);!o||o.width===0||o.height===0||(M.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(i=>({...i}))},xn())}function xn(){document.addEventListener("mousemove",ur,!0),document.addEventListener("mouseup",dr,!0)}function ur(t){const{activeId:e,dragState:n}=M;if(!e||!n)return;t.preventDefault();const r=T(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,i=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const a=qr(n.handle,n.startBounds,o,i);C(e,Zo({bounds:a}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const a=n.startBounds,s=qr(n.handle,a,o,i),c=a.width===0?1:s.width/a.width,l=a.height===0?1:s.height/a.height,u=n.startPoints.map(f=>({x:s.x+(f.x-a.x)*c,y:s.y+(f.y-a.y)*l}));C(e,tc({points:u}))}else if(n.kind==="rotate"){const a=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let s=(n.startRotation+(a-n.startMouseAngle))%360;s<0&&(s+=360),r.kind==="shape"?C(e,{rotate:s}):r.kind==="freedraw"?C(e,{rotate:s}):r.kind==="text"&&C(e,{rotate:s})}}function dr(){document.removeEventListener("mousemove",ur,!0),document.removeEventListener("mouseup",dr,!0),M.dragState=null}function Jo(t){var o;const{activeId:e}=M;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),_o(e);return}if(t.key.startsWith("Arrow")){const i=T(e);if(!i||i.kind!=="shape")return;const a=t.shiftKey?10:1,s=t.key==="ArrowLeft"?-a:t.key==="ArrowRight"?a:0,c=t.key==="ArrowUp"?-a:t.key==="ArrowDown"?a:0;if(s!==0||c!==0){t.preventDefault();const l=vn(i,U());C(e,Zo({bounds:{...i.bounds,x:l.x+s,y:l.y+c}}))}}}}function ti(t,e,n,r,o){const i=document.createElementNS(O,"rect");return i.setAttribute("x",String(t-Ce/2)),i.setAttribute("y",String(e-Ce/2)),i.setAttribute("width",String(Ce)),i.setAttribute("height",String(Ce)),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),i.style.cursor=r,i.style.pointerEvents="auto",i.setAttribute("pointer-events","all"),i.addEventListener("mousedown",a=>o(a,n)),i}function ei(t,e,n){const r=document.createElementNS(O,"g"),o=e-18,i=e-Uo,a=12,s=document.createElementNS(O,"line");s.setAttribute("x1",String(t)),s.setAttribute("y1",String(e)),s.setAttribute("x2",String(t)),s.setAttribute("y2",String(o)),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1"),s.setAttribute("stroke-dasharray","2 3"),s.style.pointerEvents="none",r.appendChild(s);const c=document.createElementNS(O,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(i+1)),c.setAttribute("r",String(a)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(O,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(i)),l.setAttribute("r",String(a)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const u=t-8,f=i-8,d=document.createElementNS(O,"path");d.setAttribute("d",`M ${u+4} ${f+11} A 5 5 0 1 1 ${u+11} ${f+4}`),d.setAttribute("fill","none"),d.setAttribute("stroke","oklch(0.48 0.085 245)"),d.setAttribute("stroke-width","1.5"),d.setAttribute("stroke-linecap","round"),d.setAttribute("stroke-linejoin","round"),d.style.pointerEvents="none",r.appendChild(d);const p=document.createElementNS(O,"path");return p.setAttribute("d",`M ${u+11} ${f+1.5} L ${u+14} ${f+4} L ${u+11} ${f+6.5} Z`),p.setAttribute("fill","oklch(0.48 0.085 245)"),p.setAttribute("stroke","oklch(0.48 0.085 245)"),p.setAttribute("stroke-width","1.5"),p.setAttribute("stroke-linejoin","round"),p.style.pointerEvents="none",r.appendChild(p),l.addEventListener("mousedown",h=>n(h)),r}function pr(t,e){const n=document.createElementNS(O,"g"),r=t.x-Br,o=t.y-Br;return n.appendChild(ac(r,o,e)),n}function ac(t,e,n){const r=document.createElementNS(O,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(O,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const i=document.createElementNS(O,"circle");i.setAttribute("cx",String(t)),i.setAttribute("cy",String(e)),i.setAttribute("r","12"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.92 0.008 240)"),i.setAttribute("stroke-width","1"),r.appendChild(i);const a=t-6,s=e-6,c=document.createElementNS(O,"path");return c.setAttribute("d",[`M ${a+1.5} ${s+3.5} L ${a+10.5} ${s+3.5}`,`M ${a+4.5} ${s+3.5} L ${a+4.5} ${s+2} L ${a+7.5} ${s+2} L ${a+7.5} ${s+3.5}`,`M ${a+3} ${s+3.5} L ${a+3.5} ${s+10.5} A 0.8 0.8 0 0 0 ${a+4.3} ${s+11} L ${a+7.7} ${s+11} A 0.8 0.8 0 0 0 ${a+8.5} ${s+10.5} L ${a+9} ${s+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function fr(t){const e=document.createElementNS(O,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function wn(){const{host:t,activeId:e,activeMode:n}=M;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=T(e);if(!r){Kn();return}if(n==="freedraw"&&r.kind==="freedraw"){uc(t,r);return}if(n==="text"&&r.kind==="text"){lc(t,r);return}if(r.kind!=="shape"){Kn();return}sc(t,r)}function sc(t,e){const n=vn(e,U()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,i=r.x+r.width/2,a=r.y+r.height/2,s=document.createElementNS(O,"g");o&&s.setAttribute("transform",`rotate(${o} ${i} ${a})`),s.appendChild(fr(r));for(const c of Xo){const{x:l,y:u}=c.offset(r);s.appendChild(ti(l,u,c.name,c.cursor,rc))}s.appendChild(cc(r)),t.appendChild(s),t.appendChild(pr(r,hr))}function cc(t){const e=t.x+t.width/2,n=t.y-Uo,r=document.createElementNS(O,"g"),o=document.createElementNS(O,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const i=document.createElementNS(O,"g");i.style.cursor="grab",i.style.pointerEvents="auto",i.setAttribute("pointer-events","all");const a=document.createElementNS(O,"circle");a.setAttribute("cx",String(e)),a.setAttribute("cy",String(n)),a.setAttribute("r","9"),a.setAttribute("fill","oklch(1 0 0)"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","2"),i.appendChild(a);const s=document.createElementNS(O,"path");return s.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),s.setAttribute("fill","none"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","1.4"),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.style.pointerEvents="none",i.appendChild(s),i.addEventListener("mousedown",c=>oc(c)),r.appendChild(i),r}function lc(t,e){const n=_s(e.id);if(!n)return;const r=ni(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(fr(r)),t.appendChild(ei(o,r.y,a=>Qo(a,()=>({x:o,y:i})))),t.appendChild(pr(r,hr))}function uc(t,e){const n=yn(e,U()),r=Yo(n);if(!r)return;const o=ni(r),i=o.x+o.width/2,a=o.y+o.height/2;t.appendChild(fr(o));for(const s of Xo){if(s.name!=="nw"&&s.name!=="ne"&&s.name!=="sw"&&s.name!=="se")continue;const{x:c,y:l}=s.offset(o);t.appendChild(ti(c,l,s.name,s.cursor,ic))}t.appendChild(ei(i,o.y,s=>Qo(s,()=>({x:i,y:a})))),t.appendChild(pr(o,hr))}function ni(t){return{x:t.x-Ie,y:t.y-Ie,width:t.width+Ie*2,height:t.height+Ie*2}}function hr(){const t=M.activeId;t&&_o(t)}function dc(t){const e=T(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const i=document.querySelectorAll(o);if(i.length===0)return;const a=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;i.forEach(s=>{s.style.animation=""}),i[0].getBoundingClientRect(),i.forEach(s=>{s.style.transformBox="fill-box",s.style.transformOrigin="center",s.style.setProperty("--wp-final-rot",`${a}deg`),s.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{s.style.animation="",s.style.transformBox="",s.style.transformOrigin="",s.removeEventListener("animationend",c),s.removeEventListener("animationcancel",c)};s.addEventListener("animationend",c),s.addEventListener("animationcancel",c)})}function pc(t){const e=T(t);!e||e.kind!=="shape"||(M.activeId=t,M.activeMode="shape",mr(),wn())}function fc(t){const e=T(t);!e||e.kind!=="freedraw"||(M.activeId=t,M.activeMode="freedraw",mr(),wn())}function hc(t){const e=T(t);!e||e.kind!=="text"||(M.activeId=t,M.activeMode="text",mr(),wn())}function Kn(){var t;M.host&&(ec(),(t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,M.host.remove(),M.host=null,M.activeId=null,M.activeMode="shape",M.dragState=null)}function mc(t){return M.host!==null&&t!==null&&M.host.contains(t)}function mr(){if(M.host)return;const t=document.createElementNS(O,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),M.host=t,nc(),M.unsubscribeScenario=ye(wn)}const gc=400,bc=0;function vc(t){return{kind:t,durationMs:gc,delayMs:bc}}function yc(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const jr=10,xc=46,ri=12,oi=36,ii=0,ai=20,wc=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],kc=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],Sc=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}],Ac=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],E={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function yt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function si(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,color:t}}):n.kind==="shape"?C(e,{stroke:t}):n.kind==="freedraw"&&C(e,{stroke:t}))}function ci(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&C(e,{fill:t}))}function li(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,borderColor:t}})}function Ec(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontFamily:t}})}function Mc(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontSize:t}})}function $c(){const t=E.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,bold:!e.style.bold}})}function Lc(){const t=E.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Tc(t){const e=E.activeId;e&&C(e,{entryAnimation:t==="none"?void 0:vc(t)})}function Cc(t){const e=E.activeId;if(!e)return;const n=T(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?C(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?C(e,{fillOpacity:r}):n.kind==="freedraw"&&C(e,{strokeOpacity:r})}function Ic(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="shape"?C(e,{strokeWidth:t}):n.kind==="freedraw"&&C(e,{strokeWidth:t}))}function Pc(){const{shadow:t}=E;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=a=>{r&&Rn(e,a.clientX)},i=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",i,!0)};n.addEventListener("mousedown",a=>{r=!0,Rn(e,a.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0),a.preventDefault()}),e.addEventListener("mousedown",a=>{const s=a.target;s instanceof Element&&s.closest('[data-region="alpha-thumb"]')||(Rn(e,a.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0))})}function Rn(t,e){const n=t.getBoundingClientRect();Cc(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function Zn(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function Dc(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function Fn(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function zn(t,e,n){var l,u,f;const r=E.swatchMode==="muted"?wc:kc,o=[];if(n&&(t==="bg"||t==="border")){const d=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${d}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let d=0;d<r.length;d++){const p=r[d];if(!p)continue;const h=d===1,g=Fn(e,p.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${p.resolved}" style="background:${p.resolved}" aria-pressed="${g}" title="${t} ${p.resolved}"></button>
    `)}const i=P(),a=(t==="text"||t==="border"?(l=i==null?void 0:i.siteColors)==null?void 0:l.text:(u=i==null?void 0:i.siteColors)==null?void 0:u.background)??[];for(const d of a){const p=Fn(e,d);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${yt(d)}" style="background:${yt(d)}" aria-pressed="${p}" title="Site color ${yt(d)}"></button>
    `)}const s=t==="text"||t==="border"?"text":"background",c=((f=i==null?void 0:i.customColors)==null?void 0:f[s])??[];for(const d of c){const p=Fn(e,d);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${yt(d)}" style="background:${yt(d)}" aria-pressed="${p}" title="Custom ${yt(d)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${yt(d)}" title="Remove" aria-label="Remove color ${yt(d)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function gr(){const{shadow:t,activeId:e,activeKind:n}=E;if(!t||!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.querySelector('[data-region="caption"]');i&&(i.textContent=_c(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(a=>{const s=a.getAttribute("data-mode");a.setAttribute("aria-pressed",String(s===E.swatchMode))}),Oc(t,n),Nc(t,n,o),Rc(t,n,o),Fc(t,n,o),zc(t,o),Hc(t,o)}function Oc(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const i=t.querySelector('[data-region="width-row"]'),a=e==="shape"||e==="freedraw";i&&(i.hidden=!a);const s=t.querySelector('[data-region="bg-row"]');s&&(s.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const u=t.querySelector('[data-region="bg-label"]');u&&(u.textContent=e==="text"?"Bg":"Fill")}function Nc(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const i=t.querySelector('[data-region="bold"]');i&&i.setAttribute("aria-pressed",String(n.style.bold));const a=t.querySelector('[data-region="italic"]');a&&a.setAttribute("aria-pressed",String(n.style.italic===!0))}function Rc(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),i=n.strokeWidth;r&&(r.value=String(i)),o&&(o.textContent=String(i))}function Fc(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),i=t.querySelector('[data-region="border-swatches"]'),a=t.querySelector('[data-region="bg-row"]'),s=t.querySelector('[data-region="border-row"]'),c=Zn(n,"text"),l=Zn(n,"bg");if(r&&(r.innerHTML=zn("text",c,!1)),o&&!(a!=null&&a.hidden)&&(o.innerHTML=zn("bg",l,e==="text")),i&&!(s!=null&&s.hidden)&&n.kind==="text"){const u=n.style.borderColor??"#000000";i.innerHTML=zn("border",u,!0)}}function zc(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=yc(e))}function Hc(t,e){const n=Math.round(Dc(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),i=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),i&&(i.textContent=`${n}%`)}function _c(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function Bc(t){const{shadow:e,host:n}=E;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>qc(o)),e.addEventListener("change",o=>jc(o)),e.addEventListener("input",o=>Wc(o)),Pc(),document.addEventListener("mousedown",o=>Xc(o,t),!0),document.addEventListener("keydown",o=>Yc(o,t),!0)}function qc(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(E.swatchMode=c,gr());return}if(e.closest('[data-region="bold"]'))return $c();if(e.closest('[data-region="italic"]'))return Lc();if(e.closest('[data-region="effect-play"]')){E.activeId&&dc(E.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return si(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return ci(o.getAttribute("data-value")??"");const i=e.closest('[data-swatch="border"]');if(i)return li(i.getAttribute("data-value")??"");const a=e.closest('[data-action="more-colors"]');if(a instanceof HTMLElement)return Uc(a);const s=e.closest('[data-action="custom-remove"]');if(s instanceof HTMLElement){const c=s.getAttribute("data-slot"),l=s.getAttribute("data-value");c&&l&&Ls(c==="text"||c==="border"?"text":"background",l)}}function jc(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Ec(e.value):e.dataset.region==="effect"&&Tc(e.value))}function Wc(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(ri,Math.min(oi,Number(e.value)||16));Mc(n)}else if(e.dataset.region==="width"){const n=Math.max(ii,Math.min(ai,Number(e.value)||0));Ic(n)}}}function Uc(t){const{activeId:e,activeKind:n}=E;if(!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.getAttribute("data-slot");if(!i)return;const a=Zn(o,i)||"#ffffff";Ns({anchor:t,initialColor:a,onConfirm:s=>{$s(i==="text"||i==="border"?"text":"background",s),i==="text"?si(s):i==="border"?li(s):ci(s)}})}function Xc(t,e){const{host:n,activeAnchorSelector:r}=E,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||mc(o)||Rs()||r&&o instanceof Element&&o.closest(r)||(e(),_t())}function Yc(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function ui(t){const{host:e}=E;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-jr-xc;o<8&&(o=r.bottom+jr);const i=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${i}px`}function Gc(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function Vc(t,e){t==="text"?hc(e):t==="shape"?pc(e):fc(e)}function Kc(){return`
    ${qt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function Zc(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function Qc(){return[Kc(),Zc()].join(`
`)}function Jc(){return`
    <style>${Qc()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${tl()}
      ${el()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${nl()}
      <div class="divider"></div>
      ${rl()}
      ${ol()}
      ${il()}
      ${al()}
    </div>
  `}function tl(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function el(){return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Sc.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${ri}" max="${oi}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function nl(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function rl(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${ii}" max="${ai}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function ol(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Ac.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function il(){return`
    <div class="alpha-row">
      <span class="label">Alpha</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function al(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function br(t,e,n){T(t)&&(E.activeId=t,E.activeKind=n,E.activeAnchorSelector=Gc(n,t),E.host||dl(),gr(),ui(e),Vc(n,t))}function vr(){var t;E.host&&((t=E.unsubscribeScenario)==null||t.call(E),E.unsubscribeScenario=null,_t(),Kn(),E.host.remove(),E.host=null,E.shadow=null,E.activeId=null,E.activeKind=null,E.activeAnchorSelector=null)}function sl(){return E.activeId}function cl(t,e){br(t,e,"text")}function di(){vr()}function ll(t,e){br(t,e,"shape")}function ul(t,e){br(t,e,"freedraw")}function dl(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",ve),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${z+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=Jc(),E.host=t,E.shadow=e,document.body.appendChild(t),Bc(vr),E.unsubscribeScenario=ye(pl)}function pl(){const{activeId:t,host:e,activeAnchorSelector:n}=E;if(!t||!e)return;if(!T(t)){vr();return}if(gr(),n){const o=document.querySelector(n);o&&ui(o)}}const ht=20;let Xe=null,Wr=!1;function fl(){Wr||(Wr=!0,document.addEventListener("keydown",gl,!0)),hl()}async function hl(){try{const e=(await chrome.storage.local.get(Z.annotationClipboard))[Z.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(Xe=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function ml(t){try{await chrome.storage.local.set({[Z.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function gl(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||vt()!=="replay"&&(bl()||(e==="c"?vl(t):yl(t)))}function bl(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function vl(t){const e=sl();if(!e)return;const n=T(e);n&&(Xe=n,ml(n),t.preventDefault())}function yl(t){if(!Xe||!mt())return;const e=xl(Xe);xe(e),t.preventDefault()}function xl(t){switch(t.kind){case"text":return wl(t);case"shape":return kl(t);case"freedraw":return Sl(t);case"arrow":return Al(t)}}function wl(t){return{...t,id:kn("text"),position:{x:t.position.x+ht,y:t.position.y+ht},style:{...t.style}}}function kl(t){return{...t,id:kn("shape"),bounds:{...t.bounds,x:t.bounds.x+ht,y:t.bounds.y+ht}}}function Sl(t){return{...t,id:kn("freedraw"),points:t.points.map(e=>({x:e.x+ht,y:e.y+ht}))}}function Al(t){return{...t,id:kn("arrow"),from:{x:t.from.x+ht,y:t.from.y+ht},to:{x:t.to.x+ht,y:t.to.y+ht}}}function kn(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function Hn(t,e,n){if(t&&t.length){const[r,o]=e,i=Math.PI/180*n,a=Math.cos(i),s=Math.sin(i);for(const c of t){const[l,u]=c;c[0]=(l-r)*a-(u-o)*s+r,c[1]=(l-r)*s+(u-o)*a+o}}}function El(t,e){return t[0]===e[0]&&t[1]===e[1]}function Ml(t,e,n,r=1){const o=n,i=Math.max(e,.1),a=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,s=[0,0];if(o)for(const l of a)Hn(l,s,o);const c=(function(l,u,f){const d=[];for(const y of l){const A=[...y];El(A[0],A[A.length-1])||A.push([A[0][0],A[0][1]]),A.length>2&&d.push(A)}const p=[];u=Math.max(u,.1);const h=[];for(const y of d)for(let A=0;A<y.length-1;A++){const H=y[A],N=y[A+1];if(H[1]!==N[1]){const I=Math.min(H[1],N[1]);h.push({ymin:I,ymax:Math.max(H[1],N[1]),x:I===H[1]?H[0]:N[0],islope:(N[0]-H[0])/(N[1]-H[1])})}}if(h.sort(((y,A)=>y.ymin<A.ymin?-1:y.ymin>A.ymin?1:y.x<A.x?-1:y.x>A.x?1:y.ymax===A.ymax?0:(y.ymax-A.ymax)/Math.abs(y.ymax-A.ymax))),!h.length)return p;let g=[],v=h[0].ymin,x=0;for(;g.length||h.length;){if(h.length){let y=-1;for(let A=0;A<h.length&&!(h[A].ymin>v);A++)y=A;h.splice(0,y+1).forEach((A=>{g.push({s:v,edge:A})}))}if(g=g.filter((y=>!(y.edge.ymax<=v))),g.sort(((y,A)=>y.edge.x===A.edge.x?0:(y.edge.x-A.edge.x)/Math.abs(y.edge.x-A.edge.x))),(f!==1||x%u==0)&&g.length>1)for(let y=0;y<g.length;y+=2){const A=y+1;if(A>=g.length)break;const H=g[y].edge,N=g[A].edge;p.push([[Math.round(H.x),v],[Math.round(N.x),v]])}v+=f,g.forEach((y=>{y.edge.x=y.edge.x+f*y.edge.islope})),x++}return p})(a,i,r);if(o){for(const l of a)Hn(l,s,-o);(function(l,u,f){const d=[];l.forEach((p=>d.push(...p))),Hn(d,u,f)})(c,s,-o)}return c}function ke(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let i=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(i=o),Ml(t,o,r,i||1)}class yr{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=ke(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function Sn(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class $l extends yr{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=ke(e,Object.assign({},n,{hachureGap:r})),i=Math.PI/180*n.hachureAngle,a=[],s=.5*r*Math.cos(i),c=.5*r*Math.sin(i);for(const[l,u]of o)Sn([l,u])&&a.push([[l[0]-s,l[1]+c],[...u]],[[l[0]+s,l[1]-c],[...u]]);return{type:"fillSketch",ops:this.renderLines(a,n)}}}class Ll extends yr{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),i=this._fillPolygons(e,o);return r.ops=r.ops.concat(i.ops),r}}class Tl{constructor(e){this.helper=e}fillPolygons(e,n){const r=ke(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let i=n.fillWeight;i<0&&(i=n.strokeWidth/2);const a=o/4;for(const s of e){const c=Sn(s),l=c/o,u=Math.ceil(l)-1,f=c-u*o,d=(s[0][0]+s[1][0])/2-o/4,p=Math.min(s[0][1],s[1][1]);for(let h=0;h<u;h++){const g=p+f+h*o,v=d-a+2*Math.random()*a,x=g-a+2*Math.random()*a,y=this.helper.ellipse(v,x,i,i,n);r.push(...y.ops)}}return{type:"fillSketch",ops:r}}}class Cl{constructor(e){this.helper=e}fillPolygons(e,n){const r=ke(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,i=[];return e.forEach((a=>{const s=Sn(a),c=Math.floor(s/(r+o)),l=(s+o-c*(r+o))/2;let u=a[0],f=a[1];u[0]>f[0]&&(u=a[1],f=a[0]);const d=Math.atan((f[1]-u[1])/(f[0]-u[0]));for(let p=0;p<c;p++){const h=p*(r+o),g=h+r,v=[u[0]+h*Math.cos(d)+l*Math.cos(d),u[1]+h*Math.sin(d)+l*Math.sin(d)],x=[u[0]+g*Math.cos(d)+l*Math.cos(d),u[1]+g*Math.sin(d)+l*Math.sin(d)];i.push(...this.helper.doubleLineOps(v[0],v[1],x[0],x[1],n))}})),i}}class Il{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,i=ke(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(i,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((i=>{const a=Sn(i),s=Math.round(a/(2*n));let c=i[0],l=i[1];c[0]>l[0]&&(c=i[1],l=i[0]);const u=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let f=0;f<s;f++){const d=2*f*n,p=2*(f+1)*n,h=Math.sqrt(2*Math.pow(n,2)),g=[c[0]+d*Math.cos(u),c[1]+d*Math.sin(u)],v=[c[0]+p*Math.cos(u),c[1]+p*Math.sin(u)],x=[g[0]+h*Math.cos(u+Math.PI/4),g[1]+h*Math.sin(u+Math.PI/4)];o.push(...this.helper.doubleLineOps(g[0],g[1],x[0],x[1],r),...this.helper.doubleLineOps(x[0],x[1],v[0],v[1],r))}})),o}}const X={};class Pl{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const Dl=0,_n=1,Ur=2,Pe={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Bn(t,e){return t.type===e}function xr(t){const e=[],n=(function(a){const s=new Array;for(;a!=="";)if(a.match(/^([ \t\r\n,]+)/))a=a.substr(RegExp.$1.length);else if(a.match(/^([aAcChHlLmMqQsStTvVzZ])/))s[s.length]={type:Dl,text:RegExp.$1},a=a.substr(RegExp.$1.length);else{if(!a.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];s[s.length]={type:_n,text:`${parseFloat(RegExp.$1)}`},a=a.substr(RegExp.$1.length)}return s[s.length]={type:Ur,text:""},s})(t);let r="BOD",o=0,i=n[o];for(;!Bn(i,Ur);){let a=0;const s=[];if(r==="BOD"){if(i.text!=="M"&&i.text!=="m")return xr("M0,0"+t);o++,a=Pe[i.text],r=i.text}else Bn(i,_n)?a=Pe[r]:(o++,a=Pe[i.text],r=i.text);if(!(o+a<n.length))throw new Error("Path data ended short");for(let c=o;c<o+a;c++){const l=n[c];if(!Bn(l,_n))throw new Error("Param not a number: "+r+","+l.text);s[s.length]=+l.text}if(typeof Pe[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:s};e.push(c),o+=a,i=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function pi(t){let e=0,n=0,r=0,o=0;const i=[];for(const{key:a,data:s}of t)switch(a){case"M":i.push({key:"M",data:[...s]}),[e,n]=s,[r,o]=s;break;case"m":e+=s[0],n+=s[1],i.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":i.push({key:"L",data:[...s]}),[e,n]=s;break;case"l":e+=s[0],n+=s[1],i.push({key:"L",data:[e,n]});break;case"C":i.push({key:"C",data:[...s]}),e=s[4],n=s[5];break;case"c":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":i.push({key:"Q",data:[...s]}),e=s[2],n=s[3];break;case"q":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":i.push({key:"A",data:[...s]}),e=s[5],n=s[6];break;case"a":e+=s[5],n+=s[6],i.push({key:"A",data:[s[0],s[1],s[2],s[3],s[4],e,n]});break;case"H":i.push({key:"H",data:[...s]}),e=s[0];break;case"h":e+=s[0],i.push({key:"H",data:[e]});break;case"V":i.push({key:"V",data:[...s]}),n=s[0];break;case"v":n+=s[0],i.push({key:"V",data:[n]});break;case"S":i.push({key:"S",data:[...s]}),e=s[2],n=s[3];break;case"s":{const c=s.map(((l,u)=>u%2?l+n:l+e));i.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":i.push({key:"T",data:[...s]}),e=s[0],n=s[1];break;case"t":e+=s[0],n+=s[1],i.push({key:"T",data:[e,n]});break;case"Z":case"z":i.push({key:"Z",data:[]}),e=r,n=o}return i}function fi(t){const e=[];let n="",r=0,o=0,i=0,a=0,s=0,c=0;for(const{key:l,data:u}of t){switch(l){case"M":e.push({key:"M",data:[...u]}),[r,o]=u,[i,a]=u;break;case"C":e.push({key:"C",data:[...u]}),r=u[4],o=u[5],s=u[2],c=u[3];break;case"L":e.push({key:"L",data:[...u]}),[r,o]=u;break;case"H":r=u[0],e.push({key:"L",data:[r,o]});break;case"V":o=u[0],e.push({key:"L",data:[r,o]});break;case"S":{let f=0,d=0;n==="C"||n==="S"?(f=r+(r-s),d=o+(o-c)):(f=r,d=o),e.push({key:"C",data:[f,d,...u]}),s=u[0],c=u[1],r=u[2],o=u[3];break}case"T":{const[f,d]=u;let p=0,h=0;n==="Q"||n==="T"?(p=r+(r-s),h=o+(o-c)):(p=r,h=o);const g=r+2*(p-r)/3,v=o+2*(h-o)/3,x=f+2*(p-f)/3,y=d+2*(h-d)/3;e.push({key:"C",data:[g,v,x,y,f,d]}),s=p,c=h,r=f,o=d;break}case"Q":{const[f,d,p,h]=u,g=r+2*(f-r)/3,v=o+2*(d-o)/3,x=p+2*(f-p)/3,y=h+2*(d-h)/3;e.push({key:"C",data:[g,v,x,y,p,h]}),s=f,c=d,r=p,o=h;break}case"A":{const f=Math.abs(u[0]),d=Math.abs(u[1]),p=u[2],h=u[3],g=u[4],v=u[5],x=u[6];f===0||d===0?(e.push({key:"C",data:[r,o,v,x,v,x]}),r=v,o=x):(r!==v||o!==x)&&(hi(r,o,v,x,f,d,p,h,g).forEach((function(y){e.push({key:"C",data:y})})),r=v,o=x);break}case"Z":e.push({key:"Z",data:[]}),r=i,o=a}n=l}return e}function se(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function hi(t,e,n,r,o,i,a,s,c,l){const u=(f=a,Math.PI*f/180);var f;let d=[],p=0,h=0,g=0,v=0;if(l)[p,h,g,v]=l;else{[t,e]=se(t,e,-u),[n,r]=se(n,r,-u);const J=(t-n)/2,_=(e-r)/2;let dt=J*J/(o*o)+_*_/(i*i);dt>1&&(dt=Math.sqrt(dt),o*=dt,i*=dt);const Wt=o*o,Ut=i*i,Oa=Wt*Ut-Wt*_*_-Ut*J*J,Na=Wt*_*_+Ut*J*J,Pr=(s===c?-1:1)*Math.sqrt(Math.abs(Oa/Na));g=Pr*o*_/i+(t+n)/2,v=Pr*-i*J/o+(e+r)/2,p=Math.asin(parseFloat(((e-v)/i).toFixed(9))),h=Math.asin(parseFloat(((r-v)/i).toFixed(9))),t<g&&(p=Math.PI-p),n<g&&(h=Math.PI-h),p<0&&(p=2*Math.PI+p),h<0&&(h=2*Math.PI+h),c&&p>h&&(p-=2*Math.PI),!c&&h>p&&(h-=2*Math.PI)}let x=h-p;if(Math.abs(x)>120*Math.PI/180){const J=h,_=n,dt=r;h=c&&h>p?p+120*Math.PI/180*1:p+120*Math.PI/180*-1,d=hi(n=g+o*Math.cos(h),r=v+i*Math.sin(h),_,dt,o,i,a,0,c,[h,J,g,v])}x=h-p;const y=Math.cos(p),A=Math.sin(p),H=Math.cos(h),N=Math.sin(h),I=Math.tan(x/4),Q=4/3*o*I,ut=4/3*i*I,Le=[t,e],rt=[t+Q*A,e-ut*y],Tt=[n+Q*N,r-ut*H],Ir=[n,r];if(rt[0]=2*Le[0]-rt[0],rt[1]=2*Le[1]-rt[1],l)return[rt,Tt,Ir].concat(d);{d=[rt,Tt,Ir].concat(d);const J=[];for(let _=0;_<d.length;_+=3){const dt=se(d[_][0],d[_][1],u),Wt=se(d[_+1][0],d[_+1][1],u),Ut=se(d[_+2][0],d[_+2][1],u);J.push([dt[0],dt[1],Wt[0],Wt[1],Ut[0],Ut[1]])}return J}}const Ol={randOffset:function(t,e){return w(t,e)},randOffsetWithRange:function(t,e,n){return Ye(t,e,n)},ellipse:function(t,e,n,r,o){const i=gi(n,r,o);return Qn(t,e,o,i).opset},doubleLineOps:function(t,e,n,r,o){return Lt(t,e,n,r,o,!0)}};function mi(t,e,n,r,o){return{type:"path",ops:Lt(t,e,n,r,o)}}function Be(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let i=0;i<r-1;i++)o.push(...Lt(t[i][0],t[i][1],t[i+1][0],t[i+1][1],n));return e&&o.push(...Lt(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?mi(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function Nl(t,e,n,r,o){return(function(i,a){return Be(i,!0,a)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function Xr(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=De(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:De(n[0],1.5*(1+.22*e.roughness),Vr(e));for(let i=1;i<n.length;i++){const a=n[i];if(a.length){const s=De(a,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:De(a,1.5*(1+.22*e.roughness),Vr(e));for(const l of s)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function gi(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),i=2*Math.PI/o;let a=Math.abs(t/2),s=Math.abs(e/2);const c=1-n.curveFitting;return a+=w(a*c,n),s+=w(s*c,n),{increment:i,rx:a,ry:s}}function Qn(t,e,n,r){const[o,i]=Kr(r.increment,t,e,r.rx,r.ry,1,r.increment*Ye(.1,Ye(.4,1,n),n),n);let a=Ge(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[s]=Kr(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=Ge(s,null,n);a=a.concat(c)}return{estimatedPoints:i,opset:{type:"path",ops:a}}}function Yr(t,e,n,r,o,i,a,s,c){const l=t,u=e;let f=Math.abs(n/2),d=Math.abs(r/2);f+=w(.01*f,c),d+=w(.01*d,c);let p=o,h=i;for(;p<0;)p+=2*Math.PI,h+=2*Math.PI;h-p>2*Math.PI&&(p=0,h=2*Math.PI);const g=2*Math.PI/c.curveStepCount,v=Math.min(g/2,(h-p)/2),x=Zr(v,l,u,f,d,p,h,1,c);if(!c.disableMultiStroke){const y=Zr(v,l,u,f,d,p,h,1.5,c);x.push(...y)}return a&&(s?x.push(...Lt(l,u,l+f*Math.cos(p),u+d*Math.sin(p),c),...Lt(l,u,l+f*Math.cos(h),u+d*Math.sin(h),c)):x.push({op:"lineTo",data:[l,u]},{op:"lineTo",data:[l+f*Math.cos(p),u+d*Math.sin(p)]})),{type:"path",ops:x}}function Gr(t,e){const n=fi(pi(xr(t))),r=[];let o=[0,0],i=[0,0];for(const{key:a,data:s}of n)switch(a){case"M":i=[s[0],s[1]],o=[s[0],s[1]];break;case"L":r.push(...Lt(i[0],i[1],s[0],s[1],e)),i=[s[0],s[1]];break;case"C":{const[c,l,u,f,d,p]=s;r.push(...Rl(c,l,u,f,d,p,i,e)),i=[d,p];break}case"Z":r.push(...Lt(i[0],i[1],o[0],o[1],e)),i=[o[0],o[1]]}return{type:"path",ops:r}}function qn(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,i=r.length;if(i>2){n.push({op:"move",data:[r[0][0]+w(o,e),r[0][1]+w(o,e)]});for(let a=1;a<i;a++)n.push({op:"lineTo",data:[r[a][0]+w(o,e),r[a][1]+w(o,e)]})}}return{type:"fillPath",ops:n}}function Yt(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!X[o])switch(o){case"zigzag":X[o]||(X[o]=new $l(r));break;case"cross-hatch":X[o]||(X[o]=new Ll(r));break;case"dots":X[o]||(X[o]=new Tl(r));break;case"dashed":X[o]||(X[o]=new Cl(r));break;case"zigzag-line":X[o]||(X[o]=new Il(r));break;default:o="hachure",X[o]||(X[o]=new yr(r))}return X[o]})(e,Ol).fillPolygons(t,e)}function Vr(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function bi(t){return t.randomizer||(t.randomizer=new Pl(t.seed||0)),t.randomizer.next()}function Ye(t,e,n,r=1){return n.roughness*r*(bi(n)*(e-t)+t)}function w(t,e,n=1){return Ye(-t,t,e,n)}function Lt(t,e,n,r,o,i=!1){const a=i?o.disableMultiStrokeFill:o.disableMultiStroke,s=Jn(t,e,n,r,o,!0,!1);if(a)return s;const c=Jn(t,e,n,r,o,!0,!0);return s.concat(c)}function Jn(t,e,n,r,o,i,a){const s=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(s);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let u=o.maxRandomnessOffset||0;u*u*100>s&&(u=c/10);const f=u/2,d=.2+.2*bi(o);let p=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;p=w(p,o,l),h=w(h,o,l);const g=[],v=()=>w(f,o,l),x=()=>w(u,o,l),y=o.preserveVertices;return a?g.push({op:"move",data:[t+(y?0:v()),e+(y?0:v())]}):g.push({op:"move",data:[t+(y?0:w(u,o,l)),e+(y?0:w(u,o,l))]}),a?g.push({op:"bcurveTo",data:[p+t+(n-t)*d+v(),h+e+(r-e)*d+v(),p+t+2*(n-t)*d+v(),h+e+2*(r-e)*d+v(),n+(y?0:v()),r+(y?0:v())]}):g.push({op:"bcurveTo",data:[p+t+(n-t)*d+x(),h+e+(r-e)*d+x(),p+t+2*(n-t)*d+x(),h+e+2*(r-e)*d+x(),n+(y?0:x()),r+(y?0:x())]}),g}function De(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]),r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]),o===t.length-1&&r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]);return Ge(r,null,n)}function Ge(t,e,n){const r=t.length,o=[];if(r>3){const i=[],a=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let s=1;s+2<r;s++){const c=t[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*t[s+1][0]-a*t[s-1][0])/6,c[1]+(a*t[s+1][1]-a*t[s-1][1])/6],i[2]=[t[s+1][0]+(a*t[s][0]-a*t[s+2][0])/6,t[s+1][1]+(a*t[s][1]-a*t[s+2][1])/6],i[3]=[t[s+1][0],t[s+1][1]],o.push({op:"bcurveTo",data:[i[1][0],i[1][1],i[2][0],i[2][1],i[3][0],i[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...Jn(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function Kr(t,e,n,r,o,i,a,s){const c=[],l=[];if(s.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let u=0;u<=2*Math.PI;u+=t){const f=[e+r*Math.cos(u),n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const u=w(.5,s)-Math.PI/2;l.push([w(i,s)+e+.9*r*Math.cos(u-t),w(i,s)+n+.9*o*Math.sin(u-t)]);const f=2*Math.PI+u-.01;for(let d=u;d<f;d+=t){const p=[w(i,s)+e+r*Math.cos(d),w(i,s)+n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([w(i,s)+e+r*Math.cos(u+2*Math.PI+.5*a),w(i,s)+n+o*Math.sin(u+2*Math.PI+.5*a)]),l.push([w(i,s)+e+.98*r*Math.cos(u+a),w(i,s)+n+.98*o*Math.sin(u+a)]),l.push([w(i,s)+e+.9*r*Math.cos(u+.5*a),w(i,s)+n+.9*o*Math.sin(u+.5*a)])}return[l,c]}function Zr(t,e,n,r,o,i,a,s,c){const l=i+w(.1,c),u=[];u.push([w(s,c)+e+.9*r*Math.cos(l-t),w(s,c)+n+.9*o*Math.sin(l-t)]);for(let f=l;f<=a;f+=t)u.push([w(s,c)+e+r*Math.cos(f),w(s,c)+n+o*Math.sin(f)]);return u.push([e+r*Math.cos(a),n+o*Math.sin(a)]),u.push([e+r*Math.cos(a),n+o*Math.sin(a)]),Ge(u,null,c)}function Rl(t,e,n,r,o,i,a,s){const c=[],l=[s.maxRandomnessOffset||1,(s.maxRandomnessOffset||1)+.3];let u=[0,0];const f=s.disableMultiStroke?1:2,d=s.preserveVertices;for(let p=0;p<f;p++)p===0?c.push({op:"move",data:[a[0],a[1]]}):c.push({op:"move",data:[a[0]+(d?0:w(l[0],s)),a[1]+(d?0:w(l[0],s))]}),u=d?[o,i]:[o+w(l[p],s),i+w(l[p],s)],c.push({op:"bcurveTo",data:[t+w(l[p],s),e+w(l[p],s),n+w(l[p],s),r+w(l[p],s),u[0],u[1]]});return c}function ce(t){return[...t]}function Qr(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(ce(t[0]),ce(t[1]),ce(t[2]),ce(t[2]));else{const o=[];o.push(t[0],t[0]);for(let s=1;s<t.length;s++)o.push(t[s]),s===t.length-1&&o.push(t[s]);const i=[],a=1-e;r.push(ce(o[0]));for(let s=1;s+2<o.length;s++){const c=o[s];i[0]=[c[0],c[1]],i[1]=[c[0]+(a*o[s+1][0]-a*o[s-1][0])/6,c[1]+(a*o[s+1][1]-a*o[s-1][1])/6],i[2]=[o[s+1][0]+(a*o[s][0]-a*o[s+2][0])/6,o[s+1][1]+(a*o[s][1]-a*o[s+2][1])/6],i[3]=[o[s+1][0],o[s+1][1]],r.push(i[1],i[2],i[3])}}return r}function qe(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function Fl(t,e,n){const r=qe(e,n);if(r===0)return qe(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),qe(t,It(e,n,o))}function It(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function tr(t,e,n,r){const o=r||[];if((function(s,c){const l=s[c+0],u=s[c+1],f=s[c+2],d=s[c+3];let p=3*u[0]-2*l[0]-d[0];p*=p;let h=3*u[1]-2*l[1]-d[1];h*=h;let g=3*f[0]-2*d[0]-l[0];g*=g;let v=3*f[1]-2*d[1]-l[1];return v*=v,p<g&&(p=g),h<v&&(h=v),p+h})(t,e)<n){const s=t[e+0];o.length?(i=o[o.length-1],a=s,Math.sqrt(qe(i,a))>1&&o.push(s)):o.push(s),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],u=t[e+2],f=t[e+3],d=It(c,l,.5),p=It(l,u,.5),h=It(u,f,.5),g=It(d,p,.5),v=It(p,h,.5),x=It(g,v,.5);tr([c,d,g,x],0,n,o),tr([x,v,h,f],0,n,o)}var i,a;return o}function zl(t,e){return Ve(t,0,t.length,e)}function Ve(t,e,n,r,o){const i=o||[],a=t[e],s=t[n-1];let c=0,l=1;for(let u=e+1;u<n-1;++u){const f=Fl(t[u],a,s);f>c&&(c=f,l=u)}return Math.sqrt(c)>r?(Ve(t,e,l+1,r,i),Ve(t,l,n,r,i)):(i.length||i.push(a),i.push(s)),i}function jn(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let i=0;i<o;i++)tr(t,3*i,e,r);return n&&n>0?Ve(r,0,r.length,n):r}const G="none";class Ke{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,i){const a=this._o(i);return this._d("line",[mi(e,n,r,o,a)],a)}rectangle(e,n,r,o,i){const a=this._o(i),s=[],c=Nl(e,n,r,o,a);if(a.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];a.fillStyle==="solid"?s.push(qn([l],a)):s.push(Yt([l],a))}return a.stroke!==G&&s.push(c),this._d("rectangle",s,a)}ellipse(e,n,r,o,i){const a=this._o(i),s=[],c=gi(r,o,a),l=Qn(e,n,a,c);if(a.fill)if(a.fillStyle==="solid"){const u=Qn(e,n,a,c).opset;u.type="fillPath",s.push(u)}else s.push(Yt([l.estimatedPoints],a));return a.stroke!==G&&s.push(l.opset),this._d("ellipse",s,a)}circle(e,n,r,o){const i=this.ellipse(e,n,r,r,o);return i.shape="circle",i}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[Be(e,!1,r)],r)}arc(e,n,r,o,i,a,s=!1,c){const l=this._o(c),u=[],f=Yr(e,n,r,o,i,a,s,!0,l);if(s&&l.fill)if(l.fillStyle==="solid"){const d=Object.assign({},l);d.disableMultiStroke=!0;const p=Yr(e,n,r,o,i,a,!0,!1,d);p.type="fillPath",u.push(p)}else u.push((function(d,p,h,g,v,x,y){const A=d,H=p;let N=Math.abs(h/2),I=Math.abs(g/2);N+=w(.01*N,y),I+=w(.01*I,y);let Q=v,ut=x;for(;Q<0;)Q+=2*Math.PI,ut+=2*Math.PI;ut-Q>2*Math.PI&&(Q=0,ut=2*Math.PI);const Le=(ut-Q)/y.curveStepCount,rt=[];for(let Tt=Q;Tt<=ut;Tt+=Le)rt.push([A+N*Math.cos(Tt),H+I*Math.sin(Tt)]);return rt.push([A+N*Math.cos(ut),H+I*Math.sin(ut)]),rt.push([A,H]),Yt([rt],y)})(e,n,r,o,i,a,l));return l.stroke!==G&&u.push(f),this._d("arc",u,l)}curve(e,n){const r=this._o(n),o=[],i=Xr(e,r);if(r.fill&&r.fill!==G)if(r.fillStyle==="solid"){const a=Xr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(a.ops)})}else{const a=[],s=e;if(s.length){const c=typeof s[0][0]=="number"?[s]:s;for(const l of c)l.length<3?a.push(...l):l.length===3?a.push(...jn(Qr([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):a.push(...jn(Qr(l),10,(1+r.roughness)/2))}a.length&&o.push(Yt([a],r))}return r.stroke!==G&&o.push(i),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],i=Be(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(qn([e],r)):o.push(Yt([e],r))),r.stroke!==G&&o.push(i),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const i=r.fill&&r.fill!=="transparent"&&r.fill!==G,a=r.stroke!==G,s=!!(r.simplification&&r.simplification<1),c=(function(u,f,d){const p=fi(pi(xr(u))),h=[];let g=[],v=[0,0],x=[];const y=()=>{x.length>=4&&g.push(...jn(x,f)),x=[]},A=()=>{y(),g.length&&(h.push(g),g=[])};for(const{key:N,data:I}of p)switch(N){case"M":A(),v=[I[0],I[1]],g.push(v);break;case"L":y(),g.push([I[0],I[1]]);break;case"C":if(!x.length){const Q=g.length?g[g.length-1]:v;x.push([Q[0],Q[1]])}x.push([I[0],I[1]]),x.push([I[2],I[3]]),x.push([I[4],I[5]]);break;case"Z":y(),g.push([v[0],v[1]])}if(A(),!d)return h;const H=[];for(const N of h){const I=zl(N,d);I.length&&H.push(I)}return H})(e,1,s?4-4*(r.simplification||1):(1+r.roughness)/2),l=Gr(e,r);if(i)if(r.fillStyle==="solid")if(c.length===1){const u=Gr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(u.ops)})}else o.push(qn(c,r));else o.push(Yt(c,r));return a&&(s?c.forEach((u=>{o.push(Be(u,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const i=typeof n=="number"&&n>=0?o.data.map((a=>+a.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${i[0]} ${i[1]} `;break;case"bcurveTo":r+=`C${i[0]} ${i[1]}, ${i[2]} ${i[3]}, ${i[4]} ${i[5]} `;break;case"lineTo":r+=`L${i[0]} ${i[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const i of n){let a=null;switch(i.type){case"path":a={d:this.opsToPath(i),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:G};break;case"fillPath":a={d:this.opsToPath(i),stroke:G,strokeWidth:0,fill:r.fill||G};break;case"fillSketch":a=this.fillSketch(i,r)}a&&o.push(a)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||G,strokeWidth:r,fill:G}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class Hl{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new Ke(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,i=e.options.fixedDecimalPlaceDigits;for(const a of n)switch(a.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,a,i),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const s=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,a,i,s),o.restore();break}case"fillSketch":this.fillSketch(o,a,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const i of n.ops){const a=typeof r=="number"&&r>=0?i.data.map((s=>+s.toFixed(r))):i.data;switch(i.op){case"move":e.moveTo(a[0],a[1]);break;case"bcurveTo":e.bezierCurveTo(a[0],a[1],a[2],a[3],a[4],a[5]);break;case"lineTo":e.lineTo(a[0],a[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a),a}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a),a}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a),a}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i),i}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const Oe="http://www.w3.org/2000/svg";class _l{constructor(e,n){this.svg=e,this.gen=new Ke(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,i=o.createElementNS(Oe,"g"),a=e.options.fixedDecimalPlaceDigits;for(const s of n){let c=null;switch(s.type){case"path":c=o.createElementNS(Oe,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(Oe,"path"),c.setAttribute("d",this.opsToPath(s,a)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,s,r)}c&&i.appendChild(c)}return i}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const i=e.createElementNS(Oe,"path");return i.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),i.setAttribute("stroke",r.fill||""),i.setAttribute("stroke-width",o+""),i.setAttribute("fill","none"),r.fillLineDash&&i.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&i.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),i}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,i){const a=this.gen.line(e,n,r,o,i);return this.draw(a)}rectangle(e,n,r,o,i){const a=this.gen.rectangle(e,n,r,o,i);return this.draw(a)}ellipse(e,n,r,o,i){const a=this.gen.ellipse(e,n,r,o,i);return this.draw(a)}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,i,a,s=!1,c){const l=this.gen.arc(e,n,r,o,i,a,s,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var vi={canvas:(t,e)=>new Hl(t,e),svg:(t,e)=>new _l(t,e),generator:t=>new Ke(t),newSeed:()=>Ke.newSeed()};const Bl="http://www.w3.org/2000/svg",Jr=1,yi="#000000",Ze=3;let F=null;function ql(){F||(F=document.createElementNS(Bl,"svg"),F.setAttribute("data-manuscript","ui"),F.setAttribute("width","100%"),F.setAttribute("height","100%"),F.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z+4}`,"overflow: visible"].join("; "),document.body.appendChild(F))}function wr(){F==null||F.remove(),F=null}function xi(t,e,n,r){if(!F)return;for(;F.firstChild;)F.removeChild(F.firstChild);const o=vi.svg(F);to(p=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:Jr,...p}));const i=Math.atan2(r-e,n-t),a=14+Ze*2,s=Math.PI/7,c=n-a*Math.cos(i-s),l=r-a*Math.sin(i-s),u=n-a*Math.cos(i+s),f=r-a*Math.sin(i+s),d=`M ${c} ${l} L ${n} ${r} L ${u} ${f}`;to(p=>o.path(d,{roughness:1.5,bowing:1,seed:Jr+1,...p}))}function to(t){F&&(F.appendChild(t({stroke:"#ffffff",strokeWidth:Ze+4})),F.appendChild(t({stroke:yi,strokeWidth:Ze})))}const jl=8;let Qe=!1,eo=null,ne=!1,Ot=0,Nt=0;function Wl(){eo||(eo=ct(({prev:t,next:e})=>{e==="arrow"?Ul():t==="arrow"&&Xl()}))}function Ul(){Qe||(Qe=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",wi,!0),document.addEventListener("mousemove",ki,!0),document.addEventListener("mouseup",Si,!0),document.addEventListener("keydown",Ai,!0))}function Xl(){Qe&&(Qe=!1,ne=!1,document.body.style.cursor="",document.removeEventListener("mousedown",wi,!0),document.removeEventListener("mousemove",ki,!0),document.removeEventListener("mouseup",Si,!0),document.removeEventListener("keydown",Ai,!0),wr())}function wi(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),ne=!0,Ot=t.clientX,Nt=t.clientY,ql(),xi(Ot,Nt,Ot,Nt))}function ki(t){ne&&(t.preventDefault(),xi(Ot,Nt,t.clientX,t.clientY))}function Si(t){if(!ne)return;ne=!1,wr();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Ot,n-Nt)<jl){D("idle");return}t.preventDefault(),t.stopPropagation();const o=U(),i={kind:"arrow",id:Yl(),style:"excalidraw",from:{x:Ot,y:Nt},to:{x:e,y:n},...o?{fromAnchorOffset:{x:Ot-o.left,y:Nt-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:yi,strokeWidth:Ze};xe(i),D("idle")}function Ai(t){t.key==="Escape"&&(t.preventDefault(),ne=!1,wr(),D("idle"))}function Yl(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const no="http://www.w3.org/2000/svg",Ei="#1a1a1a",Mi=3,Gl=2,Vl=2;let Je=!1,ro=null,re=!1,st=[],nt=null,pt=null;function Kl(){ro||(ro=ct(({prev:t,next:e})=>{e==="freedraw"?Zl():t==="freedraw"&&Ql()}))}function Zl(){Je||(Je=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",$i,!0),document.addEventListener("mousemove",Li,!0),document.addEventListener("mouseup",Ti,!0),document.addEventListener("keydown",Ci,!0))}function Ql(){Je&&(Je=!1,re=!1,st=[],document.body.style.cursor="",document.removeEventListener("mousedown",$i,!0),document.removeEventListener("mousemove",Li,!0),document.removeEventListener("mouseup",Ti,!0),document.removeEventListener("keydown",Ci,!0),kr())}function $i(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),re=!0,st=[{x:t.clientX,y:t.clientY}],Jl(),Ii())}function Li(t){if(!re)return;t.preventDefault();const e=st[st.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<Vl||(st.push({x:t.clientX,y:t.clientY}),Ii())}function Ti(t){if(!re)return;if(re=!1,kr(),st.length<Gl){st=[],D("idle");return}t.preventDefault(),t.stopPropagation();const e=st.slice(),n=U(),r={kind:"freedraw",id:tu(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:Ei,strokeWidth:Mi};xe(r),st=[],D("idle")}function Ci(t){t.key==="Escape"&&(t.preventDefault(),re=!1,st=[],kr(),D("idle"))}function Jl(){nt||(nt=document.createElementNS(no,"svg"),nt.setAttribute("data-manuscript","ui"),nt.setAttribute("width","100%"),nt.setAttribute("height","100%"),nt.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z+4}`,"overflow: visible"].join("; "),pt=document.createElementNS(no,"polyline"),pt.setAttribute("fill","none"),pt.setAttribute("stroke",Ei),pt.setAttribute("stroke-width",String(Mi)),pt.setAttribute("stroke-linecap","round"),pt.setAttribute("stroke-linejoin","round"),nt.appendChild(pt),document.body.appendChild(nt))}function kr(){nt==null||nt.remove(),nt=null,pt=null}function Ii(){pt&&pt.setAttribute("points",st.map(t=>`${t.x},${t.y}`).join(" "))}function tu(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Se="manuscript:element-selected";let tn=!1,tt=null,oo=null;function eu(){oo||(oo=ct(({prev:t,next:e})=>{e==="picker"?nu():t==="picker"&&ru()}))}function nu(){tn||(tn=!0,document.addEventListener("mouseover",Pi,!0),document.addEventListener("mouseout",Di,!0),document.addEventListener("click",Oi,!0),document.addEventListener("keydown",Ni,!0))}function ru(){tn&&(tn=!1,document.removeEventListener("mouseover",Pi,!0),document.removeEventListener("mouseout",Di,!0),document.removeEventListener("click",Oi,!0),document.removeEventListener("keydown",Ni,!0),Ri())}function Pi(t){const e=t.target;!(e instanceof HTMLElement)||Fi(e)||iu(e)}function Di(t){Ri()}function Oi(t){const e=t.target;if(!(e instanceof HTMLElement)||Fi(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=Vs(e);if(!Ks(n,e)){ou();return}const r=e.getBoundingClientRect(),o={chain:n,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};document.dispatchEvent(new CustomEvent(Se,{detail:o})),D("idle")}let ot=null,Ne=null;function ou(){ot&&ot.remove(),ot=document.createElement("div"),ot.setAttribute("data-manuscript","ui"),ot.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${z+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),ot.textContent=b("toast.ambiguous-selector"),document.body.appendChild(ot),Ne!==null&&window.clearTimeout(Ne),Ne=window.setTimeout(()=>{ot==null||ot.remove(),ot=null,Ne=null},3500)}function Ni(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function iu(t){tt||(tt=document.createElement("div"),tt.setAttribute("data-manuscript","ui"),tt.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${z+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(tt));const e=t.getBoundingClientRect();tt.style.left=`${e.left}px`,tt.style.top=`${e.top}px`,tt.style.width=`${e.width}px`,tt.style.height=`${e.height}px`,tt.style.display="block"}function Ri(){tt&&(tt.style.display="none")}function Fi(t){return t.closest('[data-manuscript="ui"]')!==null}const Ae="http://www.w3.org/2000/svg";function Sr(t,e){let n;switch(t){case"rectangle":n=au(e);break;case"ellipse":n=su(e);break;case"triangle":n=Re(uu(e),e);break;case"diamond":n=Re(du(e),e);break;case"star":n=Re(pu(e),e);break;case"callout":n=lu(fu(e),e);break;case"line":n=cu(e);break;case"block-arrow":n=Re(hu(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function au(t){const e=document.createElementNS(Ae,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),An(e,t),e}function su(t){const e=document.createElementNS(Ae,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),An(e,t),e}function cu(t){const e=document.createElementNS(Ae,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function Re(t,e){const n=document.createElementNS(Ae,"polygon");return n.setAttribute("points",t),An(n,e),n.setAttribute("stroke-linejoin","round"),n}function lu(t,e){const n=document.createElementNS(Ae,"path");return n.setAttribute("d",t),An(n,e),n.setAttribute("stroke-linejoin","round"),n}function An(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function uu(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function du(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function pu(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,i=[];for(let a=0;a<10;a++){const s=Math.PI/5*a-Math.PI/2,c=a%2===0?r:o;i.push(`${e+Math.cos(s)*c},${n+Math.sin(s)*c}`)}return i.join(" ")}function fu(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,i=t.x+t.width*.5,a=t.x+t.width*.22,s=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${i} ${r}`,`L ${a} ${s}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function hu(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const mu="http://www.w3.org/2000/svg",gu="#ffffff",bu="#1a1a1a",vu=2;let W=null,ft=null;function zi(t){return{fill:t==="line"?"transparent":gu,stroke:bu,strokeWidth:vu}}function yu(){ft||(ft=document.createElement("div"),ft.setAttribute("data-manuscript","ui"),ft.textContent="Click and drag to draw a shape · Esc to cancel",ft.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${z+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(ft))}function Hi(){ft==null||ft.remove(),ft=null}function xu(){W||(W=document.createElementNS(mu,"svg"),W.setAttribute("data-manuscript","ui"),W.setAttribute("width","100%"),W.setAttribute("height","100%"),W.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z+4}`,"overflow: visible"].join("; "),document.body.appendChild(W))}function Ar(){W==null||W.remove(),W=null}function _i(t,e,n,r,o){if(!W)return;for(;W.firstChild;)W.removeChild(W.firstChild);const i=t==="line"?r-e:Math.abs(r-e),a=t==="line"?o-n:Math.abs(o-n),s=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=zi(t),u=Sr(t,{x:s,y:c,width:i,height:a,...l});u&&W.appendChild(u)}const wu=6;let xt="rectangle",en=!1,io=null,oe=!1,wt=0,kt=0;function ku(t){xt=t}function Su(){io||(io=ct(({prev:t,next:e})=>{e==="shape"?Au():t==="shape"&&Eu()}))}function Au(){en||(en=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Bi,!0),document.addEventListener("mousemove",qi,!0),document.addEventListener("mouseup",ji,!0),document.addEventListener("keydown",Wi,!0),yu())}function Eu(){en&&(en=!1,oe=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Bi,!0),document.removeEventListener("mousemove",qi,!0),document.removeEventListener("mouseup",ji,!0),document.removeEventListener("keydown",Wi,!0),Ar(),Hi())}function Bi(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),oe=!0,wt=t.clientX,kt=t.clientY,Hi(),xu(),_i(xt,wt,kt,wt,kt))}function qi(t){oe&&(t.preventDefault(),_i(xt,wt,kt,t.clientX,t.clientY))}function ji(t){if(!oe)return;oe=!1,Ar();const e=t.clientX,n=t.clientY,r=xt==="line"?e-wt:Math.abs(e-wt),o=xt==="line"?n-kt:Math.abs(n-kt);if(Math.max(Math.abs(r),Math.abs(o))<wu){D("idle");return}t.preventDefault(),t.stopPropagation();const i=xt==="line"?{x:wt,y:kt,width:r,height:o}:{x:Math.min(wt,e),y:Math.min(kt,n),width:r,height:o},a=zi(xt),s=U(),c={kind:"shape",id:Mu(),shapeKind:xt,bounds:i,...s?{boundsAnchorOffset:{x:i.x-s.left,y:i.y-s.top}}:{},...a};xe(c),D("idle")}function Wi(t){t.key==="Escape"&&(t.preventDefault(),oe=!1,Ar(),D("idle"))}function Mu(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const $u={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},Lu="Text";let nn=!1,ao=null;function Tu(){ao||(ao=ct(({prev:t,next:e})=>{e==="text"?Cu():t==="text"&&Iu()}))}function Cu(){nn||(nn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Ui,!0),document.addEventListener("keydown",Xi,!0))}function Iu(){nn&&(nn=!1,document.body.style.cursor="",document.removeEventListener("click",Ui,!0),document.removeEventListener("keydown",Xi,!0))}function Ui(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=U(),o={kind:"text",id:Pu(),text:Lu,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...$u}};xe(o),requestAnimationFrame(()=>{const i=document.querySelector(`[data-annotation-text="${o.id}"]`);i&&i.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),D("idle")}function Xi(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function Pu(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Du="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",Ou="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",so="Asta Sans",Nu="fonts/AstaSans-VariableFont_wght.ttf";let co=!1;function Ru(){co||(co=!0,lo(Du),lo(Ou),Fu())}function lo(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function Fu(){try{for(const t of document.fonts)if(t.family===so)return}catch{}try{const t=chrome.runtime.getURL(Nu);new FontFace(so,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const it="manuscript";function En(...t){}function Wn(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function Gt(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function Yi(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===it&&typeof e.type=="string"}function zu(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const i=o.data;if(Yi(i)){if(En("child received",i.type,"in",location.href),i.type==="set-mode"){D(i.mode),t=i.mode;return}if(i.type==="top-drag-start"){n=!0;return}if(i.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(Se,(o=>{const i=o.detail;Gt({source:it,type:"element-selected",detail:i})})),ct(({prev:o,next:i})=>{o==="picker"&&i==="idle"&&Gt({source:it,type:"exit-picker"})}),Gt({source:it,type:"frame-ready"}),document.addEventListener("mousedown",o=>{Gt({source:it,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&Gt({source:it,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&Gt({source:it,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function Hu(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const i=o.getBoundingClientRect();return{x:i.left,y:i.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function _u(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Bu(){ct(({next:t})=>{Wn({source:it,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Wn({source:it,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Wn({source:it,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(Yi(e)){if(En("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){qu(t.source,e.detail);return}if(e.type==="exit-picker"){D("idle");return}if(e.type==="iframe-mousedown"){uo("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";uo(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){ju(t.source);return}}})}function qu(t,e){const n=_u(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};En("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(Se,{detail:o})),D("idle")}function uo(t,e,n,r){const o=Hu(e),i=n+o.x,a=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:i,clientY:a}))}function ju(t){if(vt()==="picker")try{t==null||t.postMessage({source:it,type:"set-mode",mode:"picker"},"*"),En("top → late child: set-mode picker")}catch{}}function Wu(){if(typeof window>"u")return;window===window.top?Bu():zu()}const Uu="iframe-tool-overlay",po=new Set(["text","shape","freedraw"]);let Qt=[],Un=!1,Vt=null;function Xu(){typeof window>"u"||window===window.top&&(ct(({next:t})=>{po.has(t)?fo():Gi()}),po.has(vt())&&fo())}function fo(){Gi(),ho(),window.addEventListener("scroll",rn,!0),window.addEventListener("resize",rn),Vt=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&ho()}),Vt.observe(document.body,{childList:!0,subtree:!0})}function Gi(){Qt.forEach(t=>t.remove()),Qt=[],window.removeEventListener("scroll",rn,!0),window.removeEventListener("resize",rn),Vt==null||Vt.disconnect(),Vt=null}function ho(){Qt.forEach(e=>e.remove()),Qt=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",Uu),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${z+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),Qt.push(n),Vi(n,e)})}const Fe=8;function Vi(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-Fe}px`,t.style.top=`${n.top-Fe}px`,t.style.width=`${n.width+Fe*2}px`,t.style.height=`${n.height+Fe*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function rn(){Un||(Un=!0,requestAnimationFrame(()=>{Un=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=Qt[e];r&&Vi(r,n),e++})}))}let $t=!1;function Mn(){return $t}async function Yu(){try{if(typeof(await chrome.storage.local.get(Z.prompterWindowId))[Z.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&($t=!0)}catch{}}async function Ki(){if($t){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}$t=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&($t=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function Zi(){if($t){$t=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function Qi(t){try{await chrome.storage.local.set({[Z.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function Gu(){$t=!1}const Ct="http://www.w3.org/2000/svg",mo="manuscript-spotlight-mask";let le=null,V=null,at=null,K=null,er=[];function Ji(t){le=t,V||Ku(),on(),Vu(t)}function ie(){le=null,ta(),V&&(V.remove(),V=null,at=null,K=null)}function Vu(t){var n;ta();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=on;r.addEventListener("scroll",o,!0),er.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",on)}function ta(){for(const t of er)t.remove();er=[],window.removeEventListener("resize",on)}function Ku(){V=document.createElementNS(Ct,"svg"),V.setAttribute("data-manuscript","ui"),V.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z}`].join("; "),V.setAttribute("width","100%"),V.setAttribute("height","100%");const t=document.createElementNS(Ct,"defs"),e=document.createElementNS(Ct,"mask");e.setAttribute("id",mo);const n=document.createElementNS(Ct,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),at=document.createElementNS(Ct,"rect"),at.setAttribute("fill","black"),at.setAttribute("rx","4"),at.setAttribute("ry","4"),e.appendChild(at),t.appendChild(e),V.appendChild(t);const r=document.createElementNS(Ct,"rect");r.setAttribute("width","100%"),r.setAttribute("height","100%"),r.setAttribute("fill","rgba(0, 0, 0, 0.55)"),r.setAttribute("mask",`url(#${mo})`),V.appendChild(r),K=document.createElementNS(Ct,"rect"),K.setAttribute("fill","none"),K.setAttribute("stroke","rgba(255, 61, 139, 0.85)"),K.setAttribute("stroke-width","3"),K.setAttribute("rx","4"),K.setAttribute("ry","4"),V.appendChild(K),document.body.appendChild(V)}function on(){if(!le||!at||!K)return;const t=le.getBoundingClientRect(),e=Zu(le),n=4,r=t.left+e.x-n,o=t.top+e.y-n,i=t.width+n*2,a=t.height+n*2;at.setAttribute("x",String(r)),at.setAttribute("y",String(o)),at.setAttribute("width",String(i)),at.setAttribute("height",String(a)),K.setAttribute("x",String(r)),K.setAttribute("y",String(o)),K.setAttribute("width",String(i)),K.setAttribute("height",String(a))}function Zu(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const go="data-wp-animations";function Qu(){if(document.head.querySelector(`[${go}]`))return;const t=document.createElement("style");t.setAttribute(go,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function he(t,e,n){if(!e||e.kind==="none"||vt()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const i=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",i),t.removeEventListener("animationcancel",i)};t.addEventListener("animationend",i),t.addEventListener("animationcancel",i)}const an="http://www.w3.org/2000/svg",ea="data-annotation-text",bo="data-annotation-arrow",na="data-annotation-shape",vo="data-annotation-freedraw",L={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function Ju(t,e){const{svg:n,roughSvg:r}=L;if(!n||!r)return;const o=ed(t.id),{from:i,to:a}=Js(t,e);ra(t,s=>r.line(i.x,i.y,a.x,a.y,{roughness:1.5,bowing:1,seed:o,...s})),td(t,i,a,o+1)}function td(t,e,n,r){const{roughSvg:o}=L;if(!o)return;const i=Math.atan2(n.y-e.y,n.x-e.x),a=14+t.strokeWidth*2,s=Math.PI/7,c=n.x-a*Math.cos(i-s),l=n.y-a*Math.sin(i-s),u=n.x-a*Math.cos(i+s),f=n.y-a*Math.sin(i+s),d=`M ${c} ${l} L ${n.x} ${n.y} L ${u} ${f}`;ra(t,p=>o.path(d,{roughness:1.5,bowing:1,seed:r,...p}))}function ra(t,e){const{svg:n}=L;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(bo,t.id),he(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(bo,t.id),he(o,t.entryAnimation,0),n.appendChild(o)}function ed(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const $={state:null,unsubscribeStep:null};function gt(){return $.state!==null}function Er(){var t;return((t=$.state)==null?void 0:t.standalone)===!0}function nd(t,e){const{svg:n}=L;if(!n)return;const r=yn(t,e),o=rd(t,r),i=r.map(c=>`${c.x},${c.y}`).join(" "),a=document.createElementNS(an,"polyline");if(a.setAttribute("points",i),a.setAttribute("fill","none"),a.setAttribute("stroke",t.stroke),a.setAttribute("stroke-width",String(t.strokeWidth)),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute(vo,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&a.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&a.setAttribute("transform",o),a.style.pointerEvents="none",he(a,t.entryAnimation,t.rotate??0),n.appendChild(a),Er())return;const s=document.createElementNS(an,"polyline");s.setAttribute(vo,t.id),s.setAttribute("points",i),s.setAttribute("fill","none"),s.setAttribute("stroke","transparent"),s.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute("pointer-events","stroke"),o&&s.setAttribute("transform",o),s.style.cursor="pointer",s.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),od(t.id,c,s))}),n.appendChild(s)}function rd(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,i=-1/0,a=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>i&&(i=l.x),l.y>a&&(a=l.y);const s=(r+i)/2,c=(o+a)/2;return`rotate(${n} ${s} ${c})`}function od(t,e,n){const r=T(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},i=U(),a=yn(r,i).map(u=>({...u}));let s=!1;const c=u=>{const f=u.clientX-o.x,d=u.clientY-o.y;if(!s&&Math.hypot(f,d)<3)return;s=!0,u.preventDefault();const p=a.map(g=>({x:g.x+f,y:g.y+d})),h=i?{points:p,pointsAnchorOffset:p.map(g=>({x:g.x-i.left,y:g.y-i.top}))}:{points:p,pointsAnchorOffset:void 0};C(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const u=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),f=u[u.length-1]??n;ul(t,f)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function id(t,e){const{svg:n}=L;if(!n)return;const r=vn(t,e),o=Sr(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(na,t.id),o.style.pointerEvents="none",he(o,t.entryAnimation,t.rotate??0),n.appendChild(o),Er()||n.appendChild(ad(t,r)))}function ad(t,e){const n=document.createElementNS(an,"rect");if(n.setAttribute(na,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>sd(t.id,r,n)),n}function sd(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=T(t);if(!o||o.kind!=="shape")return;const i=U(),a=o.boundsAnchorOffset&&i?{x:i.left+o.boundsAnchorOffset.x,y:i.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},s={...o.bounds,x:a.x,y:a.y};let c=!1;const l=f=>{const d=f.clientX-r.x,p=f.clientY-r.y;if(!c&&Math.hypot(d,p)<3)return;c=!0,f.preventDefault();const h=s.x+d,g=s.y+p,v=i?{bounds:{...s,x:h,y:g},boundsAnchorOffset:{x:h-i.left,y:g-i.top}}:{bounds:{...s,x:h,y:g},boundsAnchorOffset:void 0};C(t,v)},u=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0);const f=document.querySelectorAll(`[data-annotation-shape="${t}"]`),d=f[f.length-1]??n;ll(t,d)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",u,!0)}function cd(t,e){const{host:n}=L;if(!n)return;const r=document.createElement("div");r.setAttribute(ea,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,i=t.style.backgroundColor??"#ffffff",a=t.style.backgroundOpacity??.96,s=i==="transparent"?"transparent":ld(i,a),c=t.rotate??0,l=t.style.borderColor??"#000000",u=l==="transparent"?"none":`2px solid ${l}`,f=Qs(t,e),d=Er();r.style.cssText=["position: absolute",`left: ${f.x}px`,`top: ${f.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${s}`,`border: ${u}`,"border-radius: 8px",d?"pointer-events: none":"pointer-events: auto",d?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,d||ud(r,t.id),he(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function ld(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,i=0,a=0;return r.length===4?(o=parseInt(r[1]+r[1],16),i=parseInt(r[2]+r[2],16),a=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),i=parseInt(r.slice(3,5),16),a=parseInt(r.slice(5,7),16)),`rgba(${o}, ${i}, ${a}, ${n})`}return t}function ud(t,e){let n=!1,r=0,o=0,i=0,a=0,s=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,s=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();i=l.left,a=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,u=c.clientY-o;Math.abs(l)+Math.abs(u)>2&&(s=!0),t.style.left=`${i+l}px`,t.style.top=`${a+u}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!s))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),u=U(),f=u?{position:{x:c,y:l},anchorOffset:{x:c-u.left,y:l-u.top}}:{position:{x:c,y:l},anchorOffset:void 0};C(e,f)}),t.addEventListener("click",c=>{s||t.isContentEditable||(c.stopPropagation(),cl(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),dd(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",C(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function dd(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function oa(){if(L.host)return;Qu();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${z+3}`].join("; ");const e=document.createElementNS(an,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),L.host=t,L.svg=e,L.roughSvg=vi.svg(e),document.body.appendChild(t),L.unsubscribe=ye(je),L.unsubscribeMode=ct(je),pd(),je()}let Jt=null;function ue(){Jt===null&&(Jt=requestAnimationFrame(()=>{Jt=null,je()}))}let Rt=null,nr=null;function pd(){window.addEventListener("resize",ue),window.addEventListener("scroll",ue,!0),typeof ResizeObserver<"u"&&(Rt=new ResizeObserver(ue))}function fd(){window.removeEventListener("resize",ue),window.removeEventListener("scroll",ue,!0),Rt&&(Rt.disconnect(),Rt=null),nr=null,Jt!==null&&(cancelAnimationFrame(Jt),Jt=null)}function ia(){var t,e;(t=L.unsubscribe)==null||t.call(L),L.unsubscribe=null,(e=L.unsubscribeMode)==null||e.call(L),L.unsubscribeMode=null,fd(),L.host&&(L.host.remove(),L.host=null,L.svg=null,L.roughSvg=null)}function hd(){return L.host!==null}function je(){const{host:t,svg:e}=L;if(!t||!e)return;for(t.querySelectorAll(`[${ea}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=U();if(Rt){let o=null;try{o=md()}catch{o=null}o!==nr&&(Rt.disconnect(),o&&Rt.observe(o),nr=o)}const r=Bo();for(const o of r)o.kind==="text"?cd(o,n):o.kind==="arrow"?Ju(o,n):o.kind==="shape"?id(o,n):o.kind==="freedraw"&&nd(o,n)}function md(){const t=mt();if(!(t!=null&&t.selectors))return null;try{return fe(t.selectors)}catch{return null}}const k={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function Kt(t,e,n){return Math.max(e,Math.min(n,t))}function aa(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=yd()),gd()}function gd(){const{host:t}=k;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),i=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${Kt(o,0,n)}px`),Number.isFinite(i)&&(t.style.top=`${Kt(i,0,r)}px`)}async function bd(){try{return(await chrome.storage.local.get(Z.replayControlsOrientation))[Z.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function vd(t){try{await chrome.storage.local.set({[Z.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function yd(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function xd(){try{const e=(await chrome.storage.local.get(Z.replayControlsPosition))[Z.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function yo(t){try{await chrome.storage.local.set({[Z.replayControlsPosition]:t})}catch{}}function wd(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function kd(){const{host:t,shadow:e}=k;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,i=0,a=0,s=0;const c=d=>{if(!k.host)return;d.preventDefault(),d.stopPropagation(),r=!0,n.classList.add("dragging");const p=k.host.getBoundingClientRect();k.host.style.left=`${p.left}px`,k.host.style.top=`${p.top}px`,k.host.style.bottom="auto",k.host.style.transform="none",o=d.clientX,i=d.clientY,a=p.left,s=p.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",u,!0)},l=d=>{if(!r||!k.host)return;const p=k.host.getBoundingClientRect(),h=d.clientX-o,g=d.clientY-i,v=Kt(a+h,0,window.innerWidth-p.width),x=Kt(s+g,0,window.innerHeight-p.height);k.host.style.left=`${v}px`,k.host.style.top=`${x}px`},u=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0);const d=k.host;if(d){const p=parseFloat(d.style.left||"0"),h=parseFloat(d.style.top||"0");Number.isFinite(p)&&Number.isFinite(h)&&yo({left:p,top:h})}},f=()=>{if(k.host&&k.host.style.transform==="none"){const d=k.host.getBoundingClientRect(),p=Kt(d.left,0,window.innerWidth-d.width),h=Kt(d.top,0,window.innerHeight-d.height);k.host.style.left=`${p}px`,k.host.style.top=`${h}px`,yo({left:p,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",f),k.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",f),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0)}}function sa(){return`
    ${qt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function ca(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Sd(t){return ca(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function Ad(t,e){const{shadow:n}=k;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,i)=>{const a=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${i===e?" active":""}" role="option" data-action="step-jump" data-index="${i}" aria-selected="${i===e}" title="${Sd(a)}">${i+1}. ${ca(a)}</li>`}).join(""))}function Ed(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function rr(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function la(t){const{host:e,shadow:n}=k;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||rr()}let We=-1,Ue=!1;function Md(){We=-1,Ue=!1}function $d(t,e,n){const{shadow:r}=k;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",We=-1,Ue=!1;return}o.classList.remove("hidden");const s=t!==We||Ue&&!n;We=t,Ue=n;let c=o.querySelector(".progress-fill");(!c||s)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function Ld(){return`
    ${qt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid rgb(255 255 255 / 0.6);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: rgb(255 255 255 / 0.08); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: rgb(255 255 255 / 0.15); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: rgb(255 255 255 / 0.2);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: rgb(255 255 255 / 0.18);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: rgb(255 255 255 / 0.55);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: rgb(255 255 255 / 0.75);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: rgb(255 255 255 / 0.08); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function Td(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function Cd(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function Id(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?Td(14):Cd(14))}function $n(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",ve);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}function Pd(t){if(k.host)return;const{host:e,shadow:n}=$n();k.host=e,k.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${z+6}`,"pointer-events: auto"].join("; "),n.innerHTML=`<style>${Ld()}</style>${Dd()}`,n.addEventListener("click",r=>Od(r,t)),document.body.appendChild(e),kd(),document.addEventListener("mousedown",la,!0),k.orientationApplied=!1,bd().then(r=>{k.orientationApplied||(k.orientationApplied=!0,aa(r))}),xd().then(r=>{k.host&&r&&k.host.style.transform!=="none"&&wd(k.host,r)})}function Dd(){return`
    <div class="bar" role="toolbar" aria-label="${b("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${b("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${b("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${b("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${b("replay.prompter-aria")}" title="${b("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${b("replay.tts-aria")}" title="${b("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${b("replay.move-aria")}" title="${b("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${b("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${b("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Od(t,e){var i;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){Ed();return}const r=n.closest('[data-action="step-jump"]');if(r){const a=Number(r.getAttribute("data-index"));Number.isFinite(a)&&(rr(),e.onStepSelect(a));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(i=n.closest("[data-action]"))==null?void 0:i.getAttribute("data-action");switch(o&&rr(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Nd();break}}function Nd(){const{shadow:t}=k;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";k.orientationApplied=!0,aa(n),vd(n)}function Rd(){var t,e;(t=k.cleanupDrag)==null||t.call(k),k.cleanupDrag=null,document.removeEventListener("mousedown",la,!0),(e=k.host)==null||e.remove(),k.host=null,k.shadow=null,k.orientationApplied=!1,Md()}function xo(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const i=e.querySelector('[data-action="prev"]');i&&i.toggleAttribute("disabled",t.currentIndex<=0);const a=e.querySelector('[data-action="next"]');a&&(a.toggleAttribute("disabled",!1),a.setAttribute("aria-label",t.currentIndex>=t.total-1?b("replay.finish-aria"):b("replay.next-aria"))),$d(t.currentIndex,t.timerDurationMs??null,t.paused),Ad(t.steps??[],t.currentIndex),Id(t.ttsEnabled===!0)}let St=null;function Fd(t){Ee();const{host:e,shadow:n}=$n();St=e,St.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${z+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${sa()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${b("replay.notfound.title")}</h2>
          <p>${b("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${b("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${b("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var s;const i=o.target;if(!(i instanceof HTMLElement))return;const a=(s=i.closest("[data-action]"))==null?void 0:s.getAttribute("data-action");a==="skip"?t.onSkip():a==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),St.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(St)}function Ee(){if(!St)return;const t=St.__cleanup;t==null||t(),St.remove(),St=null}let At=null;function zd(t){sn();const{host:e,shadow:n}=$n();At=e,At.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${z+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${sa()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${b("replay.url-mismatch.title")}</h2>
          <p>${b("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${b("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${b("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${b("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",i=>{var c;const a=i.target;if(!(a instanceof HTMLElement))return;const s=(c=a.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");s==="navigate"?t.onNavigate():s==="force"?t.onForce():s==="cancel"&&t.onCancel()});const o=i=>{i.key==="Escape"?(i.preventDefault(),t.onCancel()):i.key==="Enter"&&(i.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),At.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild(At)}function sn(){if(!At)return;const t=At.__cleanup;t==null||t(),At.remove(),At=null}let Dt=null;function Hd(t){Me();const e=t.getBoundingClientRect(),n=_d(t),r=e.left+n.x,o=e.top+n.y,i=e.bottom+n.y,a=36,s=8,c=o-s-a<8,l=c?Math.min(window.innerHeight-8-a,i+s):Math.max(8,o-s-a),u=Math.max(8,Math.min(r,window.innerWidth-200)),f=c?"up":"down",{host:d,shadow:p}=$n();Dt=d,Dt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${u}px`,`z-index: ${z+6}`,"pointer-events: none"].join("; "),p.innerHTML=`
    <style>
      ${qt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${b("prompter.action-step")}</span>
      <span>${b("replay.action-prompt")}</span>
      <span class="tip ${f}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Dt)}function Me(){Dt==null||Dt.remove(),Dt=null}function _d(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let te=null;function Bd(t){te||(te=e=>{if($.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",te,!0))}function qd(){te&&(document.removeEventListener("keydown",te,!0),te=null)}function ua(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function jd(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function Wd(t,e){var r,o,i;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||ua(n,location.href)||((o=$.state)==null?void 0:o.standalone)===!0)return!1;try{await sr({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((i=$.state)==null?void 0:i.paused)??!1})}catch(a){console.warn("[manuscript] persist activeReplay before nav failed",a)}return location.href=n,!0}function Ud(t){return new Promise(e=>{zd({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{sn(),e("force")},onCancel:()=>{sn(),e("cancel")}})})}async function Xd(t){try{const e=await Co();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Mr(){const t=P();if(!(!t||!$.state)&&$.state.standalone!==!0)try{await sr({scenarioId:t.id,stepIndex:q(),startedAt:Date.now(),paused:$.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function da(t,e,n){const r=P();if(!r)return{ok:!1};if(n&&await Xd(r.id))return{ok:!0};const o=jd(r);if(!o||ua(o,location.href))return{ok:!0};const i=await Ud(o);return i==="cancel"?{ok:!1}:i==="navigate"?(await sr({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class pa extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function Yd(t,e=Ra){const n=fe(t);return n?Promise.resolve(n):new Promise((r,o)=>{let i=!1;const s=(Ko(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(i)return;const u=fe(t);u&&(i=!0,c.disconnect(),clearTimeout(l),r(u))}),l=setTimeout(()=>{i||(i=!0,c.disconnect(),o(new pa(t)))},e);c.observe(s,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function ae(){const{state:t}=$;if(!t)return;const e=P();if(!e)return;const n=e.steps[q()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(Io().then(o=>{xo({currentIndex:q(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:o})}),xo({currentIndex:q(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),Mn()){const o=q(),i=e.steps[o],a=e.steps[o+1];Qi({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(s=>({name:s.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:a?{name:a.name,description:a.description,autoAdvanceMs:a.autoAdvanceMs??null,waitForNavigation:a.waitForNavigation,thumbnailDataUrl:a.thumbnailDataUrl??null}:null})}}async function Gd(){if(Mn()){await Zi(),cn(!1);return}cn(!0),await Ki(),ae()}function Vd(){cn(!1)}function cn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function Ln(t){var i;const{state:e}=$;if(!e)return;const n=P();if(!n)return;const r=n.steps[q()];if(ae(),!r)return;if(Ee(),Me(),Wa()&&!e.paused&&Ua(r.description),!r.selectors){ie(),r.waitForNavigation||wo(t);return}const o=new AbortController;e.pendingWait=o;try{const a=await Yd(r.selectors);if(o.signal.aborted)return;a.scrollIntoView({block:"center"}),Ji(a),r.waitForNavigation?(Hd(a),Kd(a,o,t.onNext)):wo(t)}catch(a){if(o.signal.aborted)return;if(a instanceof pa){ie(),Fd({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",a)}finally{((i=$.state)==null?void 0:i.pendingWait)===o&&($.state.pendingWait=null)}}function Kd(t,e,n){if(!$.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!$.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function wo(t){var a;const{state:e}=$;if(!e||e.paused)return;const n=P();if(!n)return;const r=q(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(a=e.autoAdvanceAbort)==null||a.abort();const i=new AbortController;e.autoAdvanceAbort=i,(async()=>{const s=[],c=Xa();c&&s.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&s.push(new Promise(l=>{const u=window.setTimeout(()=>{$.state&&$.state.autoAdvanceTimer===u&&($.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);$.state&&($.state.autoAdvanceTimer=u),i.signal.addEventListener("abort",()=>{window.clearTimeout(u),l()})})),s.length!==0&&(await Promise.race([Promise.all(s).then(()=>{}),new Promise(l=>{i.signal.aborted?l():i.signal.addEventListener("abort",()=>l(),{once:!0})})]),!i.signal.aborted&&(!$.state||$.state.paused||q()===r&&t.onNext()))})()}function Tn(){var e,n;const{state:t}=$;t&&(t.autoAdvanceTimer!==null&&(window.clearTimeout(t.autoAdvanceTimer),t.autoAdvanceTimer=null),(e=t.autoAdvanceAbort)==null||e.abort(),t.autoAdvanceAbort=null,(n=t.pendingWait)==null||n.abort(),t.pendingWait=null,Po())}const Cn={onNext:()=>void me(),onExit:()=>void ge()};async function $e(t=0,e={}){if($.state)return;const n=P();if(!n||n.steps.length===0||e.standalone!==!0&&!(await da(n.id,t,!0)).ok)return;$.state={originalStepIndex:q(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,standalone:e.standalone===!0},D("replay"),Pd({onPrev:ln,onNext:me,onTogglePause:un,onExit:ge,onStepSelect:o=>void Lr(o),onTogglePrompter:()=>void Gd(),onToggleTts:()=>void Zd()}),Mn()&&cn(!0),Bd({onNext:()=>void me(),onPrev:()=>void ln(),onTogglePause:un,onExit:()=>void ge()}),$.unsubscribeStep=ye(ae);const r=Math.min(Math.max(0,t),n.steps.length-1);jt(r),await Mr(),await Ln(Cn)}async function $r(t){if(!$.state)return;const e=P();e&&(t<0||t>=e.steps.length||(Tn(),Ee(),Me(),!await Wd(e,t)&&(jt(t),await Mr(),await Ln(Cn))))}async function Lr(t){t!==q()&&await $r(t)}async function me(){const{state:t}=$;if(!t)return;const e=P();if(!e)return;const n=q();if(n>=e.steps.length-1){Tn(),Ee(),Me(),t.paused=!0,ae();return}await $r(n+1)}async function ln(){await $r(q()-1)}async function Zd(){const t=!await Io();await Ya(t),t||Po(),ae()}function un(){const{state:t}=$;if(!t)return;const e=P();if(e&&t.paused&&q()>=e.steps.length-1){Qd();return}t.paused=!t.paused,t.paused?Tn():Ln(Cn),ae()}async function Qd(){if(!$.state)return;const t=P();!t||!(await da(t.id,0,!1)).ok||$.state&&($.state.paused=!1,jt(0),await Mr(),await Ln(Cn))}async function ge(){var r;const{state:t}=$;if(!t)return;Tn(),Ee(),Me(),sn(),ie(),Rd(),Zi(),qd(),(r=$.unsubscribeStep)==null||r.call($),$.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;$.state=null,jt(e),D("idle"),await Ha(),n&&(ia(),Ho())}const Jd=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],bt=28,ze=4,tp="http://www.w3.org/2000/svg";let B=null,Bt=null,de=null;function ep(t,e){In(),de=e,B=document.createElement("div"),B.setAttribute("data-manuscript","ui"),B.style.cssText=["position: fixed",`z-index: ${z+5}`,"pointer-events: auto"].join("; "),Bt=B.attachShadow({mode:"open"}),Bt.innerHTML=np(),op(),document.body.appendChild(B),ko(t),rp(),requestAnimationFrame(()=>{B&&ko(t)}),document.addEventListener("mousedown",fa,!0),document.addEventListener("keydown",ha,!0)}function In(){B&&(document.removeEventListener("mousedown",fa,!0),document.removeEventListener("keydown",ha,!0),B.remove(),B=null,Bt=null,de=null)}function np(){return`
    <style>
      :host { all: initial; }
      .menu {
        background: #ffffff;
        border: 2px solid #000000;
        border-radius: 8px;
        padding: 6px;
        font-family: 'Asta Sans', system-ui, sans-serif;
        box-shadow: 0 4px 16px rgba(0, 0, 0, 0.15);
        display: grid;
        grid-template-columns: repeat(4, ${bt+ze*2}px);
        gap: 2px;
      }
      .menu-btn {
        width: ${bt+ze*2}px;
        height: ${bt+ze*2}px;
        padding: ${ze}px;
        border: 1px solid transparent;
        border-radius: 4px;
        background: #ffffff;
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        box-sizing: border-box;
      }
      .menu-btn:hover {
        border-color: #ff3d8b;
        background: #fef0f5;
      }
      .menu-btn:focus-visible {
        outline: 2px solid #ff3d8b;
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function rp(){if(!Bt)return;const t=Bt.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of Jd){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(tp,"svg");o.setAttribute("width",String(bt)),o.setAttribute("height",String(bt)),o.setAttribute("viewBox",`0 0 ${bt} ${bt}`);const i=Sr(e,{x:3,y:3,width:bt-6,height:bt-6,fill:e==="line"?"transparent":"#ffffff",stroke:"#1a1a1a",strokeWidth:1.5});i&&o.appendChild(i),r.appendChild(o),t.appendChild(r)}}}function op(){Bt&&Bt.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(de==null||de(r),In())})}function ko(t){if(!B)return;const e=t.getBoundingClientRect();B.style.top="0px",B.style.left="0px";const n=B.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),B.style.top=`${Math.max(8,r)}px`,B.style.left=`${Math.max(8,o)}px`}function fa(t){if(!B)return;const e=t.target;e instanceof Node&&B.contains(e)||In()}function ha(t){t.key==="Escape"&&(t.preventDefault(),In())}const ip=320,ee=32,ap=.8,dn=200,S={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null};function pn(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function et(t){return pn(t)}function be(t,e=!1){const{shadow:n}=S;if(!n)return;const r=n.querySelector('[data-region="toast"]');r&&(r.textContent=t,r.classList.add("visible"),r.classList.toggle("error",e),S.toastTimer!==null&&window.clearTimeout(S.toastTimer),S.toastTimer=window.setTimeout(()=>{r.classList.remove("visible"),S.toastTimer=null},2500))}function fn(t,e,n){return Math.max(e,Math.min(n,t))}function sp(){const t=P();if(t)try{const e=_a(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${up(t.name)}-${dp(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),be(b("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),be(b("toast.export-failed"),!0)}}async function cp(){const t=P();if(t){if(t.steps.length===0){be(b("toast.no-steps"),!0);return}di(),await $e(0,{paused:!0})}}function lp(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Ba(r);zo(o),be(b("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),be(b("toast.import-failed"),!0)}}),t.click()}function up(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function dp(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function Pn(t){const e=P(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!pp(n.pickedAtUrl,location.href)?(ma(n.pickedAtUrl,t),!0):!1}function pe(){const t=P();if(!t)return;const e=q(),n=t.steps[e],r=t.steps[e+1];Qi({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function pp(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function ma(t,e){const n=P();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let hn=!1,ga=0,ba=0,or=0,ir=0;function fp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=S;if(!o)return;hn=!0,ga=n.clientX,ba=n.clientY;const i=o.getBoundingClientRect();or=i.left,ir=i.top,o.style.left=`${or}px`,o.style.top=`${ir}px`,o.style.right="auto",document.addEventListener("mousemove",va,!0),document.addEventListener("mouseup",ya,!0),n.preventDefault()})}function va(t){const{host:e}=S;if(!hn||!e)return;const n=t.clientX-ga,r=t.clientY-ba,o=e.offsetWidth,i=e.offsetHeight,a=fn(or+n,0,window.innerWidth-o),s=fn(ir+r,0,window.innerHeight-i);e.style.left=`${a}px`,e.style.top=`${s}px`}function ya(){hn&&(hn=!1,document.removeEventListener("mousemove",va,!0),document.removeEventListener("mouseup",ya,!0))}let mn=!1,xa=0,wa=0;function hp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=S;r&&(mn=!0,xa=n.clientY,wa=r.getBoundingClientRect().height,document.addEventListener("mousemove",ka,!0),document.addEventListener("mouseup",Sa,!0),n.preventDefault(),n.stopPropagation())})}function ka(t){const{host:e}=S;if(!mn||!e)return;const n=t.clientY-xa,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-ee,i=fn(wa+n,dn,o);e.style.height=`${i}px`,e.style.maxHeight=`${i}px`}function Sa(){mn&&(mn=!1,document.removeEventListener("mousemove",ka,!0),document.removeEventListener("mouseup",Sa,!0))}function mp(t){const e=window.innerHeight-ee*2;return fn(t,dn,Math.max(dn,e))}function Aa(){const{host:t}=S;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-ee;if(e.bottom>n){const o=Math.max(dn,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),i=window.innerWidth-r.width;o>i&&(t.style.left=`${Math.max(0,i)}px`)}if(t.style.top){const o=parseFloat(t.style.top),i=window.innerHeight-r.height;o>i&&(t.style.top=`${Math.max(0,i)}px`)}}function Tr(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function Ea(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function gp(){const t=Tr();t&&(t.hidden?(bp(),t.hidden=!1):t.hidden=!0)}function Ma(){const t=Tr();t&&(t.hidden=!0)}async function bp(){const t=Ea();if(!t)return;await Va();const e=Ka(),n=await Za(),r=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const i of e){const a=i.name===n?" selected":"";o.push(`<option value="${r(i.name)}"${a}>${r(i.name)} (${r(i.lang)})</option>`)}t.innerHTML=o.join("")}function vp(){var n;const t=Ea();t&&t.addEventListener("change",()=>{const r=t.value;Ga(r.length>0?r:null)});const e=(n=S.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>Ma())}function yp(t){var o;const e=Tr();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=S.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Ma()}function Ft(t){const e=t===q();jt(t),e&&$a()}function $a(){const t=mt();if(!(t!=null&&t.selectors)){ie();return}const e=fe(t.selectors);e?(e.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),Ji(e)):ie()}function So(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function Cr(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function xp(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function wp(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function kp(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function Sp(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function Ap(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function Ep(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=P(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));Ft(l)}const i=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${i}" aria-label="Auto-advance seconds" />
    ${Cr(10)}
  `;const a=t.querySelector("input");if(!a)return;a.focus(),a.select();const s=l=>{if(t.classList.remove("editing"),l){Ao(t,i);return}const u=a.value.trim();let f=5;if(u===""||u==="0")Zt(r.id,{autoAdvanceMs:null});else{const d=Number(u);Number.isFinite(d)&&d>0?(Zt(r.id,{autoAdvanceMs:Math.round(d*1e3)}),f=d):Zt(r.id,{autoAdvanceMs:null})}Ao(t,f)};a.addEventListener("blur",()=>s(!1)),a.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),a.blur()):l.key==="Escape"&&(l.preventDefault(),s(!0))}),a.addEventListener("mousedown",l=>l.stopPropagation())}function Ao(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${Cr(10)}
  `}function Mp(t,e){const{shadow:n,host:r}=S;if(!n||!r)return;fp(),hp(),Tp(),vp(),document.addEventListener("mousedown",yp,!0);const o=i=>i.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",i=>$p(i,t,e))}function $p(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void cp();if(o.closest('[data-action="prompter"]')){n(!0),Ki().then(()=>{pe()});return}if(o.closest('[data-action="export"]'))return sp();if(o.closest('[data-action="import"]'))return lp();if(o.closest('[data-action="settings-toggle"]'))return gp();const i=o.closest('[data-action="tool-set"]');if(i instanceof HTMLElement){t.stopPropagation();const s=i.getAttribute("data-tool");if(s==="shape"){ep(i,c=>{ku(c),D("shape")});return}D(vt()===s?"idle":s);return}if(Lp(t,o))return;const a=o.closest("[data-step-card]");if(a&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const s=Number(a.getAttribute("data-step-card"));if(Pn(s))return;Ft(s)}}function Lp(t,e){var c;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const l=Number(n.getAttribute("data-insert-index"));return Hr({insertIndex:l}),!0}if(e.closest('[data-action="step-add"]'))return Hr(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const l=Number(r.getAttribute("data-step-index"));return Pn(l)||(Ft(l),D(vt()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),As(Number(o.getAttribute("data-step-index"))),!0;const i=e.closest('[data-action="step-link"]');if(i){t.stopPropagation();const l=i.getAttribute("data-url")??"",u=i.closest("[data-step-card]"),f=u?Number(u.getAttribute("data-step-card")):0;return l&&ma(l,Number.isFinite(f)?f:0),!0}const a=e.closest('[data-action="step-action-toggle"]');if(a instanceof HTMLElement){t.stopPropagation();const l=Number(a.getAttribute("data-step-index")),u=(c=P())==null?void 0:c.steps[l];return u&&(Ft(l),Zt(u.id,{waitForNavigation:!u.waitForNavigation})),!0}const s=e.closest('[data-action="step-timer"]');return s instanceof HTMLElement?(t.stopPropagation(),s.classList.contains("disabled")||Ep(s),!0):!1}function Tp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>ar(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=P();r&&(e.textContent=r.name),ar(e),e.blur()}}),e.addEventListener("blur",()=>{ks(e.textContent??"")}))}function ar(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const Cp='[data-manuscript="ui"][data-region="permission-banner"]';function La(){return document.querySelector(Cp)}function Ip(t){const e=La();if(e){Ca(e,t);return}Pp(t)}function Ta(){const t=La();t&&t.remove()}function Ca(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function Pp(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),e.setAttribute("data-palette",ve),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${z+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=Dp(),Ca(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>Ta()),document.body.appendChild(e)}function Dp(){return`
    <style>
      ${qt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const He=16,Op=240,Np=/permission|<all_urls>|activeTab/i;async function Rp(t){const e=Fp({x:t.x-He,y:t.y-He,width:t.width+He*2,height:t.height+He*2});if(e.width<=0||e.height<=0)return null;const n=await zp();if(!n.ok)return Np.test(n.error)?Ip(b("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await Bp(n.dataUrl,e,Op)}catch(r){return console.error("[manuscript] crop failed",r),null}}function Fp(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function zp(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await _p();try{return{ok:!0,dataUrl:await Hp()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function Hp(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function _p(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function Bp(t,e,n){const r=await qp(t),o=r.naturalWidth/window.innerWidth||1,i=e.x*o,a=e.y*o,s=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),u=Math.max(1,Math.round(e.width*l)),f=Math.max(1,Math.round(e.height*l)),d=document.createElement("canvas");d.width=u,d.height=f;const p=d.getContext("2d");if(!p)throw new Error("No 2d context");return p.drawImage(r,i,a,s,c,0,0,u,f),d.toDataURL("image/png")}function qp(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function Ia(t){const e=t.detail;Ms(e.chain);const n=jp(e.rect,e.chain.framePath);Wp(n)}function jp(t,e){if(!e||e.length===0)return t;const n=Zs(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function Wp(t){try{const e=await Rp(t);Ss(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}function Up(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function Xp(){return`
      ${qt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function Yp(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -1px;
        left: 3px;
        font-family: var(--ff-mono);
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 1px 3px;
        border-radius: 2px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

  `}function Gp(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function Vp(){return[Xp(),Yp(),Gp(),Up()].join(`
`)}function Kp(){return`
    <style>${Vp()}</style>
    <div class="panel" role="region" aria-label="${b("panel.aria.region")}">
      ${Zp()}
      ${Qp()}
      <div class="body" data-region="steps"></div>
      ${Jp()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${b("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function Zp(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${qa({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <button type="button" class="close-btn" data-action="close" aria-label="${b("panel.close-aria")}">×</button>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${b("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function Qp(){return`
    <div class="tool-bar" role="toolbar" aria-label="${b("panel.tool-label")}">
      <span class="eyebrow">${b("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${b("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${b("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${b("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function Jp(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${b("panel.replay-aria")}" title="${b("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${b("panel.prompter-aria")}" title="${b("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${b("panel.import-aria")}" title="${b("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${b("panel.export-aria")}" title="${b("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${b("panel.settings-aria")}" title="${b("panel.settings.title")}" data-region="settings-toggle">
          ${Ap(16)}
        </button>
      </div>
      ${tf()}
    </div>
  `}function tf(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${b("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${b("panel.settings.close-aria")}" title="${b("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${b("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${b("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function ef(t){const e=t.pickedAtUrl;return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${et(e)}"
        aria-label="Open ${et(e)}"
      >${Sp(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${pn(e)}</span>
    </div>
  `:""}function nf(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,i=t.thumbnailDataUrl!==null,a=n&&vt()==="picker",s="step-thumb"+(o?" has-element":"")+(a?" is-picking":""),c=i?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,u=t.waitForNavigation;return r.innerHTML=`
    <button
      type="button"
      class="${s}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${et(b("step.wand-aria",{n:e+1}))}"
      title="${et(b("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!i?`<span class="step-thumb-icon">${kp(18)}</span>`:""}
      ${!o&&!i?'<span class="step-thumb-plus">+</span>':""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${et(b("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${pn(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${et(b("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${pn(t.description)}</div>
    </div>
    ${ef(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${u}" aria-label="${et(b("step.action-aria"))}" title="${et(b("step.action-aria"))}">${wp(10)}</button>
      <div class="step-timer${u?" disabled":""}" data-action="step-timer" data-step-id="${et(t.id)}" title="${et(b("step.timer-aria"))}" ${u?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${Cr(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${et(b("step.delete-aria"))}" title="${et(b("step.delete-aria"))}">${xp(12)}</button>
    </div>
  `,r}function rf(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function of(t,e,n){Eo(t,"step-name",n,r=>Zt(e.id,{name:r})),Eo(t,"step-desc",n,r=>Zt(e.id,{description:r}),{escapeBlurs:!0}),af(t,n)}function Eo(t,e,n,r,o={}){const i=t.querySelector(`[data-region="${e}"]`);i&&(i.addEventListener("input",()=>rf(i)),i.addEventListener("focus",()=>{Pn(n)||jt(n)}),i.addEventListener("mousedown",a=>a.stopPropagation()),i.addEventListener("blur",()=>r(i.textContent??"")),i.addEventListener("keydown",a=>{(a.key==="Enter"&&e==="step-name"||a.key==="Escape"&&o.escapeBlurs)&&(a.preventDefault(),i.blur())}))}function af(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}S.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),S.dragFromIndex=null,(n=S.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{S.dragFromIndex===null||S.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(S.dragFromIndex===null||S.dragFromIndex===e)&&(Es(S.dragFromIndex,e),S.dragFromIndex=null)})}function sf(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=P();if(e.innerHTML="",!n)return;const r=q();n.steps.forEach((i,a)=>{if(a>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(a)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${a+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${a}" aria-label="Insert step here">
          ${So(8,1.6)}
        </button>
      `,e.appendChild(c)}const s=nf(i,a,r===a);e.appendChild(s),of(s,i,a)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${So(10,1.8)}
    </button>
  `,e.appendChild(o)}function Pa(t){const{host:e}=S;e&&(e.dataset.promptedHidden=t?"1":"",vt()!=="replay"&&(e.style.display=t?"none":""))}async function gn(t){if(S.host){t&&await zr(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-palette",ve);const n=mp(window.innerHeight*ap);e.style.cssText=["position: fixed",`top: ${ee}px`,`right: ${ee}px`,`width: ${ip}px`,`height: ${n}px`,`max-height: calc(100vh - ${ee*2}px)`,`z-index: ${z+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=Kp(),S.host=e,S.shadow=r,Mp(Da,Pa),document.body.appendChild(e),t&&await zr(t)||Fr(),oa(),document.addEventListener(Se,Ia),window.addEventListener("resize",Aa),S.unsubscribeMode=ct(Xn),S.unsubscribeScenario=ye(Xn),Xn();const o=P();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(i){console.warn("[manuscript] markActive failed",i)}}function Da(){var e,n;const{host:t}=S;t&&(document.removeEventListener(Se,Ia),window.removeEventListener("resize",Aa),(e=S.unsubscribeMode)==null||e.call(S),S.unsubscribeMode=null,(n=S.unsubscribeScenario)==null||n.call(S),S.unsubscribeScenario=null,D("idle"),ie(),di(),ia(),Ho(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),S.host=null,S.shadow=null)}function Xn(){const{host:t,shadow:e}=S;if(!e||!t)return;const n=vt(),r=t.dataset.promptedHidden==="1";t.style.display=n==="replay"||r?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(a=>{const s=a.getAttribute("data-tool");a.setAttribute("aria-pressed",String(s===n))});const o=P(),i=e.querySelector('[data-region="title-edit"]');i&&o&&i!==e.activeElement&&(i.textContent!==o.name&&(i.textContent=o.name),ar(i)),sf(),$a(),Mn()&&!gt()&&pe()}function cf(t,e,n){switch(t.type){case"panel.open":return gn(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return Da(),n({ok:!0}),!1;case"scenario.replay":return gn(t.scenarioId).then(()=>$e(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return lf(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return Gu(),gt()&&ge(),Vd(),Pa(!1),n({ok:!0}),!1}return!1}function lf(t,e){if(gt()){t==="prev"?ln():t==="next"?me():t==="jump"&&typeof e=="number"?Lr(e):t==="pause"&&un();return}const n=P();if(!n)return;const r=q();if(t==="prev")r>0&&Ft(r-1),pe();else if(t==="next")r<n.steps.length-1&&Ft(r+1),pe();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(Pn(e))return;Ft(e)}pe()}else t==="pause"&&$e(r)}async function uf(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function df(){try{const t=await Co();if(!t)return;if(pf()){await chrome.storage.local.remove(Z.activeReplay);return}D("replay"),await gn(t.scenarioId),await $e(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function pf(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function ff(){try{const t=await uf();if(!t)return;await gn(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&jt(t.stepIndex)}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const hf="manuscript:host",mf="manuscript:ext",gf="manuscript:ready";let Mo=!1;function bf(){Mo||(window.addEventListener("message",yf),Mo=!0,ct(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Pt("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(gf)))}function vf(t){return typeof t=="object"&&t!==null&&t.source===hf&&typeof t.type=="string"}function Pt(t,e,n){const r={source:mf,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function yf(t){const e=t.data;if(vf(e))switch(e.type){case"ping":Pt("pong",e.requestId,{version:wf()});return;case"load":try{const n=xf(e.scenario);zo(n),Pt("load-ack",e.requestId,{ok:!0})}catch(n){Pt("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!hd()&&oa(),Pt("play-ack",e.requestId,{ok:!0}),$e(r,{paused:o,standalone:n}).catch(i=>{console.warn("[manuscript] startReplay failed",i)});return}case"pause":gt()&&un(),Pt("pause-ack",e.requestId,{ok:gt()});return;case"next":gt()&&me();return;case"prev":gt()&&ln();return;case"jump":gt()&&typeof e.index=="number"&&Lr(e.index);return;case"exit":(async()=>(gt()&&await ge(),Pt("exit-ack",e.requestId,{ok:!0})))();return}}function xf(t){if(t==null)throw new Dr("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new Dr("Invalid JSON",n)}return Or(e,{strict:!0})}return Or(t,{strict:!0})}function wf(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const kf=window===window.top;Ru();Qa();ja();eu();Tu();Wl();Su();Kl();fl();Wu();Xu();var $o,Lo;kf&&(Yu().then(()=>{df(),ff()}),chrome.runtime.onMessage.addListener(cf),(Lo=($o=chrome.permissions)==null?void 0:$o.onAdded)==null||Lo.addListener(()=>Ta()),bf());
