import './assets/chunk-CWb0FSeY.js';
