const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/chunk-is4wiPY0.js","assets/chunk-aRRa0OE6.js","assets/chunk-_P7E0VjS.js","assets/chunk-DAwYOt8I.js","assets/chunk-Cr8au9ne.js"])))=>i.map(i=>d[i]);
import{O as H,S as Q,E as qa}from"./chunk-aRRa0OE6.js";import{s as Ro,g as ja,S as Wa,a as dr,b as No,c as Ua,d as Xa,e as Ya,m as Ga,f as Fr,h as _r}from"./chunk-_P7E0VjS.js";import{t as b,i as Va}from"./chunk-DAwYOt8I.js";import{g as Fo,i as Ka,a as Za,b as _o,c as Qa,s as Ja,d as ts,w as es,l as ns,e as rs,f as os}from"./chunk-Cr8au9ne.js";const Zn="manuscript:mode-changed";let Ue="idle";function bt(){return Ue}function D(t){if(t===Ue)return;const e=Ue;Ue=t,document.dispatchEvent(new CustomEvent(Zn,{detail:{prev:e,next:t}}))}function dt(t){const e=n=>t(n.detail);return document.addEventListener(Zn,e),()=>document.removeEventListener(Zn,e)}function Ho(t,e,n){const r=Math.floor(t/60%6),o=t/60-Math.floor(t/60),i=n*(1-e),s=n*(1-o*e),a=n*(1-(1-o)*e);let c=0,l=0,u=0;switch(r){case 0:c=n,l=a,u=i;break;case 1:c=s,l=n,u=i;break;case 2:c=i,l=n,u=a;break;case 3:c=i,l=s,u=n;break;case 4:c=a,l=i,u=n;break;case 5:c=n,l=i,u=s;break}return[Math.round(c*255),Math.round(l*255),Math.round(u*255)]}function zo(t,e,n){const r=t/255,o=e/255,i=n/255,s=Math.max(r,o,i),a=Math.min(r,o,i),c=s-a;let l=0;return c!==0&&(s===r?l=(o-i)/c%6:s===o?l=(i-r)/c+2:l=(r-o)/c+4,l*=60,l<0&&(l+=360)),{h:l,s:s===0?0:c/s,v:s}}function Bo(t,e,n){return"#"+[t,e,n].map(r=>r.toString(16).padStart(2,"0")).join("")}function qo(t){let e=t.trim();if(!e.startsWith("#"))return{h:0,s:1,v:1};if(e=e.slice(1),e.length===3&&(e=e.split("").map(i=>i+i).join("")),e.length!==6)return{h:0,s:1,v:1};const n=parseInt(e.slice(0,2),16),r=parseInt(e.slice(2,4),16),o=parseInt(e.slice(4,6),16);return[n,r,o].some(i=>!Number.isFinite(i))?{h:0,s:1,v:1}:zo(n,r,o)}function Fn(t){const e=Number(t);return Number.isFinite(e)?Math.max(0,Math.min(255,Math.round(e))):0}function Hr(t,e){let n=!1;t.addEventListener("mousedown",r=>{n=!0,e(r),r.preventDefault()}),document.addEventListener("mousemove",r=>{n&&e(r)}),document.addEventListener("mouseup",()=>{n=!1})}async function is(t){let e;try{const n=window.top;e=n==null?void 0:n.EyeDropper}catch{}if(e||(e=window.EyeDropper),!e){console.info("[manuscript] EyeDropper API not available");return}try{const n=await new e().open();t(n.sRGBHex)}catch{}}const as=`/* ─────────────────────────────────────────────────────────────
   Manuscript — Design tokens
   3 palettes (A Ink, B Graphite, C Sepia) + shared accents + type scale
   All colors authored in oklch for perceptual harmony.
   ───────────────────────────────────────────────────────────── */

:root {
  /* Type — Pretendard Variable single family, weight scale */
  --ff-sans: 'Pretendard Variable', Pretendard, -apple-system, 'Apple SD Gothic Neo',
             'Helvetica Neue', Arial, sans-serif;
  --ff-mono: ui-monospace, 'SF Mono', 'JetBrains Mono', Menlo, Consolas, monospace;
  /* Classical serif — reserved for the brand wordmark. Renaissance Garamond
     reinforces the manuscript/manus-scriptus etymology. */
  --ff-serif: 'EB Garamond', 'Apple Garamond', Garamond, 'Times New Roman', serif;

  /* Scale (px) — Floating panel 작업 모드 기준. compact density.
     Body 14px가 최소; B2B 차분 톤에서 13/14가 표준.                  */
  --fs-display: 28px;  --lh-display: 1.2;  --fw-display: 600;
  --fs-h1:      20px;  --lh-h1:      1.3;  --fw-h1:      600;
  --fs-h2:      16px;  --lh-h2:      1.35; --fw-h2:      600;
  --fs-body:    14px;  --lh-body:    1.5;  --fw-body:    400;
  --fs-strong:  14px;  --lh-strong:  1.5;  --fw-strong:  500;
  --fs-small:   12px;  --lh-small:   1.45; --fw-small:   400;
  --fs-cap:     11px;  --lh-cap:     1.3;  --fw-cap:     600;
  --ls-cap:     0.08em;

  /* Radius + spacing — soft, document-like */
  --r-xs: 4px; --r-sm: 6px; --r-md: 10px; --r-lg: 14px; --r-pill: 999px;
  --shadow-sm: 0 1px 2px rgb(0 0 0 / 0.04), 0 1px 1px rgb(0 0 0 / 0.03);
  --shadow-md: 0 2px 6px rgb(0 0 0 / 0.06), 0 1px 2px rgb(0 0 0 / 0.04);
  --shadow-lg: 0 12px 28px rgb(0 0 0 / 0.10), 0 4px 8px rgb(0 0 0 / 0.05);
  /* Apple-leaning layered shadow for elevated cards (active step, etc.).
     Per-palette overrides may tune this in tokens.css. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);

  /* ───── Functional accents (shared across all palettes) ───── */
  --c-success: oklch(0.52 0.09 150);
  --c-warning: oklch(0.66 0.10 75);
  --c-error:   oklch(0.52 0.14 27);
  --c-info:    oklch(0.50 0.08 245);

  /* ───── PALETTE A — INK (default) ─────
     Deep navy on warm paper. Most B2B-standard, archival voice. */
  --c-bg:        oklch(0.985 0.005 80);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 80);
  --c-text:      oklch(0.18  0.015 250);
  --c-text-mute: oklch(0.45  0.012 250);
  --c-text-soft: oklch(0.62  0.010 250);
  --c-border:    oklch(0.91  0.008 250);
  --c-border-strong: oklch(0.82 0.012 250);
  --c-primary:   oklch(0.30  0.045 250);
  --c-primary-h: oklch(0.22  0.050 250);
  --c-primary-fg: oklch(0.985 0.003 80);
  --c-tint:      oklch(0.93  0.020 250); /* selected step bg */
  --c-focus:     oklch(0.55  0.10  250); /* focus ring */
}

/* ───── PALETTE B — GRAPHITE ─────
   Near-black on bone. Calmest, monochrome. Maximum trust signal. */
[data-palette="graphite"] {
  --c-bg:        oklch(0.97  0.004 70);
  --c-surface:   oklch(0.995 0.003 70);
  --c-surface-2: oklch(0.94  0.005 70);
  --c-text:      oklch(0.16  0.005 60);
  --c-text-mute: oklch(0.46  0.006 60);
  --c-text-soft: oklch(0.62  0.005 60);
  --c-border:    oklch(0.90  0.006 70);
  --c-border-strong: oklch(0.80 0.008 70);
  --c-primary:   oklch(0.22  0.008 60);
  --c-primary-h: oklch(0.12  0     0);
  --c-primary-fg: oklch(0.98  0.003 70);
  --c-tint:      oklch(0.93  0.006 70);
  --c-focus:     oklch(0.50  0.010 60);
}

/* ───── PALETTE C — SEPIA ─────
   Parchment + oxblood. Strongest manuscript metaphor. */
[data-palette="sepia"] {
  --c-bg:        oklch(0.96  0.013 75);
  --c-surface:   oklch(0.99  0.007 80);
  --c-surface-2: oklch(0.935 0.018 75);
  --c-text:      oklch(0.22  0.020 40);
  --c-text-mute: oklch(0.48  0.022 40);
  --c-text-soft: oklch(0.62  0.018 50);
  --c-border:    oklch(0.88  0.020 65);
  --c-border-strong: oklch(0.78 0.025 60);
  --c-primary:   oklch(0.35  0.085 27);
  --c-primary-h: oklch(0.28  0.090 27);
  --c-primary-fg: oklch(0.985 0.008 80);
  --c-tint:      oklch(0.92  0.025 60);
  --c-focus:     oklch(0.50  0.10  30);
}

/* ───── PALETTE D — STUDIO ─────
   Cool snow + Apple-leaning blue. Subtle borders, depth via shadow.
   chroma stays within doctrine (≤0.09). */
[data-palette="studio"] {
  --c-bg:        oklch(0.985 0.005 240);
  --c-surface:   oklch(1     0     0);
  --c-surface-2: oklch(0.965 0.006 240);
  --c-text:      oklch(0.20  0.020 240);
  --c-text-mute: oklch(0.50  0.015 240);
  --c-text-soft: oklch(0.66  0.010 240);
  --c-border:    oklch(0.92  0.008 240);
  --c-border-strong: oklch(0.84 0.010 240);
  --c-primary:   oklch(0.48  0.085 245);
  --c-primary-h: oklch(0.40  0.090 245);
  --c-primary-fg: oklch(0.99  0.003 240);
  --c-tint:      oklch(0.94  0.025 245);
  --c-focus:     oklch(0.60  0.13  245);

  /* Elevated-card shadow — softer + more layered than the default --shadow-md.
     Used on the active step in the floating panel. */
  --shadow-card: 0 1px 2px rgb(0 0 0 / 0.04),
                 0 4px 10px rgb(0 0 0 / 0.05),
                 0 12px 24px rgb(0 0 0 / 0.06);
}

/* ───── Annotation color sets ─────
   Two curated 8-color sets the user picks from when authoring annotations.
   These are independent from the UI palette so the shell can be calm
   while annotations stay expressive (or both can be calm together).      */
:root {
  /* Vibrant — figma-style. Default for "강조 우선" 사용자. */
  --ann-vib-1: oklch(0.18 0.005 250);   /* ink black */
  --ann-vib-2: oklch(0.99 0     0);     /* paper white */
  --ann-vib-3: oklch(0.62 0.22  27);    /* red */
  --ann-vib-4: oklch(0.70 0.18 350);    /* pink */
  --ann-vib-5: oklch(0.60 0.16 145);    /* green */
  --ann-vib-6: oklch(0.55 0.18 250);    /* blue */
  --ann-vib-7: oklch(0.82 0.15  90);    /* yellow */
  --ann-vib-8: oklch(0.50 0.18 290);    /* purple */

  /* Muted — same 8 hues, chroma halved. B2B-friendly default. */
  --ann-mut-1: oklch(0.20 0.008 250);
  --ann-mut-2: oklch(0.99 0     0);
  --ann-mut-3: oklch(0.45 0.10  27);
  --ann-mut-4: oklch(0.50 0.09 350);
  --ann-mut-5: oklch(0.45 0.08 145);
  --ann-mut-6: oklch(0.42 0.09 250);
  --ann-mut-7: oklch(0.62 0.10  75);
  --ann-mut-8: oklch(0.42 0.08 290);
}

/* ───── Base ───── */
html, body { margin: 0; padding: 0; }
body {
  font-family: var(--ff-sans);
  font-size: var(--fs-body);
  line-height: var(--lh-body);
  color: var(--c-text);
  background: var(--c-bg);
  font-feature-settings: 'ss03', 'cv01';
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}
* { box-sizing: border-box; }
`;function Pt(){return as.replace(/:root\s*\{/g,":host {")}const ue="studio",ss=140,cs=140;function ls(){return`
    ${Pt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .picker {
      width: 240px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
    }

    .top { display: flex; gap: 10px; }
    .sv {
      position: relative;
      flex: 1;
      height: ${ss}px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      cursor: crosshair;
      overflow: hidden;
      user-select: none;
    }
    .sv-base { position: absolute; inset: 0; }
    .sv-white {
      position: absolute; inset: 0;
      background: linear-gradient(to right, #ffffff, rgba(255, 255, 255, 0));
    }
    .sv-black {
      position: absolute; inset: 0;
      background: linear-gradient(to top, #000000, rgba(0, 0, 0, 0));
    }
    .sv-cursor {
      position: absolute;
      width: 12px; height: 12px;
      border: 1.5px solid #ffffff;
      border-radius: 999px;
      transform: translate(-50%, -50%);
      box-shadow: 0 0 0 1px rgb(0 0 0 / 0.35);
      pointer-events: none;
    }

    .hue {
      position: relative;
      width: 12px;
      height: ${cs}px;
      border-radius: 999px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      background: linear-gradient(
        to bottom,
        #f00 0%, #ff0 17%, #0f0 33%,
        #0ff 50%, #00f 67%, #f0f 83%, #f00 100%
      );
      user-select: none;
    }
    .hue-cursor {
      position: absolute;
      left: 50%;
      width: 18px; height: 8px;
      border-radius: 4px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.12);
      transform: translate(-50%, -50%);
      pointer-events: none;
    }
  `}function us(){return`
    .actions { display: flex; align-items: center; gap: 6px; }
    .icon-btn {
      width: 28px; height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
      background: var(--c-surface);
      color: var(--c-text);
      cursor: pointer;
      padding: 0;
      display: grid;
      place-items: center;
      transition: border-color 0.12s ease;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }
    .icon-btn:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .icon-btn svg { display: block; }
    .preview {
      flex: 1;
      height: 28px;
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border-strong);
      box-shadow: inset 0 0 0 1px rgb(255 255 255 / 0.12);
    }
    .confirm {
      border-color: var(--c-text);
      background: var(--c-text);
      color: var(--c-surface);
    }
    .confirm:hover {
      background: var(--c-primary);
      border-color: var(--c-primary);
      color: var(--c-primary-fg);
    }

    .rgb-wrap { display: flex; flex-direction: column; gap: 4px; }
    .rgb-head {
      display: flex;
      align-items: center;
      justify-content: space-between;
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .modes { display: inline-flex; gap: 8px; }
    .modes .active { color: var(--c-text); }
    .hex-display {
      font-family: var(--ff-mono);
      font-size: 10px;
      letter-spacing: 0;
      color: var(--c-text-mute);
      text-transform: none;
    }
    .rgb { display: flex; gap: 8px; }
    .rgb-cell {
      flex: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 5px;
    }
    .rgb-cell input {
      width: 100%;
      height: 28px;
      padding: 0 8px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-mono);
      font-size: 12px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      text-align: center;
      line-height: 1;
      appearance: textfield;
    }
    .rgb-cell input:focus {
      outline: none;
      border-color: var(--c-focus);
    }
    .rgb-cell input::-webkit-outer-spin-button,
    .rgb-cell input::-webkit-inner-spin-button {
      -webkit-appearance: none;
      margin: 0;
    }
    .rgb-cell label {
      font-size: 9px;
      font-weight: 600;
      letter-spacing: 0.10em;
      color: var(--c-text-soft);
      text-transform: uppercase;
      line-height: 1;
    }

    .recent { display: flex; flex-direction: column; gap: 6px; }
    .recent-label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
    }
    .recent-list { display: flex; gap: 4px; flex-wrap: wrap; }
    .recent-swatch {
      width: 18px;
      height: 18px;
      border-radius: 4px;
      border: 1px solid var(--c-border);
      cursor: pointer;
      padding: 0;
      background: transparent;
    }
    .recent-swatch:hover { border-color: var(--c-border-strong); }
    .recent-swatch:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 1px;
    }
  `}function ds(){return[ls(),us()].join(`
`)}const Qn="manuscript:scenario-changed",ps=500,fs=5e3,m={scenario:null,currentStepIndex:0,saveTimer:null};function P(){return m.scenario}function W(){return m.currentStepIndex}function ot(){return m.scenario?m.scenario.steps[m.currentStepIndex]??null:null}function de(t){return document.addEventListener(Qn,t),()=>document.removeEventListener(Qn,t)}function j(){document.dispatchEvent(new CustomEvent(Qn)),hs()}function it(){m.scenario&&(m.scenario.updatedAt=new Date().toISOString())}function jo(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function pr(){return{id:jo("step"),name:"",description:"",thumbnailDataUrl:null,selectors:null,annotations:[],autoAdvanceMs:fs,waitForNavigation:!1}}function hs(){if(!m.scenario)return;m.saveTimer!==null&&window.clearTimeout(m.saveTimer);const t=m.scenario;m.saveTimer=window.setTimeout(()=>{m.saveTimer=null,Ro(t).catch(e=>{console.error("[manuscript] save failed",e)})},ps)}function wn(){m.saveTimer!==null&&(window.clearTimeout(m.saveTimer),m.saveTimer=null,m.scenario&&Ro(m.scenario).catch(t=>{console.error("[manuscript] flush save failed",t)}))}const ms=["--primary","--brand","--accent","--theme-color","--color-primary","--color-brand","--color-accent","--color-link","--link-color","--primary-color","--brand-color","--accent-color","--bs-primary","--bs-link-color"],gs=8,bs=5;function vs(){if(typeof document>"u")return{text:[],background:[]};const t=new Set,e=document.querySelector('meta[name="theme-color"]');if(e){const s=Jn(e.getAttribute("content"));s&&t.add(s)}const n=getComputedStyle(document.documentElement);for(const s of ms){const a=Jn(n.getPropertyValue(s));a&&t.add(a)}const r=[{el:document.body,prop:"background-color"},{el:document.querySelector("header"),prop:"background-color"},{el:document.querySelector("nav"),prop:"background-color"},{el:document.querySelector("a[href]"),prop:"color"},{el:document.querySelector("h1"),prop:"color"}];for(const{el:s,prop:a}of r)zr(t,s,a);const o=document.querySelectorAll('button:not([disabled]), [role="button"], .btn, a.button');for(let s=0;s<o.length&&s<bs;s++)zr(t,o[s]??null,"background-color");const i=Array.from(t).filter(ys).slice(0,gs);return{text:i,background:i}}function zr(t,e,n){if(!e||e.closest('[data-manuscript="ui"]'))return;const r=getComputedStyle(e).getPropertyValue(n),o=Jn(r);o&&t.add(o)}function Jn(t){if(!t)return null;const e=t.trim().toLowerCase();if(!e||e==="transparent"||e==="inherit"||e==="initial"||e==="currentcolor")return null;if(e.startsWith("#")){if(/^#[0-9a-f]{3}$/.test(e)){const r=e[1],o=e[2],i=e[3];return`#${r}${r}${o}${o}${i}${i}`}return/^#[0-9a-f]{6}$/.test(e)?e:/^#[0-9a-f]{8}$/.test(e)?e.slice(0,7):null}const n=e.match(/^rgba?\(\s*(\d+)\s*[,\s]\s*(\d+)\s*[,\s]\s*(\d+)(?:\s*[,/]\s*([\d.]+))?\s*\)$/);if(n){if((n[4]!==void 0?Number(n[4]):1)<.5)return null;const o=_n(n[1]),i=_n(n[2]),s=_n(n[3]);return`#${Hn(o)}${Hn(i)}${Hn(s)}`}return null}function _n(t){return Math.max(0,Math.min(255,Number(t)|0))}function Hn(t){return t.toString(16).padStart(2,"0")}function ys(t){const e=t.match(/^#([0-9a-f]{2})([0-9a-f]{2})([0-9a-f]{2})$/);if(!e)return!1;const n=parseInt(e[1],16),r=parseInt(e[2],16),o=parseInt(e[3],16);if(n>245&&r>245&&o>245||n<10&&r<10&&o<10)return!1;const i=Math.max(n,r,o),s=Math.min(n,r,o);return!(i-s<12)}const xs="'Asta Sans', sans-serif",ws=6,ks=new Set(["serif","sans-serif","monospace","cursive","fantasy","system-ui","ui-sans-serif","ui-serif","ui-monospace","ui-rounded","math","emoji","fangsong","inherit","initial","unset","revert"]);function Ss(){if(typeof document>"u")return[];const t=[document.body,document.querySelector("h1"),document.querySelector("h2"),document.querySelector("p"),document.querySelector("a[href]"),document.querySelector("button:not([disabled])"),document.querySelector("nav"),document.querySelector("code"),document.querySelector("pre")],e=new Set,n=[];for(const r of t){if(!r||r.closest('[data-manuscript="ui"]'))continue;const o=getComputedStyle(r).fontFamily;if(!o)continue;const i=o.trim();if(!i)continue;const s=As(i);if(!s)continue;const a=s.toLowerCase();if(!ks.has(a)&&!e.has(a)&&(e.add(a),n.push(Es(i)),n.length>=ws))break}return n}function As(t){const e=t.split(",")[0];if(!e)return null;const n=e.trim();return n&&(n.startsWith('"')&&n.endsWith('"')||n.startsWith("'")&&n.endsWith("'")?n.slice(1,-1):n).trim()||null}function Es(t){return/asta\s*sans/i.test(t)?t:`${t}, ${xs}`}function Br(){wn();const t=Ms(),e=$s();m.scenario={schemaVersion:Wa,id:jo("scn"),name:"Untitled",url:typeof location<"u"?location.href:"",createdAt:new Date().toISOString(),updatedAt:new Date().toISOString(),steps:[pr()],...t?{siteColors:t}:{},...e&&e.length>0?{siteFonts:e}:{}},m.currentStepIndex=0,j()}function Ms(){try{const t=vs();return t.text.length===0&&t.background.length===0?null:t}catch(t){return console.warn("[manuscript] extractSiteColors failed",t),null}}function $s(){try{return Ss()}catch(t){return console.warn("[manuscript] extractSiteFonts failed",t),null}}async function qr(t){wn();const e=await ja(t);return e?(m.scenario=e,m.currentStepIndex=0,j(),!0):!1}function Wo(t){wn(),m.scenario=t,m.currentStepIndex=0,j()}function Ls(t){if(!m.scenario)return;const e=t.trim();!e||e===m.scenario.name||(m.scenario.name=e,m.scenario.updatedAt=new Date().toISOString(),j())}function Uo(){wn(),m.scenario=null,m.currentStepIndex=0,j()}function jr(t={}){if(!m.scenario)return-1;const e=t.insertIndex===void 0||t.insertIndex<0||t.insertIndex>m.scenario.steps.length?m.scenario.steps.length:t.insertIndex;return m.scenario.steps.splice(e,0,pr()),it(),m.currentStepIndex=e,j(),m.currentStepIndex}function te(t,e){if(!m.scenario)return;const n=m.scenario.steps.find(o=>o.id===t);if(!n)return;let r=!1;e.name!==void 0&&e.name!==n.name&&(n.name=e.name,r=!0),e.description!==void 0&&e.description!==n.description&&(n.description=e.description,r=!0),e.autoAdvanceMs!==void 0&&e.autoAdvanceMs!==n.autoAdvanceMs&&(n.autoAdvanceMs=e.autoAdvanceMs,r=!0),e.thumbnailDataUrl!==void 0&&e.thumbnailDataUrl!==n.thumbnailDataUrl&&(n.thumbnailDataUrl=e.thumbnailDataUrl,r=!0),e.waitForNavigation!==void 0&&e.waitForNavigation!==n.waitForNavigation&&(n.waitForNavigation=e.waitForNavigation,r=!0),r&&(it(),j())}function Ts(t){const e=ot();!e||!m.scenario||e.thumbnailDataUrl!==t&&(e.thumbnailDataUrl=t,it(),j())}function Cs(t){m.scenario&&(t<0||t>=m.scenario.steps.length||(m.scenario.steps.splice(t,1),m.scenario.steps.length===0?(m.scenario.steps.push(pr()),m.currentStepIndex=0):m.currentStepIndex>=m.scenario.steps.length?m.currentStepIndex=m.scenario.steps.length-1:t<m.currentStepIndex&&(m.currentStepIndex-=1),it(),j()))}function Bf(t){const e=ot();if(!e||!m.scenario)return;const r={...e.spotlight??{},...t};for(const o of Object.keys(r))r[o]===void 0&&delete r[o];Object.keys(r).length===0?delete e.spotlight:e.spotlight=r,it(),j()}function Ut(t){m.scenario&&(t<0||t>=m.scenario.steps.length||t!==m.currentStepIndex&&(m.currentStepIndex=t,j()))}function Is(t,e){if(!m.scenario||t===e||t<0||t>=m.scenario.steps.length||e<0||e>=m.scenario.steps.length)return;const[n]=m.scenario.steps.splice(t,1);n&&(m.scenario.steps.splice(e,0,n),m.currentStepIndex===t?m.currentStepIndex=e:t<m.currentStepIndex&&e>=m.currentStepIndex?m.currentStepIndex-=1:t>m.currentStepIndex&&e<=m.currentStepIndex&&(m.currentStepIndex+=1),it(),j())}function Ps(t){const e=ot();!e||!m.scenario||(e.selectors=t,typeof location<"u"&&(e.pickedAtUrl=location.href),it(),j())}function Ee(t){const e=ot();!e||!m.scenario||(e.annotations.push(t),it(),j())}function Xo(t){const e=ot();!e||!m.scenario||(e.annotations=e.annotations.filter(n=>n.id!==t),it(),j())}function C(t,e){const n=ot();!n||!m.scenario||(n.annotations=n.annotations.map(r=>r.id===t?{...r,...e}:r),it(),j())}function Yo(){var t;return((t=ot())==null?void 0:t.annotations)??[]}function T(t){return Yo().find(e=>e.id===t)}function Ds(t,e){if(!m.scenario)return;const n=e.trim();if(!n)return;const r=m.scenario.customColors??{},o=r[t]??[];o.includes(n)||(m.scenario.customColors={...r,[t]:[...o,n]},it(),j())}function Os(t,e){if(!m.scenario||!m.scenario.customColors)return;const n=m.scenario.customColors[t];!n||!n.includes(e)||(m.scenario.customColors={...m.scenario.customColors,[t]:n.filter(r=>r!==e)},it(),j())}function Rs(){return`
    <style>${ds()}</style>
    <div class="picker" role="dialog" aria-label="Custom color picker">
      ${Ns()}
      ${Fs()}
      ${_s()}
      ${Hs()}
    </div>
  `}function Ns(){return`
    <div class="top">
      <div class="sv" data-region="sv">
        <div class="sv-base" data-region="sv-base"></div>
        <div class="sv-white"></div>
        <div class="sv-black"></div>
        <div class="sv-cursor" data-region="sv-cursor"></div>
      </div>
      <div class="hue" data-region="hue">
        <div class="hue-cursor" data-region="hue-cursor"></div>
      </div>
    </div>
  `}function Fs(){return`
    <div class="actions">
      <button type="button" class="icon-btn" data-action="eyedrop" title="Pick from page" aria-label="Eyedropper">
        <svg width="14" height="14" viewBox="0 0 16 16" fill="currentColor">
          <g transform="rotate(45 8 8)">
            <path d="M 6 2 a 2 1.5 0 0 1 4 0 v 1.5 h -0.4 v 1 h 0.4 v 5.4 l -2 4.6 l -2 -4.6 v -5.4 h 0.4 v -1 h -0.4 z"/>
          </g>
        </svg>
      </button>
      <div class="preview" data-region="preview"></div>
      <button type="button" class="icon-btn confirm" data-action="confirm" title="Apply" aria-label="Confirm and apply color">
        <svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M 3.5 8.5 L 6.5 11.5 L 12.5 5"/>
        </svg>
      </button>
    </div>
  `}function _s(){return`
    <div class="rgb-wrap">
      <div class="rgb-head">
        <span class="modes">
          <span class="active">RGB</span>
          <span>HEX</span>
          <span>HSL</span>
        </span>
        <span class="hex-display" data-region="hex">#000000</span>
      </div>
      <div class="rgb">
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="r" aria-label="Red" />
          <label>R</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="g" aria-label="Green" />
          <label>G</label>
        </div>
        <div class="rgb-cell">
          <input type="number" min="0" max="255" data-channel="b" aria-label="Blue" />
          <label>B</label>
        </div>
      </div>
    </div>
  `}function Hs(){var i,s;const t=P(),e=((i=t==null?void 0:t.customColors)==null?void 0:i.text)??[],n=((s=t==null?void 0:t.customColors)==null?void 0:s.background)??[],r=Array.from(new Set([...e,...n])).slice(-7);return r.length===0?"":`
    <div class="recent" data-region="recent">
      <span class="recent-label">Recent</span>
      <div class="recent-list">${r.map(a=>`<button type="button" class="recent-swatch" data-action="recent" data-color="${Oe(a)}" style="background: ${Oe(a)}" aria-label="Use ${Oe(a)}" title="${Oe(a)}"></button>`).join("")}</div>
    </div>
  `}function Oe(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/'/g,"&#39;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function zs(t,e){const n=e.getBoundingClientRect();t.style.top="0px",t.style.left="0px";const r=t.getBoundingClientRect();let o=n.bottom+8;o+r.height>window.innerHeight-8&&(o=n.top-r.height-8);let i=n.left;i+r.width>window.innerWidth-8&&(i=window.innerWidth-r.width-8),t.style.top=`${Math.max(8,o)}px`,t.style.left=`${Math.max(8,i)}px`}let K=null,F=null,Lt=0,Bt=1,qt=1,Tt=null;function Bs(t){jt(),Tt=t.onConfirm;const e=qo(t.initialColor);Lt=e.h,Bt=e.s,qt=e.v,K=document.createElement("div"),K.setAttribute("data-manuscript","ui"),K.setAttribute("data-palette",ue),K.style.cssText=["position: fixed",`z-index: ${H+7}`,"pointer-events: auto"].join("; "),F=K.attachShadow({mode:"open"}),F.innerHTML=Rs(),js(),document.body.appendChild(K),zs(K,t.anchor),Me(),document.addEventListener("mousedown",Vo,!0),document.addEventListener("keydown",Ko,!0)}function jt(){K&&(document.removeEventListener("mousedown",Vo,!0),document.removeEventListener("keydown",Ko,!0),K.remove(),K=null,F=null,Tt=null)}function qs(){return K!==null}function Me(){if(!F)return;const t=F.querySelector('[data-region="sv-base"]');t&&(t.style.background=`hsl(${Lt}deg, 100%, 50%)`);const e=F.querySelector('[data-region="sv-cursor"]');e&&(e.style.left=`${Bt*100}%`,e.style.top=`${(1-qt)*100}%`);const n=F.querySelector('[data-region="hue-cursor"]');n&&(n.style.top=`${Lt/360*100}%`);const[r,o,i]=Ho(Lt,Bt,qt),s=Bo(r,o,i),a=F.querySelector('[data-region="preview"]');a&&(a.style.background=`rgb(${r}, ${o}, ${i})`);const c=F.querySelector('[data-region="hex"]');c&&(c.textContent=s),F.querySelectorAll("[data-channel]").forEach(l=>{if(document.activeElement===K&&F.activeElement===l)return;const u=l.dataset.channel;u==="r"?l.value=String(r):u==="g"?l.value=String(o):u==="b"&&(l.value=String(i))})}function Go(){const[t,e,n]=Ho(Lt,Bt,qt);return Bo(t,e,n)}function js(){if(!F)return;const t=F.querySelector('[data-region="sv"]');t&&Hr(t,n=>Ws(t,n));const e=F.querySelector('[data-region="hue"]');e&&Hr(e,n=>Us(e,n)),F.addEventListener("input",n=>{var c,l,u;const r=n.target;if(!(r instanceof HTMLInputElement)||!r.dataset.channel)return;const o=Fn((c=F.querySelector('[data-channel="r"]'))==null?void 0:c.value),i=Fn((l=F.querySelector('[data-channel="g"]'))==null?void 0:l.value),s=Fn((u=F.querySelector('[data-channel="b"]'))==null?void 0:u.value),a=zo(o,i,s);Lt=a.h,Bt=a.s,qt=a.v,Me()}),F.addEventListener("click",n=>{const r=n.target;if(!(r instanceof Element))return;const o=r.closest("[data-action]"),i=o==null?void 0:o.getAttribute("data-action");if(i==="confirm")Tt==null||Tt(Go()),jt();else if(i==="eyedrop")is(Wr);else if(i==="recent"){const s=o==null?void 0:o.getAttribute("data-color");s&&Wr(s)}})}function Wr(t){const e=qo(t);Lt=e.h,Bt=e.s,qt=e.v,Me()}function Ws(t,e){const n=t.getBoundingClientRect();Bt=Math.max(0,Math.min(1,(e.clientX-n.left)/n.width)),qt=Math.max(0,Math.min(1,1-(e.clientY-n.top)/n.height)),Me()}function Us(t,e){const n=t.getBoundingClientRect();Lt=Math.max(0,Math.min(1,(e.clientY-n.top)/n.height))*360,Me()}function Vo(t){if(!K)return;const e=t.target;e instanceof HTMLElement&&K.contains(e)||jt()}function Ko(t){t.key==="Escape"?(t.preventDefault(),jt()):t.key==="Enter"&&(t.preventDefault(),Tt==null||Tt(Go()),jt())}const Re=8,Gt=6,Zo=32,Ur=16,Ne=4,Qo=[{name:"nw",cursor:"nwse-resize",offset:t=>({x:t.x,y:t.y})},{name:"n",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y})},{name:"ne",cursor:"nesw-resize",offset:t=>({x:t.x+t.width,y:t.y})},{name:"e",cursor:"ew-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height/2})},{name:"se",cursor:"nwse-resize",offset:t=>({x:t.x+t.width,y:t.y+t.height})},{name:"s",cursor:"ns-resize",offset:t=>({x:t.x+t.width/2,y:t.y+t.height})},{name:"sw",cursor:"nesw-resize",offset:t=>({x:t.x,y:t.y+t.height})},{name:"w",cursor:"ew-resize",offset:t=>({x:t.x,y:t.y+t.height/2})}];function Xr(t,e,n,r){let{x:o,y:i,width:s,height:a}=e;return t==="nw"||t==="w"||t==="sw"?(o+=n,s-=n):(t==="ne"||t==="e"||t==="se")&&(s+=n),t==="nw"||t==="n"||t==="ne"?(i+=r,a-=r):(t==="sw"||t==="s"||t==="se")&&(a+=r),s<Gt&&(o=e.x+e.width-Gt,s=Gt),a<Gt&&(i=e.y+e.height-Gt,a=Gt),{x:o,y:i,width:s,height:a}}function Jo(t){if(t.length===0)return null;let e=1/0,n=1/0,r=-1/0,o=-1/0;for(const i of t)i.x<e&&(e=i.x),i.y<n&&(n=i.y),i.x>r&&(r=i.x),i.y>o&&(o=i.y);return{x:e,y:n,width:r-e,height:o-n}}function Xs(t){const e=document.querySelector(`[data-annotation-text="${t}"]`);if(!e)return null;const n=e.getBoundingClientRect();return{x:n.left,y:n.top,width:n.width,height:n.height}}const M={host:null,activeId:null,activeMode:"shape",dragState:null,unsubscribeScenario:null},O="http://www.w3.org/2000/svg";function ti(t,e=4){const n=[];let r=t,o=0;for(;r&&r!==document.body&&o<e;){const i=r.tagName.toLowerCase(),s=r.parentElement,a=r.tagName;if(s){const c=Array.from(s.children).filter(l=>{var u;return l.tagName===a&&!((u=l.matches)!=null&&u.call(l,'[data-manuscript="ui"]'))});if(c.length>1){const l=c.indexOf(r)+1;n.unshift(`${i}:nth-of-type(${l})`)}else n.unshift(i)}else n.unshift(i);r=s,o++}return n.join(" > ")}function fr(t){var e;return((e=t.closest)==null?void 0:e.call(t,'[data-manuscript="ui"]'))!==null}function Ys(t){return typeof CSS<"u"&&typeof CSS.escape=="function"?CSS.escape(t):t.replace(/[^\w-]/g,"\\$&")}const Gs=["data-testid","data-test","id","aria-label"];function Vs(t){for(const e of Gs){const n=t.getAttribute(e);if(n&&n.length>0)return{kind:"stable-attr",cssSelector:`[${e}="${Ys(n)}"]`}}return{kind:"stable-attr",cssSelector:ti(t)}}function Ks(t,e){try{const n=Array.from(e.querySelectorAll(t.cssSelector)),r=[];for(const o of n)if(!fr(o)&&(r.push(o),r.length>1))return null;return r[0]??null}catch{return null}}function Zs(t){const e=(t.textContent??"").trim().slice(0,100),n=t.parentElement?ti(t.parentElement,2):"";return{kind:"text-parent",text:e,parentSelector:n,tagName:t.tagName.toLowerCase()}}function Qs(t,e){return t.text?(t.parentSelector?Array.from(e.querySelectorAll(`${t.parentSelector} ${t.tagName}`)):Array.from(e.querySelectorAll(t.tagName))).find(r=>!fr(r)&&(r.textContent??"").trim().includes(t.text))??null:null}function Js(t){const e=t.getBoundingClientRect(),n=[];let r=t.parentElement;for(let o=0;o<2&&r;o++){for(const i of Array.from(r.children)){if(i===t)continue;const s=(i.textContent??"").trim();if(s.length>0&&s.length<60&&n.push(s),n.length>=4)break}r=r.parentElement}return{kind:"visual-heuristic",x:Math.round(e.left),y:Math.round(e.top),width:Math.round(e.width),height:Math.round(e.height),nearbyText:n.slice(0,4)}}function tc(t,e){var a;if(typeof e.elementFromPoint!="function")return null;const n=e.elementFromPoint(t.x+Math.floor(t.width/2),t.y+Math.floor(t.height/2));if(!(n instanceof HTMLElement)||fr(n))return null;const r=n.getBoundingClientRect();if(!(Math.abs(r.width-t.width)<t.width*.5&&Math.abs(r.height-t.height)<t.height*.5))return null;if(t.nearbyText.length===0)return n;const i=(((a=n.parentElement)==null?void 0:a.textContent)??"").trim();return t.nearbyText.some(c=>i.includes(c))?n:null}function ec(t){return{layer1:Vs(t),layer2:Zs(t),layer3:Js(t)}}function nc(t,e){const n=e.ownerDocument;return n?ei(t,n)===e:!1}function ye(t){const e=ni(t.framePath);return e?ei(t,e):null}function ei(t,e){return Ks(t.layer1,e)??Qs(t.layer2,e)??tc(t.layer3,e)}function ni(t){if(!t||t.length===0)return document;if(typeof window>"u")return null;let e=window;for(const n of t){const r=e.frames[n.index];if(!r)return null;e=r}try{return e.document}catch{return null}}function rc(t){if(!t||t.length===0||typeof window>"u")return null;const e=t[0];return e?document.querySelectorAll("iframe")[e.index]??null:null}function Y(){const t=ot();if(!t||!t.selectors)return null;try{const e=ye(t.selectors);return e?e.getBoundingClientRect():null}catch{return null}}function oc(t,e){return t.anchorOffset&&e?{x:e.left+t.anchorOffset.x,y:e.top+t.anchorOffset.y}:t.position}function kn(t,e){return t.boundsAnchorOffset&&e?{x:e.left+t.boundsAnchorOffset.x,y:e.top+t.boundsAnchorOffset.y}:{x:t.bounds.x,y:t.bounds.y}}function ic(t,e){const n=t.fromAnchorOffset&&e?{x:e.left+t.fromAnchorOffset.x,y:e.top+t.fromAnchorOffset.y}:t.from,r=t.toAnchorOffset&&e?{x:e.left+t.toAnchorOffset.x,y:e.top+t.toAnchorOffset.y}:t.to;return{from:n,to:r}}function Sn(t,e){return t.pointsAnchorOffset&&e&&t.pointsAnchorOffset.length===t.points.length?t.pointsAnchorOffset.map(n=>({x:e.left+n.x,y:e.top+n.y})):t.points}function ri(t){if(!t.bounds)return t;const e=Y();return e?{...t,boundsAnchorOffset:{x:t.bounds.x-e.left,y:t.bounds.y-e.top}}:{...t,boundsAnchorOffset:void 0}}function ac(t){if(!t.points)return t;const e=Y();return e?{...t,pointsAnchorOffset:t.points.map(n=>({x:n.x-e.left,y:n.y-e.top}))}:{...t,pointsAnchorOffset:void 0}}function sc(){document.removeEventListener("mousemove",hr,!0),document.removeEventListener("mouseup",mr,!0),document.removeEventListener("keydown",ii,!0)}function cc(){document.addEventListener("keydown",ii,!0)}function lc(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="shape")return;const r=kn(n,Y());M.dragState={kind:"resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...n.bounds,x:r.x,y:r.y}},An()}function uc(t){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const e=T(M.activeId);if(!e||e.kind!=="shape")return;const n=e.bounds.x+e.bounds.width/2,r=e.bounds.y+e.bounds.height/2,o=Math.atan2(t.clientY-r,t.clientX-n)*180/Math.PI;M.dragState={kind:"rotate",center:{x:n,y:r},startMouseAngle:o,startRotation:e.rotate??0},An()}function oi(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n)return;const r=e(),o=Math.atan2(t.clientY-r.y,t.clientX-r.x)*180/Math.PI,i=n.kind==="shape"||n.kind==="freedraw"||n.kind==="text"?n.rotate??0:0;M.dragState={kind:"rotate",center:r,startMouseAngle:o,startRotation:i},An()}function dc(t,e){if(!M.activeId)return;t.stopPropagation(),t.preventDefault();const n=T(M.activeId);if(!n||n.kind!=="freedraw")return;const r=Sn(n,Y()),o=Jo(r);!o||o.width===0||o.height===0||(M.dragState={kind:"freedraw-resize",handle:e,startMouse:{x:t.clientX,y:t.clientY},startBounds:{...o},startPoints:r.map(i=>({...i}))},An())}function An(){document.addEventListener("mousemove",hr,!0),document.addEventListener("mouseup",mr,!0)}function hr(t){const{activeId:e,dragState:n}=M;if(!e||!n)return;t.preventDefault();const r=T(e);if(!r)return;const o=n.kind!=="rotate"?t.clientX-n.startMouse.x:0,i=n.kind!=="rotate"?t.clientY-n.startMouse.y:0;if(n.kind==="resize"&&r.kind==="shape"){const s=Xr(n.handle,n.startBounds,o,i);C(e,ri({bounds:s}))}else if(n.kind==="freedraw-resize"&&r.kind==="freedraw"){const s=n.startBounds,a=Xr(n.handle,s,o,i),c=s.width===0?1:a.width/s.width,l=s.height===0?1:a.height/s.height,u=n.startPoints.map(f=>({x:a.x+(f.x-s.x)*c,y:a.y+(f.y-s.y)*l}));C(e,ac({points:u}))}else if(n.kind==="rotate"){const s=Math.atan2(t.clientY-n.center.y,t.clientX-n.center.x)*180/Math.PI;let a=(n.startRotation+(s-n.startMouseAngle))%360;a<0&&(a+=360),r.kind==="shape"?C(e,{rotate:a}):r.kind==="freedraw"?C(e,{rotate:a}):r.kind==="text"&&C(e,{rotate:a})}}function mr(){document.removeEventListener("mousemove",hr,!0),document.removeEventListener("mouseup",mr,!0),M.dragState=null}function ii(t){var o;const{activeId:e}=M;if(!e)return;const n=(o=t.target)==null?void 0:o.tagName;if(n==="INPUT"||n==="TEXTAREA"||n==="SELECT")return;const r=document.activeElement;if(!(r!=null&&r.isContentEditable)){if(t.key==="Delete"||t.key==="Backspace"){t.preventDefault(),Xo(e);return}if(t.key.startsWith("Arrow")){const i=T(e);if(!i||i.kind!=="shape")return;const s=t.shiftKey?10:1,a=t.key==="ArrowLeft"?-s:t.key==="ArrowRight"?s:0,c=t.key==="ArrowUp"?-s:t.key==="ArrowDown"?s:0;if(a!==0||c!==0){t.preventDefault();const l=kn(i,Y());C(e,ri({bounds:{...i.bounds,x:l.x+a,y:l.y+c}}))}}}}function ai(t,e,n,r,o){const i=document.createElementNS(O,"rect");return i.setAttribute("x",String(t-Re/2)),i.setAttribute("y",String(e-Re/2)),i.setAttribute("width",String(Re)),i.setAttribute("height",String(Re)),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.48 0.085 245)"),i.setAttribute("stroke-width","2"),i.style.cursor=r,i.style.pointerEvents="auto",i.setAttribute("pointer-events","all"),i.addEventListener("mousedown",s=>o(s,n)),i}function si(t,e,n){const r=document.createElementNS(O,"g"),o=e-18,i=e-Zo,s=12,a=document.createElementNS(O,"line");a.setAttribute("x1",String(t)),a.setAttribute("y1",String(e)),a.setAttribute("x2",String(t)),a.setAttribute("y2",String(o)),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","1"),a.setAttribute("stroke-dasharray","2 3"),a.style.pointerEvents="none",r.appendChild(a);const c=document.createElementNS(O,"circle");c.setAttribute("cx",String(t)),c.setAttribute("cy",String(i+1)),c.setAttribute("r",String(s)),c.setAttribute("fill","rgba(0,0,0,0.04)"),c.style.pointerEvents="none",r.appendChild(c);const l=document.createElementNS(O,"circle");l.setAttribute("cx",String(t)),l.setAttribute("cy",String(i)),l.setAttribute("r",String(s)),l.setAttribute("fill","oklch(1 0 0)"),l.setAttribute("stroke","oklch(0.48 0.085 245)"),l.setAttribute("stroke-width","1"),l.style.cursor="grab",l.setAttribute("pointer-events","all"),r.appendChild(l);const u=t-8,f=i-8,d=document.createElementNS(O,"path");d.setAttribute("d",`M ${u+4} ${f+11} A 5 5 0 1 1 ${u+11} ${f+4}`),d.setAttribute("fill","none"),d.setAttribute("stroke","oklch(0.48 0.085 245)"),d.setAttribute("stroke-width","1.5"),d.setAttribute("stroke-linecap","round"),d.setAttribute("stroke-linejoin","round"),d.style.pointerEvents="none",r.appendChild(d);const p=document.createElementNS(O,"path");return p.setAttribute("d",`M ${u+11} ${f+1.5} L ${u+14} ${f+4} L ${u+11} ${f+6.5} Z`),p.setAttribute("fill","oklch(0.48 0.085 245)"),p.setAttribute("stroke","oklch(0.48 0.085 245)"),p.setAttribute("stroke-width","1.5"),p.setAttribute("stroke-linejoin","round"),p.style.pointerEvents="none",r.appendChild(p),l.addEventListener("mousedown",h=>n(h)),r}function gr(t,e){const n=document.createElementNS(O,"g"),r=t.x-Ur,o=t.y-Ur;return n.appendChild(pc(r,o,e)),n}function pc(t,e,n){const r=document.createElementNS(O,"g");r.style.cursor="pointer",r.style.pointerEvents="auto",r.setAttribute("pointer-events","all");const o=document.createElementNS(O,"circle");o.setAttribute("cx",String(t)),o.setAttribute("cy",String(e+1)),o.setAttribute("r","12"),o.setAttribute("fill","rgba(0,0,0,0.04)"),o.style.pointerEvents="none",r.appendChild(o);const i=document.createElementNS(O,"circle");i.setAttribute("cx",String(t)),i.setAttribute("cy",String(e)),i.setAttribute("r","12"),i.setAttribute("fill","oklch(1 0 0)"),i.setAttribute("stroke","oklch(0.92 0.008 240)"),i.setAttribute("stroke-width","1"),r.appendChild(i);const s=t-6,a=e-6,c=document.createElementNS(O,"path");return c.setAttribute("d",[`M ${s+1.5} ${a+3.5} L ${s+10.5} ${a+3.5}`,`M ${s+4.5} ${a+3.5} L ${s+4.5} ${a+2} L ${s+7.5} ${a+2} L ${s+7.5} ${a+3.5}`,`M ${s+3} ${a+3.5} L ${s+3.5} ${a+10.5} A 0.8 0.8 0 0 0 ${s+4.3} ${a+11} L ${s+7.7} ${a+11} A 0.8 0.8 0 0 0 ${s+8.5} ${a+10.5} L ${s+9} ${a+3.5}`].join(" ")),c.setAttribute("fill","none"),c.setAttribute("stroke","oklch(0.50 0.015 240)"),c.setAttribute("stroke-width","1.2"),c.setAttribute("stroke-linecap","round"),c.setAttribute("stroke-linejoin","round"),c.style.pointerEvents="none",r.appendChild(c),r.addEventListener("mousedown",l=>{l.stopPropagation(),l.preventDefault(),n()}),r}function br(t){const e=document.createElementNS(O,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),e.setAttribute("fill","none"),e.setAttribute("stroke","oklch(0.48 0.085 245)"),e.setAttribute("stroke-width","1"),e.setAttribute("stroke-dasharray","4 3"),e}function En(){const{host:t,activeId:e,activeMode:n}=M;if(!t||!e)return;for(;t.firstChild;)t.removeChild(t.firstChild);const r=T(e);if(!r){tr();return}if(n==="freedraw"&&r.kind==="freedraw"){gc(t,r);return}if(n==="text"&&r.kind==="text"){mc(t,r);return}if(r.kind!=="shape"){tr();return}fc(t,r)}function fc(t,e){const n=kn(e,Y()),r={...e.bounds,x:n.x,y:n.y},o=e.rotate??0,i=r.x+r.width/2,s=r.y+r.height/2,a=document.createElementNS(O,"g");o&&a.setAttribute("transform",`rotate(${o} ${i} ${s})`),a.appendChild(br(r));for(const c of Qo){const{x:l,y:u}=c.offset(r);a.appendChild(ai(l,u,c.name,c.cursor,lc))}a.appendChild(hc(r)),t.appendChild(a),t.appendChild(gr(r,vr))}function hc(t){const e=t.x+t.width/2,n=t.y-Zo,r=document.createElementNS(O,"g"),o=document.createElementNS(O,"line");o.setAttribute("x1",String(e)),o.setAttribute("y1",String(t.y)),o.setAttribute("x2",String(e)),o.setAttribute("y2",String(n)),o.setAttribute("stroke","oklch(0.48 0.085 245)"),o.setAttribute("stroke-width","1"),r.appendChild(o);const i=document.createElementNS(O,"g");i.style.cursor="grab",i.style.pointerEvents="auto",i.setAttribute("pointer-events","all");const s=document.createElementNS(O,"circle");s.setAttribute("cx",String(e)),s.setAttribute("cy",String(n)),s.setAttribute("r","9"),s.setAttribute("fill","oklch(1 0 0)"),s.setAttribute("stroke","oklch(0.48 0.085 245)"),s.setAttribute("stroke-width","2"),i.appendChild(s);const a=document.createElementNS(O,"path");return a.setAttribute("d",`M ${e-4} ${n-1} A 4 4 0 1 1 ${e+3} ${n+2} M ${e+1} ${n-1} L ${e+3} ${n+2} L ${e+5} ${n-1}`),a.setAttribute("fill","none"),a.setAttribute("stroke","oklch(0.48 0.085 245)"),a.setAttribute("stroke-width","1.4"),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.style.pointerEvents="none",i.appendChild(a),i.addEventListener("mousedown",c=>uc(c)),r.appendChild(i),r}function mc(t,e){const n=Xs(e.id);if(!n)return;const r=ci(n),o=r.x+r.width/2,i=r.y+r.height/2;t.appendChild(br(r)),t.appendChild(si(o,r.y,s=>oi(s,()=>({x:o,y:i})))),t.appendChild(gr(r,vr))}function gc(t,e){const n=Sn(e,Y()),r=Jo(n);if(!r)return;const o=ci(r),i=o.x+o.width/2,s=o.y+o.height/2;t.appendChild(br(o));for(const a of Qo){if(a.name!=="nw"&&a.name!=="ne"&&a.name!=="sw"&&a.name!=="se")continue;const{x:c,y:l}=a.offset(o);t.appendChild(ai(c,l,a.name,a.cursor,dc))}t.appendChild(si(i,o.y,a=>oi(a,()=>({x:i,y:s})))),t.appendChild(gr(o,vr))}function ci(t){return{x:t.x-Ne,y:t.y-Ne,width:t.width+Ne*2,height:t.height+Ne*2}}function vr(){const t=M.activeId;t&&Xo(t)}function bc(t){const e=T(t);if(!e)return;const n=e.entryAnimation;if(!n||n.kind==="none")return;const o={text:`[data-annotation-text="${t}"]`,shape:`[data-annotation-shape="${t}"]`,freedraw:`[data-annotation-freedraw="${t}"]`,arrow:`[data-annotation-arrow="${t}"]`}[e.kind];if(!o)return;const i=document.querySelectorAll(o);if(i.length===0)return;const s=e.kind==="shape"||e.kind==="freedraw"||e.kind==="text"?e.rotate??0:0;i.forEach(a=>{a.style.animation=""}),i[0].getBoundingClientRect(),i.forEach(a=>{a.style.transformBox="fill-box",a.style.transformOrigin="center",a.style.setProperty("--wp-final-rot",`${s}deg`),a.style.animation=`wp-${n.kind} ${Math.max(50,n.durationMs)}ms ease-out backwards`;const c=()=>{a.style.animation="",a.style.transformBox="",a.style.transformOrigin="",a.removeEventListener("animationend",c),a.removeEventListener("animationcancel",c)};a.addEventListener("animationend",c),a.addEventListener("animationcancel",c)})}function vc(t){const e=T(t);!e||e.kind!=="shape"||(M.activeId=t,M.activeMode="shape",yr(),En())}function yc(t){const e=T(t);!e||e.kind!=="freedraw"||(M.activeId=t,M.activeMode="freedraw",yr(),En())}function xc(t){const e=T(t);!e||e.kind!=="text"||(M.activeId=t,M.activeMode="text",yr(),En())}function tr(){var t;M.host&&(sc(),(t=M.unsubscribeScenario)==null||t.call(M),M.unsubscribeScenario=null,M.host.remove(),M.host=null,M.activeId=null,M.activeMode="shape",M.dragState=null)}function wc(t){return M.host!==null&&t!==null&&M.host.contains(t)}function yr(){if(M.host)return;const t=document.createElementNS(O,"svg");t.setAttribute("data-manuscript","ui"),t.setAttribute("width","100%"),t.setAttribute("height","100%"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(t),M.host=t,cc(),M.unsubscribeScenario=de(En)}const kc=400,Sc=0;function Ac(t){return{kind:t,durationMs:kc,delayMs:Sc}}function Ec(t){var e;return((e=t.entryAnimation)==null?void 0:e.kind)??"none"}const Yr=10,Mc=46,li=12,ui=36,di=0,pi=20,$c=[{token:"var(--ann-mut-1)",resolved:"oklch(0.20 0.008 250)"},{token:"var(--ann-mut-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-mut-3)",resolved:"oklch(0.45 0.10 27)"},{token:"var(--ann-mut-4)",resolved:"oklch(0.50 0.09 350)"},{token:"var(--ann-mut-5)",resolved:"oklch(0.45 0.08 145)"},{token:"var(--ann-mut-6)",resolved:"oklch(0.42 0.09 250)"},{token:"var(--ann-mut-7)",resolved:"oklch(0.62 0.10 75)"},{token:"var(--ann-mut-8)",resolved:"oklch(0.42 0.08 290)"}],Lc=[{token:"var(--ann-vib-1)",resolved:"oklch(0.18 0.005 250)"},{token:"var(--ann-vib-2)",resolved:"oklch(0.99 0 0)"},{token:"var(--ann-vib-3)",resolved:"oklch(0.62 0.22 27)"},{token:"var(--ann-vib-4)",resolved:"oklch(0.70 0.18 350)"},{token:"var(--ann-vib-5)",resolved:"oklch(0.60 0.16 145)"},{token:"var(--ann-vib-6)",resolved:"oklch(0.55 0.18 250)"},{token:"var(--ann-vib-7)",resolved:"oklch(0.82 0.15 90)"},{token:"var(--ann-vib-8)",resolved:"oklch(0.50 0.18 290)"}],Tc=[{label:"Sans",value:"'Pretendard Variable', Pretendard, system-ui, sans-serif"},{label:"Serif",value:"'EB Garamond', Georgia, serif"},{label:"Mono",value:"ui-monospace, monospace"}],Cc=[{value:"none",label:"None"},{value:"fade",label:"Fade"},{value:"slide-left",label:"Slide →"},{value:"slide-right",label:"Slide ←"},{value:"slide-up",label:"Slide ↑"},{value:"slide-down",label:"Slide ↓"},{value:"bounce",label:"Bounce"},{value:"zoom",label:"Zoom"},{value:"rotate",label:"Rotate (2×)"}],E={host:null,shadow:null,activeId:null,activeKind:null,activeAnchorSelector:null,swatchMode:"muted",unsubscribeScenario:null};function wt(t){return t.replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;")}function fi(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,color:t}}):n.kind==="shape"?C(e,{stroke:t}):n.kind==="freedraw"&&C(e,{stroke:t}))}function hi(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="text"?C(e,{style:{...n.style,backgroundColor:t}}):n.kind==="shape"&&C(e,{fill:t}))}function mi(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,borderColor:t}})}function Ic(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontFamily:t}})}function Pc(t){const e=E.activeId;if(!e)return;const n=T(e);!n||n.kind!=="text"||C(e,{style:{...n.style,fontSize:t}})}function Dc(){const t=E.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,bold:!e.style.bold}})}function Oc(){const t=E.activeId;if(!t)return;const e=T(t);!e||e.kind!=="text"||C(t,{style:{...e.style,italic:e.style.italic!==!0}})}function Rc(t){const e=E.activeId;e&&C(e,{entryAnimation:t==="none"?void 0:Ac(t)})}function Nc(t){const e=E.activeId;if(!e)return;const n=T(e);if(!n)return;const r=Math.max(0,Math.min(1,t));n.kind==="text"?C(e,{style:{...n.style,backgroundOpacity:r}}):n.kind==="shape"?C(e,{fillOpacity:r}):n.kind==="freedraw"&&C(e,{strokeOpacity:r})}function Fc(t){const e=E.activeId;if(!e)return;const n=T(e);n&&(n.kind==="shape"?C(e,{strokeWidth:t}):n.kind==="freedraw"&&C(e,{strokeWidth:t}))}function _c(){const{shadow:t}=E;if(!t)return;const e=t.querySelector('[data-region="alpha-track"]'),n=t.querySelector('[data-region="alpha-thumb"]');if(!e||!n)return;let r=!1;const o=s=>{r&&zn(e,s.clientX)},i=()=>{r=!1,document.removeEventListener("mousemove",o,!0),document.removeEventListener("mouseup",i,!0)};n.addEventListener("mousedown",s=>{r=!0,zn(e,s.clientX),document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0),s.preventDefault()}),e.addEventListener("mousedown",s=>{const a=s.target;a instanceof Element&&a.closest('[data-region="alpha-thumb"]')||(zn(e,s.clientX),r=!0,document.addEventListener("mousemove",o,!0),document.addEventListener("mouseup",i,!0))})}function zn(t,e){const n=t.getBoundingClientRect();Nc(Math.max(0,Math.min(1,(e-n.left)/n.width)))}function er(t,e){return t.kind==="text"?e==="text"?t.style.color:e==="border"?t.style.borderColor??"#000000":t.style.backgroundColor??"transparent":t.kind==="shape"?e==="text"?t.stroke:t.fill:e==="text"?t.stroke:""}function Hc(t){return t.kind==="text"?t.style.backgroundOpacity??1:t.kind==="shape"?t.fillOpacity??1:t.strokeOpacity??1}function Bn(t,e){return t?t===e?!0:t.replace(/\s+/g,"")===e.replace(/\s+/g,""):!1}function qn(t,e,n){var l,u,f;const r=E.swatchMode==="muted"?$c:Lc,o=[];if(n&&(t==="bg"||t==="border")){const d=e==="transparent"||!e;o.push(`
      <button type="button" class="swatch transparent" data-swatch="${t}" data-value="transparent" title="Transparent" aria-pressed="${d}">
        <svg viewBox="0 0 22 22" width="22" height="22">
          <line x1="3" y1="19" x2="19" y2="3" stroke="var(--c-error)" stroke-width="1.5"/>
        </svg>
      </button>
    `)}for(let d=0;d<r.length;d++){const p=r[d];if(!p)continue;const h=d===1,g=Bn(e,p.resolved);o.push(`
      <button type="button" class="swatch${h?" is-white":""}" data-swatch="${t}" data-value="${p.resolved}" style="background:${p.resolved}" aria-pressed="${g}" title="${t} ${p.resolved}"></button>
    `)}const i=P(),s=(t==="text"||t==="border"?(l=i==null?void 0:i.siteColors)==null?void 0:l.text:(u=i==null?void 0:i.siteColors)==null?void 0:u.background)??[];for(const d of s){const p=Bn(e,d);o.push(`
      <button type="button" class="swatch site" data-swatch="${t}" data-value="${wt(d)}" style="background:${wt(d)}" aria-pressed="${p}" title="Site color ${wt(d)}"></button>
    `)}const a=t==="text"||t==="border"?"text":"background",c=((f=i==null?void 0:i.customColors)==null?void 0:f[a])??[];for(const d of c){const p=Bn(e,d);o.push(`
      <span class="swatch-wrap">
        <button type="button" class="swatch" data-swatch="${t}" data-value="${wt(d)}" style="background:${wt(d)}" aria-pressed="${p}" title="Custom ${wt(d)}"></button>
        <button type="button" class="swatch-remove" data-action="custom-remove" data-slot="${t}" data-value="${wt(d)}" title="Remove" aria-label="Remove color ${wt(d)}">×</button>
      </span>
    `)}return o.push(`
    <button type="button" class="swatch more" data-action="more-colors" data-slot="${t}" title="More colors" aria-label="More colors">···</button>
  `),o.join("")}function xr(){const{shadow:t,activeId:e,activeKind:n}=E;if(!t||!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.querySelector('[data-region="caption"]');i&&(i.textContent=Xc(n)),t.querySelectorAll('[data-action="swatch-mode"]').forEach(s=>{const a=s.getAttribute("data-mode");s.setAttribute("aria-pressed",String(a===E.swatchMode))}),zc(t,n),Bc(t,n,o),qc(t,n,o),jc(t,n,o),Wc(t,o),Uc(t,o)}function zc(t,e){const n=t.querySelector('[data-region="type-row"]'),r=t.querySelector('[data-region="divider-1"]'),o=e==="text";n&&(n.hidden=!o),r&&(r.hidden=!o);const i=t.querySelector('[data-region="width-row"]'),s=e==="shape"||e==="freedraw";i&&(i.hidden=!s);const a=t.querySelector('[data-region="bg-row"]');a&&(a.hidden=e==="freedraw");const c=t.querySelector('[data-region="border-row"]');c&&(c.hidden=e!=="text");const l=t.querySelector('[data-region="text-label"]');l&&(l.textContent=e==="text"?"Text":"Stroke");const u=t.querySelector('[data-region="bg-label"]');u&&(u.textContent=e==="text"?"Bg":"Fill")}function Bc(t,e,n){if(e!=="text"||n.kind!=="text")return;const r=t.querySelector('[data-region="font"]');r&&(r.value=n.style.fontFamily);const o=t.querySelector('[data-region="size"]');o&&(o.value=String(n.style.fontSize));const i=t.querySelector('[data-region="bold"]');i&&i.setAttribute("aria-pressed",String(n.style.bold));const s=t.querySelector('[data-region="italic"]');s&&s.setAttribute("aria-pressed",String(n.style.italic===!0))}function qc(t,e,n){if(e!=="shape"&&e!=="freedraw"||n.kind!=="shape"&&n.kind!=="freedraw")return;const r=t.querySelector('[data-region="width"]'),o=t.querySelector('[data-region="width-value"]'),i=n.strokeWidth;r&&(r.value=String(i)),o&&(o.textContent=String(i))}function jc(t,e,n){const r=t.querySelector('[data-region="text-swatches"]'),o=t.querySelector('[data-region="bg-swatches"]'),i=t.querySelector('[data-region="border-swatches"]'),s=t.querySelector('[data-region="bg-row"]'),a=t.querySelector('[data-region="border-row"]'),c=er(n,"text"),l=er(n,"bg");if(r&&(r.innerHTML=qn("text",c,!1)),o&&!(s!=null&&s.hidden)&&(o.innerHTML=qn("bg",l,e==="text")),i&&!(a!=null&&a.hidden)&&n.kind==="text"){const u=n.style.borderColor??"#000000";i.innerHTML=qn("border",u,!0)}}function Wc(t,e){const n=t.querySelector('[data-region="effect"]');n&&(n.value=Ec(e))}function Uc(t,e){const n=Math.round(Hc(e)*100),r=t.querySelector('[data-region="alpha-fill"]'),o=t.querySelector('[data-region="alpha-thumb"]'),i=t.querySelector('[data-region="alpha-value"]');r&&(r.style.width=`${n}%`),o&&(o.style.left=`${n}%`),i&&(i.textContent=`${n}%`)}function Xc(t){return t==="text"?"Text":t==="shape"?"Shape":"Freedraw"}function Yc(t){const{shadow:e,host:n}=E;if(!e||!n)return;const r=o=>o.stopPropagation();n.addEventListener("keydown",r),n.addEventListener("keypress",r),n.addEventListener("keyup",r),e.addEventListener("click",o=>Gc(o)),e.addEventListener("change",o=>Vc(o)),e.addEventListener("input",o=>Kc(o)),_c(),document.addEventListener("mousedown",o=>Qc(o,t),!0),document.addEventListener("keydown",o=>Jc(o,t),!0)}function Gc(t){const e=t.target;if(!(e instanceof Element))return;const n=e.closest('[data-action="swatch-mode"]');if(n){const c=n.getAttribute("data-mode");(c==="muted"||c==="vibrant")&&(E.swatchMode=c,xr());return}if(e.closest('[data-region="bold"]'))return Dc();if(e.closest('[data-region="italic"]'))return Oc();if(e.closest('[data-region="effect-play"]')){E.activeId&&bc(E.activeId);return}const r=e.closest('[data-swatch="text"]');if(r)return fi(r.getAttribute("data-value")??"");const o=e.closest('[data-swatch="bg"]');if(o)return hi(o.getAttribute("data-value")??"");const i=e.closest('[data-swatch="border"]');if(i)return mi(i.getAttribute("data-value")??"");const s=e.closest('[data-action="more-colors"]');if(s instanceof HTMLElement)return Zc(s);const a=e.closest('[data-action="custom-remove"]');if(a instanceof HTMLElement){const c=a.getAttribute("data-slot"),l=a.getAttribute("data-value");c&&l&&Os(c==="text"||c==="border"?"text":"background",l)}}function Vc(t){const e=t.target;e instanceof HTMLElement&&(e.dataset.region==="font"?Ic(e.value):e.dataset.region==="effect"&&Rc(e.value))}function Kc(t){const e=t.target;if(e instanceof HTMLInputElement){if(e.dataset.region==="size"){const n=Math.max(li,Math.min(ui,Number(e.value)||16));Pc(n)}else if(e.dataset.region==="width"){const n=Math.max(di,Math.min(pi,Number(e.value)||0));Fc(n)}}}function Zc(t){const{activeId:e,activeKind:n}=E;if(!e||!n)return;const r=T(e);if(!r||r.kind==="arrow")return;const o=r,i=t.getAttribute("data-slot");if(!i)return;const s=er(o,i)||"#ffffff";Bs({anchor:t,initialColor:s,onConfirm:a=>{Ds(i==="text"||i==="border"?"text":"background",a),i==="text"?fi(a):i==="border"?mi(a):hi(a)}})}function Qc(t,e){const{host:n,activeAnchorSelector:r}=E,o=t.target;!(o instanceof HTMLElement)&&!(o instanceof SVGElement)||n!=null&&n.contains(o)||wc(o)||qs()||r&&o instanceof Element&&o.closest(r)||(e(),jt())}function Jc(t,e){t.key==="Escape"&&(t.preventDefault(),e())}function gi(t){const{host:e}=E;if(!e)return;e.style.left="0px",e.style.top="0px";const n=e.getBoundingClientRect(),r=t.getBoundingClientRect();let o=r.top-n.height-Yr-Mc;o<8&&(o=r.bottom+Yr);const i=Math.max(8,Math.min(r.left+r.width/2-n.width/2,window.innerWidth-n.width-8));e.style.top=`${o}px`,e.style.left=`${i}px`}function tl(t,e){return t==="text"?`[data-annotation-text="${e}"]`:t==="shape"?`[data-annotation-shape="${e}"]`:`[data-annotation-freedraw="${e}"]`}function el(t,e){t==="text"?xc(e):t==="shape"?vc(e):yc(e)}function nl(){return`
    ${Pt()}
    :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
    *, *::before, *::after { box-sizing: border-box; }

    .popup {
      width: 320px;
      background: var(--c-surface);
      border: 1px solid var(--c-border);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-card);
      padding: 12px;
      display: flex;
      flex-direction: column;
      gap: 10px;
      position: relative;
      font-size: var(--fs-body);
    }
    .anchor-tick {
      position: absolute;
      left: 50%;
      top: 100%;
      transform: translate(-50%, -1px);
      width: 12px;
      height: 6px;
      pointer-events: none;
    }

    .row { display: flex; align-items: center; gap: 6px; }
    .row.label-row { gap: 8px; }
    .label {
      font-size: 10px;
      font-weight: 600;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--c-text-soft);
      width: 50px;
      padding-right: 6px;
      flex-shrink: 0;
    }
    .label.wide {
      letter-spacing: 0.10em;
      width: auto;
    }
    .divider {
      height: 1px;
      background: var(--c-border);
      margin: 2px 0;
    }

    .header { display: flex; align-items: center; justify-content: space-between; }
    .toggle {
      display: inline-flex;
      padding: 2px;
      background: var(--c-surface-2);
      border-radius: var(--r-sm);
      border: 1px solid var(--c-border);
    }
    .toggle button {
      padding: 3px 9px;
      border: none;
      border-radius: var(--r-xs);
      background: transparent;
      color: var(--c-text-mute);
      font-size: 10px;
      font-weight: 600;
      font-family: var(--ff-sans);
      cursor: pointer;
      letter-spacing: 0.02em;
    }
    .toggle button[aria-pressed="true"] {
      background: var(--c-surface);
      color: var(--c-text);
      box-shadow: var(--shadow-sm);
    }

    .type-row { display: flex; align-items: center; gap: 6px; }
    .select, .size-input, .type-btn {
      height: 28px;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      font-family: var(--ff-sans);
      font-size: 12px;
      line-height: 1;
      cursor: pointer;
      padding: 0 10px;
    }
    .select {
      flex: 1;
      min-width: 0;
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 6px;
      appearance: auto;
    }
    .size-input {
      width: 54px;
      padding: 0 8px;
      text-align: right;
      font-family: var(--ff-mono);
      font-weight: 500;
      font-variant-numeric: tabular-nums;
    }
    .type-btn {
      width: 28px;
      padding: 0;
      display: inline-grid;
      place-items: center;
      font-size: 12px;
      font-weight: 600;
    }
    .type-btn.italic { font-style: italic; font-weight: 500; }
    .type-btn[aria-pressed="true"] {
      background: var(--c-text);
      color: var(--c-surface);
      border-color: var(--c-text);
    }
    .type-btn[aria-pressed="false"] { color: var(--c-text-mute); }
  `}function rl(){return`
    .swatch-row { display: flex; align-items: center; gap: 8px; }
    .swatches { display: flex; gap: 4px; flex: 1; flex-wrap: wrap; }
    .swatch {
      width: 22px;
      height: 22px;
      padding: 0;
      border-radius: 999px;
      border: 1px solid rgba(0, 0, 0, 0.08);
      cursor: pointer;
      position: relative;
    }
    .swatch.is-white { border-color: var(--c-border-strong); }
    .swatch[aria-pressed="true"] {
      border: 2px solid var(--c-text);
      box-shadow: 0 0 0 2px var(--c-surface), 0 0 0 3px var(--c-text);
    }
    .swatch.transparent {
      background: var(--c-surface);
      border-color: var(--c-border-strong);
      overflow: hidden;
    }
    .swatch.transparent svg { position: absolute; inset: 0; }
    .swatch.more {
      background: var(--c-surface);
      border-color: var(--c-border);
      color: var(--c-text-mute);
      display: inline-grid;
      place-items: center;
      font-size: 10px;
      line-height: 1;
    }
    .swatch-wrap { position: relative; width: 22px; height: 22px; display: inline-block; }
    .swatch-remove {
      position: absolute;
      top: -5px;
      right: -5px;
      width: 14px;
      height: 14px;
      padding: 0;
      border-radius: 999px;
      background: var(--c-text);
      color: var(--c-surface);
      border: 1px solid var(--c-surface);
      font-size: 10px;
      line-height: 1;
      cursor: pointer;
      display: none;
      align-items: center;
      justify-content: center;
    }
    .swatch-wrap:hover .swatch-remove,
    .swatch-remove:focus-visible { display: inline-flex; }
    .swatch-remove:hover { background: var(--c-error); }
    /* hidden HTML attribute가 display:flex보다 우선되도록 */
    .type-row[hidden],
    .width-row[hidden],
    .swatch-row[hidden],
    .divider[hidden] { display: none !important; }

    .effect-controls { display: flex; flex: 1; gap: 4px; }
    .icon-btn {
      width: 28px;
      height: 28px;
      padding: 0;
      border: 1px solid var(--c-border);
      border-radius: var(--r-sm);
      background: var(--c-surface);
      color: var(--c-text);
      display: inline-grid;
      place-items: center;
      cursor: pointer;
    }
    .icon-btn:hover { border-color: var(--c-border-strong); }

    .alpha-row { display: flex; align-items: center; gap: 8px; }
    .alpha-track-wrap { flex: 1; height: 28px; display: flex; align-items: center; gap: 10px; }
    .alpha-track {
      flex: 1;
      height: 4px;
      border-radius: 999px;
      background: var(--c-border);
      position: relative;
      cursor: pointer;
    }
    .alpha-fill {
      position: absolute; left: 0; top: 0; bottom: 0;
      background: var(--c-text);
      border-radius: 999px;
    }
    .alpha-thumb {
      position: absolute;
      top: 50%;
      transform: translate(-50%, -50%);
      width: 14px;
      height: 14px;
      border-radius: 999px;
      background: var(--c-surface);
      border: 1.5px solid var(--c-text);
      box-shadow: 0 1px 2px rgb(0 0 0 / 0.08);
      cursor: grab;
    }
    .alpha-thumb:active { cursor: grabbing; }
    .alpha-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }

    .width-row { display: flex; align-items: center; gap: 8px; }
    .width-input { flex: 1; accent-color: var(--c-text); height: 4px; padding: 0; margin: 0; }
    .width-value {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      color: var(--c-text);
      font-variant-numeric: tabular-nums;
      min-width: 32px;
      text-align: right;
    }
  `}function ol(){return[nl(),rl()].join(`
`)}function il(){return`
    <style>${ol()}</style>
    <div class="popup" role="dialog" aria-label="Annotation properties">
      ${al()}
      ${sl()}
      <div class="divider" data-region="divider-1" hidden></div>
      ${cl()}
      <div class="divider"></div>
      ${ll()}
      ${ul()}
      ${dl()}
      ${pl()}
    </div>
  `}function al(){return`
    <div class="header">
      <span class="label wide" data-region="caption">Annotation · 속성</span>
      <div class="toggle" role="tablist" aria-label="Color palette mode">
        <button type="button" data-action="swatch-mode" data-mode="muted" aria-pressed="true">Muted</button>
        <button type="button" data-action="swatch-mode" data-mode="vibrant" aria-pressed="false">Vibrant</button>
      </div>
    </div>
  `}function sl(){return`
    <div class="type-row" data-region="type-row" hidden>
      <select class="select" data-region="font">
        ${Tc.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
      </select>
      <input class="size-input" type="number" min="${li}" max="${ui}" data-region="size" />
      <button type="button" class="type-btn" data-region="bold" aria-pressed="false" title="Bold">B</button>
      <button type="button" class="type-btn italic" data-region="italic" aria-pressed="false" title="Italic">I</button>
    </div>
  `}function cl(){return`
    <div class="swatch-row" data-region="text-row">
      <span class="label" data-region="text-label">Text</span>
      <div class="swatches" data-region="text-swatches"></div>
    </div>
    <div class="swatch-row" data-region="bg-row">
      <span class="label" data-region="bg-label">Bg</span>
      <div class="swatches" data-region="bg-swatches"></div>
    </div>
    <div class="swatch-row" data-region="border-row" hidden>
      <span class="label" data-region="border-label">Border</span>
      <div class="swatches" data-region="border-swatches"></div>
    </div>
  `}function ll(){return`
    <div class="width-row" data-region="width-row" hidden>
      <span class="label">Width</span>
      <input class="width-input" type="range" min="${di}" max="${pi}" step="1" data-region="width" />
      <span class="width-value" data-region="width-value">2</span>
    </div>
  `}function ul(){return`
    <div class="row label-row">
      <span class="label">Effect</span>
      <div class="effect-controls">
        <select class="select" data-region="effect">
          ${Cc.map(t=>`<option value="${t.value}">${t.label}</option>`).join("")}
        </select>
        <button type="button" class="icon-btn" data-region="effect-play" title="Preview effect" aria-label="Preview effect">
          <svg width="9" height="9" viewBox="0 0 16 16" fill="currentColor"><path d="M 4 3 L 4 13 L 13 8 Z"/></svg>
        </button>
      </div>
    </div>
  `}function dl(){return`
    <div class="alpha-row">
      <span class="label">Opacity</span>
      <div class="alpha-track-wrap">
        <div class="alpha-track" data-region="alpha-track">
          <div class="alpha-fill" data-region="alpha-fill"></div>
          <div class="alpha-thumb" data-region="alpha-thumb"></div>
        </div>
        <span class="alpha-value" data-region="alpha-value">100%</span>
      </div>
    </div>
  `}function pl(){return`
    <div class="anchor-tick">
      <svg viewBox="0 0 12 6" width="12" height="6">
        <path d="M 0 0 L 6 6 L 12 0 Z" fill="var(--c-surface)"/>
        <path d="M 0 0 L 6 6 L 12 0" fill="none" stroke="var(--c-border)" stroke-width="1"/>
      </svg>
    </div>
  `}function wr(t,e,n){T(t)&&(E.activeId=t,E.activeKind=n,E.activeAnchorSelector=tl(n,t),E.host||bl(),xr(),gi(e),el(n,t))}function kr(){var t;E.host&&((t=E.unsubscribeScenario)==null||t.call(E),E.unsubscribeScenario=null,jt(),tr(),E.host.remove(),E.host=null,E.shadow=null,E.activeId=null,E.activeKind=null,E.activeAnchorSelector=null)}function fl(){return E.activeId}function hl(t,e){wr(t,e,"text")}function bi(){kr()}function ml(t,e){wr(t,e,"shape")}function gl(t,e){wr(t,e,"freedraw")}function bl(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",ue),t.setAttribute("data-popup","annotation-editor"),t.style.cssText=["position: fixed",`z-index: ${H+5}`,"pointer-events: auto"].join("; ");const e=t.attachShadow({mode:"open"});e.innerHTML=il(),E.host=t,E.shadow=e,document.body.appendChild(t),Yc(kr),E.unsubscribeScenario=de(vl)}function vl(){const{activeId:t,host:e,activeAnchorSelector:n}=E;if(!t||!e)return;if(!T(t)){kr();return}if(xr(),n){const o=document.querySelector(n);o&&gi(o)}}const gt=20;let Ze=null,Gr=!1;function yl(){Gr||(Gr=!0,document.addEventListener("keydown",kl,!0)),xl()}async function xl(){try{const e=(await chrome.storage.local.get(Q.annotationClipboard))[Q.annotationClipboard];e&&typeof e=="object"&&"kind"in e&&"id"in e&&(Ze=e)}catch(t){console.warn("[manuscript] clipboard load failed",t)}}async function wl(t){try{await chrome.storage.local.set({[Q.annotationClipboard]:t})}catch(e){console.warn("[manuscript] clipboard save failed",e)}}function kl(t){if(!(t.ctrlKey||t.metaKey))return;const e=t.key.toLowerCase();e!=="c"&&e!=="v"||bt()!=="replay"&&(Sl()||(e==="c"?Al(t):El(t)))}function Sl(){let t=document.activeElement;for(;t&&t.shadowRoot&&t.shadowRoot.activeElement;)t=t.shadowRoot.activeElement;return t?!!(t instanceof HTMLInputElement||t instanceof HTMLTextAreaElement||t instanceof HTMLSelectElement||t instanceof HTMLElement&&t.isContentEditable):!1}function Al(t){const e=fl();if(!e)return;const n=T(e);n&&(Ze=n,wl(n),t.preventDefault())}function El(t){if(!Ze||!ot())return;const e=Ml(Ze);Ee(e),t.preventDefault()}function Ml(t){switch(t.kind){case"text":return $l(t);case"shape":return Ll(t);case"freedraw":return Tl(t);case"arrow":return Cl(t)}}function $l(t){return{...t,id:Mn("text"),position:{x:t.position.x+gt,y:t.position.y+gt},style:{...t.style}}}function Ll(t){return{...t,id:Mn("shape"),bounds:{...t.bounds,x:t.bounds.x+gt,y:t.bounds.y+gt}}}function Tl(t){return{...t,id:Mn("freedraw"),points:t.points.map(e=>({x:e.x+gt,y:e.y+gt}))}}function Cl(t){return{...t,id:Mn("arrow"),from:{x:t.from.x+gt,y:t.from.y+gt},to:{x:t.to.x+gt,y:t.to.y+gt}}}function Mn(t){return`${t}-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}function jn(t,e,n){if(t&&t.length){const[r,o]=e,i=Math.PI/180*n,s=Math.cos(i),a=Math.sin(i);for(const c of t){const[l,u]=c;c[0]=(l-r)*s-(u-o)*a+r,c[1]=(l-r)*a+(u-o)*s+o}}}function Il(t,e){return t[0]===e[0]&&t[1]===e[1]}function Pl(t,e,n,r=1){const o=n,i=Math.max(e,.1),s=t[0]&&t[0][0]&&typeof t[0][0]=="number"?[t]:t,a=[0,0];if(o)for(const l of s)jn(l,a,o);const c=(function(l,u,f){const d=[];for(const y of l){const A=[...y];Il(A[0],A[A.length-1])||A.push([A[0][0],A[0][1]]),A.length>2&&d.push(A)}const p=[];u=Math.max(u,.1);const h=[];for(const y of d)for(let A=0;A<y.length-1;A++){const z=y[A],R=y[A+1];if(z[1]!==R[1]){const I=Math.min(z[1],R[1]);h.push({ymin:I,ymax:Math.max(z[1],R[1]),x:I===z[1]?z[0]:R[0],islope:(R[0]-z[0])/(R[1]-z[1])})}}if(h.sort(((y,A)=>y.ymin<A.ymin?-1:y.ymin>A.ymin?1:y.x<A.x?-1:y.x>A.x?1:y.ymax===A.ymax?0:(y.ymax-A.ymax)/Math.abs(y.ymax-A.ymax))),!h.length)return p;let g=[],v=h[0].ymin,x=0;for(;g.length||h.length;){if(h.length){let y=-1;for(let A=0;A<h.length&&!(h[A].ymin>v);A++)y=A;h.splice(0,y+1).forEach((A=>{g.push({s:v,edge:A})}))}if(g=g.filter((y=>!(y.edge.ymax<=v))),g.sort(((y,A)=>y.edge.x===A.edge.x?0:(y.edge.x-A.edge.x)/Math.abs(y.edge.x-A.edge.x))),(f!==1||x%u==0)&&g.length>1)for(let y=0;y<g.length;y+=2){const A=y+1;if(A>=g.length)break;const z=g[y].edge,R=g[A].edge;p.push([[Math.round(z.x),v],[Math.round(R.x),v]])}v+=f,g.forEach((y=>{y.edge.x=y.edge.x+f*y.edge.islope})),x++}return p})(s,i,r);if(o){for(const l of s)jn(l,a,-o);(function(l,u,f){const d=[];l.forEach((p=>d.push(...p))),jn(d,u,f)})(c,a,-o)}return c}function $e(t,e){var n;const r=e.hachureAngle+90;let o=e.hachureGap;o<0&&(o=4*e.strokeWidth),o=Math.round(Math.max(o,.1));let i=1;return e.roughness>=1&&(((n=e.randomizer)===null||n===void 0?void 0:n.next())||Math.random())>.7&&(i=o),Pl(t,o,r,i||1)}class Sr{constructor(e){this.helper=e}fillPolygons(e,n){return this._fillPolygons(e,n)}_fillPolygons(e,n){const r=$e(e,n);return{type:"fillSketch",ops:this.renderLines(r,n)}}renderLines(e,n){const r=[];for(const o of e)r.push(...this.helper.doubleLineOps(o[0][0],o[0][1],o[1][0],o[1][1],n));return r}}function $n(t){const e=t[0],n=t[1];return Math.sqrt(Math.pow(e[0]-n[0],2)+Math.pow(e[1]-n[1],2))}class Dl extends Sr{fillPolygons(e,n){let r=n.hachureGap;r<0&&(r=4*n.strokeWidth),r=Math.max(r,.1);const o=$e(e,Object.assign({},n,{hachureGap:r})),i=Math.PI/180*n.hachureAngle,s=[],a=.5*r*Math.cos(i),c=.5*r*Math.sin(i);for(const[l,u]of o)$n([l,u])&&s.push([[l[0]-a,l[1]+c],[...u]],[[l[0]+a,l[1]-c],[...u]]);return{type:"fillSketch",ops:this.renderLines(s,n)}}}class Ol extends Sr{fillPolygons(e,n){const r=this._fillPolygons(e,n),o=Object.assign({},n,{hachureAngle:n.hachureAngle+90}),i=this._fillPolygons(e,o);return r.ops=r.ops.concat(i.ops),r}}class Rl{constructor(e){this.helper=e}fillPolygons(e,n){const r=$e(e,n=Object.assign({},n,{hachureAngle:0}));return this.dotsOnLines(r,n)}dotsOnLines(e,n){const r=[];let o=n.hachureGap;o<0&&(o=4*n.strokeWidth),o=Math.max(o,.1);let i=n.fillWeight;i<0&&(i=n.strokeWidth/2);const s=o/4;for(const a of e){const c=$n(a),l=c/o,u=Math.ceil(l)-1,f=c-u*o,d=(a[0][0]+a[1][0])/2-o/4,p=Math.min(a[0][1],a[1][1]);for(let h=0;h<u;h++){const g=p+f+h*o,v=d-s+2*Math.random()*s,x=g-s+2*Math.random()*s,y=this.helper.ellipse(v,x,i,i,n);r.push(...y.ops)}}return{type:"fillSketch",ops:r}}}class Nl{constructor(e){this.helper=e}fillPolygons(e,n){const r=$e(e,n);return{type:"fillSketch",ops:this.dashedLine(r,n)}}dashedLine(e,n){const r=n.dashOffset<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashOffset,o=n.dashGap<0?n.hachureGap<0?4*n.strokeWidth:n.hachureGap:n.dashGap,i=[];return e.forEach((s=>{const a=$n(s),c=Math.floor(a/(r+o)),l=(a+o-c*(r+o))/2;let u=s[0],f=s[1];u[0]>f[0]&&(u=s[1],f=s[0]);const d=Math.atan((f[1]-u[1])/(f[0]-u[0]));for(let p=0;p<c;p++){const h=p*(r+o),g=h+r,v=[u[0]+h*Math.cos(d)+l*Math.cos(d),u[1]+h*Math.sin(d)+l*Math.sin(d)],x=[u[0]+g*Math.cos(d)+l*Math.cos(d),u[1]+g*Math.sin(d)+l*Math.sin(d)];i.push(...this.helper.doubleLineOps(v[0],v[1],x[0],x[1],n))}})),i}}class Fl{constructor(e){this.helper=e}fillPolygons(e,n){const r=n.hachureGap<0?4*n.strokeWidth:n.hachureGap,o=n.zigzagOffset<0?r:n.zigzagOffset,i=$e(e,n=Object.assign({},n,{hachureGap:r+o}));return{type:"fillSketch",ops:this.zigzagLines(i,o,n)}}zigzagLines(e,n,r){const o=[];return e.forEach((i=>{const s=$n(i),a=Math.round(s/(2*n));let c=i[0],l=i[1];c[0]>l[0]&&(c=i[1],l=i[0]);const u=Math.atan((l[1]-c[1])/(l[0]-c[0]));for(let f=0;f<a;f++){const d=2*f*n,p=2*(f+1)*n,h=Math.sqrt(2*Math.pow(n,2)),g=[c[0]+d*Math.cos(u),c[1]+d*Math.sin(u)],v=[c[0]+p*Math.cos(u),c[1]+p*Math.sin(u)],x=[g[0]+h*Math.cos(u+Math.PI/4),g[1]+h*Math.sin(u+Math.PI/4)];o.push(...this.helper.doubleLineOps(g[0],g[1],x[0],x[1],r),...this.helper.doubleLineOps(x[0],x[1],v[0],v[1],r))}})),o}}const G={};class _l{constructor(e){this.seed=e}next(){return this.seed?(2**31-1&(this.seed=Math.imul(48271,this.seed)))/2**31:Math.random()}}const Hl=0,Wn=1,Vr=2,Fe={A:7,a:7,C:6,c:6,H:1,h:1,L:2,l:2,M:2,m:2,Q:4,q:4,S:4,s:4,T:2,t:2,V:1,v:1,Z:0,z:0};function Un(t,e){return t.type===e}function Ar(t){const e=[],n=(function(s){const a=new Array;for(;s!=="";)if(s.match(/^([ \t\r\n,]+)/))s=s.substr(RegExp.$1.length);else if(s.match(/^([aAcChHlLmMqQsStTvVzZ])/))a[a.length]={type:Hl,text:RegExp.$1},s=s.substr(RegExp.$1.length);else{if(!s.match(/^(([-+]?[0-9]+(\.[0-9]*)?|[-+]?\.[0-9]+)([eE][-+]?[0-9]+)?)/))return[];a[a.length]={type:Wn,text:`${parseFloat(RegExp.$1)}`},s=s.substr(RegExp.$1.length)}return a[a.length]={type:Vr,text:""},a})(t);let r="BOD",o=0,i=n[o];for(;!Un(i,Vr);){let s=0;const a=[];if(r==="BOD"){if(i.text!=="M"&&i.text!=="m")return Ar("M0,0"+t);o++,s=Fe[i.text],r=i.text}else Un(i,Wn)?s=Fe[r]:(o++,s=Fe[i.text],r=i.text);if(!(o+s<n.length))throw new Error("Path data ended short");for(let c=o;c<o+s;c++){const l=n[c];if(!Un(l,Wn))throw new Error("Param not a number: "+r+","+l.text);a[a.length]=+l.text}if(typeof Fe[r]!="number")throw new Error("Bad segment: "+r);{const c={key:r,data:a};e.push(c),o+=s,i=n[o],r==="M"&&(r="L"),r==="m"&&(r="l")}}return e}function vi(t){let e=0,n=0,r=0,o=0;const i=[];for(const{key:s,data:a}of t)switch(s){case"M":i.push({key:"M",data:[...a]}),[e,n]=a,[r,o]=a;break;case"m":e+=a[0],n+=a[1],i.push({key:"M",data:[e,n]}),r=e,o=n;break;case"L":i.push({key:"L",data:[...a]}),[e,n]=a;break;case"l":e+=a[0],n+=a[1],i.push({key:"L",data:[e,n]});break;case"C":i.push({key:"C",data:[...a]}),e=a[4],n=a[5];break;case"c":{const c=a.map(((l,u)=>u%2?l+n:l+e));i.push({key:"C",data:c}),e=c[4],n=c[5];break}case"Q":i.push({key:"Q",data:[...a]}),e=a[2],n=a[3];break;case"q":{const c=a.map(((l,u)=>u%2?l+n:l+e));i.push({key:"Q",data:c}),e=c[2],n=c[3];break}case"A":i.push({key:"A",data:[...a]}),e=a[5],n=a[6];break;case"a":e+=a[5],n+=a[6],i.push({key:"A",data:[a[0],a[1],a[2],a[3],a[4],e,n]});break;case"H":i.push({key:"H",data:[...a]}),e=a[0];break;case"h":e+=a[0],i.push({key:"H",data:[e]});break;case"V":i.push({key:"V",data:[...a]}),n=a[0];break;case"v":n+=a[0],i.push({key:"V",data:[n]});break;case"S":i.push({key:"S",data:[...a]}),e=a[2],n=a[3];break;case"s":{const c=a.map(((l,u)=>u%2?l+n:l+e));i.push({key:"S",data:c}),e=c[2],n=c[3];break}case"T":i.push({key:"T",data:[...a]}),e=a[0],n=a[1];break;case"t":e+=a[0],n+=a[1],i.push({key:"T",data:[e,n]});break;case"Z":case"z":i.push({key:"Z",data:[]}),e=r,n=o}return i}function yi(t){const e=[];let n="",r=0,o=0,i=0,s=0,a=0,c=0;for(const{key:l,data:u}of t){switch(l){case"M":e.push({key:"M",data:[...u]}),[r,o]=u,[i,s]=u;break;case"C":e.push({key:"C",data:[...u]}),r=u[4],o=u[5],a=u[2],c=u[3];break;case"L":e.push({key:"L",data:[...u]}),[r,o]=u;break;case"H":r=u[0],e.push({key:"L",data:[r,o]});break;case"V":o=u[0],e.push({key:"L",data:[r,o]});break;case"S":{let f=0,d=0;n==="C"||n==="S"?(f=r+(r-a),d=o+(o-c)):(f=r,d=o),e.push({key:"C",data:[f,d,...u]}),a=u[0],c=u[1],r=u[2],o=u[3];break}case"T":{const[f,d]=u;let p=0,h=0;n==="Q"||n==="T"?(p=r+(r-a),h=o+(o-c)):(p=r,h=o);const g=r+2*(p-r)/3,v=o+2*(h-o)/3,x=f+2*(p-f)/3,y=d+2*(h-d)/3;e.push({key:"C",data:[g,v,x,y,f,d]}),a=p,c=h,r=f,o=d;break}case"Q":{const[f,d,p,h]=u,g=r+2*(f-r)/3,v=o+2*(d-o)/3,x=p+2*(f-p)/3,y=h+2*(d-h)/3;e.push({key:"C",data:[g,v,x,y,p,h]}),a=f,c=d,r=p,o=h;break}case"A":{const f=Math.abs(u[0]),d=Math.abs(u[1]),p=u[2],h=u[3],g=u[4],v=u[5],x=u[6];f===0||d===0?(e.push({key:"C",data:[r,o,v,x,v,x]}),r=v,o=x):(r!==v||o!==x)&&(xi(r,o,v,x,f,d,p,h,g).forEach((function(y){e.push({key:"C",data:y})})),r=v,o=x);break}case"Z":e.push({key:"Z",data:[]}),r=i,o=s}n=l}return e}function fe(t,e,n){return[t*Math.cos(n)-e*Math.sin(n),t*Math.sin(n)+e*Math.cos(n)]}function xi(t,e,n,r,o,i,s,a,c,l){const u=(f=s,Math.PI*f/180);var f;let d=[],p=0,h=0,g=0,v=0;if(l)[p,h,g,v]=l;else{[t,e]=fe(t,e,-u),[n,r]=fe(n,r,-u);const tt=(t-n)/2,B=(e-r)/2;let ft=tt*tt/(o*o)+B*B/(i*i);ft>1&&(ft=Math.sqrt(ft),o*=ft,i*=ft);const Xt=o*o,Yt=i*i,za=Xt*Yt-Xt*B*B-Yt*tt*tt,Ba=Xt*B*B+Yt*tt*tt,Nr=(a===c?-1:1)*Math.sqrt(Math.abs(za/Ba));g=Nr*o*B/i+(t+n)/2,v=Nr*-i*tt/o+(e+r)/2,p=Math.asin(parseFloat(((e-v)/i).toFixed(9))),h=Math.asin(parseFloat(((r-v)/i).toFixed(9))),t<g&&(p=Math.PI-p),n<g&&(h=Math.PI-h),p<0&&(p=2*Math.PI+p),h<0&&(h=2*Math.PI+h),c&&p>h&&(p-=2*Math.PI),!c&&h>p&&(h-=2*Math.PI)}let x=h-p;if(Math.abs(x)>120*Math.PI/180){const tt=h,B=n,ft=r;h=c&&h>p?p+120*Math.PI/180*1:p+120*Math.PI/180*-1,d=xi(n=g+o*Math.cos(h),r=v+i*Math.sin(h),B,ft,o,i,s,0,c,[h,tt,g,v])}x=h-p;const y=Math.cos(p),A=Math.sin(p),z=Math.cos(h),R=Math.sin(h),I=Math.tan(x/4),J=4/3*o*I,pt=4/3*i*I,De=[t,e],at=[t+J*A,e-pt*y],Dt=[n+J*R,r-pt*z],Rr=[n,r];if(at[0]=2*De[0]-at[0],at[1]=2*De[1]-at[1],l)return[at,Dt,Rr].concat(d);{d=[at,Dt,Rr].concat(d);const tt=[];for(let B=0;B<d.length;B+=3){const ft=fe(d[B][0],d[B][1],u),Xt=fe(d[B+1][0],d[B+1][1],u),Yt=fe(d[B+2][0],d[B+2][1],u);tt.push([ft[0],ft[1],Xt[0],Xt[1],Yt[0],Yt[1]])}return tt}}const zl={randOffset:function(t,e){return w(t,e)},randOffsetWithRange:function(t,e,n){return Qe(t,e,n)},ellipse:function(t,e,n,r,o){const i=ki(n,r,o);return nr(t,e,o,i).opset},doubleLineOps:function(t,e,n,r,o){return It(t,e,n,r,o,!0)}};function wi(t,e,n,r,o){return{type:"path",ops:It(t,e,n,r,o)}}function Xe(t,e,n){const r=(t||[]).length;if(r>2){const o=[];for(let i=0;i<r-1;i++)o.push(...It(t[i][0],t[i][1],t[i+1][0],t[i+1][1],n));return e&&o.push(...It(t[r-1][0],t[r-1][1],t[0][0],t[0][1],n)),{type:"path",ops:o}}return r===2?wi(t[0][0],t[0][1],t[1][0],t[1][1],n):{type:"path",ops:[]}}function Bl(t,e,n,r,o){return(function(i,s){return Xe(i,!0,s)})([[t,e],[t+n,e],[t+n,e+r],[t,e+r]],o)}function Kr(t,e){if(t.length){const n=typeof t[0][0]=="number"?[t]:t,r=_e(n[0],1*(1+.2*e.roughness),e),o=e.disableMultiStroke?[]:_e(n[0],1.5*(1+.22*e.roughness),Jr(e));for(let i=1;i<n.length;i++){const s=n[i];if(s.length){const a=_e(s,1*(1+.2*e.roughness),e),c=e.disableMultiStroke?[]:_e(s,1.5*(1+.22*e.roughness),Jr(e));for(const l of a)l.op!=="move"&&r.push(l);for(const l of c)l.op!=="move"&&o.push(l)}}return{type:"path",ops:r.concat(o)}}return{type:"path",ops:[]}}function ki(t,e,n){const r=Math.sqrt(2*Math.PI*Math.sqrt((Math.pow(t/2,2)+Math.pow(e/2,2))/2)),o=Math.ceil(Math.max(n.curveStepCount,n.curveStepCount/Math.sqrt(200)*r)),i=2*Math.PI/o;let s=Math.abs(t/2),a=Math.abs(e/2);const c=1-n.curveFitting;return s+=w(s*c,n),a+=w(a*c,n),{increment:i,rx:s,ry:a}}function nr(t,e,n,r){const[o,i]=to(r.increment,t,e,r.rx,r.ry,1,r.increment*Qe(.1,Qe(.4,1,n),n),n);let s=Je(o,null,n);if(!n.disableMultiStroke&&n.roughness!==0){const[a]=to(r.increment,t,e,r.rx,r.ry,1.5,0,n),c=Je(a,null,n);s=s.concat(c)}return{estimatedPoints:i,opset:{type:"path",ops:s}}}function Zr(t,e,n,r,o,i,s,a,c){const l=t,u=e;let f=Math.abs(n/2),d=Math.abs(r/2);f+=w(.01*f,c),d+=w(.01*d,c);let p=o,h=i;for(;p<0;)p+=2*Math.PI,h+=2*Math.PI;h-p>2*Math.PI&&(p=0,h=2*Math.PI);const g=2*Math.PI/c.curveStepCount,v=Math.min(g/2,(h-p)/2),x=eo(v,l,u,f,d,p,h,1,c);if(!c.disableMultiStroke){const y=eo(v,l,u,f,d,p,h,1.5,c);x.push(...y)}return s&&(a?x.push(...It(l,u,l+f*Math.cos(p),u+d*Math.sin(p),c),...It(l,u,l+f*Math.cos(h),u+d*Math.sin(h),c)):x.push({op:"lineTo",data:[l,u]},{op:"lineTo",data:[l+f*Math.cos(p),u+d*Math.sin(p)]})),{type:"path",ops:x}}function Qr(t,e){const n=yi(vi(Ar(t))),r=[];let o=[0,0],i=[0,0];for(const{key:s,data:a}of n)switch(s){case"M":i=[a[0],a[1]],o=[a[0],a[1]];break;case"L":r.push(...It(i[0],i[1],a[0],a[1],e)),i=[a[0],a[1]];break;case"C":{const[c,l,u,f,d,p]=a;r.push(...ql(c,l,u,f,d,p,i,e)),i=[d,p];break}case"Z":r.push(...It(i[0],i[1],o[0],o[1],e)),i=[o[0],o[1]]}return{type:"path",ops:r}}function Xn(t,e){const n=[];for(const r of t)if(r.length){const o=e.maxRandomnessOffset||0,i=r.length;if(i>2){n.push({op:"move",data:[r[0][0]+w(o,e),r[0][1]+w(o,e)]});for(let s=1;s<i;s++)n.push({op:"lineTo",data:[r[s][0]+w(o,e),r[s][1]+w(o,e)]})}}return{type:"fillPath",ops:n}}function Vt(t,e){return(function(n,r){let o=n.fillStyle||"hachure";if(!G[o])switch(o){case"zigzag":G[o]||(G[o]=new Dl(r));break;case"cross-hatch":G[o]||(G[o]=new Ol(r));break;case"dots":G[o]||(G[o]=new Rl(r));break;case"dashed":G[o]||(G[o]=new Nl(r));break;case"zigzag-line":G[o]||(G[o]=new Fl(r));break;default:o="hachure",G[o]||(G[o]=new Sr(r))}return G[o]})(e,zl).fillPolygons(t,e)}function Jr(t){const e=Object.assign({},t);return e.randomizer=void 0,t.seed&&(e.seed=t.seed+1),e}function Si(t){return t.randomizer||(t.randomizer=new _l(t.seed||0)),t.randomizer.next()}function Qe(t,e,n,r=1){return n.roughness*r*(Si(n)*(e-t)+t)}function w(t,e,n=1){return Qe(-t,t,e,n)}function It(t,e,n,r,o,i=!1){const s=i?o.disableMultiStrokeFill:o.disableMultiStroke,a=rr(t,e,n,r,o,!0,!1);if(s)return a;const c=rr(t,e,n,r,o,!0,!0);return a.concat(c)}function rr(t,e,n,r,o,i,s){const a=Math.pow(t-n,2)+Math.pow(e-r,2),c=Math.sqrt(a);let l=1;l=c<200?1:c>500?.4:-.0016668*c+1.233334;let u=o.maxRandomnessOffset||0;u*u*100>a&&(u=c/10);const f=u/2,d=.2+.2*Si(o);let p=o.bowing*o.maxRandomnessOffset*(r-e)/200,h=o.bowing*o.maxRandomnessOffset*(t-n)/200;p=w(p,o,l),h=w(h,o,l);const g=[],v=()=>w(f,o,l),x=()=>w(u,o,l),y=o.preserveVertices;return s?g.push({op:"move",data:[t+(y?0:v()),e+(y?0:v())]}):g.push({op:"move",data:[t+(y?0:w(u,o,l)),e+(y?0:w(u,o,l))]}),s?g.push({op:"bcurveTo",data:[p+t+(n-t)*d+v(),h+e+(r-e)*d+v(),p+t+2*(n-t)*d+v(),h+e+2*(r-e)*d+v(),n+(y?0:v()),r+(y?0:v())]}):g.push({op:"bcurveTo",data:[p+t+(n-t)*d+x(),h+e+(r-e)*d+x(),p+t+2*(n-t)*d+x(),h+e+2*(r-e)*d+x(),n+(y?0:x()),r+(y?0:x())]}),g}function _e(t,e,n){if(!t.length)return[];const r=[];r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]),r.push([t[0][0]+w(e,n),t[0][1]+w(e,n)]);for(let o=1;o<t.length;o++)r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]),o===t.length-1&&r.push([t[o][0]+w(e,n),t[o][1]+w(e,n)]);return Je(r,null,n)}function Je(t,e,n){const r=t.length,o=[];if(r>3){const i=[],s=1-n.curveTightness;o.push({op:"move",data:[t[1][0],t[1][1]]});for(let a=1;a+2<r;a++){const c=t[a];i[0]=[c[0],c[1]],i[1]=[c[0]+(s*t[a+1][0]-s*t[a-1][0])/6,c[1]+(s*t[a+1][1]-s*t[a-1][1])/6],i[2]=[t[a+1][0]+(s*t[a][0]-s*t[a+2][0])/6,t[a+1][1]+(s*t[a][1]-s*t[a+2][1])/6],i[3]=[t[a+1][0],t[a+1][1]],o.push({op:"bcurveTo",data:[i[1][0],i[1][1],i[2][0],i[2][1],i[3][0],i[3][1]]})}}else r===3?(o.push({op:"move",data:[t[1][0],t[1][1]]}),o.push({op:"bcurveTo",data:[t[1][0],t[1][1],t[2][0],t[2][1],t[2][0],t[2][1]]})):r===2&&o.push(...rr(t[0][0],t[0][1],t[1][0],t[1][1],n,!0,!0));return o}function to(t,e,n,r,o,i,s,a){const c=[],l=[];if(a.roughness===0){t/=4,l.push([e+r*Math.cos(-t),n+o*Math.sin(-t)]);for(let u=0;u<=2*Math.PI;u+=t){const f=[e+r*Math.cos(u),n+o*Math.sin(u)];c.push(f),l.push(f)}l.push([e+r*Math.cos(0),n+o*Math.sin(0)]),l.push([e+r*Math.cos(t),n+o*Math.sin(t)])}else{const u=w(.5,a)-Math.PI/2;l.push([w(i,a)+e+.9*r*Math.cos(u-t),w(i,a)+n+.9*o*Math.sin(u-t)]);const f=2*Math.PI+u-.01;for(let d=u;d<f;d+=t){const p=[w(i,a)+e+r*Math.cos(d),w(i,a)+n+o*Math.sin(d)];c.push(p),l.push(p)}l.push([w(i,a)+e+r*Math.cos(u+2*Math.PI+.5*s),w(i,a)+n+o*Math.sin(u+2*Math.PI+.5*s)]),l.push([w(i,a)+e+.98*r*Math.cos(u+s),w(i,a)+n+.98*o*Math.sin(u+s)]),l.push([w(i,a)+e+.9*r*Math.cos(u+.5*s),w(i,a)+n+.9*o*Math.sin(u+.5*s)])}return[l,c]}function eo(t,e,n,r,o,i,s,a,c){const l=i+w(.1,c),u=[];u.push([w(a,c)+e+.9*r*Math.cos(l-t),w(a,c)+n+.9*o*Math.sin(l-t)]);for(let f=l;f<=s;f+=t)u.push([w(a,c)+e+r*Math.cos(f),w(a,c)+n+o*Math.sin(f)]);return u.push([e+r*Math.cos(s),n+o*Math.sin(s)]),u.push([e+r*Math.cos(s),n+o*Math.sin(s)]),Je(u,null,c)}function ql(t,e,n,r,o,i,s,a){const c=[],l=[a.maxRandomnessOffset||1,(a.maxRandomnessOffset||1)+.3];let u=[0,0];const f=a.disableMultiStroke?1:2,d=a.preserveVertices;for(let p=0;p<f;p++)p===0?c.push({op:"move",data:[s[0],s[1]]}):c.push({op:"move",data:[s[0]+(d?0:w(l[0],a)),s[1]+(d?0:w(l[0],a))]}),u=d?[o,i]:[o+w(l[p],a),i+w(l[p],a)],c.push({op:"bcurveTo",data:[t+w(l[p],a),e+w(l[p],a),n+w(l[p],a),r+w(l[p],a),u[0],u[1]]});return c}function he(t){return[...t]}function no(t,e=0){const n=t.length;if(n<3)throw new Error("A curve must have at least three points.");const r=[];if(n===3)r.push(he(t[0]),he(t[1]),he(t[2]),he(t[2]));else{const o=[];o.push(t[0],t[0]);for(let a=1;a<t.length;a++)o.push(t[a]),a===t.length-1&&o.push(t[a]);const i=[],s=1-e;r.push(he(o[0]));for(let a=1;a+2<o.length;a++){const c=o[a];i[0]=[c[0],c[1]],i[1]=[c[0]+(s*o[a+1][0]-s*o[a-1][0])/6,c[1]+(s*o[a+1][1]-s*o[a-1][1])/6],i[2]=[o[a+1][0]+(s*o[a][0]-s*o[a+2][0])/6,o[a+1][1]+(s*o[a][1]-s*o[a+2][1])/6],i[3]=[o[a+1][0],o[a+1][1]],r.push(i[1],i[2],i[3])}}return r}function Ye(t,e){return Math.pow(t[0]-e[0],2)+Math.pow(t[1]-e[1],2)}function jl(t,e,n){const r=Ye(e,n);if(r===0)return Ye(t,e);let o=((t[0]-e[0])*(n[0]-e[0])+(t[1]-e[1])*(n[1]-e[1]))/r;return o=Math.max(0,Math.min(1,o)),Ye(t,Ot(e,n,o))}function Ot(t,e,n){return[t[0]+(e[0]-t[0])*n,t[1]+(e[1]-t[1])*n]}function or(t,e,n,r){const o=r||[];if((function(a,c){const l=a[c+0],u=a[c+1],f=a[c+2],d=a[c+3];let p=3*u[0]-2*l[0]-d[0];p*=p;let h=3*u[1]-2*l[1]-d[1];h*=h;let g=3*f[0]-2*d[0]-l[0];g*=g;let v=3*f[1]-2*d[1]-l[1];return v*=v,p<g&&(p=g),h<v&&(h=v),p+h})(t,e)<n){const a=t[e+0];o.length?(i=o[o.length-1],s=a,Math.sqrt(Ye(i,s))>1&&o.push(a)):o.push(a),o.push(t[e+3])}else{const c=t[e+0],l=t[e+1],u=t[e+2],f=t[e+3],d=Ot(c,l,.5),p=Ot(l,u,.5),h=Ot(u,f,.5),g=Ot(d,p,.5),v=Ot(p,h,.5),x=Ot(g,v,.5);or([c,d,g,x],0,n,o),or([x,v,h,f],0,n,o)}var i,s;return o}function Wl(t,e){return tn(t,0,t.length,e)}function tn(t,e,n,r,o){const i=o||[],s=t[e],a=t[n-1];let c=0,l=1;for(let u=e+1;u<n-1;++u){const f=jl(t[u],s,a);f>c&&(c=f,l=u)}return Math.sqrt(c)>r?(tn(t,e,l+1,r,i),tn(t,l,n,r,i)):(i.length||i.push(s),i.push(a)),i}function Yn(t,e=.15,n){const r=[],o=(t.length-1)/3;for(let i=0;i<o;i++)or(t,3*i,e,r);return n&&n>0?tn(r,0,r.length,n):r}const Z="none";class en{constructor(e){this.defaultOptions={maxRandomnessOffset:2,roughness:1,bowing:1,stroke:"#000",strokeWidth:1,curveTightness:0,curveFitting:.95,curveStepCount:9,fillStyle:"hachure",fillWeight:-1,hachureAngle:-41,hachureGap:-1,dashOffset:-1,dashGap:-1,zigzagOffset:-1,seed:0,disableMultiStroke:!1,disableMultiStrokeFill:!1,preserveVertices:!1,fillShapeRoughnessGain:.8},this.config=e||{},this.config.options&&(this.defaultOptions=this._o(this.config.options))}static newSeed(){return Math.floor(Math.random()*2**31)}_o(e){return e?Object.assign({},this.defaultOptions,e):this.defaultOptions}_d(e,n,r){return{shape:e,sets:n||[],options:r||this.defaultOptions}}line(e,n,r,o,i){const s=this._o(i);return this._d("line",[wi(e,n,r,o,s)],s)}rectangle(e,n,r,o,i){const s=this._o(i),a=[],c=Bl(e,n,r,o,s);if(s.fill){const l=[[e,n],[e+r,n],[e+r,n+o],[e,n+o]];s.fillStyle==="solid"?a.push(Xn([l],s)):a.push(Vt([l],s))}return s.stroke!==Z&&a.push(c),this._d("rectangle",a,s)}ellipse(e,n,r,o,i){const s=this._o(i),a=[],c=ki(r,o,s),l=nr(e,n,s,c);if(s.fill)if(s.fillStyle==="solid"){const u=nr(e,n,s,c).opset;u.type="fillPath",a.push(u)}else a.push(Vt([l.estimatedPoints],s));return s.stroke!==Z&&a.push(l.opset),this._d("ellipse",a,s)}circle(e,n,r,o){const i=this.ellipse(e,n,r,r,o);return i.shape="circle",i}linearPath(e,n){const r=this._o(n);return this._d("linearPath",[Xe(e,!1,r)],r)}arc(e,n,r,o,i,s,a=!1,c){const l=this._o(c),u=[],f=Zr(e,n,r,o,i,s,a,!0,l);if(a&&l.fill)if(l.fillStyle==="solid"){const d=Object.assign({},l);d.disableMultiStroke=!0;const p=Zr(e,n,r,o,i,s,!0,!1,d);p.type="fillPath",u.push(p)}else u.push((function(d,p,h,g,v,x,y){const A=d,z=p;let R=Math.abs(h/2),I=Math.abs(g/2);R+=w(.01*R,y),I+=w(.01*I,y);let J=v,pt=x;for(;J<0;)J+=2*Math.PI,pt+=2*Math.PI;pt-J>2*Math.PI&&(J=0,pt=2*Math.PI);const De=(pt-J)/y.curveStepCount,at=[];for(let Dt=J;Dt<=pt;Dt+=De)at.push([A+R*Math.cos(Dt),z+I*Math.sin(Dt)]);return at.push([A+R*Math.cos(pt),z+I*Math.sin(pt)]),at.push([A,z]),Vt([at],y)})(e,n,r,o,i,s,l));return l.stroke!==Z&&u.push(f),this._d("arc",u,l)}curve(e,n){const r=this._o(n),o=[],i=Kr(e,r);if(r.fill&&r.fill!==Z)if(r.fillStyle==="solid"){const s=Kr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(s.ops)})}else{const s=[],a=e;if(a.length){const c=typeof a[0][0]=="number"?[a]:a;for(const l of c)l.length<3?s.push(...l):l.length===3?s.push(...Yn(no([l[0],l[0],l[1],l[2]]),10,(1+r.roughness)/2)):s.push(...Yn(no(l),10,(1+r.roughness)/2))}s.length&&o.push(Vt([s],r))}return r.stroke!==Z&&o.push(i),this._d("curve",o,r)}polygon(e,n){const r=this._o(n),o=[],i=Xe(e,!0,r);return r.fill&&(r.fillStyle==="solid"?o.push(Xn([e],r)):o.push(Vt([e],r))),r.stroke!==Z&&o.push(i),this._d("polygon",o,r)}path(e,n){const r=this._o(n),o=[];if(!e)return this._d("path",o,r);e=(e||"").replace(/\n/g," ").replace(/(-\s)/g,"-").replace("/(ss)/g"," ");const i=r.fill&&r.fill!=="transparent"&&r.fill!==Z,s=r.stroke!==Z,a=!!(r.simplification&&r.simplification<1),c=(function(u,f,d){const p=yi(vi(Ar(u))),h=[];let g=[],v=[0,0],x=[];const y=()=>{x.length>=4&&g.push(...Yn(x,f)),x=[]},A=()=>{y(),g.length&&(h.push(g),g=[])};for(const{key:R,data:I}of p)switch(R){case"M":A(),v=[I[0],I[1]],g.push(v);break;case"L":y(),g.push([I[0],I[1]]);break;case"C":if(!x.length){const J=g.length?g[g.length-1]:v;x.push([J[0],J[1]])}x.push([I[0],I[1]]),x.push([I[2],I[3]]),x.push([I[4],I[5]]);break;case"Z":y(),g.push([v[0],v[1]])}if(A(),!d)return h;const z=[];for(const R of h){const I=Wl(R,d);I.length&&z.push(I)}return z})(e,1,a?4-4*(r.simplification||1):(1+r.roughness)/2),l=Qr(e,r);if(i)if(r.fillStyle==="solid")if(c.length===1){const u=Qr(e,Object.assign(Object.assign({},r),{disableMultiStroke:!0,roughness:r.roughness?r.roughness+r.fillShapeRoughnessGain:0}));o.push({type:"fillPath",ops:this._mergedShape(u.ops)})}else o.push(Xn(c,r));else o.push(Vt(c,r));return s&&(a?c.forEach((u=>{o.push(Xe(u,!1,r))})):o.push(l)),this._d("path",o,r)}opsToPath(e,n){let r="";for(const o of e.ops){const i=typeof n=="number"&&n>=0?o.data.map((s=>+s.toFixed(n))):o.data;switch(o.op){case"move":r+=`M${i[0]} ${i[1]} `;break;case"bcurveTo":r+=`C${i[0]} ${i[1]}, ${i[2]} ${i[3]}, ${i[4]} ${i[5]} `;break;case"lineTo":r+=`L${i[0]} ${i[1]} `}}return r.trim()}toPaths(e){const n=e.sets||[],r=e.options||this.defaultOptions,o=[];for(const i of n){let s=null;switch(i.type){case"path":s={d:this.opsToPath(i),stroke:r.stroke,strokeWidth:r.strokeWidth,fill:Z};break;case"fillPath":s={d:this.opsToPath(i),stroke:Z,strokeWidth:0,fill:r.fill||Z};break;case"fillSketch":s=this.fillSketch(i,r)}s&&o.push(s)}return o}fillSketch(e,n){let r=n.fillWeight;return r<0&&(r=n.strokeWidth/2),{d:this.opsToPath(e),stroke:n.fill||Z,strokeWidth:r,fill:Z}}_mergedShape(e){return e.filter(((n,r)=>r===0||n.op!=="move"))}}class Ul{constructor(e,n){this.canvas=e,this.ctx=this.canvas.getContext("2d"),this.gen=new en(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.ctx,i=e.options.fixedDecimalPlaceDigits;for(const s of n)switch(s.type){case"path":o.save(),o.strokeStyle=r.stroke==="none"?"transparent":r.stroke,o.lineWidth=r.strokeWidth,r.strokeLineDash&&o.setLineDash(r.strokeLineDash),r.strokeLineDashOffset&&(o.lineDashOffset=r.strokeLineDashOffset),this._drawToContext(o,s,i),o.restore();break;case"fillPath":{o.save(),o.fillStyle=r.fill||"";const a=e.shape==="curve"||e.shape==="polygon"||e.shape==="path"?"evenodd":"nonzero";this._drawToContext(o,s,i,a),o.restore();break}case"fillSketch":this.fillSketch(o,s,r)}}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2),e.save(),r.fillLineDash&&e.setLineDash(r.fillLineDash),r.fillLineDashOffset&&(e.lineDashOffset=r.fillLineDashOffset),e.strokeStyle=r.fill||"",e.lineWidth=o,this._drawToContext(e,n,r.fixedDecimalPlaceDigits),e.restore()}_drawToContext(e,n,r,o="nonzero"){e.beginPath();for(const i of n.ops){const s=typeof r=="number"&&r>=0?i.data.map((a=>+a.toFixed(r))):i.data;switch(i.op){case"move":e.moveTo(s[0],s[1]);break;case"bcurveTo":e.bezierCurveTo(s[0],s[1],s[2],s[3],s[4],s[5]);break;case"lineTo":e.lineTo(s[0],s[1])}}n.type==="fillPath"?e.fill(o):e.stroke()}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}line(e,n,r,o,i){const s=this.gen.line(e,n,r,o,i);return this.draw(s),s}rectangle(e,n,r,o,i){const s=this.gen.rectangle(e,n,r,o,i);return this.draw(s),s}ellipse(e,n,r,o,i){const s=this.gen.ellipse(e,n,r,o,i);return this.draw(s),s}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i),i}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r),r}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r),r}arc(e,n,r,o,i,s,a=!1,c){const l=this.gen.arc(e,n,r,o,i,s,a,c);return this.draw(l),l}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r),r}path(e,n){const r=this.gen.path(e,n);return this.draw(r),r}}const He="http://www.w3.org/2000/svg";class Xl{constructor(e,n){this.svg=e,this.gen=new en(n)}draw(e){const n=e.sets||[],r=e.options||this.getDefaultOptions(),o=this.svg.ownerDocument||window.document,i=o.createElementNS(He,"g"),s=e.options.fixedDecimalPlaceDigits;for(const a of n){let c=null;switch(a.type){case"path":c=o.createElementNS(He,"path"),c.setAttribute("d",this.opsToPath(a,s)),c.setAttribute("stroke",r.stroke),c.setAttribute("stroke-width",r.strokeWidth+""),c.setAttribute("fill","none"),r.strokeLineDash&&c.setAttribute("stroke-dasharray",r.strokeLineDash.join(" ").trim()),r.strokeLineDashOffset&&c.setAttribute("stroke-dashoffset",`${r.strokeLineDashOffset}`);break;case"fillPath":c=o.createElementNS(He,"path"),c.setAttribute("d",this.opsToPath(a,s)),c.setAttribute("stroke","none"),c.setAttribute("stroke-width","0"),c.setAttribute("fill",r.fill||""),e.shape!=="curve"&&e.shape!=="polygon"||c.setAttribute("fill-rule","evenodd");break;case"fillSketch":c=this.fillSketch(o,a,r)}c&&i.appendChild(c)}return i}fillSketch(e,n,r){let o=r.fillWeight;o<0&&(o=r.strokeWidth/2);const i=e.createElementNS(He,"path");return i.setAttribute("d",this.opsToPath(n,r.fixedDecimalPlaceDigits)),i.setAttribute("stroke",r.fill||""),i.setAttribute("stroke-width",o+""),i.setAttribute("fill","none"),r.fillLineDash&&i.setAttribute("stroke-dasharray",r.fillLineDash.join(" ").trim()),r.fillLineDashOffset&&i.setAttribute("stroke-dashoffset",`${r.fillLineDashOffset}`),i}get generator(){return this.gen}getDefaultOptions(){return this.gen.defaultOptions}opsToPath(e,n){return this.gen.opsToPath(e,n)}line(e,n,r,o,i){const s=this.gen.line(e,n,r,o,i);return this.draw(s)}rectangle(e,n,r,o,i){const s=this.gen.rectangle(e,n,r,o,i);return this.draw(s)}ellipse(e,n,r,o,i){const s=this.gen.ellipse(e,n,r,o,i);return this.draw(s)}circle(e,n,r,o){const i=this.gen.circle(e,n,r,o);return this.draw(i)}linearPath(e,n){const r=this.gen.linearPath(e,n);return this.draw(r)}polygon(e,n){const r=this.gen.polygon(e,n);return this.draw(r)}arc(e,n,r,o,i,s,a=!1,c){const l=this.gen.arc(e,n,r,o,i,s,a,c);return this.draw(l)}curve(e,n){const r=this.gen.curve(e,n);return this.draw(r)}path(e,n){const r=this.gen.path(e,n);return this.draw(r)}}var Ai={canvas:(t,e)=>new Ul(t,e),svg:(t,e)=>new Xl(t,e),generator:t=>new en(t),newSeed:()=>en.newSeed()};const Yl="http://www.w3.org/2000/svg",ro=1,Ei="#000000",nn=3;let _=null;function Gl(){_||(_=document.createElementNS(Yl,"svg"),_.setAttribute("data-manuscript","ui"),_.setAttribute("width","100%"),_.setAttribute("height","100%"),_.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(_))}function Er(){_==null||_.remove(),_=null}function Mi(t,e,n,r){if(!_)return;for(;_.firstChild;)_.removeChild(_.firstChild);const o=Ai.svg(_);oo(p=>o.line(t,e,n,r,{roughness:1.5,bowing:1,seed:ro,...p}));const i=Math.atan2(r-e,n-t),s=14+nn*2,a=Math.PI/7,c=n-s*Math.cos(i-a),l=r-s*Math.sin(i-a),u=n-s*Math.cos(i+a),f=r-s*Math.sin(i+a),d=`M ${c} ${l} L ${n} ${r} L ${u} ${f}`;oo(p=>o.path(d,{roughness:1.5,bowing:1,seed:ro+1,...p}))}function oo(t){_&&(_.appendChild(t({stroke:"#ffffff",strokeWidth:nn+4})),_.appendChild(t({stroke:Ei,strokeWidth:nn})))}const Vl=8;let rn=!1,io=null,ae=!1,Ft=0,_t=0;function Kl(){io||(io=dt(({prev:t,next:e})=>{e==="arrow"?Zl():t==="arrow"&&Ql()}))}function Zl(){rn||(rn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",$i,!0),document.addEventListener("mousemove",Li,!0),document.addEventListener("mouseup",Ti,!0),document.addEventListener("keydown",Ci,!0))}function Ql(){rn&&(rn=!1,ae=!1,document.body.style.cursor="",document.removeEventListener("mousedown",$i,!0),document.removeEventListener("mousemove",Li,!0),document.removeEventListener("mouseup",Ti,!0),document.removeEventListener("keydown",Ci,!0),Er())}function $i(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),ae=!0,Ft=t.clientX,_t=t.clientY,Gl(),Mi(Ft,_t,Ft,_t))}function Li(t){ae&&(t.preventDefault(),Mi(Ft,_t,t.clientX,t.clientY))}function Ti(t){if(!ae)return;ae=!1,Er();const e=t.clientX,n=t.clientY;if(Math.hypot(e-Ft,n-_t)<Vl){D("idle");return}t.preventDefault(),t.stopPropagation();const o=Y(),i={kind:"arrow",id:Jl(),style:"excalidraw",from:{x:Ft,y:_t},to:{x:e,y:n},...o?{fromAnchorOffset:{x:Ft-o.left,y:_t-o.top},toAnchorOffset:{x:e-o.left,y:n-o.top}}:{},color:Ei,strokeWidth:nn};Ee(i),D("idle")}function Ci(t){t.key==="Escape"&&(t.preventDefault(),ae=!1,Er(),D("idle"))}function Jl(){return`arrow-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const ao="http://www.w3.org/2000/svg",Ii="#1a1a1a",Pi=3,tu=2,eu=2;let on=!1,so=null,se=!1,ut=[],rt=null,ht=null;function nu(){so||(so=dt(({prev:t,next:e})=>{e==="freedraw"?ru():t==="freedraw"&&ou()}))}function ru(){on||(on=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Di,!0),document.addEventListener("mousemove",Oi,!0),document.addEventListener("mouseup",Ri,!0),document.addEventListener("keydown",Ni,!0))}function ou(){on&&(on=!1,se=!1,ut=[],document.body.style.cursor="",document.removeEventListener("mousedown",Di,!0),document.removeEventListener("mousemove",Oi,!0),document.removeEventListener("mouseup",Ri,!0),document.removeEventListener("keydown",Ni,!0),Mr())}function Di(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),se=!0,ut=[{x:t.clientX,y:t.clientY}],iu(),Fi())}function Oi(t){if(!se)return;t.preventDefault();const e=ut[ut.length-1];if(!e)return;const n=t.clientX-e.x,r=t.clientY-e.y;Math.hypot(n,r)<eu||(ut.push({x:t.clientX,y:t.clientY}),Fi())}function Ri(t){if(!se)return;if(se=!1,Mr(),ut.length<tu){ut=[],D("idle");return}t.preventDefault(),t.stopPropagation();const e=ut.slice(),n=Y(),r={kind:"freedraw",id:au(),points:e,...n?{pointsAnchorOffset:e.map(o=>({x:o.x-n.left,y:o.y-n.top}))}:{},stroke:Ii,strokeWidth:Pi};Ee(r),ut=[],D("idle")}function Ni(t){t.key==="Escape"&&(t.preventDefault(),se=!1,ut=[],Mr(),D("idle"))}function iu(){rt||(rt=document.createElementNS(ao,"svg"),rt.setAttribute("data-manuscript","ui"),rt.setAttribute("width","100%"),rt.setAttribute("height","100%"),rt.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),ht=document.createElementNS(ao,"polyline"),ht.setAttribute("fill","none"),ht.setAttribute("stroke",Ii),ht.setAttribute("stroke-width",String(Pi)),ht.setAttribute("stroke-linecap","round"),ht.setAttribute("stroke-linejoin","round"),rt.appendChild(ht),document.body.appendChild(rt))}function Mr(){rt==null||rt.remove(),rt=null,ht=null}function Fi(){ht&&ht.setAttribute("points",ut.map(t=>`${t.x},${t.y}`).join(" "))}function au(){return`freedraw-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Le="manuscript:element-selected";let an=!1,et=null,co=null;function su(){co||(co=dt(({prev:t,next:e})=>{e==="picker"?cu():t==="picker"&&lu()}))}function cu(){an||(an=!0,document.addEventListener("mouseover",_i,!0),document.addEventListener("mouseout",Hi,!0),document.addEventListener("click",zi,!0),document.addEventListener("keydown",Bi,!0))}function lu(){an&&(an=!1,document.removeEventListener("mouseover",_i,!0),document.removeEventListener("mouseout",Hi,!0),document.removeEventListener("click",zi,!0),document.removeEventListener("keydown",Bi,!0),qi())}function _i(t){const e=t.target;!(e instanceof HTMLElement)||ji(e)||du(e)}function Hi(t){qi()}function zi(t){const e=t.target;if(!(e instanceof HTMLElement)||ji(e))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n=ec(e);if(!nc(n,e)){uu();return}const r=e.getBoundingClientRect(),o={chain:n,rect:{x:r.x,y:r.y,width:r.width,height:r.height}};document.dispatchEvent(new CustomEvent(Le,{detail:o})),D("idle")}let st=null,ze=null;function uu(){st&&st.remove(),st=document.createElement("div"),st.setAttribute("data-manuscript","ui"),st.style.cssText=["position: fixed","top: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${H+8}`,"background: rgba(0, 0, 0, 0.92)","color: #ffffff","padding: 12px 18px","border-radius: 8px","font-family: 'Pretendard Variable', Pretendard, system-ui, sans-serif","font-size: 13px","line-height: 1.4","box-shadow: 0 6px 20px rgba(0, 0, 0, 0.25)","pointer-events: none","max-width: 360px","text-align: center"].join("; "),st.textContent=b("toast.ambiguous-selector"),document.body.appendChild(st),ze!==null&&window.clearTimeout(ze),ze=window.setTimeout(()=>{st==null||st.remove(),st=null,ze=null},3500)}function Bi(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function du(t){et||(et=document.createElement("div"),et.setAttribute("data-manuscript","ui"),et.style.cssText=["position: fixed","pointer-events: none","border: 2px solid rgba(255, 61, 139, 0.6)","background: rgba(255, 61, 139, 0.05)",`z-index: ${H+1}`,"box-sizing: border-box","transition: none"].join("; "),document.body.appendChild(et));const e=t.getBoundingClientRect();et.style.left=`${e.left}px`,et.style.top=`${e.top}px`,et.style.width=`${e.width}px`,et.style.height=`${e.height}px`,et.style.display="block"}function qi(){et&&(et.style.display="none")}function ji(t){return t.closest('[data-manuscript="ui"]')!==null}const Te="http://www.w3.org/2000/svg";function $r(t,e){let n;switch(t){case"rectangle":n=pu(e);break;case"ellipse":n=fu(e);break;case"triangle":n=Be(gu(e),e);break;case"diamond":n=Be(bu(e),e);break;case"star":n=Be(vu(e),e);break;case"callout":n=mu(yu(e),e);break;case"line":n=hu(e);break;case"block-arrow":n=Be(xu(e),e);break}if(n&&e.rotate){const r=e.x+e.width/2,o=e.y+e.height/2;n.setAttribute("transform",`rotate(${e.rotate} ${r} ${o})`)}return n}function pu(t){const e=document.createElementNS(Te,"rect");return e.setAttribute("x",String(t.x)),e.setAttribute("y",String(t.y)),e.setAttribute("width",String(t.width)),e.setAttribute("height",String(t.height)),Ln(e,t),e}function fu(t){const e=document.createElementNS(Te,"ellipse");return e.setAttribute("cx",String(t.x+t.width/2)),e.setAttribute("cy",String(t.y+t.height/2)),e.setAttribute("rx",String(Math.max(0,t.width/2))),e.setAttribute("ry",String(Math.max(0,t.height/2))),Ln(e,t),e}function hu(t){const e=document.createElementNS(Te,"line");return e.setAttribute("x1",String(t.x)),e.setAttribute("y1",String(t.y)),e.setAttribute("x2",String(t.x+t.width)),e.setAttribute("y2",String(t.y+t.height)),e.setAttribute("stroke",t.stroke||"#000000"),e.setAttribute("stroke-width",String(t.strokeWidth)),e.setAttribute("stroke-linecap","round"),e.setAttribute("fill","none"),e}function Be(t,e){const n=document.createElementNS(Te,"polygon");return n.setAttribute("points",t),Ln(n,e),n.setAttribute("stroke-linejoin","round"),n}function mu(t,e){const n=document.createElementNS(Te,"path");return n.setAttribute("d",t),Ln(n,e),n.setAttribute("stroke-linejoin","round"),n}function Ln(t,e){t.setAttribute("fill",e.fill||"transparent"),t.setAttribute("stroke",e.stroke||"transparent"),t.setAttribute("stroke-width",String(e.strokeWidth)),e.fillOpacity!==void 0&&e.fillOpacity<1&&t.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,e.fillOpacity))))}function gu(t){const e=t.x,n=t.x+t.width,r=t.y,o=t.y+t.height;return`${(e+n)/2},${r} ${n},${o} ${e},${o}`}function bu(t){const e=t.x+t.width/2,n=t.y+t.height/2;return`${e},${t.y} ${t.x+t.width},${n} ${e},${t.y+t.height} ${t.x},${n}`}function vu(t){const e=t.x+t.width/2,n=t.y+t.height/2,r=Math.min(t.width,t.height)/2,o=r*.5,i=[];for(let s=0;s<10;s++){const a=Math.PI/5*s-Math.PI/2,c=s%2===0?r:o;i.push(`${e+Math.cos(a)*c},${n+Math.sin(a)*c}`)}return i.join(" ")}function yu(t){const e=Math.min(10,t.width/4,t.height/4),n=Math.min(18,t.height*.2),r=t.y+t.height-n,o=t.x+t.width*.32,i=t.x+t.width*.5,s=t.x+t.width*.22,a=t.y+t.height;return[`M ${t.x+e} ${t.y}`,`L ${t.x+t.width-e} ${t.y}`,`Q ${t.x+t.width} ${t.y} ${t.x+t.width} ${t.y+e}`,`L ${t.x+t.width} ${r-e}`,`Q ${t.x+t.width} ${r} ${t.x+t.width-e} ${r}`,`L ${i} ${r}`,`L ${s} ${a}`,`L ${o} ${r}`,`L ${t.x+e} ${r}`,`Q ${t.x} ${r} ${t.x} ${r-e}`,`L ${t.x} ${t.y+e}`,`Q ${t.x} ${t.y} ${t.x+e} ${t.y}`,"Z"].join(" ")}function xu(t){const e=t.x+t.width/2,n=t.y+t.height*.45,r=Math.min(t.width/2,t.width*.22);return[`${e},${t.y}`,`${t.x+t.width},${n}`,`${e+r},${n}`,`${e+r},${t.y+t.height}`,`${e-r},${t.y+t.height}`,`${e-r},${n}`,`${t.x},${n}`].join(" ")}const wu="http://www.w3.org/2000/svg",ku="#ffffff",Su="#1a1a1a",Au=2;let U=null,mt=null;function Wi(t){return{fill:t==="line"?"transparent":ku,stroke:Su,strokeWidth:Au}}function Eu(){mt||(mt=document.createElement("div"),mt.setAttribute("data-manuscript","ui"),mt.textContent="Click and drag to draw a shape · Esc to cancel",mt.style.cssText=["position: fixed","top: 16px","left: 50%","transform: translateX(-50%)","background: rgba(26, 26, 26, 0.92)","color: #ffffff","padding: 8px 16px","border-radius: 999px","font-family: 'Asta Sans', system-ui, sans-serif","font-size: 12px","font-weight: 500",`z-index: ${H+6}`,"pointer-events: none","box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2)","transition: opacity 0.2s ease"].join("; "),document.body.appendChild(mt))}function Ui(){mt==null||mt.remove(),mt=null}function Mu(){U||(U=document.createElementNS(wu,"svg"),U.setAttribute("data-manuscript","ui"),U.setAttribute("width","100%"),U.setAttribute("height","100%"),U.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+4}`,"overflow: visible"].join("; "),document.body.appendChild(U))}function Lr(){U==null||U.remove(),U=null}function Xi(t,e,n,r,o){if(!U)return;for(;U.firstChild;)U.removeChild(U.firstChild);const i=t==="line"?r-e:Math.abs(r-e),s=t==="line"?o-n:Math.abs(o-n),a=t==="line"?e:Math.min(e,r),c=t==="line"?n:Math.min(n,o),l=Wi(t),u=$r(t,{x:a,y:c,width:i,height:s,...l});u&&U.appendChild(u)}const $u=6;let St="rectangle",sn=!1,lo=null,ce=!1,At=0,Et=0;function Lu(t){St=t}function Tu(){lo||(lo=dt(({prev:t,next:e})=>{e==="shape"?Cu():t==="shape"&&Iu()}))}function Cu(){sn||(sn=!0,document.body.style.cursor="crosshair",document.addEventListener("mousedown",Yi,!0),document.addEventListener("mousemove",Gi,!0),document.addEventListener("mouseup",Vi,!0),document.addEventListener("keydown",Ki,!0),Eu())}function Iu(){sn&&(sn=!1,ce=!1,document.body.style.cursor="",document.removeEventListener("mousedown",Yi,!0),document.removeEventListener("mousemove",Gi,!0),document.removeEventListener("mouseup",Vi,!0),document.removeEventListener("keydown",Ki,!0),Lr(),Ui())}function Yi(t){const e=t.target;e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]')||(t.preventDefault(),t.stopPropagation(),ce=!0,At=t.clientX,Et=t.clientY,Ui(),Mu(),Xi(St,At,Et,At,Et))}function Gi(t){ce&&(t.preventDefault(),Xi(St,At,Et,t.clientX,t.clientY))}function Vi(t){if(!ce)return;ce=!1,Lr();const e=t.clientX,n=t.clientY,r=St==="line"?e-At:Math.abs(e-At),o=St==="line"?n-Et:Math.abs(n-Et);if(Math.max(Math.abs(r),Math.abs(o))<$u){D("idle");return}t.preventDefault(),t.stopPropagation();const i=St==="line"?{x:At,y:Et,width:r,height:o}:{x:Math.min(At,e),y:Math.min(Et,n),width:r,height:o},s=Wi(St),a=Y(),c={kind:"shape",id:Pu(),shapeKind:St,bounds:i,...a?{boundsAnchorOffset:{x:i.x-a.left,y:i.y-a.top}}:{},...s};Ee(c),D("idle")}function Ki(t){t.key==="Escape"&&(t.preventDefault(),ce=!1,Lr(),D("idle"))}function Pu(){return`shape-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Du={fontFamily:"'Asta Sans', system-ui, sans-serif",fontSize:16,color:"#000000",bold:!1},Ou="Text";let cn=!1,uo=null;function Ru(){uo||(uo=dt(({prev:t,next:e})=>{e==="text"?Nu():t==="text"&&Fu()}))}function Nu(){cn||(cn=!0,document.body.style.cursor="crosshair",document.addEventListener("click",Zi,!0),document.addEventListener("keydown",Qi,!0))}function Fu(){cn&&(cn=!1,document.body.style.cursor="",document.removeEventListener("click",Zi,!0),document.removeEventListener("keydown",Qi,!0))}function Zi(t){const e=t.target;if(e instanceof HTMLElement&&e.closest('[data-manuscript="ui"]'))return;t.preventDefault(),t.stopPropagation(),t.stopImmediatePropagation();const n={x:t.clientX,y:t.clientY},r=Y(),o={kind:"text",id:_u(),text:Ou,position:n,...r?{anchorOffset:{x:n.x-r.left,y:n.y-r.top}}:{},style:{...Du}};Ee(o),requestAnimationFrame(()=>{const i=document.querySelector(`[data-annotation-text="${o.id}"]`);i&&i.dispatchEvent(new MouseEvent("dblclick",{bubbles:!0}))}),D("idle")}function Qi(t){t.key==="Escape"&&(t.preventDefault(),D("idle"))}function _u(){return`text-${Date.now()}-${Math.random().toString(36).slice(2,8)}`}const Hu="https://cdn.jsdelivr.net/gh/orioncactus/pretendard/dist/web/variable/pretendardvariable-dynamic-subset.css",zu="https://fonts.googleapis.com/css2?family=EB+Garamond:ital,wght@0,400;0,500;0,600;1,400&display=swap",po="Asta Sans",Bu="fonts/AstaSans-VariableFont_wght.ttf";let fo=!1;function qu(){fo||(fo=!0,ho(Hu),ho(zu),ju())}function ho(t){if(!(typeof document>"u")&&!document.querySelector(`link[href="${t}"]`))try{const e=document.createElement("link");e.rel="stylesheet",e.href=t,e.setAttribute("data-manuscript","font"),document.head.appendChild(e)}catch(e){console.warn("[manuscript] font link inject failed",t,e)}}function ju(){try{for(const t of document.fonts)if(t.family===po)return}catch{}try{const t=chrome.runtime.getURL(Bu);new FontFace(po,`url(${t}) format('truetype-variations')`,{weight:"100 900",style:"normal",display:"swap"}).load().then(n=>{document.fonts.add(n)},n=>{console.warn("[manuscript] Asta Sans load failed",n)})}catch(t){console.warn("[manuscript] FontFace API unavailable",t)}}const ct="manuscript";function Tn(...t){}function Gn(t){for(let e=0;e<window.frames.length;e++){const n=window.frames[e];if(n)try{n.postMessage(t,"*")}catch{}}}function Kt(t){var e;try{(e=window.top)==null||e.postMessage(t,"*")}catch{}}function Ji(t){if(typeof t!="object"||t===null)return!1;const e=t;return e.source===ct&&typeof e.type=="string"}function Wu(){let t="idle";const e=o=>o==="shape"||o==="freedraw";let n=!1;window.addEventListener("message",o=>{const i=o.data;if(Ji(i)){if(Tn("child received",i.type,"in",location.href),i.type==="set-mode"){D(i.mode),t=i.mode;return}if(i.type==="top-drag-start"){n=!0;return}if(i.type==="top-drag-end"){n=!1;return}}}),document.addEventListener(Le,(o=>{const i=o.detail;Kt({source:ct,type:"element-selected",detail:i})})),dt(({prev:o,next:i})=>{o==="picker"&&i==="idle"&&Kt({source:ct,type:"exit-picker"})}),Kt({source:ct,type:"frame-ready"}),document.addEventListener("mousedown",o=>{Kt({source:ct,type:"iframe-mousedown",x:o.clientX,y:o.clientY})},!0);const r=()=>e(t)||n;document.addEventListener("mousemove",o=>{r()&&Kt({source:ct,type:"iframe-mousemove",x:o.clientX,y:o.clientY})},!0),document.addEventListener("mouseup",o=>{r()&&Kt({source:ct,type:"iframe-mouseup",x:o.clientX,y:o.clientY})},!0)}function Uu(t){if(!t||t===window)return{x:0,y:0};for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;try{const o=t.frameElement;if(o){const i=o.getBoundingClientRect();return{x:i.left,y:i.top}}}catch{}const r=document.querySelectorAll("iframe")[e];if(r){const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}break}return{x:0,y:0}}function Xu(t){if(!t||t===window)return null;for(let e=0;e<window.frames.length;e++){if(window.frames[e]!==t)continue;let n="";try{const r=t.frameElement;r!=null&&r.src&&(n=r.src)}catch{}if(!n){const o=document.querySelectorAll("iframe")[e];o!=null&&o.src&&(n=o.src)}return{index:e,url:n}}return null}function Yu(){dt(({next:t})=>{Gn({source:ct,type:"set-mode",mode:t})}),document.addEventListener("mousedown",()=>Gn({source:ct,type:"top-drag-start"}),!0),document.addEventListener("mouseup",()=>Gn({source:ct,type:"top-drag-end"}),!0),window.addEventListener("message",t=>{const e=t.data;if(Ji(e)){if(Tn("top received",e.type,"from",t.origin||"(opaque)"),e.type==="element-selected"){Gu(t.source,e.detail);return}if(e.type==="exit-picker"){D("idle");return}if(e.type==="iframe-mousedown"){mo("mousedown",t.source,e.x??0,e.y??0);return}if(e.type==="iframe-mouseup"||e.type==="iframe-mousemove"){const n=e.type==="iframe-mouseup"?"mouseup":"mousemove";mo(n,t.source,e.x,e.y);return}if(e.type==="frame-ready"){Vu(t.source);return}}})}function Gu(t,e){const n=Xu(t),o={chain:n?{...e.chain,framePath:[n]}:e.chain,rect:e.rect};Tn("top enriched framePath:",n?`[${n.index}] ${n.url}`:"top frame"),document.dispatchEvent(new CustomEvent(Le,{detail:o})),D("idle")}function mo(t,e,n,r){const o=Uu(e),i=n+o.x,s=r+o.y;document.body.dispatchEvent(new MouseEvent(t,{bubbles:!0,cancelable:!0,clientX:i,clientY:s}))}function Vu(t){if(bt()==="picker")try{t==null||t.postMessage({source:ct,type:"set-mode",mode:"picker"},"*"),Tn("top → late child: set-mode picker")}catch{}}function Ku(){if(typeof window>"u")return;window===window.top?Yu():Wu()}const Zu="iframe-tool-overlay",go=new Set(["text","shape","freedraw"]);let ee=[],Vn=!1,Zt=null;function Qu(){typeof window>"u"||window===window.top&&(dt(({next:t})=>{go.has(t)?bo():ta()}),go.has(bt())&&bo())}function bo(){ta(),vo(),window.addEventListener("scroll",ln,!0),window.addEventListener("resize",ln),Zt=new MutationObserver(t=>{let e=!1;for(const n of t){for(const r of Array.from(n.addedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break;for(const r of Array.from(n.removedNodes))if(r instanceof HTMLIFrameElement){e=!0;break}if(e)break}e&&vo()}),Zt.observe(document.body,{childList:!0,subtree:!0})}function ta(){ee.forEach(t=>t.remove()),ee=[],window.removeEventListener("scroll",ln,!0),window.removeEventListener("resize",ln),Zt==null||Zt.disconnect(),Zt=null}function vo(){ee.forEach(e=>e.remove()),ee=[],document.querySelectorAll("iframe").forEach(e=>{if(e.closest('[data-manuscript="ui"]'))return;const n=document.createElement("div");n.setAttribute("data-overlay",Zu),n.style.cssText=["position: fixed","pointer-events: auto",`z-index: ${H+2}`,"background: transparent","cursor: crosshair"].join("; "),document.body.appendChild(n),ee.push(n),ea(n,e)})}const qe=8;function ea(t,e){const n=e.getBoundingClientRect();t.style.left=`${n.left-qe}px`,t.style.top=`${n.top-qe}px`,t.style.width=`${n.width+qe*2}px`,t.style.height=`${n.height+qe*2}px`,t.style.display=n.width>0&&n.height>0?"block":"none"}function ln(){Vn||(Vn=!0,requestAnimationFrame(()=>{Vn=!1;const t=document.querySelectorAll("iframe");let e=0;t.forEach(n=>{if(n.closest('[data-manuscript="ui"]'))return;const r=ee[e];r&&ea(r,n),e++})}))}let Ct=!1;function Cn(){return Ct}async function Ju(){try{if(typeof(await chrome.storage.local.get(Q.prompterWindowId))[Q.prompterWindowId]!="number")return;const e=await chrome.runtime.sendMessage({type:"prompter.probe"});e!=null&&e.ok&&(Ct=!0)}catch{}}async function na(){if(Ct){try{const t=await chrome.runtime.sendMessage({type:"prompter.focus"});if(t!=null&&t.ok)return}catch{}Ct=!1}try{const t=await chrome.runtime.sendMessage({type:"prompter.open"});t!=null&&t.ok&&(Ct=!0)}catch(t){console.warn("[manuscript] open prompter failed",t)}}async function ra(){if(Ct){Ct=!1;try{await chrome.runtime.sendMessage({type:"prompter.close"})}catch{}}}async function oa(t){try{await chrome.storage.local.set({[Q.prompterState]:t})}catch(e){console.warn("[manuscript] prompter state write failed",e)}}function td(){Ct=!1}const ed="modulepreload",nd=function(t){return"/"+t},yo={},rd=function(e,n,r){let o=Promise.resolve();if(n&&n.length>0){let s=function(l){return Promise.all(l.map(u=>Promise.resolve(u).then(f=>({status:"fulfilled",value:f}),f=>({status:"rejected",reason:f}))))};document.getElementsByTagName("link");const a=document.querySelector("meta[property=csp-nonce]"),c=(a==null?void 0:a.nonce)||(a==null?void 0:a.getAttribute("nonce"));o=s(n.map(l=>{if(l=nd(l),l in yo)return;yo[l]=!0;const u=l.endsWith(".css"),f=u?'[rel="stylesheet"]':"";if(document.querySelector(`link[href="${l}"]${f}`))return;const d=document.createElement("link");if(d.rel=u?"stylesheet":ed,u||(d.as="script"),d.crossOrigin="",d.href=l,c&&d.setAttribute("nonce",c),document.head.appendChild(d),u)return new Promise((p,h)=>{d.addEventListener("load",p),d.addEventListener("error",()=>h(new Error(`Unable to preload CSS for ${l}`)))})}))}function i(s){const a=new Event("vite:preloadError",{cancelable:!0});if(a.payload=s,window.dispatchEvent(a),!a.defaultPrevented)throw s}return o.then(s=>{for(const a of s||[])a.status==="rejected"&&i(a.reason);return e().catch(i)})},kt="http://www.w3.org/2000/svg",xo="manuscript-spotlight-mask",od="oklch(0.42 0.09 250)",id=3,ad="rgb(0, 0, 0)",sd=.55,me=14;let ne=null,V=null,lt=null,X=null,N=null,xt=null,ir=[],Qt=null;function ia(t){ne=t,V||ld(),wo(),xe(),cd(t),Qt||(Qt=de(wo))}function le(){ne=null,aa(),Qt==null||Qt(),Qt=null,V&&(V.remove(),V=null,lt=null,X=null,N=null,xt=null)}function cd(t){var n;aa();const e=[window];try{const r=(n=t.ownerDocument)==null?void 0:n.defaultView;r&&r!==window&&e.push(r)}catch{}for(const r of e){const o=xe;r.addEventListener("scroll",o,!0),ir.push({target:r,remove:()=>r.removeEventListener("scroll",o,!0)})}window.addEventListener("resize",xe)}function aa(){for(const t of ir)t.remove();ir=[],window.removeEventListener("resize",xe)}function ld(){V=document.createElementNS(kt,"svg"),V.setAttribute("data-manuscript","ui"),V.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H}`].join("; "),V.setAttribute("width","100%"),V.setAttribute("height","100%");const t=document.createElementNS(kt,"defs"),e=document.createElementNS(kt,"mask");e.setAttribute("id",xo);const n=document.createElementNS(kt,"rect");n.setAttribute("width","100%"),n.setAttribute("height","100%"),n.setAttribute("fill","white"),e.appendChild(n),lt=document.createElementNS(kt,"rect"),lt.setAttribute("fill","black"),lt.setAttribute("rx","4"),lt.setAttribute("ry","4"),e.appendChild(lt),t.appendChild(e),V.appendChild(t),xt=document.createElementNS(kt,"rect"),xt.setAttribute("width","100%"),xt.setAttribute("height","100%"),xt.setAttribute("mask",`url(#${xo})`),V.appendChild(xt),X=document.createElementNS(kt,"rect"),X.setAttribute("fill","none"),X.setAttribute("rx","4"),X.setAttribute("ry","4"),X.style.pointerEvents="none",V.appendChild(X),N=document.createElementNS(kt,"rect"),N.setAttribute("fill","none"),N.setAttribute("stroke","transparent"),N.setAttribute("stroke-width",String(me)),N.setAttribute("rx","4"),N.setAttribute("ry","4"),N.setAttribute("pointer-events","stroke"),N.style.cursor="pointer",N.addEventListener("click",ud),V.appendChild(N),document.body.appendChild(V)}function wo(){var i;if(!X||!xt)return;const t=((i=ot())==null?void 0:i.spotlight)??{},e=t.stroke??od,n=t.strokeWidth??id,r=t.dimColor??ad,o=t.dimOpacity??sd;X.setAttribute("stroke",e),X.setAttribute("stroke-width",String(n)),xt.setAttribute("fill",r),xt.setAttribute("fill-opacity",String(Math.max(0,Math.min(1,o)))),xe()}function ud(t){bt()!=="replay"&&(!ne||!N||(t.stopPropagation(),t.preventDefault(),rd(()=>import("./chunk-is4wiPY0.js"),__vite__mapDeps([0,1,2,3,4])).then(e=>{N&&e.openSpotlightEditor(N)})))}function xe(){if(!ne||!lt||!X||!N)return;const t=ne.getBoundingClientRect(),e=dd(ne),n=4,r=t.left+e.x-n,o=t.top+e.y-n,i=t.width+n*2,s=t.height+n*2;lt.setAttribute("x",String(r)),lt.setAttribute("y",String(o)),lt.setAttribute("width",String(i)),lt.setAttribute("height",String(s));const a=Math.max(0,Number(X.getAttribute("stroke-width")??0)),c=r-a/2,l=o-a/2,u=i+a,f=s+a;X.setAttribute("x",String(c)),X.setAttribute("y",String(l)),X.setAttribute("width",String(u)),X.setAttribute("height",String(f));const d=c-me/2,p=l-me/2,h=u+me,g=f+me;N.setAttribute("x",String(d)),N.setAttribute("y",String(p)),N.setAttribute("width",String(h)),N.setAttribute("height",String(g))}function dd(t){try{const e=t.ownerDocument,n=e==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}const ko="data-wp-animations";function pd(){if(document.head.querySelector(`[${ko}]`))return;const t=document.createElement("style");t.setAttribute(ko,"true"),t.textContent=`
    @keyframes wp-fade { from { opacity: 0; } to { opacity: 1; } }
    @keyframes wp-slide-left {
      from { transform: translateX(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-right {
      from { transform: translateX(30px) rotate(0deg); opacity: 0; }
      to { transform: translateX(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-up {
      from { transform: translateY(30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-slide-down {
      from { transform: translateY(-30px) rotate(0deg); opacity: 0; }
      to { transform: translateY(0) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    @keyframes wp-bounce {
      0% { transform: scale(0.3) rotate(0deg); opacity: 0; }
      50% { transform: scale(1.1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
      70% { transform: scale(0.95) rotate(var(--wp-final-rot, 0deg)); }
      100% { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); }
    }
    @keyframes wp-zoom {
      from { transform: scale(0) rotate(0deg); opacity: 0; }
      to { transform: scale(1) rotate(var(--wp-final-rot, 0deg)); opacity: 1; }
    }
    /* rotate effect — 720deg(2회전) 후 final rotate. */
    @keyframes wp-rotate {
      from { transform: rotate(0deg); opacity: 0; }
      to { transform: rotate(calc(720deg + var(--wp-final-rot, 0deg))); opacity: 1; }
    }
  `,document.head.appendChild(t)}function we(t,e,n){if(!e||e.kind==="none"||bt()!=="replay")return;const r=Math.max(50,e.durationMs||400),o=Math.max(0,e.delayMs||0);t.style.transformBox="fill-box",t.style.transformOrigin="center",t.style.setProperty("--wp-final-rot",`${n}deg`),t.style.animation=`wp-${e.kind} ${r}ms ease-out ${o}ms backwards`;const i=()=>{t.style.animation="",t.style.transformBox="",t.style.transformOrigin="",t.removeEventListener("animationend",i),t.removeEventListener("animationcancel",i)};t.addEventListener("animationend",i),t.addEventListener("animationcancel",i)}const un="http://www.w3.org/2000/svg",sa="data-annotation-text",So="data-annotation-arrow",ca="data-annotation-shape",Ao="data-annotation-freedraw",L={host:null,svg:null,roughSvg:null,unsubscribe:null,unsubscribeMode:null};function fd(t,e){const{svg:n,roughSvg:r}=L;if(!n||!r)return;const o=md(t.id),{from:i,to:s}=ic(t,e);la(t,a=>r.line(i.x,i.y,s.x,s.y,{roughness:1.5,bowing:1,seed:o,...a})),hd(t,i,s,o+1)}function hd(t,e,n,r){const{roughSvg:o}=L;if(!o)return;const i=Math.atan2(n.y-e.y,n.x-e.x),s=14+t.strokeWidth*2,a=Math.PI/7,c=n.x-s*Math.cos(i-a),l=n.y-s*Math.sin(i-a),u=n.x-s*Math.cos(i+a),f=n.y-s*Math.sin(i+a),d=`M ${c} ${l} L ${n.x} ${n.y} L ${u} ${f}`;la(t,p=>o.path(d,{roughness:1.5,bowing:1,seed:r,...p}))}function la(t,e){const{svg:n}=L;if(!n)return;const r=e({stroke:"#ffffff",strokeWidth:t.strokeWidth+4});r.setAttribute(So,t.id),we(r,t.entryAnimation,0),n.appendChild(r);const o=e({stroke:t.color,strokeWidth:t.strokeWidth});o.setAttribute(So,t.id),we(o,t.entryAnimation,0),n.appendChild(o)}function md(t){let e=0;for(let n=0;n<t.length;n++)e=e*31+t.charCodeAt(n)|0;return Math.abs(e%1e5)}const $={state:null,unsubscribeStep:null};function vt(){return $.state!==null}function Tr(){var t;return((t=$.state)==null?void 0:t.standalone)===!0}function gd(t,e){const{svg:n}=L;if(!n)return;const r=Sn(t,e),o=bd(t,r),i=r.map(c=>`${c.x},${c.y}`).join(" "),s=document.createElementNS(un,"polyline");if(s.setAttribute("points",i),s.setAttribute("fill","none"),s.setAttribute("stroke",t.stroke),s.setAttribute("stroke-width",String(t.strokeWidth)),s.setAttribute("stroke-linecap","round"),s.setAttribute("stroke-linejoin","round"),s.setAttribute(Ao,t.id),t.strokeOpacity!==void 0&&t.strokeOpacity<1&&s.setAttribute("stroke-opacity",String(Math.max(0,Math.min(1,t.strokeOpacity)))),o&&s.setAttribute("transform",o),s.style.pointerEvents="none",we(s,t.entryAnimation,t.rotate??0),n.appendChild(s),Tr())return;const a=document.createElementNS(un,"polyline");a.setAttribute(Ao,t.id),a.setAttribute("points",i),a.setAttribute("fill","none"),a.setAttribute("stroke","transparent"),a.setAttribute("stroke-width",String(Math.max(12,t.strokeWidth+10))),a.setAttribute("stroke-linecap","round"),a.setAttribute("stroke-linejoin","round"),a.setAttribute("pointer-events","stroke"),o&&a.setAttribute("transform",o),a.style.cursor="pointer",a.addEventListener("mousedown",c=>{c.button===0&&(c.stopPropagation(),c.preventDefault(),vd(t.id,c,a))}),n.appendChild(a)}function bd(t,e){const n=t.rotate??0;if(!n||e.length===0)return"";let r=1/0,o=1/0,i=-1/0,s=-1/0;for(const l of e)l.x<r&&(r=l.x),l.y<o&&(o=l.y),l.x>i&&(i=l.x),l.y>s&&(s=l.y);const a=(r+i)/2,c=(o+s)/2;return`rotate(${n} ${a} ${c})`}function vd(t,e,n){const r=T(t);if(!r||r.kind!=="freedraw")return;const o={x:e.clientX,y:e.clientY},i=Y(),s=Sn(r,i).map(u=>({...u}));let a=!1;const c=u=>{const f=u.clientX-o.x,d=u.clientY-o.y;if(!a&&Math.hypot(f,d)<3)return;a=!0,u.preventDefault();const p=s.map(g=>({x:g.x+f,y:g.y+d})),h=i?{points:p,pointsAnchorOffset:p.map(g=>({x:g.x-i.left,y:g.y-i.top}))}:{points:p,pointsAnchorOffset:void 0};C(t,h)},l=()=>{document.removeEventListener("mousemove",c,!0),document.removeEventListener("mouseup",l,!0);const u=document.querySelectorAll(`[data-annotation-freedraw="${t}"]`),f=u[u.length-1]??n;gl(t,f)};document.addEventListener("mousemove",c,!0),document.addEventListener("mouseup",l,!0)}function yd(t,e){const{svg:n}=L;if(!n)return;const r=kn(t,e),o=$r(t.shapeKind,{x:r.x,y:r.y,width:t.bounds.width,height:t.bounds.height,fill:t.fill,stroke:t.stroke,strokeWidth:t.strokeWidth,fillOpacity:t.fillOpacity,rotate:t.rotate});o&&(o.setAttribute(ca,t.id),o.style.pointerEvents="none",we(o,t.entryAnimation,t.rotate??0),n.appendChild(o),Tr()||n.appendChild(xd(t,r)))}function xd(t,e){const n=document.createElementNS(un,"rect");if(n.setAttribute(ca,t.id),n.setAttribute("x",String(e.x)),n.setAttribute("y",String(e.y)),n.setAttribute("width",String(Math.max(0,t.bounds.width))),n.setAttribute("height",String(Math.max(0,t.bounds.height))),n.setAttribute("fill","rgba(0, 0, 0, 0.001)"),n.setAttribute("stroke","none"),n.setAttribute("pointer-events","all"),n.style.pointerEvents="all",n.style.cursor="pointer",t.rotate){const r=e.x+t.bounds.width/2,o=e.y+t.bounds.height/2;n.setAttribute("transform",`rotate(${t.rotate} ${r} ${o})`)}return n.addEventListener("mousedown",r=>wd(t.id,r,n)),n}function wd(t,e,n){if(e.button!==0)return;e.stopPropagation(),e.preventDefault();const r={x:e.clientX,y:e.clientY},o=T(t);if(!o||o.kind!=="shape")return;const i=Y(),s=o.boundsAnchorOffset&&i?{x:i.left+o.boundsAnchorOffset.x,y:i.top+o.boundsAnchorOffset.y}:{x:o.bounds.x,y:o.bounds.y},a={...o.bounds,x:s.x,y:s.y};let c=!1;const l=f=>{const d=f.clientX-r.x,p=f.clientY-r.y;if(!c&&Math.hypot(d,p)<3)return;c=!0,f.preventDefault();const h=a.x+d,g=a.y+p,v=i?{bounds:{...a,x:h,y:g},boundsAnchorOffset:{x:h-i.left,y:g-i.top}}:{bounds:{...a,x:h,y:g},boundsAnchorOffset:void 0};C(t,v)},u=()=>{document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0);const f=document.querySelectorAll(`[data-annotation-shape="${t}"]`),d=f[f.length-1]??n;ml(t,d)};document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",u,!0)}function kd(t,e){const{host:n}=L;if(!n)return;const r=document.createElement("div");r.setAttribute(sa,t.id),r.setAttribute("data-manuscript","ui"),r.dataset.annotationId=t.id;const o=t.style.italic===!0,i=t.style.backgroundColor??"#ffffff",s=t.style.backgroundOpacity??.96,a=i==="transparent"?"transparent":Sd(i,s),c=t.rotate??0,l=t.style.borderColor??"#000000",u=l==="transparent"?"none":`2px solid ${l}`,f=oc(t,e),d=Tr();r.style.cssText=["position: absolute",`left: ${f.x}px`,`top: ${f.y}px`,`font-family: ${t.style.fontFamily}`,`font-size: ${t.style.fontSize}px`,`color: ${t.style.color}`,`font-weight: ${t.style.bold?"700":"400"}`,`font-style: ${o?"italic":"normal"}`,"padding: 8px 12px",`background: ${a}`,`border: ${u}`,"border-radius: 8px",d?"pointer-events: none":"pointer-events: auto",d?"cursor: default":"cursor: move","user-select: none","box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1)","max-width: 320px","word-wrap: break-word","line-height: 1.4",`transform: rotate(${c}deg)`,"transform-origin: center center"].join("; "),r.textContent=t.text,d||Ad(r,t.id),we(r,t.entryAnimation,t.rotate??0),n.appendChild(r)}function Sd(t,e){const n=Math.max(0,Math.min(1,e)),r=t.trim();if(r.startsWith("#")){let o=0,i=0,s=0;return r.length===4?(o=parseInt(r[1]+r[1],16),i=parseInt(r[2]+r[2],16),s=parseInt(r[3]+r[3],16)):r.length===7&&(o=parseInt(r.slice(1,3),16),i=parseInt(r.slice(3,5),16),s=parseInt(r.slice(5,7),16)),`rgba(${o}, ${i}, ${s}, ${n})`}return t}function Ad(t,e){let n=!1,r=0,o=0,i=0,s=0,a=!1;t.addEventListener("mousedown",c=>{if(t.isContentEditable)return;n=!0,a=!1,r=c.clientX,o=c.clientY;const l=t.getBoundingClientRect();i=l.left,s=l.top,c.preventDefault()}),document.addEventListener("mousemove",c=>{if(!n)return;const l=c.clientX-r,u=c.clientY-o;Math.abs(l)+Math.abs(u)>2&&(a=!0),t.style.left=`${i+l}px`,t.style.top=`${s+u}px`}),document.addEventListener("mouseup",()=>{if(!n||(n=!1,!a))return;const c=parseFloat(t.style.left),l=parseFloat(t.style.top),u=Y(),f=u?{position:{x:c,y:l},anchorOffset:{x:c-u.left,y:l-u.top}}:{position:{x:c,y:l},anchorOffset:void 0};C(e,f)}),t.addEventListener("click",c=>{a||t.isContentEditable||(c.stopPropagation(),hl(e,t))}),t.addEventListener("dblclick",()=>{t.contentEditable="true",t.style.cursor="text",t.focus(),Ed(t)}),t.addEventListener("blur",()=>{t.isContentEditable&&(t.contentEditable="false",t.style.cursor="move",C(e,{text:t.textContent??""}))}),t.addEventListener("keydown",c=>{c.key==="Escape"&&t.isContentEditable&&t.blur()})}function Ed(t){const e=document.createRange();e.selectNodeContents(t),e.collapse(!1);const n=window.getSelection();n&&(n.removeAllRanges(),n.addRange(e))}function ua(){if(L.host)return;pd();const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.style.cssText=["position: fixed","top: 0","left: 0","width: 100vw","height: 100vh","pointer-events: none",`z-index: ${H+3}`].join("; ");const e=document.createElementNS(un,"svg");e.setAttribute("width","100%"),e.setAttribute("height","100%"),e.style.cssText=["position: absolute","top: 0","left: 0","pointer-events: none","overflow: visible"].join("; "),t.appendChild(e),L.host=t,L.svg=e,L.roughSvg=Ai.svg(e),document.body.appendChild(t),L.unsubscribe=de(Ge),L.unsubscribeMode=dt(Ge),Md(),Ge()}let re=null;function ge(){re===null&&(re=requestAnimationFrame(()=>{re=null,Ge()}))}let Ht=null,ar=null;function Md(){window.addEventListener("resize",ge),window.addEventListener("scroll",ge,!0),typeof ResizeObserver<"u"&&(Ht=new ResizeObserver(ge))}function $d(){window.removeEventListener("resize",ge),window.removeEventListener("scroll",ge,!0),Ht&&(Ht.disconnect(),Ht=null),ar=null,re!==null&&(cancelAnimationFrame(re),re=null)}function da(){var t,e;(t=L.unsubscribe)==null||t.call(L),L.unsubscribe=null,(e=L.unsubscribeMode)==null||e.call(L),L.unsubscribeMode=null,$d(),L.host&&(L.host.remove(),L.host=null,L.svg=null,L.roughSvg=null)}function Ld(){return L.host!==null}function Ge(){const{host:t,svg:e}=L;if(!t||!e)return;for(t.querySelectorAll(`[${sa}]`).forEach(o=>o.remove());e.firstChild;)e.removeChild(e.firstChild);const n=Y();if(Ht){let o=null;try{o=Td()}catch{o=null}o!==ar&&(Ht.disconnect(),o&&Ht.observe(o),ar=o)}const r=Yo();for(const o of r)o.kind==="text"?kd(o,n):o.kind==="arrow"?fd(o,n):o.kind==="shape"?yd(o,n):o.kind==="freedraw"&&gd(o,n)}function Td(){const t=ot();if(!(t!=null&&t.selectors))return null;try{return ye(t.selectors)}catch{return null}}const k={host:null,shadow:null,orientationApplied:!1,cleanupDrag:null};function Jt(t,e,n){return Math.max(e,Math.min(n,t))}function pa(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector(".bar");if(!n)return;n.classList.toggle("vertical",t==="vertical");const r=e.querySelector('[data-region="orient-icon"]');r&&(r.innerHTML=Dd()),Cd()}function Cd(){const{host:t}=k;if(!t||t.style.transform!=="none")return;const e=t.getBoundingClientRect(),n=Math.max(0,window.innerWidth-e.width),r=Math.max(0,window.innerHeight-e.height),o=parseFloat(t.style.left),i=parseFloat(t.style.top);Number.isFinite(o)&&(t.style.left=`${Jt(o,0,n)}px`),Number.isFinite(i)&&(t.style.top=`${Jt(i,0,r)}px`)}async function Id(){try{return(await chrome.storage.local.get(Q.replayControlsOrientation))[Q.replayControlsOrientation]==="vertical"?"vertical":"horizontal"}catch{return"horizontal"}}async function Pd(t){try{await chrome.storage.local.set({[Q.replayControlsOrientation]:t})}catch(e){console.warn("[manuscript] save orientation failed",e)}}function Dd(){return'<svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M 5.5 1.5 L 3 4 L 5.5 6.5 M 3 4 L 12 4 L 12 13 M 9.5 10.5 L 12 13 L 14.5 10.5"/></svg>'}async function Od(){try{const e=(await chrome.storage.local.get(Q.replayControlsPosition))[Q.replayControlsPosition];return e&&typeof e=="object"&&typeof e.left=="number"&&typeof e.top=="number"?e:null}catch{return null}}async function Eo(t){try{await chrome.storage.local.set({[Q.replayControlsPosition]:t})}catch{}}function Rd(t,e){const n=t.getBoundingClientRect(),r=Math.max(0,Math.min(e.left,window.innerWidth-n.width)),o=Math.max(0,Math.min(e.top,window.innerHeight-n.height));t.style.left=`${r}px`,t.style.top=`${o}px`,t.style.bottom="auto",t.style.transform="none"}function Nd(){const{host:t,shadow:e}=k;if(!t||!e)return;const n=e.querySelector('[data-region="move-handle"]');if(!n)return;let r=!1,o=0,i=0,s=0,a=0;const c=d=>{if(!k.host)return;d.preventDefault(),d.stopPropagation(),r=!0,n.classList.add("dragging");const p=k.host.getBoundingClientRect();k.host.style.left=`${p.left}px`,k.host.style.top=`${p.top}px`,k.host.style.bottom="auto",k.host.style.transform="none",o=d.clientX,i=d.clientY,s=p.left,a=p.top,document.addEventListener("mousemove",l,!0),document.addEventListener("mouseup",u,!0)},l=d=>{if(!r||!k.host)return;const p=k.host.getBoundingClientRect(),h=d.clientX-o,g=d.clientY-i,v=Jt(s+h,0,window.innerWidth-p.width),x=Jt(a+g,0,window.innerHeight-p.height);k.host.style.left=`${v}px`,k.host.style.top=`${x}px`},u=()=>{r=!1,n.classList.remove("dragging"),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0);const d=k.host;if(d){const p=parseFloat(d.style.left||"0"),h=parseFloat(d.style.top||"0");Number.isFinite(p)&&Number.isFinite(h)&&Eo({left:p,top:h})}},f=()=>{if(k.host&&k.host.style.transform==="none"){const d=k.host.getBoundingClientRect(),p=Jt(d.left,0,window.innerWidth-d.width),h=Jt(d.top,0,window.innerHeight-d.height);k.host.style.left=`${p}px`,k.host.style.top=`${h}px`,Eo({left:p,top:h})}};n.addEventListener("mousedown",c),window.addEventListener("resize",f),k.cleanupDrag=()=>{n.removeEventListener("mousedown",c),window.removeEventListener("resize",f),document.removeEventListener("mousemove",l,!0),document.removeEventListener("mouseup",u,!0)}}function fa(){return`
    ${Pt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
      color: var(--c-text);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .modal {
      background: var(--c-surface);
      border-radius: var(--r-md);
      padding: 22px 24px 20px;
      max-width: 420px;
      font-size: var(--fs-body);
      line-height: var(--lh-body);
      box-shadow: var(--shadow-lg);
      border-top: 3px solid var(--c-error);
    }
    .modal-head {
      display: flex;
      align-items: flex-start;
      gap: 12px;
      margin-bottom: 12px;
    }
    .icon-circle {
      width: 28px;
      height: 28px;
      border-radius: 999px;
      background: color-mix(in oklab, var(--c-error) 14%, transparent);
      color: var(--c-error);
      display: grid;
      place-items: center;
      font-size: 16px;
      font-weight: 600;
      flex-shrink: 0;
    }
    h2 {
      margin: 0;
      font-size: 15px;
      font-weight: 600;
      color: var(--c-text);
    }
    p {
      margin: 4px 0 0;
      color: var(--c-text-mute);
      font-size: 13px;
      line-height: 1.5;
    }
    .actions {
      display: flex;
      gap: 8px;
      justify-content: flex-end;
      margin-top: 14px;
      flex-wrap: wrap;
    }
    button {
      font-family: inherit;
      font-size: 12px;
      font-weight: 500;
      padding: 8px 14px;
      border-radius: var(--r-sm);
      cursor: pointer;
    }
    .primary {
      background: var(--c-primary);
      color: var(--c-primary-fg);
      border: none;
    }
    .primary:hover { background: var(--c-primary-h); }
    .secondary {
      background: var(--c-surface);
      color: var(--c-text);
      border: 1px solid var(--c-border-strong);
    }
    .secondary:hover { border-color: var(--c-text-mute); }
    button:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .url {
      display: block;
      font-family: var(--ff-mono);
      font-size: 12px;
      background: var(--c-surface-2);
      padding: 8px 10px;
      border-radius: var(--r-sm);
      word-break: break-all;
      margin: 12px 0 0 40px;
      color: var(--c-text);
    }
  `}function ha(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;")}function Fd(t){return ha(t).replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function _d(t,e){const{shadow:n}=k;if(!n)return;const r=n.querySelector('[data-region="step-popup"]');r&&(r.innerHTML=t.map((o,i)=>{const s=o.name&&o.name.length>0?o.name:"Step Name";return`<li class="step-item${i===e?" active":""}" role="option" data-action="step-jump" data-index="${i}" aria-selected="${i===e}" title="${Fd(s)}">${i+1}. ${ha(s)}</li>`}).join(""))}function Hd(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');if(!e)return;e.hidden=!e.hidden;const n=t.querySelector('[data-region="counter"]');if(n==null||n.setAttribute("aria-expanded",String(!e.hidden)),!e.hidden){const r=e.querySelector(".step-item.active");r&&typeof r.scrollIntoView=="function"&&r.scrollIntoView({block:"nearest"})}}function sr(){const{shadow:t}=k;if(!t)return;const e=t.querySelector('[data-region="step-popup"]');e&&(e.hidden=!0);const n=t.querySelector('[data-region="counter"]');n==null||n.setAttribute("aria-expanded","false")}function ma(t){const{host:e,shadow:n}=k;if(!e||!n)return;const r=n.querySelector('[data-region="step-popup"]');!r||r.hidden||t.target instanceof Node&&e.contains(t.target)||sr()}let Ve=-1,Ke=!1;function zd(){Ve=-1,Ke=!1}function Bd(t,e,n){const{shadow:r}=k;if(!r)return;const o=r.querySelector('[data-region="progress"]');if(!o)return;if(e===null||e<=0){o.classList.add("hidden"),o.innerHTML="",Ve=-1,Ke=!1;return}o.classList.remove("hidden");const a=t!==Ve||Ke&&!n;Ve=t,Ke=n;let c=o.querySelector(".progress-fill");(!c||a)&&(c==null||c.remove(),c=document.createElement("div"),c.className="progress-fill",c.style.animationDuration=`${e}ms`,o.appendChild(c)),c.classList.toggle("paused",n)}function qd(){return`
    ${Pt()}
    :host {
      display: block;
      font-family: var(--ff-sans);
    }
    *, *::before, *::after { box-sizing: border-box; }

    .bar {
      position: relative;
      display: inline-flex;
      align-items: center;
      gap: 4px;
      padding: 8px 6px 8px 14px;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-pill);
      box-shadow: var(--shadow-md);
      opacity: 0.45;
      transition: opacity 0.15s;
    }

    /* Horizontal mode: progress strip floats above the pill so the user
       can see remaining time without it crowding the controls. Vertical
       mode keeps its side strip inside the pill (see .bar.vertical .progress). */
    .progress {
      position: absolute;
      left: 50%;
      right: auto;
      top: auto;
      bottom: calc(100% + 6px);
      width: calc(100% - 28px);
      height: 4px;
      transform: translateX(-50%);
      border: 1px solid rgb(255 255 255 / 0.6);
      border-radius: 2px;
      overflow: hidden;
      background: transparent;
      pointer-events: none;
    }
    .progress.hidden { display: none; }
    .progress-fill {
      height: 100%;
      width: 100%;
      background: #0a99ff;
      transform: scaleX(0);
      transform-origin: left center;
      animation-name: progress-grow-x;
      animation-timing-function: linear;
      animation-fill-mode: forwards;
    }
    .progress-fill.paused { animation-play-state: paused; }
    @keyframes progress-grow-x {
      from { transform: scaleX(0); }
      to   { transform: scaleX(1); }
    }
    .bar.vertical .progress {
      left: auto;
      right: 4px;
      top: 50%;
      bottom: auto;
      width: 4px;
      height: calc(90% - 26px);
      transform: translateY(-50%);
    }
    .bar.vertical .progress-fill {
      transform: scaleY(0);
      transform-origin: center top;
      animation-name: progress-grow-y;
    }
    @keyframes progress-grow-y {
      from { transform: scaleY(0); }
      to   { transform: scaleY(1); }
    }
    .bar:hover,
    .bar.paused,
    .bar:has([data-region="step-popup"]:not([hidden])) { opacity: 1; }

    .ctrl-tts.active { color: var(--c-primary); }

    .counter {
      font-family: var(--ff-mono);
      font-size: 11px;
      font-weight: 500;
      font-variant-numeric: tabular-nums;
      margin-right: 8px;
      opacity: 0.85;
      min-width: 36px;
      text-align: center;
      cursor: pointer;
      user-select: none;
      padding: 2px 4px;
      border-radius: var(--r-xs);
      white-space: nowrap;
      flex-shrink: 0;
    }
    .counter:hover { background: rgb(255 255 255 / 0.08); }
    [data-action="move-drag"] { cursor: grab; }
    [data-action="move-drag"].dragging { cursor: grabbing; }
    [data-action="move-drag"] svg { display: block; }

    .ctrl {
      background: transparent;
      border: none;
      color: inherit;
      font-family: inherit;
      font-size: 14px;
      line-height: 1;
      width: 24px;
      height: 24px;
      border-radius: 999px;
      cursor: pointer;
      display: inline-grid;
      place-items: center;
      padding: 0;
      transition: background 0.12s ease;
      flex-shrink: 0;
    }
    .ctrl:hover { background: rgb(255 255 255 / 0.15); }
    .ctrl:focus-visible {
      outline: 2px solid var(--c-focus);
      outline-offset: 2px;
    }
    .ctrl[disabled] { opacity: 0.4; cursor: not-allowed; }

    .divider {
      width: 1px;
      height: 16px;
      background: rgb(255 255 255 / 0.2);
      margin: 0 4px;
    }

    .ctrl-exit { opacity: 0.7; }
    .ctrl-exit:hover { opacity: 1; }

    [data-action="orient"] svg { display: block; }

    .step-popup {
      position: absolute;
      bottom: calc(100% + 6px);
      left: 0;
      margin: 0;
      padding: 6px 0;
      list-style: none;
      background: var(--c-text);
      color: var(--c-surface);
      border-radius: var(--r-md);
      box-shadow: var(--shadow-md);
      max-height: 180px;
      overflow-y: auto;
      min-width: 210px;
      max-width: 300px;
      font-family: var(--ff-sans);
      font-size: 13px;
      line-height: 1.3;
      z-index: 1;
    }
    .step-popup[hidden] { display: none; }
    .step-popup::-webkit-scrollbar { width: 8px; }
    .step-popup::-webkit-scrollbar-track {
      background: rgb(255 255 255 / 0.18);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb {
      background: rgb(255 255 255 / 0.55);
      border-radius: 999px;
    }
    .step-popup::-webkit-scrollbar-thumb:hover {
      background: rgb(255 255 255 / 0.75);
    }
    .step-popup li {
      padding: 6px 14px;
      cursor: pointer;
      opacity: 0.72;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      transition: opacity 0.12s ease, background 0.12s ease;
    }
    .step-popup li:hover { background: rgb(255 255 255 / 0.08); opacity: 1; }
    .step-popup li.active { opacity: 1; font-weight: 600; }

    .bar.vertical {
      flex-direction: column;
      align-items: center;
      padding: 14px 14px 8px 8px;
      gap: 4px;
    }
    .bar.vertical .counter {
      margin-right: 0;
      margin-bottom: 4px;
      min-width: 0;
      padding: 0 6px;
    }
    .bar.vertical .divider {
      width: 16px;
      height: 1px;
      margin: 4px 0;
    }
  `}function jd(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 a 2.5 2.5 0 0 1 0 4"/><path d="M 12.5 4 a 5 5 0 0 1 0 8"/></svg>`}function Wd(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 3 6 L 3 10 L 6 10 L 9 12.5 L 9 3.5 L 6 6 Z" fill="currentColor"/><path d="M 11 6 L 14 9 M 14 6 L 11 9"/></svg>`}function Ud(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-action="tts-toggle"]');if(!n)return;n.setAttribute("aria-pressed",String(t)),n.classList.toggle("active",t);const r=n.querySelector('[data-region="tts-icon"]');r&&(r.innerHTML=t?jd(14):Wd(14))}function In(){const t=document.createElement("div");t.setAttribute("data-manuscript","ui"),t.setAttribute("data-palette",ue);const e=t.attachShadow({mode:"open"});return{host:t,shadow:e}}function Xd(t){if(k.host)return;const{host:e,shadow:n}=In();k.host=e,k.shadow=n,e.style.cssText=["position: fixed","bottom: 32px","left: 50%","transform: translateX(-50%)",`z-index: ${H+6}`,"pointer-events: auto"].join("; "),n.innerHTML=`<style>${qd()}</style>${Yd()}`,n.addEventListener("click",r=>Gd(r,t)),document.body.appendChild(e),Nd(),document.addEventListener("mousedown",ma,!0),k.orientationApplied=!1,Id().then(r=>{k.orientationApplied||(k.orientationApplied=!0,pa(r))}),Od().then(r=>{k.host&&r&&k.host.style.transform!=="none"&&Rd(k.host,r)})}function Yd(){return`
    <div class="bar" role="toolbar" aria-label="${b("replay.counter-aria")}">
      <span class="counter" data-region="counter" aria-live="polite" role="button" aria-haspopup="listbox" aria-expanded="false" tabindex="0">1 / 1</span>
      <button class="ctrl" data-action="prev" aria-label="${b("replay.prev-aria")}">‹</button>
      <button class="ctrl" data-action="pause" aria-label="${b("replay.pause-aria")}"><span data-region="pause-icon">II</span></button>
      <button class="ctrl" data-action="next" aria-label="${b("replay.next-aria")}">›</button>
      <span class="divider" aria-hidden="true"></span>
      <button class="ctrl" data-action="prompter" aria-label="${b("replay.prompter-aria")}" title="${b("replay.prompter-title")}"><svg width="13" height="13" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg></button>
      <button class="ctrl ctrl-tts" data-action="tts-toggle" aria-pressed="false" aria-label="${b("replay.tts-aria")}" title="${b("replay.tts-title")}" data-region="tts-toggle"><span data-region="tts-icon"></span></button>
      <button class="ctrl" data-action="move-drag" data-region="move-handle" aria-label="${b("replay.move-aria")}" title="${b("replay.move-title")}"><svg width="12" height="12" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 8 2 L 8 14 M 2 8 L 14 8 M 6 4 L 8 2 L 10 4 M 6 12 L 8 14 L 10 12 M 4 6 L 2 8 L 4 10 M 12 6 L 14 8 L 12 10"/></svg></button>
      <button class="ctrl" data-action="orient" aria-label="${b("replay.orient-aria")}" data-region="orient-icon"></button>
      <button class="ctrl ctrl-exit" data-action="exit" aria-label="${b("replay.exit-aria")}">×</button>
      <div class="progress hidden" data-region="progress" aria-hidden="true"></div>
      <ul class="step-popup" data-region="step-popup" role="listbox" hidden></ul>
    </div>
  `}function Gd(t,e){var i;const n=t.target;if(!(n instanceof Element))return;if(n.closest('[data-region="counter"]')){Hd();return}const r=n.closest('[data-action="step-jump"]');if(r){const s=Number(r.getAttribute("data-index"));Number.isFinite(s)&&(sr(),e.onStepSelect(s));return}if(n.closest('[data-action="tts-toggle"]')){e.onToggleTts();return}const o=(i=n.closest("[data-action]"))==null?void 0:i.getAttribute("data-action");switch(o&&sr(),o){case"prev":e.onPrev();break;case"next":e.onNext();break;case"pause":e.onTogglePause();break;case"exit":e.onExit();break;case"prompter":e.onTogglePrompter();break;case"move-drag":break;case"orient":Vd();break}}function Vd(){const{shadow:t}=k;if(!t)return;const e=t.querySelector(".bar");if(!e)return;const n=e.classList.contains("vertical")?"horizontal":"vertical";k.orientationApplied=!0,pa(n),Pd(n)}function Kd(){var t,e;(t=k.cleanupDrag)==null||t.call(k),k.cleanupDrag=null,document.removeEventListener("mousedown",ma,!0),(e=k.host)==null||e.remove(),k.host=null,k.shadow=null,k.orientationApplied=!1,zd()}function Mo(t){const{shadow:e}=k;if(!e)return;const n=e.querySelector('[data-region="counter"]');n&&(n.textContent=`${t.currentIndex+1} / ${t.total}`);const r=e.querySelector(".bar");r==null||r.classList.toggle("paused",t.paused);const o=e.querySelector('[data-region="pause-icon"]');o&&(o.textContent=t.paused?"▶":"II");const i=e.querySelector('[data-action="prev"]');i&&i.toggleAttribute("disabled",t.currentIndex<=0);const s=e.querySelector('[data-action="next"]');s&&(s.toggleAttribute("disabled",!1),s.setAttribute("aria-label",t.currentIndex>=t.total-1?b("replay.finish-aria"):b("replay.next-aria"))),Bd(t.currentIndex,t.timerDurationMs??null,t.paused),_d(t.steps??[],t.currentIndex),Ud(t.ttsEnabled===!0)}let Mt=null;function Zd(t){Ce();const{host:e,shadow:n}=In();Mt=e,Mt.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${H+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>${fa()}</style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="nf-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">!</div>
        <div>
          <h2 id="nf-title">${b("replay.notfound.title")}</h2>
          <p>${b("replay.notfound.body")}</p>
        </div>
      </div>
      <div class="actions">
        <button class="secondary" data-action="stop">${b("replay.notfound.stop")}</button>
        <button class="primary" data-action="skip" autofocus>${b("replay.notfound.skip")} →</button>
      </div>
    </div>
  `,n.addEventListener("click",o=>{var a;const i=o.target;if(!(i instanceof HTMLElement))return;const s=(a=i.closest("[data-action]"))==null?void 0:a.getAttribute("data-action");s==="skip"?t.onSkip():s==="stop"&&t.onStop()});const r=o=>{o.key==="Enter"?(o.preventDefault(),t.onSkip()):o.key==="Escape"&&(o.preventDefault(),t.onStop())};document.addEventListener("keydown",r,!0),Mt.__cleanup=()=>{document.removeEventListener("keydown",r,!0)},document.body.appendChild(Mt)}function Ce(){if(!Mt)return;const t=Mt.__cleanup;t==null||t(),Mt.remove(),Mt=null}let $t=null;function Qd(t){dn();const{host:e,shadow:n}=In();$t=e,$t.style.cssText=["position: fixed","inset: 0","background: rgba(0, 0, 0, 0.40)",`z-index: ${H+7}`,"display: flex","align-items: center","justify-content: center","pointer-events: auto"].join("; "),n.innerHTML=`
    <style>
      ${fa()}
      .modal { border-top-color: var(--c-info); max-width: 480px; }
      .icon-circle { background: color-mix(in oklab, var(--c-info) 14%, transparent); color: var(--c-info); }
    </style>
    <div class="modal" role="alertdialog" aria-modal="true" aria-labelledby="um-title">
      <div class="modal-head">
        <div class="icon-circle" aria-hidden="true">↗</div>
        <div>
          <h2 id="um-title">${b("replay.url-mismatch.title")}</h2>
          <p>${b("replay.url-mismatch.body")}</p>
        </div>
      </div>
      <span class="url" data-region="url"></span>
      <div class="actions">
        <button class="secondary" data-action="cancel">${b("replay.url-mismatch.cancel")}</button>
        <button class="secondary" data-action="force">${b("replay.url-mismatch.force")}</button>
        <button class="primary" data-action="navigate" autofocus>${b("replay.url-mismatch.navigate")} →</button>
      </div>
    </div>
  `;const r=n.querySelector('[data-region="url"]');r&&(r.textContent=t.savedUrl),n.addEventListener("click",i=>{var c;const s=i.target;if(!(s instanceof HTMLElement))return;const a=(c=s.closest("[data-action]"))==null?void 0:c.getAttribute("data-action");a==="navigate"?t.onNavigate():a==="force"?t.onForce():a==="cancel"&&t.onCancel()});const o=i=>{i.key==="Escape"?(i.preventDefault(),t.onCancel()):i.key==="Enter"&&(i.preventDefault(),t.onNavigate())};document.addEventListener("keydown",o,!0),$t.__cleanup=()=>{document.removeEventListener("keydown",o,!0)},document.body.appendChild($t)}function dn(){if(!$t)return;const t=$t.__cleanup;t==null||t(),$t.remove(),$t=null}let Nt=null;function Jd(t){Ie();const e=t.getBoundingClientRect(),n=tp(t),r=e.left+n.x,o=e.top+n.y,i=e.bottom+n.y,s=36,a=8,c=o-a-s<8,l=c?Math.min(window.innerHeight-8-s,i+a):Math.max(8,o-a-s),u=Math.max(8,Math.min(r,window.innerWidth-200)),f=c?"up":"down",{host:d,shadow:p}=In();Nt=d,Nt.style.cssText=["position: fixed",`top: ${l}px`,`left: ${u}px`,`z-index: ${H+6}`,"pointer-events: none"].join("; "),p.innerHTML=`
    <style>
      ${Pt()}
      :host { display: block; font-family: var(--ff-sans); }
      *, *::before, *::after { box-sizing: border-box; }
      .bubble {
        position: relative;
        font-size: 11px;
        font-weight: 500;
        color: var(--c-surface);
        background: var(--c-text);
        padding: 6px 10px;
        border-radius: var(--r-sm);
        box-shadow: var(--shadow-md);
        white-space: nowrap;
        display: inline-flex;
        align-items: center;
        gap: 6px;
      }
      .eyebrow {
        opacity: 0.6;
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.08em;
        text-transform: uppercase;
      }
      .tip {
        position: absolute;
        width: 8px;
        height: 8px;
        background: var(--c-text);
        transform: translateX(-50%) rotate(45deg);
        left: 50%;
      }
      .tip.down { bottom: -3px; }
      .tip.up { top: -3px; }
    </style>
    <div class="bubble">
      <span class="eyebrow">${b("prompter.action-step")}</span>
      <span>${b("replay.action-prompt")}</span>
      <span class="tip ${f}" aria-hidden="true"></span>
    </div>
  `,document.body.appendChild(Nt)}function Ie(){Nt==null||Nt.remove(),Nt=null}function tp(t){var e;try{const n=(e=t.ownerDocument)==null?void 0:e.defaultView;if(!n||n===window)return{x:0,y:0};const r=n.frameElement;if(!r)return{x:0,y:0};const o=r.getBoundingClientRect();return{x:o.left,y:o.top}}catch{return{x:0,y:0}}}let oe=null;function ep(t){oe||(oe=e=>{if($.state)switch(e.key){case"ArrowRight":e.preventDefault(),t.onNext();break;case"ArrowLeft":e.preventDefault(),t.onPrev();break;case" ":case"Spacebar":e.preventDefault(),t.onTogglePause();break;case"Escape":e.preventDefault(),t.onExit();break}},document.addEventListener("keydown",oe,!0))}function np(){oe&&(document.removeEventListener("keydown",oe,!0),oe=null)}function ga(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}function rp(t){var n;const e=(n=t.steps[0])==null?void 0:n.pickedAtUrl;return e&&e.length>0?e:t.url}async function op(t,e){var r,o,i;const n=(r=t.steps[e])==null?void 0:r.pickedAtUrl;if(!n||ga(n,location.href)||((o=$.state)==null?void 0:o.standalone)===!0)return!1;try{await dr({scenarioId:t.id,stepIndex:e,startedAt:Date.now(),paused:((i=$.state)==null?void 0:i.paused)??!1})}catch(s){console.warn("[manuscript] persist activeReplay before nav failed",s)}return location.href=n,!0}function ip(t){return new Promise(e=>{Qd({savedUrl:t,onNavigate:()=>e("navigate"),onForce:()=>{dn(),e("force")},onCancel:()=>{dn(),e("cancel")}})})}async function ap(t){try{const e=await No();return(e==null?void 0:e.scenarioId)===t}catch{return!1}}async function Cr(){const t=P();if(!(!t||!$.state)&&$.state.standalone!==!0)try{await dr({scenarioId:t.id,stepIndex:W(),startedAt:Date.now(),paused:$.state.paused})}catch(e){console.warn("[manuscript] persist activeReplay failed",e)}}async function ba(t,e,n){const r=P();if(!r)return{ok:!1};if(n&&await ap(r.id))return{ok:!0};const o=rp(r);if(!o||ga(o,location.href))return{ok:!0};const i=await ip(o);return i==="cancel"?{ok:!1}:i==="navigate"?(await dr({scenarioId:t,stepIndex:e,startedAt:Date.now()}),location.href=o,{ok:!1}):{ok:!0}}class va extends Error{constructor(e){super("element-not-found"),this.chain=e,this.name="ElementNotFoundError"}}function sp(t,e=qa){const n=ye(t);return n?Promise.resolve(n):new Promise((r,o)=>{let i=!1;const a=(ni(t.framePath)??document).body??document.body,c=new MutationObserver(()=>{if(i)return;const u=ye(t);u&&(i=!0,c.disconnect(),clearTimeout(l),r(u))}),l=setTimeout(()=>{i||(i=!0,c.disconnect(),o(new va(t)))},e);c.observe(a,{childList:!0,subtree:!0,attributes:!0,attributeFilter:["data-testid","data-test","id","aria-label"]})})}function pe(){const{state:t}=$;if(!t)return;const e=P();if(!e)return;const n=e.steps[W()],r=n&&!n.waitForNavigation&&n.autoAdvanceMs&&n.autoAdvanceMs>0?n.autoAdvanceMs:null;if(Fo().then(o=>{Mo({currentIndex:W(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(i=>({name:i.name})),ttsEnabled:o})}),Mo({currentIndex:W(),total:e.steps.length,paused:t.paused,timerDurationMs:r,steps:e.steps.map(o=>({name:o.name}))}),Cn()){const o=W(),i=e.steps[o],s=e.steps[o+1];oa({scenarioId:e.id,scenarioName:e.name,currentIndex:o,total:e.steps.length,paused:t.paused,steps:e.steps.map(a=>({name:a.name})),current:i?{name:i.name,description:i.description,autoAdvanceMs:i.autoAdvanceMs??null,waitForNavigation:i.waitForNavigation,thumbnailDataUrl:i.thumbnailDataUrl??null}:null,next:s?{name:s.name,description:s.description,autoAdvanceMs:s.autoAdvanceMs??null,waitForNavigation:s.waitForNavigation,thumbnailDataUrl:s.thumbnailDataUrl??null}:null})}}async function cp(){if(Cn()){await ra(),pn(!1);return}pn(!0),await na(),pe()}function lp(){pn(!1)}function pn(t){var e;for(const n of document.querySelectorAll('[data-manuscript="ui"]'))if((e=n.shadowRoot)!=null&&e.querySelector(".bar")){n.style.display=t?"none":"";break}}async function Pn(t){var i;const{state:e}=$;if(!e)return;const n=P();if(!n)return;const r=n.steps[W()];if(pe(),!r)return;if(Ce(),Ie(),Ka()&&!e.paused&&Za(r.description),!r.selectors){le(),r.waitForNavigation||$o(t);return}const o=new AbortController;e.pendingWait=o;try{const s=await sp(r.selectors);if(o.signal.aborted)return;s.scrollIntoView({block:"center"}),ia(s),r.waitForNavigation?(Jd(s),up(s,o,t.onNext)):$o(t)}catch(s){if(o.signal.aborted)return;if(s instanceof va){le(),Zd({onSkip:t.onNext,onStop:t.onExit});return}console.error("[manuscript] replay error",s)}finally{((i=$.state)==null?void 0:i.pendingWait)===o&&($.state.pendingWait=null)}}function up(t,e,n){if(!$.state)return;const r=()=>{t.removeEventListener("click",o,!0),e.signal.removeEventListener("abort",r)},o=()=>{r(),!(e.signal.aborted||!$.state)&&n()};t.addEventListener("click",o,!0),e.signal.addEventListener("abort",r)}function $o(t){var s;const{state:e}=$;if(!e||e.paused)return;const n=P();if(!n)return;const r=W(),o=n.steps[r];if(!o)return;e.autoAdvanceTimer!==null&&(window.clearTimeout(e.autoAdvanceTimer),e.autoAdvanceTimer=null),(s=e.autoAdvanceAbort)==null||s.abort();const i=new AbortController;e.autoAdvanceAbort=i,(async()=>{const a=[],c=Qa();c&&a.push(c),o.autoAdvanceMs&&o.autoAdvanceMs>0&&a.push(new Promise(l=>{const u=window.setTimeout(()=>{$.state&&$.state.autoAdvanceTimer===u&&($.state.autoAdvanceTimer=null),l()},o.autoAdvanceMs);$.state&&($.state.autoAdvanceTimer=u),i.signal.addEventListener("abort",()=>{window.clearTimeout(u),l()})})),a.length!==0&&(await Promise.race([Promise.all(a).then(()=>{}),new Promise(l=>{i.signal.aborted?l():i.signal.addEventListener("abort",()=>l(),{once:!0})})]),!i.signal.aborted&&(!$.state||$.state.paused||W()===r&&t.onNext()))})()}function Dn(){var e,n;const{state:t}=$;t&&(t.autoAdvanceTimer!==null&&(window.clearTimeout(t.autoAdvanceTimer),t.autoAdvanceTimer=null),(e=t.autoAdvanceAbort)==null||e.abort(),t.autoAdvanceAbort=null,(n=t.pendingWait)==null||n.abort(),t.pendingWait=null,_o())}const On={onNext:()=>void ke(),onExit:()=>void Se()};async function Pe(t=0,e={}){if($.state)return;const n=P();if(!n||n.steps.length===0||e.standalone!==!0&&!(await ba(n.id,t,!0)).ok)return;$.state={originalStepIndex:W(),paused:e.paused??!1,autoAdvanceTimer:null,pendingWait:null,autoAdvanceAbort:null,standalone:e.standalone===!0},D("replay"),Xd({onPrev:fn,onNext:ke,onTogglePause:hn,onExit:Se,onStepSelect:o=>void Pr(o),onTogglePrompter:()=>void cp(),onToggleTts:()=>void dp()}),Cn()&&pn(!0),ep({onNext:()=>void ke(),onPrev:()=>void fn(),onTogglePause:hn,onExit:()=>void Se()}),$.unsubscribeStep=de(pe);const r=Math.min(Math.max(0,t),n.steps.length-1);Ut(r),await Cr(),await Pn(On)}async function Ir(t){if(!$.state)return;const e=P();e&&(t<0||t>=e.steps.length||(Dn(),Ce(),Ie(),!await op(e,t)&&(Ut(t),await Cr(),await Pn(On))))}async function Pr(t){t!==W()&&await Ir(t)}async function ke(){const{state:t}=$;if(!t)return;const e=P();if(!e)return;const n=W();if(n>=e.steps.length-1){Dn(),Ce(),Ie(),t.paused=!0,pe();return}await Ir(n+1)}async function fn(){await Ir(W()-1)}async function dp(){const t=!await Fo();await Ja(t),t||_o(),pe()}function hn(){const{state:t}=$;if(!t)return;const e=P();if(e&&t.paused&&W()>=e.steps.length-1){pp();return}t.paused=!t.paused,t.paused?Dn():Pn(On),pe()}async function pp(){if(!$.state)return;const t=P();!t||!(await ba(t.id,0,!1)).ok||$.state&&($.state.paused=!1,Ut(0),await Cr(),await Pn(On))}async function Se(){var r;const{state:t}=$;if(!t)return;Dn(),Ce(),Ie(),dn(),le(),Kd(),ra(),np(),(r=$.unsubscribeStep)==null||r.call($),$.unsubscribeStep=null;const e=t.originalStepIndex,n=t.standalone===!0;$.state=null,Ut(e),D("idle"),await Ua(),n&&(da(),Uo())}const fp=[{kind:"rectangle",label:"Rectangle"},{kind:"ellipse",label:"Ellipse"},{kind:"triangle",label:"Triangle"},{kind:"diamond",label:"Diamond"},{kind:"star",label:"Star"},{kind:"callout",label:"Callout"},{kind:"line",label:"Line"},{kind:"block-arrow",label:"Arrow"}],yt=28,je=4,hp="http://www.w3.org/2000/svg";let q=null,Wt=null,be=null;function mp(t,e){Rn(),be=e,q=document.createElement("div"),q.setAttribute("data-manuscript","ui"),q.setAttribute("data-palette",ue),q.style.cssText=["position: fixed",`z-index: ${H+5}`,"pointer-events: auto"].join("; "),Wt=q.attachShadow({mode:"open"}),Wt.innerHTML=gp(),vp(),document.body.appendChild(q),Lo(t),bp(),requestAnimationFrame(()=>{q&&Lo(t)}),document.addEventListener("mousedown",ya,!0),document.addEventListener("keydown",xa,!0)}function Rn(){q&&(document.removeEventListener("mousedown",ya,!0),document.removeEventListener("keydown",xa,!0),q.remove(),q=null,Wt=null,be=null)}function gp(){return`
    <style>
      ${Pt()}
      :host { display: block; font-family: var(--ff-sans); color: var(--c-text); }
      *, *::before, *::after { box-sizing: border-box; }
      .menu {
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        padding: 8px;
        box-shadow: var(--shadow-card);
        display: grid;
        grid-template-columns: repeat(4, ${yt+je*2}px);
        gap: 4px;
      }
      .menu-btn {
        width: ${yt+je*2}px;
        height: ${yt+je*2}px;
        padding: ${je}px;
        border: 1px solid transparent;
        border-radius: var(--r-sm);
        background: transparent;
        color: var(--c-text);
        cursor: pointer;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        transition: background 0.12s, border-color 0.12s, color 0.12s;
      }
      .menu-btn:hover {
        background: var(--c-tint);
        border-color: var(--c-primary);
      }
      .menu-btn:active { background: var(--c-surface-2); }
      .menu-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 1px;
      }
      .menu-btn svg { display: block; color: inherit; }
    </style>
    <div class="menu" role="menu" aria-label="Shape picker" data-region="grid"></div>
  `}function bp(){if(!Wt)return;const t=Wt.querySelector('[data-region="grid"]');if(t){t.innerHTML="";for(const{kind:e,label:n}of fp){const r=document.createElement("button");r.type="button",r.className="menu-btn",r.setAttribute("data-kind",e),r.setAttribute("title",n),r.setAttribute("aria-label",n);const o=document.createElementNS(hp,"svg");o.setAttribute("width",String(yt)),o.setAttribute("height",String(yt)),o.setAttribute("viewBox",`0 0 ${yt} ${yt}`);const i=$r(e,{x:3,y:3,width:yt-6,height:yt-6,fill:"transparent",stroke:"oklch(0.18 0.015 250)",strokeWidth:1.5});i&&o.appendChild(i),r.appendChild(o),t.appendChild(r)}}}function vp(){Wt&&Wt.addEventListener("click",t=>{const e=t.target;if(!(e instanceof Element))return;const n=e.closest("[data-kind]");if(!n)return;const r=n.getAttribute("data-kind");r&&(be==null||be(r),Rn())})}function Lo(t){if(!q)return;const e=t.getBoundingClientRect();q.style.top="0px",q.style.left="0px";const n=q.getBoundingClientRect();let r=e.bottom+6;r+n.height>window.innerHeight-8&&(r=e.top-n.height-6);let o=e.left;o+n.width>window.innerWidth-8&&(o=window.innerWidth-n.width-8),q.style.top=`${Math.max(8,r)}px`,q.style.left=`${Math.max(8,o)}px`}function ya(t){if(!q)return;const e=t.target;e instanceof Node&&q.contains(e)||Rn()}function xa(t){t.key==="Escape"&&(t.preventDefault(),Rn())}const yp=320,ie=32,xp=.8,mn=200,S={host:null,shadow:null,unsubscribeMode:null,unsubscribeScenario:null,toastTimer:null,dragFromIndex:null};function gn(t){return t.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;").replace(/'/g,"&#39;")}function nt(t){return gn(t)}function Ae(t,e=!1){const{shadow:n}=S;if(!n)return;const r=n.querySelector('[data-region="toast"]');r&&(r.textContent=t,r.classList.add("visible"),r.classList.toggle("error",e),S.toastTimer!==null&&window.clearTimeout(S.toastTimer),S.toastTimer=window.setTimeout(()=>{r.classList.remove("visible"),S.toastTimer=null},2500))}function bn(t,e,n){return Math.max(e,Math.min(n,t))}function wp(){const t=P();if(t)try{const e=Xa(t),n=new Blob([e],{type:"application/json"}),r=URL.createObjectURL(n),o=document.createElement("a");o.href=r,o.download=`${Ap(t.name)}-${Ep(t.updatedAt)}.json`,document.body.appendChild(o),o.click(),o.remove(),setTimeout(()=>URL.revokeObjectURL(r),1e3),Ae(b("toast.export-success"))}catch(e){console.error("[manuscript] export failed",e),Ae(b("toast.export-failed"),!0)}}async function kp(){const t=P();if(t){if(t.steps.length===0){Ae(b("toast.no-steps"),!0);return}bi(),await Pe(0,{paused:!0})}}function Sp(){const t=document.createElement("input");t.type="file",t.accept="application/json,.json",t.style.display="none",document.body.appendChild(t),t.addEventListener("change",async()=>{var n;const e=(n=t.files)==null?void 0:n[0];if(t.remove(),!!e)try{const r=await e.text(),o=Ya(r);Wo(o),Ae(b("toast.import-success"))}catch(r){console.error("[manuscript] import failed",r),Ae(b("toast.import-failed"),!0)}}),t.click()}function Ap(t){const e=t.replace(/[^\p{L}\p{N}\-_]/gu,"_");return e.length>0?e:"scenario"}function Ep(t){const e=new Date(t),n=r=>String(r).padStart(2,"0");return`${e.getFullYear()}${n(e.getMonth()+1)}${n(e.getDate())}-${n(e.getHours())}${n(e.getMinutes())}`}function Nn(t){const e=P(),n=e==null?void 0:e.steps[t];return n!=null&&n.pickedAtUrl&&!Mp(n.pickedAtUrl,location.href)?(wa(n.pickedAtUrl,t),!0):!1}function ve(){const t=P();if(!t)return;const e=W(),n=t.steps[e],r=t.steps[e+1];oa({scenarioId:t.id,scenarioName:t.name,currentIndex:e,total:t.steps.length,paused:!0,steps:t.steps.map(o=>({name:o.name})),current:n?{name:n.name,description:n.description,autoAdvanceMs:n.autoAdvanceMs??null,waitForNavigation:n.waitForNavigation,thumbnailDataUrl:n.thumbnailDataUrl??null}:null,next:r?{name:r.name,description:r.description,autoAdvanceMs:r.autoAdvanceMs??null,waitForNavigation:r.waitForNavigation,thumbnailDataUrl:r.thumbnailDataUrl??null}:null})}function Mp(t,e){try{const n=new URL(t),r=new URL(e);return n.origin===r.origin&&n.pathname===r.pathname}catch{return!1}}async function wa(t,e){const n=P();if(n){try{await chrome.runtime.sendMessage({type:"panel.markPending",scenarioId:n.id,stepIndex:e})}catch(r){console.warn("[manuscript] markPending failed",r)}location.href=t}}let vn=!1,ka=0,Sa=0,cr=0,lr=0;function $p(){const{shadow:t}=S;if(!t)return;const e=t.querySelector(".header");e&&e.addEventListener("mousedown",n=>{const r=n.target;if(r instanceof HTMLElement&&(r.closest('[data-action="close"]')||r.closest('[data-region="title-edit"]')))return;const{host:o}=S;if(!o)return;vn=!0,ka=n.clientX,Sa=n.clientY;const i=o.getBoundingClientRect();cr=i.left,lr=i.top,o.style.left=`${cr}px`,o.style.top=`${lr}px`,o.style.right="auto",document.addEventListener("mousemove",Aa,!0),document.addEventListener("mouseup",Ea,!0),n.preventDefault()})}function Aa(t){const{host:e}=S;if(!vn||!e)return;const n=t.clientX-ka,r=t.clientY-Sa,o=e.offsetWidth,i=e.offsetHeight,s=bn(cr+n,0,window.innerWidth-o),a=bn(lr+r,0,window.innerHeight-i);e.style.left=`${s}px`,e.style.top=`${a}px`}function Ea(){vn&&(vn=!1,document.removeEventListener("mousemove",Aa,!0),document.removeEventListener("mouseup",Ea,!0))}let yn=!1,Ma=0,$a=0;function Lp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="resize"]');e&&e.addEventListener("mousedown",n=>{const{host:r}=S;r&&(yn=!0,Ma=n.clientY,$a=r.getBoundingClientRect().height,document.addEventListener("mousemove",La,!0),document.addEventListener("mouseup",Ta,!0),n.preventDefault(),n.stopPropagation())})}function La(t){const{host:e}=S;if(!yn||!e)return;const n=t.clientY-Ma,r=e.getBoundingClientRect(),o=window.innerHeight-r.top-ie,i=bn($a+n,mn,o);e.style.height=`${i}px`,e.style.maxHeight=`${i}px`}function Ta(){yn&&(yn=!1,document.removeEventListener("mousemove",La,!0),document.removeEventListener("mouseup",Ta,!0))}function Tp(t){const e=window.innerHeight-ie*2;return bn(t,mn,Math.max(mn,e))}function Ca(){const{host:t}=S;if(!t)return;const e=t.getBoundingClientRect(),n=window.innerHeight-ie;if(e.bottom>n){const o=Math.max(mn,n-e.top);t.style.height=`${o}px`,t.style.maxHeight=`${o}px`}const r=t.getBoundingClientRect();if(t.style.left){const o=parseFloat(t.style.left),i=window.innerWidth-r.width;o>i&&(t.style.left=`${Math.max(0,i)}px`)}if(t.style.top){const o=parseFloat(t.style.top),i=window.innerHeight-r.height;o>i&&(t.style.top=`${Math.max(0,i)}px`)}}function Dr(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="settings-popup"]'))??null}function Ia(){var t;return((t=S.shadow)==null?void 0:t.querySelector('[data-region="voice-select"]'))??null}function Cp(){const t=Dr();t&&(t.hidden?(Ip(),t.hidden=!1):t.hidden=!0)}function Pa(){const t=Dr();t&&(t.hidden=!0)}async function Ip(){const t=Ia();if(!t)return;await es();const e=ns(),n=await rs(),r=i=>i.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/"/g,"&quot;"),o=[`<option value=""${n===null?" selected":""}>Auto (Google preferred)</option>`];for(const i of e){const s=i.name===n?" selected":"";o.push(`<option value="${r(i.name)}"${s}>${r(i.name)} (${r(i.lang)})</option>`)}t.innerHTML=o.join("")}function Pp(){var n;const t=Ia();t&&t.addEventListener("change",()=>{const r=t.value;ts(r.length>0?r:null)});const e=(n=S.shadow)==null?void 0:n.querySelector('[data-region="settings-close"]');e==null||e.addEventListener("click",()=>Pa())}function Dp(t){var o;const e=Dr();if(!e||e.hidden)return;const n=t.composedPath();if(n.includes(e))return;const r=(o=S.shadow)==null?void 0:o.querySelector('[data-region="settings-toggle"]');r&&n.includes(r)||Pa()}function zt(t){const e=t===W();Ut(t),e&&Da()}function Da(){const t=ot();if(!(t!=null&&t.selectors)){le();return}const e=ye(t.selectors);e?(e.scrollIntoView({behavior:"smooth",block:"center",inline:"center"}),ia(e)):le()}function To(t,e){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="${e}" stroke-linecap="round" style="display:block"><path d="M 8 4 L 8 12"/><path d="M 4 8 L 12 8"/></svg>`}function Or(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><circle cx="8" cy="8" r="6"/><path d="M8 4.5 L8 8 L10.4 9.4"/></svg>`}function Op(t=12){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"><path d="M2.5 4 L13.5 4"/><path d="M6 4 L6 2.5 L10 2.5 L10 4"/><path d="M4 4 L4.6 13.5 A 1 1 0 0 0 5.6 14.5 L10.4 14.5 A 1 1 0 0 0 11.4 13.5 L12 4"/><path d="M6.6 6.8 L6.6 12"/><path d="M9.4 6.8 L9.4 12"/></svg>`}function Rp(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="currentColor"><rect x="4" y="3" width="2.6" height="10" rx="0.6"/><rect x="9.4" y="3" width="2.6" height="10" rx="0.6"/></svg>`}function Np(t=18){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>`}function Fp(t=10){return`<svg width="${t}" height="${t}" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="display:block"><path d="M 4 12 L 12 4 M 6 4 L 12 4 L 12 10"/></svg>`}function _p(t=14){return`<svg width="${t}" height="${t}" viewBox="0 0 24 24" fill="currentColor" style="display:block"><path fill-rule="evenodd" d="M10.44 4.15L9.85 1.21L14.15 1.21L13.56 4.15A8 8 0 0 1 16.44 5.35L18.11 2.85L21.15 5.89L18.65 7.56A8 8 0 0 1 19.85 10.44L22.79 9.85L22.79 14.15L19.85 13.56A8 8 0 0 1 18.65 16.44L21.15 18.11L18.11 21.15L16.44 18.65A8 8 0 0 1 13.56 19.85L14.15 22.79L9.85 22.79L10.44 19.85A8 8 0 0 1 7.56 18.65L5.89 21.15L2.85 18.11L5.35 16.44A8 8 0 0 1 4.15 13.56L1.21 14.15L1.21 9.85L4.15 10.44A8 8 0 0 1 5.35 7.56L2.85 5.89L5.89 2.85L7.56 5.35A8 8 0 0 1 10.44 4.15ZM9.5 12A2.5 2.5 0 1 0 14.5 12A2.5 2.5 0 1 0 9.5 12Z"/></svg>`}function Hp(t){var c;if(t.classList.contains("editing")||t.classList.contains("disabled"))return;const e=((c=t.closest("[data-step-id]"))==null?void 0:c.getAttribute("data-step-id"))??"",n=P(),r=n==null?void 0:n.steps.find(l=>l.id===e);if(!r)return;const o=t.closest("[data-step-card]");if(o){const l=Number(o.getAttribute("data-step-card"));zt(l)}const i=r.autoAdvanceMs!==null&&r.autoAdvanceMs>0?Math.round(r.autoAdvanceMs/1e3):5;t.classList.add("editing"),t.innerHTML=`
    <input type="number" min="0" max="999" value="${i}" aria-label="Auto-advance seconds" />
    ${Or(10)}
  `;const s=t.querySelector("input");if(!s)return;s.focus(),s.select();const a=l=>{if(t.classList.remove("editing"),l){Co(t,i);return}const u=s.value.trim();let f=5;if(u===""||u==="0")te(r.id,{autoAdvanceMs:null});else{const d=Number(u);Number.isFinite(d)&&d>0?(te(r.id,{autoAdvanceMs:Math.round(d*1e3)}),f=d):te(r.id,{autoAdvanceMs:null})}Co(t,f)};s.addEventListener("blur",()=>a(!1)),s.addEventListener("keydown",l=>{l.key==="Enter"?(l.preventDefault(),s.blur()):l.key==="Escape"&&(l.preventDefault(),a(!0))}),s.addEventListener("mousedown",l=>l.stopPropagation())}function Co(t,e){t.innerHTML=`
    <span class="step-timer-num">${e}</span>
    ${Or(10)}
  `}function zp(t,e){const{shadow:n,host:r}=S;if(!n||!r)return;$p(),Lp(),jp(),Pp(),document.addEventListener("mousedown",Dp,!0);const o=i=>i.stopPropagation();r.addEventListener("keydown",o),r.addEventListener("keypress",o),r.addEventListener("keyup",o),n.addEventListener("click",i=>Bp(i,t,e))}function Bp(t,e,n){const r=t.target;if(!(r instanceof HTMLElement)&&!(r instanceof SVGElement))return;const o=r;if(o.closest('[data-action="close"]'))return e();if(o.closest('[data-action="replay"]'))return void kp();if(o.closest('[data-action="prompter"]')){n(!0),na().then(()=>{ve()});return}if(o.closest('[data-action="export"]'))return wp();if(o.closest('[data-action="import"]'))return Sp();if(o.closest('[data-action="settings-toggle"]'))return Cp();const i=o.closest('[data-action="tool-set"]');if(i instanceof HTMLElement){t.stopPropagation();const a=i.getAttribute("data-tool");if(a==="shape"){mp(i,c=>{Lu(c),D("shape")});return}D(bt()===a?"idle":a);return}if(qp(t,o))return;const s=o.closest("[data-step-card]");if(s&&!o.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){const a=Number(s.getAttribute("data-step-card"));if(Nn(a))return;zt(a)}}function qp(t,e){var c;const n=e.closest('[data-action="step-insert"]');if(n){t.stopPropagation();const l=Number(n.getAttribute("data-insert-index"));return jr({insertIndex:l}),!0}if(e.closest('[data-action="step-add"]'))return jr(),!0;const r=e.closest('[data-action="step-wand"]');if(r){t.stopPropagation();const l=Number(r.getAttribute("data-step-index"));return Nn(l)||(zt(l),D(bt()==="picker"?"idle":"picker")),!0}const o=e.closest('[data-action="step-delete"]');if(o)return t.stopPropagation(),Cs(Number(o.getAttribute("data-step-index"))),!0;const i=e.closest('[data-action="step-link"]');if(i){t.stopPropagation();const l=i.getAttribute("data-url")??"",u=i.closest("[data-step-card]"),f=u?Number(u.getAttribute("data-step-card")):0;return l&&wa(l,Number.isFinite(f)?f:0),!0}const s=e.closest('[data-action="step-action-toggle"]');if(s instanceof HTMLElement){t.stopPropagation();const l=Number(s.getAttribute("data-step-index")),u=(c=P())==null?void 0:c.steps[l];return u&&(zt(l),te(u.id,{waitForNavigation:!u.waitForNavigation})),!0}const a=e.closest('[data-action="step-timer"]');return a instanceof HTMLElement?(t.stopPropagation(),a.classList.contains("disabled")||Hp(a),!0):!1}function jp(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="title-edit"]');e&&(e.addEventListener("input",()=>ur(e)),e.addEventListener("keydown",n=>{if(n.key==="Enter"&&(n.preventDefault(),e.blur()),n.key==="Escape"){n.preventDefault();const r=P();r&&(e.textContent=r.name),ur(e),e.blur()}}),e.addEventListener("blur",()=>{Ls(e.textContent??"")}))}function ur(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}const Wp='[data-manuscript="ui"][data-region="permission-banner"]';function Oa(){return document.querySelector(Wp)}function Up(t){const e=Oa();if(e){Na(e,t);return}Xp(t)}function Ra(){const t=Oa();t&&t.remove()}function Na(t,e){var r;const n=(r=t.shadowRoot)==null?void 0:r.querySelector('[data-region="message"]');n&&(n.textContent=e)}function Xp(t){var r;const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-region","permission-banner"),e.setAttribute("data-palette",ue),e.style.cssText=["position: fixed","top: 24px","left: 50%","transform: translateX(-50%)",`z-index: ${H+5}`,"pointer-events: none"].join("; ");const n=e.attachShadow({mode:"open"});n.innerHTML=Yp(),Na(e,t),(r=n.querySelector('[data-action="dismiss"]'))==null||r.addEventListener("click",()=>Ra()),document.body.appendChild(e)}function Yp(){return`
    <style>
      ${Pt()}
      .banner {
        pointer-events: auto;
        display: flex;
        align-items: center;
        gap: 12px;
        max-width: 560px;
        min-width: 360px;
        padding: 12px 14px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-left: 4px solid var(--c-warning);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        font-family: var(--ff-sans);
        font-size: var(--fs-body);
        line-height: 1.45;
      }
      .icon {
        flex-shrink: 0;
        color: var(--c-warning);
        font-size: 18px;
        line-height: 1;
      }
      .message {
        flex: 1;
        min-width: 0;
      }
      .dismiss {
        flex-shrink: 0;
        appearance: none;
        background: transparent;
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        border-radius: var(--r-sm);
        height: 28px;
        padding: 0 12px;
        font: inherit;
        font-size: var(--fs-small);
        font-weight: 500;
        cursor: pointer;
      }
      .dismiss:hover {
        background: var(--c-surface-2);
        color: var(--c-text);
      }
    </style>
    <div class="banner" role="status" aria-live="polite">
      <span class="icon" aria-hidden="true">⚠</span>
      <div class="message" data-region="message"></div>
      <button class="dismiss" type="button" data-action="dismiss">Got it</button>
    </div>
  `}const We=16,Gp=240,Vp=/permission|<all_urls>|activeTab/i;async function Kp(t){const e=Zp({x:t.x-We,y:t.y-We,width:t.width+We*2,height:t.height+We*2});if(e.width<=0||e.height<=0)return null;const n=await Qp();if(!n.ok)return Vp.test(n.error)?Up(b("permission.thumbnail-needs-host")):console.warn("[manuscript] capture failed",n.error),null;try{return await ef(n.dataUrl,e,Gp)}catch(r){return console.error("[manuscript] crop failed",r),null}}function Zp(t){const e=Math.max(0,t.x),n=Math.max(0,t.y),r=Math.min(window.innerWidth,t.x+t.width),o=Math.min(window.innerHeight,t.y+t.height);return{x:e,y:n,width:Math.max(0,r-e),height:Math.max(0,o-n)}}async function Qp(){const t=Array.from(document.querySelectorAll('[data-manuscript="ui"]')),e=new Map;t.forEach(n=>{e.set(n,n.style.visibility),n.style.visibility="hidden"}),await tf();try{return{ok:!0,dataUrl:await Jp()}}catch(n){return{ok:!1,error:n instanceof Error?n.message:String(n)}}finally{t.forEach(n=>{const r=e.get(n);n.style.visibility=r??""})}}function Jp(){return new Promise((t,e)=>{chrome.runtime.sendMessage({type:"capture.visibleTab"},n=>{if(chrome.runtime.lastError){e(new Error(chrome.runtime.lastError.message));return}if(!n||typeof n.dataUrl!="string"){e(new Error((n==null?void 0:n.error)??"No dataUrl returned"));return}t(n.dataUrl)})})}function tf(){return new Promise(t=>{requestAnimationFrame(()=>t())})}async function ef(t,e,n){const r=await nf(t),o=r.naturalWidth/window.innerWidth||1,i=e.x*o,s=e.y*o,a=e.width*o,c=e.height*o,l=Math.min(1,n/e.width),u=Math.max(1,Math.round(e.width*l)),f=Math.max(1,Math.round(e.height*l)),d=document.createElement("canvas");d.width=u,d.height=f;const p=d.getContext("2d");if(!p)throw new Error("No 2d context");return p.drawImage(r,i,s,a,c,0,0,u,f),d.toDataURL("image/png")}function nf(t){return new Promise((e,n)=>{const r=new Image;r.onload=()=>e(r),r.onerror=()=>n(new Error("Image load failed")),r.src=t})}function Fa(t){const e=t.detail;Ps(e.chain);const n=rf(e.rect,e.chain.framePath);of(n)}function rf(t,e){if(!e||e.length===0)return t;const n=rc(e);if(!n)return t;const r=n.getBoundingClientRect();return{x:t.x+r.left,y:t.y+r.top,width:t.width,height:t.height}}async function of(t){try{const e=await Kp(t);Ts(e)}catch(e){console.warn("[manuscript] thumbnail capture skipped",e)}}function af(){return`
      /* ---- Footer ---- */
      .footer {
        padding: 12px 14px;
        border-top: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        align-items: center;
        justify-content: space-between;
        flex-shrink: 0;
        position: relative;
      }

      /* Settings popup — opens above the gear button on the right. */
      .settings-popup {
        position: absolute;
        bottom: calc(100% + 6px);
        right: 14px;
        margin: 0;
        padding: 28px 12px 12px;
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-md);
        box-shadow: var(--shadow-lg);
        min-width: 240px;
        z-index: 4;
        font-family: var(--ff-sans);
      }
      .settings-popup[hidden] { display: none; }
      .settings-close {
        position: absolute;
        top: 4px;
        right: 4px;
        width: 22px;
        height: 22px;
        padding: 0;
        background: transparent;
        border: none;
        border-radius: var(--r-xs);
        color: var(--c-text-mute);
        cursor: pointer;
        font-size: 16px;
        line-height: 1;
        display: grid;
        place-items: center;
      }
      .settings-close:hover { background: var(--c-surface-2); color: var(--c-text); }
      .settings-row {
        display: flex;
        flex-direction: column;
        gap: 6px;
      }
      .settings-label {
        font-size: var(--fs-cap);
        font-weight: 600;
        letter-spacing: var(--ls-cap);
        text-transform: uppercase;
        color: var(--c-text-soft);
      }
      .settings-voice {
        height: 28px;
        padding: 0 26px 0 10px;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text);
        font-family: inherit;
        font-size: 12px;
        cursor: pointer;
        max-width: 100%;
        appearance: none;
        -webkit-appearance: none;
        background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='10' height='10' viewBox='0 0 16 16' fill='none' stroke='%23808080' stroke-width='1.6' stroke-linecap='round' stroke-linejoin='round'><path d='M4 6 L8 10 L12 6'/></svg>");
        background-repeat: no-repeat;
        background-position: right 8px center;
      }

      /* ---- Resize handle (bottom) ---- */
      .resize-handle {
        flex-shrink: 0;
        height: 9px;
        background: var(--c-surface-2);
        border-top: 1px solid var(--c-border);
        cursor: ns-resize;
        display: flex;
        align-items: center;
        justify-content: center;
        user-select: none;
        border-bottom-left-radius: var(--r-lg);
        border-bottom-right-radius: var(--r-lg);
        transition: background 160ms ease;
      }
      .resize-handle::after {
        content: '';
        width: 28px;
        height: 2px;
        background: var(--c-border-strong);
        border-radius: 999px;
        transition: background 160ms ease;
      }
      .resize-handle:hover { background: var(--c-tint); }
      .resize-handle:hover::after { background: var(--c-text-mute); }
      .play-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .footer-actions {
        display: flex;
        align-items: center;
        gap: 8px;
      }
      .prompter-btn {
        width: 36px;
        height: 36px;
        padding: 0;
        border-radius: 999px;
        border: none;
        background: var(--c-primary);
        color: var(--c-primary-fg);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: background 160ms ease;
      }
      .prompter-btn:hover { background: var(--c-primary-h); }
      .play-btn:hover { background: var(--c-primary-h); }
      .play-icon {
        width: 0;
        height: 0;
        border-left: 10px solid currentColor;
        border-top: 6px solid transparent;
        border-bottom: 6px solid transparent;
        margin-left: 3px;
      }
      .footer-icons {
        display: flex;
        gap: 8px;
      }
      .icon-btn {
        width: 32px;
        height: 32px;
        padding: 0;
        border-radius: var(--r-sm);
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        color: var(--c-text-mute);
        display: grid;
        place-items: center;
        cursor: pointer;
        transition: color 160ms ease, border-color 160ms ease;
      }
      .icon-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }

      /* Toast */
      .toast {
        position: absolute;
        bottom: 64px;
        left: 50%;
        transform: translateX(-50%) translateY(8px);
        background: var(--c-text);
        color: var(--c-surface);
        padding: 8px 14px;
        border-radius: var(--r-pill);
        font-size: 12px;
        opacity: 0;
        pointer-events: none;
        transition: opacity 160ms ease, transform 160ms ease;
        white-space: nowrap;
      }
      .toast.visible {
        opacity: 0.92;
        transform: translateX(-50%) translateY(0);
      }
      .toast.error { background: var(--c-error); }
  `}function sf(){return`
      ${Pt()}

      :host {
        display: block;
        font-family: var(--ff-sans);
        color: var(--c-text);
      }
      *, *::before, *::after { box-sizing: border-box; }

      .panel {
        display: flex;
        flex-direction: column;
        height: 100%;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        border-radius: var(--r-lg);
        box-shadow: var(--shadow-lg);
        overflow: hidden;
        font-size: var(--fs-body);
        line-height: var(--lh-body);
      }

      /* ---- Header ---- */
      .header {
        padding: 8px 16px 12px;
        border-bottom: 1px solid var(--c-border);
        display: flex;
        flex-direction: column;
        gap: 12px;
        flex-shrink: 0;
        cursor: move;
        user-select: none;
      }
      .header-row {
        display: flex;
        align-items: center;
        justify-content: space-between;
      }
      .brand {
        display: flex;
        align-items: center;
        gap: 8px;
        color: var(--c-text);
      }
      .brand-wordmark {
        font-family: var(--ff-serif);
        font-size: 23px;
        font-weight: 500;
        letter-spacing: -0.005em;
        line-height: 1;
      }
      .close-btn {
        background: transparent;
        border: none;
        color: var(--c-text-mute);
        font-size: 16px;
        line-height: 1;
        cursor: pointer;
        padding: 2px 4px;
      }
      .close-btn:hover { color: var(--c-text); }
      .close-btn:focus-visible {
        outline: 2px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }

      .title {
        font-size: 15px;
        font-weight: 600;
        letter-spacing: -0.005em;
        color: var(--c-text);
        cursor: text;
        outline: none;
        line-height: 1.3;
        min-height: 20px;
        word-break: break-word;
      }
      .title:focus {
        background: var(--c-tint);
        outline: 1px solid var(--c-focus);
        outline-offset: 2px;
        border-radius: 4px;
      }
      .title[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
        font-weight: 500;
      }

      /* ---- Common Toolbar ---- */
      .tool-bar {
        padding: 10px 12px;
        border-bottom: 1px solid var(--c-border);
        background: var(--c-surface-2);
        display: flex;
        flex-direction: column;
        align-items: flex-start;
        gap: 6px;
      }
      .eyebrow {
        font-size: 10px;
        font-weight: 600;
        letter-spacing: 0.10em;
        text-transform: uppercase;
        color: var(--c-text-soft);
        line-height: 1;
      }
      .tool-buttons {
        display: flex;
        gap: 4px;
      }
      .tool-btn {
        width: 26px;
        height: 26px;
        padding: 0;
        border-radius: var(--r-sm);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        font-family: var(--ff-sans);
        font-size: 12px;
        font-weight: 600;
        line-height: 1;
        transition: background 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .tool-btn:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .tool-btn[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
  `}function cf(){return`
      /* ---- Step list ---- */
      .body {
        flex: 1;
        min-height: 0;
        padding: 12px;
        background: var(--c-surface-2);
        overflow-y: auto;
        display: flex;
        flex-direction: column;
      }
      .body::-webkit-scrollbar { width: 8px; }
      .body::-webkit-scrollbar-thumb {
        background: var(--c-border-strong);
        border-radius: 999px;
      }

      .step-card {
        position: relative;
        display: flex;
        align-items: flex-start;
        gap: 10px;
        padding: 10px;
        border-radius: var(--r-md);
        border: 1px solid var(--c-border);
        background: transparent;
        opacity: 0.78;
        z-index: 1;
        cursor: grab;
        transition: background 160ms ease, box-shadow 200ms ease, opacity 160ms ease,
                    border-color 160ms ease;
      }
      .step-card:hover { border-color: var(--c-border-strong); }
      .step-card.active {
        background: var(--c-surface);
        border-color: transparent;
        box-shadow: var(--shadow-card);
        opacity: 1;
        z-index: 2;
      }
      .step-card.dragging { opacity: 0.4; cursor: grabbing; }
      .step-card.drop-target { border-color: var(--c-primary); border-style: dashed; }

      /* picker thumbnail */
      .step-thumb {
        position: relative;
        width: 44px;
        height: 44px;
        flex-shrink: 0;
        border-radius: var(--r-sm);
        border: 1.5px solid var(--c-border-strong);
        background: var(--c-surface);
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        display: grid;
        place-items: center;
        cursor: pointer;
        color: var(--c-text-mute);
        padding: 0;
      }
      .step-card.active .step-thumb { border-color: var(--c-primary); }
      .step-thumb.has-element { border-color: var(--c-primary); }
      .step-thumb.is-picking {
        border-color: var(--c-primary);
        box-shadow: 0 0 0 3px var(--c-tint);
        animation: thumb-pulse 1.4s ease-in-out infinite;
      }
      @keyframes thumb-pulse {
        0%, 100% { box-shadow: 0 0 0 3px var(--c-tint); }
        50%      { box-shadow: 0 0 0 6px var(--c-tint); }
      }
      .step-thumb-num {
        position: absolute;
        top: -1px;
        left: 3px;
        font-family: var(--ff-mono);
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text-mute);
        line-height: 1;
        background: var(--c-surface);
        padding: 1px 3px;
        border-radius: 2px;
      }
      .step-card.active .step-thumb-num { color: var(--c-primary); }
      .step-thumb-plus { font-size: 16px; line-height: 1; color: var(--c-text-mute); }
      .step-thumb-icon { color: var(--c-text); }

      /* meta column */
      .step-meta {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        gap: 4px;
      }
      .step-name {
        font-size: 13px;
        font-weight: 500;
        line-height: 20px;
        padding-right: 84px;
        color: var(--c-text);
        outline: none;
        word-break: break-word;
      }
      .step-name[data-empty="true"]::before {
        content: attr(data-placeholder);
        color: var(--c-text-soft);
      }
      .step-name:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }
      .step-desc {
        font-size: 12px;
        line-height: 1.4;
        color: var(--c-text-mute);
        outline: none;
        white-space: pre-wrap;
        word-break: break-word;
        max-height: 1.4em;
        overflow: hidden;
        transition: max-height 220ms cubic-bezier(0.2, 0.8, 0.2, 1);
      }
      .step-desc:hover,
      .step-desc:focus {
        max-height: 60em;
      }
      .step-desc[data-empty="true"] {
        color: var(--c-text-soft);
        opacity: 0.7;
      }
      .step-desc[data-empty="true"]::before {
        content: attr(data-placeholder);
      }
      .step-desc:focus {
        background: var(--c-tint);
        border-radius: 3px;
      }

      /* step-url — link button at the thumb's bottom-right; URL revealed
         as a rollover tooltip on hover. */
      .step-url {
        position: absolute;
        /* 썸네일(44×44) right-bottom 모서리. card padding 10 + thumb 44 = 54 */
        top: 44px;
        left: 44px;
        z-index: 2;
      }
      .step-url-link {
        width: 16px;
        height: 16px;
        padding: 0;
        border: 1px solid var(--c-border);
        background: var(--c-surface);
        color: var(--c-text-soft);
        cursor: pointer;
        display: grid;
        place-items: center;
        border-radius: 4px;
        transition: color 0.12s ease, border-color 0.12s ease;
      }
      .step-url-link:hover {
        color: var(--c-primary);
        border-color: var(--c-primary);
      }
      .step-url-link svg { display: block; }
      .step-url-tooltip {
        position: absolute;
        top: 50%;
        left: calc(100% + 6px);
        transform: translateY(-50%);
        background: var(--c-surface);
        color: var(--c-text);
        border: 1px solid var(--c-border);
        border-radius: var(--r-sm);
        padding: 4px 8px;
        font-size: 11px;
        line-height: 1.3;
        white-space: nowrap;
        max-width: 240px;
        overflow: hidden;
        text-overflow: ellipsis;
        box-shadow: var(--shadow-md);
        opacity: 0;
        pointer-events: none;
        transition: opacity 0.12s ease;
        z-index: 10;
      }
      .step-url:hover .step-url-tooltip { opacity: 1; }

  `}function lf(){return`
      /* controls cluster — top-right */
      .step-controls {
        position: absolute;
        top: 10px;
        right: 10px;
        height: 20px;
        display: flex;
        align-items: center;
        gap: 3px;
      }
      .step-ctrl {
        width: 20px;
        height: 20px;
        padding: 0;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        color: var(--c-text-mute);
        display: inline-grid;
        place-items: center;
        cursor: pointer;
        line-height: 1;
        transition: opacity 160ms ease, color 160ms ease, border-color 160ms ease;
      }
      .step-ctrl[aria-pressed="true"] {
        background: var(--c-primary);
        color: var(--c-primary-fg);
        border-color: var(--c-primary);
      }
      .step-ctrl:hover { color: var(--c-text); border-color: var(--c-border-strong); }
      .step-ctrl[data-action="step-delete"] {
        border-color: transparent;
        opacity: 0.7;
      }
      .step-ctrl[data-action="step-delete"]:hover { opacity: 1; color: var(--c-error); }

      /* TimerChip */
      .step-timer {
        height: 20px;
        min-width: 20px;
        padding: 0 5px;
        border-radius: var(--r-xs);
        border: 1px solid var(--c-border);
        background: transparent;
        display: inline-flex;
        align-items: center;
        justify-content: center;
        gap: 3px;
        color: var(--c-text-mute);
        cursor: pointer;
        font-family: var(--ff-mono);
      }
      .step-timer.editing {
        background: var(--c-surface-2);
        border-color: var(--c-primary);
      }
      /* Action step(pause)일 때는 timer가 영향 없으므로 비활성 표시 */
      .step-timer.disabled {
        opacity: 0.35;
        cursor: not-allowed;
      }
      .step-timer.disabled:hover { border-color: var(--c-border); }
      .step-timer-num {
        font-size: 10px;
        font-weight: 500;
        color: var(--c-text);
        font-variant-numeric: tabular-nums;
        min-width: 8px;
        text-align: right;
      }
      .step-timer input {
        width: 22px;
        padding: 0;
        margin: 0;
        background: transparent;
        border: none;
        outline: none;
        font-family: inherit;
        font-size: 10px;
        font-weight: 600;
        color: var(--c-text);
        text-align: right;
        font-variant-numeric: tabular-nums;
        appearance: textfield;
      }
      .step-timer input::-webkit-outer-spin-button,
      .step-timer input::-webkit-inner-spin-button {
        -webkit-appearance: none;
        margin: 0;
      }

      /* InsertGap */
      .insert-gap {
        position: relative;
        height: 14px;
        display: flex;
        align-items: center;
        justify-content: center;
        cursor: pointer;
      }
      .insert-gap::before {
        content: '';
        position: absolute;
        inset: 6px 8px;
        border-top: 1px dashed var(--c-border);
      }
      .insert-add {
        position: relative;
        width: 14px;
        height: 14px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border);
        display: grid;
        place-items: center;
        color: var(--c-text-soft);
        z-index: 3;
        cursor: pointer;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    background 160ms ease,
                    border-color 160ms ease,
                    color 160ms ease;
        transform-origin: center;
      }
      .insert-gap:hover .insert-add {
        transform: scale(1.7);
        border-color: var(--c-text-mute);
        color: var(--c-text-mute);
      }

      /* AddStepButton (end) */
      .add-end-wrap {
        display: flex;
        justify-content: center;
        padding: 10px 0 4px;
      }
      .add-end {
        width: 22px;
        height: 22px;
        padding: 0;
        border-radius: 999px;
        background: var(--c-surface);
        border: 1px solid var(--c-border-strong);
        display: grid;
        place-items: center;
        color: var(--c-text-mute);
        cursor: pointer;
        z-index: 3;
        transition: transform 200ms cubic-bezier(0.2, 0.8, 0.2, 1),
                    border-color 160ms ease, color 160ms ease;
        transform-origin: center;
      }
      .add-end:hover {
        transform: scale(1.25);
        border-color: var(--c-text-mute);
        color: var(--c-text);
      }

  `}function uf(){return[sf(),cf(),lf(),af()].join(`
`)}function df(){return`
    <style>${uf()}</style>
    <div class="panel" role="region" aria-label="${b("panel.aria.region")}">
      ${pf()}
      ${ff()}
      <div class="body" data-region="steps"></div>
      ${hf()}
      <div class="resize-handle" data-region="resize" role="separator" aria-label="${b("panel.close-aria")}" aria-orientation="horizontal"></div>
      <div class="toast" data-region="toast"></div>
    </div>
  `}function pf(){return`
    <div class="header">
      <div class="header-row">
        <div class="brand">${Ga({height:16})}<span class="brand-wordmark">Manuscript</span></div>
        <button type="button" class="close-btn" data-action="close" aria-label="${b("panel.close-aria")}">×</button>
      </div>
      <div
        class="title"
        data-region="title-edit"
        contenteditable="true"
        spellcheck="false"
        data-placeholder="${b("panel.title-placeholder")}"
        data-empty="true"
      ></div>
    </div>
  `}function ff(){return`
    <div class="tool-bar" role="toolbar" aria-label="${b("panel.tool-label")}">
      <span class="eyebrow">${b("panel.tool-label")}</span>
      <div class="tool-buttons">
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="text" title="${b("panel.tool.text")}" aria-pressed="false">T</button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="shape" title="${b("panel.tool.shape")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
            <rect x="2.2" y="2.2" width="7.6" height="7.6" rx="0.6"></rect>
            <circle cx="10.8" cy="10.8" r="3.2" fill="var(--c-surface)"></circle>
          </svg>
        </button>
        <button type="button" class="tool-btn" data-action="tool-set" data-tool="freedraw" title="${b("panel.tool.freedraw")}" aria-pressed="false">
          <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round">
            <path d="M 13.6 1.8 L 14.6 2.8 L 9 8.4 L 7.4 8.8 L 7.8 7.2 Z"></path>
            <path d="M 12.4 3 L 13.4 4"></path>
            <path d="M 8 9 C 6 9.5 7 12 5 12.5 S 2.5 13.5 1.5 13"></path>
          </svg>
        </button>
      </div>
    </div>
  `}function hf(){return`
    <div class="footer">
      <div class="footer-actions">
        <button type="button" class="play-btn" data-action="replay" aria-label="${b("panel.replay-aria")}" title="${b("panel.replay-title")}">
          <span class="play-icon"></span>
        </button>
        <button type="button" class="prompter-btn" data-action="prompter" aria-label="${b("panel.prompter-aria")}" title="${b("panel.prompter-aria")}">
          <svg width="16" height="16" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round" style="display:block"><rect x="2.5" y="3" width="11" height="9" rx="1"/><path d="M 4.5 5.8 L 11.5 5.8 M 4.5 8 L 11.5 8 M 4.5 10.2 L 9 10.2"/></svg>
        </button>
      </div>
      <div class="footer-icons">
        <button type="button" class="icon-btn" data-action="import" aria-label="${b("panel.import-aria")}" title="${b("panel.import-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M3 7a2 2 0 0 1 2-2h4l2 2h8a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="export" aria-label="${b("panel.export-aria")}" title="${b("panel.export-aria")}">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round">
            <path d="M14 4H6a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8"></path>
            <path d="M10 12h11"></path>
            <path d="M17 8l4 4-4 4"></path>
          </svg>
        </button>
        <button type="button" class="icon-btn" data-action="settings-toggle" aria-label="${b("panel.settings-aria")}" title="${b("panel.settings.title")}" data-region="settings-toggle">
          ${_p(16)}
        </button>
      </div>
      ${mf()}
    </div>
  `}function mf(){return`
    <div class="settings-popup" data-region="settings-popup" role="dialog" aria-label="${b("panel.settings.title")}" hidden>
      <button type="button" class="settings-close" data-region="settings-close" aria-label="${b("panel.settings.close-aria")}" title="${b("common.close")}">×</button>
      <div class="settings-row">
        <label class="settings-label" for="voice-select">${b("panel.settings.voice-label")}</label>
        <select class="settings-voice" id="voice-select" data-region="voice-select">
          <option value="">${b("panel.settings.voice-auto")}</option>
        </select>
      </div>
    </div>
  `}function gf(t){const e=t.pickedAtUrl;return e?`
    <div class="step-url" data-region="step-url">
      <button
        type="button"
        class="step-url-link"
        data-action="step-link"
        data-url="${nt(e)}"
        aria-label="Open ${nt(e)}"
      >${Fp(10)}</button>
      <span class="step-url-tooltip" role="tooltip">${gn(e)}</span>
    </div>
  `:""}function bf(t,e,n){const r=document.createElement("div");r.className="step-card"+(n?" active":""),r.setAttribute("data-step-card",String(e)),r.setAttribute("draggable","true"),r.setAttribute("role","listitem");const o=t.selectors!==null,i=t.thumbnailDataUrl!==null,s=n&&bt()==="picker",a="step-thumb"+(o?" has-element":"")+(s?" is-picking":""),c=i?` style="background-image: url('${t.thumbnailDataUrl??""}')"`:"",l=t.autoAdvanceMs!==null&&t.autoAdvanceMs>0?Math.round(t.autoAdvanceMs/1e3):5,u=t.waitForNavigation;return r.innerHTML=`
    <button
      type="button"
      class="${a}"
      data-action="step-wand"
      data-step-index="${e}"
      aria-label="${nt(b("step.wand-aria",{n:e+1}))}"
      title="${nt(b("step.wand-title"))}"${c}
    >
      <span class="step-thumb-num">${e+1}</span>
      ${o&&!i?`<span class="step-thumb-icon">${Np(18)}</span>`:""}
      ${!o&&!i?'<span class="step-thumb-plus">+</span>':""}
    </button>
    <div class="step-meta">
      <div class="step-name" data-region="step-name" contenteditable="true" spellcheck="false" draggable="false" data-placeholder="${nt(b("step.name-placeholder"))}" data-empty="${t.name.length===0?"true":"false"}">${gn(t.name)}</div>
      <div class="step-desc" data-region="step-desc" contenteditable="plaintext-only" spellcheck="false" draggable="false" data-placeholder="${nt(b("step.desc-placeholder"))}" data-empty="${t.description.length===0?"true":"false"}">${gn(t.description)}</div>
    </div>
    ${gf(t)}
    <div class="step-controls">
      <button type="button" class="step-ctrl" data-action="step-action-toggle" data-step-index="${e}" aria-pressed="${u}" aria-label="${nt(b("step.action-aria"))}" title="${nt(b("step.action-aria"))}">${Rp(10)}</button>
      <div class="step-timer${u?" disabled":""}" data-action="step-timer" data-step-id="${nt(t.id)}" title="${nt(b("step.timer-aria"))}" ${u?'aria-disabled="true"':""}>
        <span class="step-timer-num">${l}</span>
        ${Or(10)}
      </div>
      <button type="button" class="step-ctrl" data-action="step-delete" data-step-index="${e}" aria-label="${nt(b("step.delete-aria"))}" title="${nt(b("step.delete-aria"))}">${Op(12)}</button>
    </div>
  `,r}function vf(t){const e=(t.textContent??"").trim().length===0;t.setAttribute("data-empty",e?"true":"false")}function yf(t,e,n){Io(t,"step-name",n,r=>te(e.id,{name:r})),Io(t,"step-desc",n,r=>te(e.id,{description:r}),{escapeBlurs:!0}),xf(t,n)}function Io(t,e,n,r,o={}){const i=t.querySelector(`[data-region="${e}"]`);i&&(i.addEventListener("input",()=>vf(i)),i.addEventListener("focus",()=>{Nn(n)||Ut(n)}),i.addEventListener("mousedown",s=>s.stopPropagation()),i.addEventListener("blur",()=>r(i.textContent??"")),i.addEventListener("keydown",s=>{(s.key==="Enter"&&e==="step-name"||s.key==="Escape"&&o.escapeBlurs)&&(s.preventDefault(),i.blur())}))}function xf(t,e){t.addEventListener("dragstart",n=>{const r=n.target;if(r instanceof HTMLElement&&r.closest('[data-region="step-name"], [data-region="step-desc"], .step-timer.editing')){n.preventDefault();return}S.dragFromIndex=e,t.classList.add("dragging"),n.dataTransfer&&(n.dataTransfer.setData("text/plain",String(e)),n.dataTransfer.effectAllowed="move")}),t.addEventListener("dragend",()=>{var n;t.classList.remove("dragging"),S.dragFromIndex=null,(n=S.shadow)==null||n.querySelectorAll(".step-card.drop-target").forEach(r=>r.classList.remove("drop-target"))}),t.addEventListener("dragover",n=>{S.dragFromIndex===null||S.dragFromIndex===e||(n.preventDefault(),n.dataTransfer&&(n.dataTransfer.dropEffect="move"),t.classList.add("drop-target"))}),t.addEventListener("dragleave",()=>{t.classList.remove("drop-target")}),t.addEventListener("drop",n=>{n.preventDefault(),t.classList.remove("drop-target"),!(S.dragFromIndex===null||S.dragFromIndex===e)&&(Is(S.dragFromIndex,e),S.dragFromIndex=null)})}function wf(){const{shadow:t}=S;if(!t)return;const e=t.querySelector('[data-region="steps"]');if(!e)return;const n=P();if(e.innerHTML="",!n)return;const r=W();n.steps.forEach((i,s)=>{if(s>0){const c=document.createElement("div");c.className="insert-gap",c.setAttribute("data-action","step-insert"),c.setAttribute("data-insert-index",String(s)),c.setAttribute("role","button"),c.setAttribute("aria-label",`Insert step at position ${s+1}`),c.innerHTML=`
        <button type="button" class="insert-add" data-action="step-insert" data-insert-index="${s}" aria-label="Insert step here">
          ${To(8,1.6)}
        </button>
      `,e.appendChild(c)}const a=bf(i,s,r===s);e.appendChild(a),yf(a,i,s)});const o=document.createElement("div");o.className="add-end-wrap",o.innerHTML=`
    <button type="button" class="add-end" data-action="step-add" aria-label="Add step" title="Add step">
      ${To(10,1.8)}
    </button>
  `,e.appendChild(o)}function _a(t){const{host:e}=S;e&&(e.dataset.promptedHidden=t?"1":"",bt()!=="replay"&&(e.style.display=t?"none":""))}async function xn(t){if(S.host){t&&await qr(t);return}const e=document.createElement("div");e.setAttribute("data-manuscript","ui"),e.setAttribute("data-palette",ue);const n=Tp(window.innerHeight*xp);e.style.cssText=["position: fixed",`top: ${ie}px`,`right: ${ie}px`,`width: ${yp}px`,`height: ${n}px`,`max-height: calc(100vh - ${ie*2}px)`,`z-index: ${H+2}`,"display: none"].join("; ");const r=e.attachShadow({mode:"open"});r.innerHTML=df(),S.host=e,S.shadow=r,zp(Ha,_a),document.body.appendChild(e),t&&await qr(t)||Br(),ua(),document.addEventListener(Le,Fa),window.addEventListener("resize",Ca),S.unsubscribeMode=dt(Kn),S.unsubscribeScenario=de(Kn),Kn();const o=P();if(o)try{await chrome.runtime.sendMessage({type:"panel.markActive",scenarioId:o.id})}catch(i){console.warn("[manuscript] markActive failed",i)}}function Ha(){var e,n;const{host:t}=S;t&&(document.removeEventListener(Le,Fa),window.removeEventListener("resize",Ca),(e=S.unsubscribeMode)==null||e.call(S),S.unsubscribeMode=null,(n=S.unsubscribeScenario)==null||n.call(S),S.unsubscribeScenario=null,D("idle"),le(),bi(),da(),Uo(),chrome.runtime.sendMessage({type:"panel.markInactive"}).catch(()=>{}),t.remove(),S.host=null,S.shadow=null)}function Kn(){const{host:t,shadow:e}=S;if(!e||!t)return;const n=bt(),r=t.dataset.promptedHidden==="1";t.style.display=n==="replay"||r?"none":"",e.querySelectorAll('[data-action="tool-set"]').forEach(s=>{const a=s.getAttribute("data-tool");s.setAttribute("aria-pressed",String(a===n))});const o=P(),i=e.querySelector('[data-region="title-edit"]');i&&o&&i!==e.activeElement&&(i.textContent!==o.name&&(i.textContent=o.name),ur(i)),wf(),Da(),Cn()&&!vt()&&ve()}function kf(t,e,n){switch(t.type){case"panel.open":return xn(t.scenarioId).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"panel.close":return Ha(),n({ok:!0}),!1;case"scenario.replay":return xn(t.scenarioId).then(()=>Pe(0)).then(()=>n({ok:!0})).catch(r=>n({ok:!1,error:String(r)})),!0;case"prompter.cmd":return Sf(t.cmd,t.index),n({ok:!0}),!1;case"prompter.closed-by-user":return td(),vt()&&Se(),lp(),_a(!1),n({ok:!0}),!1}return!1}function Sf(t,e){if(vt()){t==="prev"?fn():t==="next"?ke():t==="jump"&&typeof e=="number"?Pr(e):t==="pause"&&hn();return}const n=P();if(!n)return;const r=W();if(t==="prev")r>0&&zt(r-1),ve();else if(t==="next")r<n.steps.length-1&&zt(r+1),ve();else if(t==="jump"&&typeof e=="number"){if(e>=0&&e<n.steps.length){if(Nn(e))return;zt(e)}ve()}else t==="pause"&&Pe(r)}async function Af(){try{const t=await chrome.runtime.sendMessage({type:"panel.consumeResumeState"}),e=t==null?void 0:t.state;return!e||typeof e.scenarioId!="string"||e.scenarioId.length===0?null:typeof e.stepIndex=="number"?{scenarioId:e.scenarioId,stepIndex:e.stepIndex}:{scenarioId:e.scenarioId}}catch{return null}}async function Ef(){try{const t=await No();if(!t)return;if(Mf()){await chrome.storage.local.remove(Q.activeReplay);return}D("replay"),await xn(t.scenarioId),await Pe(t.stepIndex,{paused:t.paused===!0})}catch(t){console.warn("[manuscript] resume replay failed",t)}}function Mf(){var t;try{return((t=performance.getEntriesByType("navigation")[0])==null?void 0:t.type)==="reload"}catch{return!1}}async function $f(){try{const t=await Af();if(!t)return;await xn(t.scenarioId),typeof t.stepIndex=="number"&&t.stepIndex>=0&&Ut(t.stepIndex)}catch(t){console.warn("[manuscript] resume authoring panel failed",t)}}const Lf="manuscript:host",Tf="manuscript:ext",Cf="manuscript:ready";let Po=!1;function If(){Po||(window.addEventListener("message",Df),Po=!0,dt(({prev:t,next:e})=>{t==="replay"&&e==="idle"&&Rt("exited",void 0,{ok:!0})}),window.dispatchEvent(new Event(Cf)))}function Pf(t){return typeof t=="object"&&t!==null&&t.source===Lf&&typeof t.type=="string"}function Rt(t,e,n){const r={source:Tf,type:t,...n};e!==void 0&&(r.requestId=e),window.postMessage(r,"*")}function Df(t){const e=t.data;if(Pf(e))switch(e.type){case"ping":Rt("pong",e.requestId,{version:Rf()});return;case"load":try{const n=Of(e.scenario);Wo(n),Rt("load-ack",e.requestId,{ok:!0})}catch(n){Rt("load-ack",e.requestId,{ok:!1,error:n instanceof Error?n.message:String(n)})}return;case"play":{const n=e.standalone!==!1,r=typeof e.startIndex=="number"?e.startIndex:0,o=e.paused===!0;n&&!Ld()&&ua(),Rt("play-ack",e.requestId,{ok:!0}),Pe(r,{paused:o,standalone:n}).catch(i=>{console.warn("[manuscript] startReplay failed",i)});return}case"pause":vt()&&hn(),Rt("pause-ack",e.requestId,{ok:vt()});return;case"next":vt()&&ke();return;case"prev":vt()&&fn();return;case"jump":vt()&&typeof e.index=="number"&&Pr(e.index);return;case"exit":(async()=>(vt()&&await Se(),Rt("exit-ack",e.requestId,{ok:!0})))();return}}function Of(t){if(t==null)throw new Fr("scenario is required");if(typeof t=="string"){let e;try{e=JSON.parse(t)}catch(n){throw new Fr("Invalid JSON",n)}return _r(e,{strict:!0})}return _r(t,{strict:!0})}function Rf(){var t,e;try{return((e=(t=chrome==null?void 0:chrome.runtime)==null?void 0:t.getManifest)==null?void 0:e.call(t).version)??"0.0.0"}catch{return"0.0.0"}}const Nf=window===window.top;qu();os();Va();su();Ru();Kl();Tu();nu();yl();Ku();Qu();var Do,Oo;Nf&&(Ju().then(()=>{Ef(),$f()}),chrome.runtime.onMessage.addListener(kf),(Oo=(Do=chrome.permissions)==null?void 0:Do.onAdded)==null||Oo.addListener(()=>Ra()),If());export{ue as D,$c as M,Lc as V,Pt as d,ot as g,de as o,Bf as u};
